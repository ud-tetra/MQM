from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json,itertools,sys
import numpy as np
sys.set_int_max_str_digits(30000)
P=Path(__file__).resolve().parent
M=192;x=64
R=F(x**M,factorial(M))/(1-F(x,M+1))
# ||coupling-vector difference||<=4G R, ||V difference||<=2sqrt2 times it.
# D<=8sqrt2 G T R <1344 R, using sqrt2<3/2,G<7,T16.
D=1344*R
vac=4*F(16384,31457265)*D
assert vac<F(1,2**28)
def bits(y):
 b=0
 while y<F(1,2**(b+1)):b+=1
 return b
# Product permutation labels are a new dilation, not the15-coordinate UD carrier.
perms=list(itertools.permutations(range(4)));lookup={p:i for i,p in enumerate(perms)}
J=np.full((24,24),F(1,24),dtype=object)
assert np.array_equal(J@J,J);assert sum(J[i,i] for i in range(24))==1
checks=0
for g in perms:
 mat=np.zeros((24,24),dtype=object)
 for j,h in enumerate(perms):mat[lookup[tuple(g[h[k]] for k in range(4))],j]=1
 assert np.array_equal(mat@J,J@mat);checks+=1
# Diagonal invariant admissibility is constant on each24-label left orbit.
diagonal_ranks=sorted(set(24*sum(mask) for mask in itertools.product([0,1],repeat=8)))
assert 7 not in diagonal_ranks
# Coherent invariant projector J tensor P_nonzero is a permitted rank7 counterexample to a universal no-go.
rank_coh=1*7;expectation=F(rank_coh,24*8);assert expectation==F(7,192)
# Translations act transitively on the bit register; zero exclusion is not invariant under a bit translation.
zero_exclusion=[int(t!=0) for t in range(8)]
translation_disagreements=[sum(zero_exclusion[t]!=zero_exclusion[t^a] for t in range(8)) for a in range(1,8)]
assert translation_disagreements==[2]*7
assert F(2**3-1,4*factorial(4)*2**3)==F(7,768)
res={'vacuum_transfer':{'status':'DERIVED conditional / EXACT fraction checks','M':M,'x':x,'endpoint_vector_debit_numerator':str(D.numerator),'endpoint_vector_debit_denominator':str(D.denominator),'endpoint_vector_dyadic_upper':'2^-'+str(bits(D)),'second_order_vacuum_debit_numerator':str(vac.numerator),'second_order_vacuum_debit_denominator':str(vac.denominator),'second_order_vacuum_dyadic_upper':'2^-'+str(bits(vac)),'acceptance_pass':True,'point_estimate_only_decimal':float(vac),'numerical_implementation_certificate':'OPEN'},'capacity':{'identity':'7/768=(8-1)/(4*24*8)','carrier_coordinates':15,'carrier_incidences':28,'declared_dilation_labels':192,'carrier_identification':False,'diagonal_left_S4_invariant_ranks':diagonal_ranks,'rank7_diagonal_selection':'NO-GO within specified diagonal left-regular ansatz only','coherent_rank7_projector':'J24 tensor (I8-|0><0|), J24 entries1/24','coherent_uniform_mixed_expectation':'7/192','coherent_projector_idempotence':'EXACT','coherent_S4_commutator_checks':checks,'translation_disagreement_counts':translation_disagreements,'reference_selection':'OPEN symmetry group and origin must be source-defined','extra_factor4_admissibility':'OPEN','latch_register_map':'OPEN','physical_promotion':0},'independent_review':'OPEN same-agent derivation'}
(P/'results/EXACT_AUDIT.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({'vacuum_debit':float(vac),'vacuum_dyadic_upper':res['vacuum_transfer']['second_order_vacuum_dyadic_upper'],'vector_debit':float(D),'diagonal_ranks':diagonal_ranks,'coherent_expectation':str(expectation)},indent=2))
