from pathlib import Path
from fractions import Fraction as F
from math import factorial
import json,sys
sys.set_int_max_str_digits(30000)
P=Path(__file__).resolve().parent
# Independent coefficient accounting: each ket has <=3 segments, each Chebyshev coefficient <=2 |J_n|.
# Poisson integral gives |J_n(real a)| <= (|a|/2)^n/n!.
# Two ket expansions:16 tail; dyad difference:32 tail; eight dyads and half trace, triangle T^2/2:64 T^2 V tail.
L=1536;x=512
raw=F(x**L,factorial(L))/(1-F(x,L+1));debit=64*F(16384,31457265)*raw
assert debit<F(1,2**128)
bits=0
while debit<F(1,2**(bits+1)):bits+=1
# Covariance comparison on the distinct stationary finite chain.
# Gauss-Legendre exact degree2M-1; complex Bessel Poisson bound includes exp(beta B ell).
# Bose terms ell<=8 use x<=128+25*8^2/1024=2073/16 at |s|<=16; later terms bounded directly.
M=192;K=8;xx=F(2073,16);r=F(1,2**21);G2=F(128,3)
ctail=xx**(2*M)/factorial(2*M)/(1-xx/F(2*M+1))
eta=4*G2*r/(1-r)*ctail+2*G2*r**(K+1)/(1-r)
response_cov=2*16**2*eta
assert response_cov<F(1,2**48)
cbits=0
while response_cov<F(1,2**(cbits+1)):cbits+=1
res={'status':'DERIVED conditional / EXACT arithmetic','Chebyshev_L':L,'Q2_dimension':3+4*L+L*(L+1)//2,'Chebyshev_transfer_numerator':str(debit.numerator),'Chebyshev_transfer_denominator':str(debit.denominator),'Chebyshev_dyadic_upper':'2^-'+str(bits),'Chebyshev_pass_2_minus_128':True,'previous_L':3072,'physical_resource_advantage':False,'covariance_Gauss_nodes':M,'Bose_terms':K,'covariance_response_numerator':str(response_cov.numerator),'covariance_response_denominator':str(response_cov.denominator),'covariance_response_dyadic_upper':'2^-'+str(cbits),'covariance_pass_2_minus_48':True,'critical_separation':'M192 covariance bound does not certify vacuum truncation at192. L1536 vacuum transfer does not certify numerical data at192.','independent_review':'OPEN same agent alternative derivation; not independent reviewer','thermal_target':'OPEN','physical_promotion':0}
(P/'results/TRANSFER_AUDIT.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:v for k,v in res.items() if 'numerator' not in k and 'denominator' not in k},indent=2))
