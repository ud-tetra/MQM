import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,time
import numpy as np
P=Path(__file__).resolve().parent
parent=P/'inputs';ns={'__file__':str(parent/'response_model.py')};exec((parent/'response_model.py').read_text(),ns)
M=192;H,H1,n=ns['models'](M)
assert np.max(np.diff(H.indptr))<=196
# Real CSR products applied separately to real and imaginary parts;
# each row <=196 entries, all stored generator entries nonnegative off diagonal.
def prop(K,V,label):
 R=V.real.copy();I=V.imag.copy()
 for step in range(128):
  ar=R.copy();ai=I.copy();tr=R.copy();ti=I.copy()
  for k in range(1,49):
   nr=(K@ti)/ (8*k);ni=-(K@tr)/(8*k)
   ar+=nr;ai+=ni;tr,ti=nr,ni
  R,I=ar,ai
  if (step+1)%16==0:print(label,step+1,flush=True)
 return R+1j*I
seed=np.zeros((H.shape[0],M),complex);seed[3+np.arange(M),np.arange(M)]=1
start=time.monotonic();W=prop(H,seed,'hot');psi=np.zeros((M+4,1),complex);psi[0,0]=1;u=prop(H1,psi,'cold')[:,0]
np.savez_compressed(P/'results/EVOLVED_COLUMNS.npz',W=W,u=u)
# Derivative of partial trace is evaluated by polarization of the retained dyads.
def bilinear_retained_derivative(W,Z,n,M):
 out=np.zeros((8,8),complex);root=np.sqrt(n)
 V=W[:3]*root;D=Z[:3]*root;out[5:8,5:8]=D@V.conj().T+V@D.conj().T
 V=(W[3:3+4*M]*root).reshape(4,M,M);D=(Z[3:3+4*M]*root).reshape(4,M,M)
 out[:4,:4]=np.einsum('ajk,bjk->ab',D,V.conj())+np.einsum('ajk,bjk->ab',V,D.conj())
 out[4,4]=2*np.sum((Z[3+4*M:]*W[3+4*M:].conj()).real*n)
 return out
Z=-1j*(H@W);z=-1j*(H1@u)
hot=ns['retained'](W,n,M);hd=bilinear_retained_derivative(W,Z,n,M)
cold=np.zeros((8,8),complex);cd=np.zeros((8,8),complex)
cold[:4,:4]=np.outer(u[:4],u[:4].conj());cold[4,4]=np.vdot(u[4:],u[4:])
cd[:4,:4]=np.outer(z[:4],u[:4].conj())+np.outer(u[:4],z[:4].conj());cd[4,4]=2*np.vdot(u[4:],z[4:]).real
D=hot-n.sum()*cold;J=hd-n.sum()*cd
row={'status':'SIMULATED raw derivative; requires error audit','M':M,'Q2_dimension':H.shape[0],'Delta_real':D.real.tolist(),'Delta_imag':D.imag.tolist(),'derivative_real':J.real.tolist(),'derivative_imag':J.imag.tolist(),'half_trace_derivative_diagnostic':float(abs(np.linalg.eigvalsh(J)).sum()/2),'trace_derivative_residual':float(abs(np.trace(J))),'seconds':time.monotonic()-start}
(P/'results/RESPONSE_JET.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps({k:v for k,v in row.items() if k not in ['Delta_real','Delta_imag','derivative_real','derivative_imag']}),flush=True)
