from pathlib import Path
from fractions import Fraction as F
from math import factorial
import json,sys
sys.set_int_max_str_digits(30000)
P=Path(__file__).resolve().parent
p=json.loads((P/'inputs/PARAMETER_INTERVALS.json').read_text());j=json.loads((P/'results/RESPONSE_JET.json').read_text())
nu=F(p['occupation_trace_upper']);dn=F(p['occupation_l1_error_upper']);dh=F(p['Hamiltonian_Q2_error_upper'])+F(1,2**40)
s=32*F(1,2**43)*3**8+F(8**49,factorial(49))/(1-F(8,50))+F(1,2**800);e=16*dh+256*s
matrix=lambda re,im:sum((abs(F(float(x))) for key in [re,im] for row in j[key] for x in row),F(0))/2
Lraw=matrix('derivative_real','derivative_imag')
Lerr=2*nu*(64*(2*e+e*e)+dh*(1+e)**2)+128*dn+F(1,2**30)
L=Lraw+Lerr;assert L<F(1,2**20)
b0=matrix('Delta_real','Delta_imag')+nu*(2*e+e*e)+dn+F(1,2**36);assert b0<F(3,2**26)
T=F(16);V=F(64,31457265);Ustar=T+F(1,2**12);M=192
x=4*Ustar;R=x**M/factorial(M)/(1-x/(M+1));vac=336*Ustar**3*V*R;assert vac<F(1,2**30)
y=8*Ustar+F(25,16);r=F(1,2**21);G2=F(128,3)
eta=4*G2*r/(1-r)*y**(2*M)/factorial(2*M)/(1-y/(2*M+1))+2*G2*r**9/(1-r);cov=2*Ustar**2*eta;assert cov<F(1,2**57)
E0=F(3,2**18)+F(1,2**128);x16=F(12433696189517,58512905602490430);rows=[]
for k in range(12,25):
 w=F(1,2**k);U=T+w;dq=F(49,1024)*w+49*w*w;xu=x16+6*V*(T*w+w*w/2);higher=xu*xu/(2*(1-xu))
 d14=4*V*(14*U*U+U)*w
 analytic=E0+dq+F(3,2**26)+d14+higher
 jetvariation=F(1,2**20)*w+F(1,8)*w*w
 total=E0+dq+F(3,2**26)+jetvariation+F(1,2**30)+F(1,2**57)+higher
 rows.append({'k':k,'halfwidth':str(w),'analytic14_target_pass':analytic<F(1,2**16),'jet_target_pass':total<F(1,2**16),'jet_total_numerator':str(total.numerator),'jet_total_denominator':str(total.denominator),'jet_total_decimal_diagnostic':float(total),'jet_variation':str(jetvariation),'cold_variation':str(dq)})
chosen=next(z for z in rows if z['jet_target_pass']);assert chosen['k']==14
assert F(int(chosen['jet_total_numerator']),int(chosen['jet_total_denominator']))<F(31,2**21)<F(1,2**16)
assert next(z for z in rows if z['analytic14_target_pass'])['k']==15
fmt=lambda q:{'numerator':str(q.numerator),'denominator':str(q.denominator),'decimal_diagnostic':float(q)}
result={'status':'DERIVED conditional response-jet window','continuum_analytic_derivative_sector_charge':14,'previous_sector_charge':64,'finite_ideal_derivative_half_trace_upper':fmt(L),'finite_derivative_dyadic_upper':'2^-20','finite_point_response_upper':fmt(b0),'uniform_vacuum_transfer_upper':fmt(vac),'uniform_covariance_transfer_upper':fmt(cov),'uniform_comparison_horizon':str(Ustar),'window':'[16-2^-14,16+2^-14] model time units','uniform_retained_error_upper':'31/2^21','halfwidth_gain_vs_parent':4,'relative_halfwidth':'2^-18 of deadline','analytic_only_window_halfwidth':'2^-15','numerical_continuum_derivative_transfer':'OPEN; uniform state comparison does not certify its derivative','scope':'Fixed launch and inherited continuum/Gaussian/arithmetic assumptions; finite response derivative and uniform continuum value comparison','physical_promotion':0,'external_independent_review':'OPEN','rows':rows}
(P/'results/JET_CERTIFICATE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['rows','finite_point_response_upper','uniform_vacuum_transfer_upper','uniform_covariance_transfer_upper']},indent=2))
