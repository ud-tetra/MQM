MQM retained-response jet v0.1,7 October2026.
Replay: python3 propagate_jet.py; python3 certify_jet.py; python3 control_derivative.py. Propagation uses about152 seconds in the recorded environment. PDF: python3 build_pdf.py withpdflatex/Poppler.
The raw derivative matrix is a simulation output; promotion uses the exact error ledger. The finite ideal derivative bound, continuum analytic charge14 and uniform value comparison are different objects. Numerical continuum derivative transfer remainsOPEN. Physical promotion0. No hardware claim or permanent hold.
All source parameters and the target remain frozen. Initial failed display roundup and protocol clarification are retained. Same-agent separate implementation checks are not external review.
EVOLVED_COLUMNS.npz is a reproducible scratch checkpoint and excluded from the deliverable; propagate_jet.py regenerates it. Retained matrices, exact ledger and source scripts are included.
