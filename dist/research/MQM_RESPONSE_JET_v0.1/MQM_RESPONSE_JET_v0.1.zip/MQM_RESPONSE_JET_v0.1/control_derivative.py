import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import itertools,json,math
import numpy as np
from scipy.linalg import eigh
from scipy.sparse.linalg import expm_multiply
P=Path(__file__).resolve().parent;model=P/'inputs/response_model.py';ns={'__file__':str(model)};exec(model.read_text(),ns)
rows=[];rng=np.random.default_rng(12345)
for M in [4,8]:
 H,H1,n=ns['models'](M);freq=H1.diagonal()[4:];c=H1[3,4:];charge=[1,1,1,1,0,2,2,2];bs=[]
 for a,q in enumerate(charge):
  for modes in itertools.combinations_with_replacement(range(M),2-q):bs.append((a,tuple(modes.count(j) for j in range(M))))
 lut={v:i for i,v in enumerate(bs)};K=np.zeros((len(bs),len(bs)));Hb=np.zeros_like(K);Hs=np.zeros_like(K)
 for j,(a,f) in enumerate(bs):
  K[j,j]=Hb[j,j]=np.dot(freq,f)
  for u,v,z in [(0,1,1),(1,2,1),(2,3,math.sqrt(4*math.sqrt(2))),(5,6,1),(6,7,1)]:
   if a==u and (v,f) in lut:
    k=lut[(v,f)];K[j,k]=K[k,j]=Hs[j,k]=Hs[k,j]=z
  for hi,lo in [(3,4),(5,0),(6,1),(7,2)]:
   if a==hi:
    for site in range(M):
     ff=list(f);ff[site]+=1
     if (lo,tuple(ff)) in lut:
      k=lut[(lo,tuple(ff))];K[j,k]=K[k,j]=c[site]*math.sqrt(1+f[site])
 def trace(X):
  R=np.zeros((8,8),complex)
  for j,(a,f) in enumerate(bs):
   for k,(b,g) in enumerate(bs):
    if f==g:R[a,b]+=X[j,k]
  return R
 v=rng.normal(size=len(bs))+1j*rng.normal(size=len(bs));v/=np.linalg.norm(v);rho=np.outer(v,v.conj());bath=float(np.linalg.norm(trace(Hb@rho-rho@Hb)));assert bath<1e-12
 vals,E=eigh(K);U=(E*np.exp(-16j*vals))@E.T;rho0=np.zeros_like(K)
 for j in range(M):f=tuple(int(k==j) for k in range(M));rho0[lut[(0,f)],lut[(0,f)]]=n[j]
 rho=U@rho0@U.conj().T;hd=trace(-1j*(K@rho-rho@K))
 psi=np.zeros(M+4,complex);psi[0]=1;u=expm_multiply(-16j*H1,psi,traceA=-16j*np.trace(H1));z=-1j*(H1@u)
 cd=np.zeros((8,8),complex);cd[:4,:4]=np.outer(z[:4],u[:4].conj())+np.outer(u[:4],z[:4].conj());cd[4,4]=2*np.vdot(u[4:],z[4:]).real
 Ddense=hd-n.sum()*cd
 seed=np.zeros((H.shape[0],M),complex);seed[3+np.arange(M),np.arange(M)]=1;W=expm_multiply(-16j*H,seed,traceA=-16j*H.diagonal().sum());Z=-1j*(H@W)
 # Independent polarization route to the derivative of retained dyads.
 Dpol=(ns['retained'](W+Z,n,M)-ns['retained'](W-Z,n,M))/2-n.sum()*cd
 err=float(np.linalg.norm(Ddense-Dpol));assert err<1e-12
 def calc(t):
  Ut=(E*np.exp(-1j*t*vals))@E.T;hot=trace(Ut@rho0@Ut.conj().T);v=expm_multiply(-1j*t*H1,psi,traceA=-1j*t*np.trace(H1));cold=np.zeros((8,8),complex);cold[:4,:4]=np.outer(v[:4],v[:4].conj());cold[4,4]=np.vdot(v[4:],v[4:]);return hot-n.sum()*cold
 dt=2.**-18;fd=(calc(16+dt)-calc(16-dt))/(2*dt);fderr=float(np.linalg.norm(fd-Ddense));assert fderr<1e-10
 exch=K-Hb-Hs;G=float(np.linalg.norm(c));en=float(np.max(abs(np.linalg.eigvalsh(exch))));assert en<=math.sqrt(2)*G+1e-12
 rows.append({'M':M,'occupation_dimension':len(bs),'bath_commutator_retained_residual':bath,'dense_vs_polarization_derivative_difference':err,'central_difference_disagreement':fderr,'exchange_norm':en,'sqrt2_G':math.sqrt(2)*G,'native_norm':float(np.max(abs(np.linalg.eigvalsh(Hs))))})
(P/'results/DERIVATIVE_CONTROLS.json').write_text(json.dumps({'status':'SIMULATED separate same-agent implementation routes; not independent reviewer','rows':rows},indent=2)+'\n');print(json.dumps(rows,indent=2))
