from pathlib import Path
import json
R=Path(__file__).resolve().parent
P={'version':'0.1','status':'FROZEN before response controls','parent':'MQM_FREQUENCY_BOUND_v0.1','source':{'Omega':64,'B':16,'kappa':8,'beta':'5/16','t':16,'h':1,'g':1,'lambda_squared':'4sqrt2','system_launch':'pR0','target':'1/65536'},'formal_object':'8x8 retained Delta2 from joint system-vacuum bath Dyson expansion; not closed8x8 system Hamiltonian','finite_controls':{'modes':[2,4,8,16],'grid':'midpoint delta_j=-B+(j+1/2)*2B/M','coupling_squared':'kappa B/(pi M)','response':'Trbath U_Q2 (pR0 projector tensor one-photon covariance N) U_Q2dag -trN rho_vac; systembath number conserved','independent_check':'M2 direct noncommuting double-commutator triangular Gauss-Legendre orders32,64,128','tolerance':'finest Frobenius difference<1e-10; hermiticity and trace<1e-10','precision':'numpy scipy binary64; numerical controls not interval certificates'},'tail_specification':'For finiteM thermal modes with occupations<=nmax:Pr(K>=r)<=binom(M+r-1,r)nmax^r; exact full dynamics for admitted K<=r-1 staysQ<=r. No uniform continuum occupation cutoff claim.','acceptance':'Passing finite controls validates response implementation only; continuum2^-16 remainsOPEN without certified continuum response transfer and numerical enclosure','physical_promotion':0}
s=json.dumps(P,indent=2)+'\n';p=R/'PROTOCOL.json'
if p.exists():assert p.read_text()==s
else:p.write_text(s)
print('FROZEN')
