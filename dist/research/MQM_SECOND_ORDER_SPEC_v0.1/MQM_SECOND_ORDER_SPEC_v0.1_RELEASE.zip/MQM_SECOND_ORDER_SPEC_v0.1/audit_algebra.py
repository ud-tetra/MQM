from pathlib import Path
from fractions import Fraction as F
import json,math

R=Path(__file__).resolve().parent
charges=[1,1,1,1,0,2,2,2];edges=[(0,1),(1,2),(2,3),(5,6),(6,7)];Sedges=[(3,4),(5,0),(6,1),(7,2)]
assert all(charges[a]==charges[b] for a,b in edges)
assert all(charges[a]-charges[b]==1 for a,b in Sedges)
# Exact first occupation derivative of a genuine finite thermal density.
# Exact first-order dual fractions (value, derivative) for rational functions.
def mul(a,b):return (a[0]*b[0],a[1]*b[0]+a[0]*b[1])
def inv(a):return (1/a[0],-a[1]/a[0]**2)
assert mul((F(3),F(2)),inv((F(3),F(2))))==(F(1),F(0))
n=[F(1,7),F(1,11),F(2,13)];p0=(F(1),F(0))
for z in n:p0=mul(p0,inv((F(1),z)))
assert p0[1]==-sum(n)
for z in n:assert mul(p0,mul((F(0),z),inv((F(1),z))))[1]==z
assert mul(p0,mul((F(0),n[0]),(F(0),n[1])))[1]==0
# Exact correlated covariance via rational orthogonal mode rotation.
u=F(3,5);v=F(4,5);assert u*u+v*v==1
N=[[u*u*n[0]+v*v*n[1],u*v*(n[1]-n[0])],[u*v*(n[1]-n[0]),v*v*n[0]+u*u*n[1]]]
assert N[0][0]+N[1][1]==n[0]+n[1] and N[0][1]!=0
def factors(n):
 out={};p=2
 while p*p<=n:
  while n%p==0:out[p]=out.get(p,0)+1;n//=p
  p+=1
 if n>1:out[n]=out.get(n,0)+1
 return out
assert sum((F(15)**j/F(math.factorial(j)) for j in range(81)),F())>2**21
rows=[]
for M in [2,4,8,16,256,768]:
 dims=[1,4+M,3+4*M+math.comb(M+1,2),3*M+4*math.comb(M+1,2)+math.comb(M+2,3)]
 tails={str(r):str(F(math.comb(M+r-1,r),(2**21-1)**r)) for r in [1,2,3]}
 rows.append({'M':M,'M_factorization':str(factors(M)),'sector_dimensions_Q0_Q1_Q2_Q3':dims,'total_Q_le2':sum(dims[:3]),'total_Q_le3':sum(dims),'initial_thermal_tail_P_K_ge_r':tails})
last=rows[-1];assert F(last['initial_thermal_tail_P_K_ge_r']['2'])<F(1,2**23);assert F(last['initial_thermal_tail_P_K_ge_r']['3'])<F(1,2**36)
res={'status':'EXACT dual-fraction thermal derivative, integer charge metadata and finite-bath tail receipts','thermal_derivative_identity':'Delta2_M=Trbath U_Q2 (systemlaunch projector tensor one-photon covariance N) U_Q2dag -trN rho0_M','scalar_parameter':'a rescales covariance for a derivative only; not physical temperature tuning','symbolic_checks':{'vacuum_derivative':str(-sum(n)),'one_photon_derivatives':[str(z) for z in n],'two_photon_first_derivative':'0','correlated_one_photon_covariance':[[str(z) for z in row] for row in N]},'counts_and_tails':rows,'source_bound_nmax':'1/(exp15-1)<1/(2^21-1)','finite_tail_scope':'Normalized thermal truncation at initialK<=r-1 has half-trace input debit<=tail; exact closed dynamics staysQ<=r; individual bath occupations must permit up tor, not onlyr-1. No uniformM->infinity globalFocktail.', 'primary_continuum_target':'OPEN','physical_promotion':0}
(R/'results/ALGEBRA_AUDIT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
