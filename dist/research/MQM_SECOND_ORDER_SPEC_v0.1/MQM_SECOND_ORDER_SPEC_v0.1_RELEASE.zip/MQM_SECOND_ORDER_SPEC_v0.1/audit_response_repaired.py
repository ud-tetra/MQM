import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,itertools,math
import numpy as np
from scipy.linalg import eigh
from numpy.polynomial.legendre import leggauss
R=Path(__file__).resolve().parent
Snames=['p0','m0','e0','d1','d0','p1','m1','e1'];charges=[1,1,1,1,0,2,2,2]
def basis(M,q):
 out=[]
 for a,charge in enumerate(charges):
  n=q-charge
  if n<0:continue
  for inds in itertools.combinations_with_replacement(range(M),n):
   f=[0]*M
   for i in inds:f[i]+=1
   out.append((a,tuple(f)))
 return out
def ham(M,bs):
 lookup={s:i for i,s in enumerate(bs)};delta=-16+(np.arange(M)+.5)*32/M;c=math.sqrt(128/(math.pi*M));H=np.zeros((len(bs),len(bs)))
 edges=[(0,1,1),(1,2,1),(2,3,math.sqrt(4*math.sqrt(2))),(5,6,1),(6,7,1)];low={3:4,5:0,6:1,7:2}
 for i,(a,f) in enumerate(bs):
  H[i,i]=np.dot(delta,f)
  for u,v,w in edges:
   if a==u and (v,f) in lookup:
    j=lookup[(v,f)];H[i,j]+=w;H[j,i]+=w
  if a in low:
   for n in range(M):
    ff=list(f);ff[n]+=1;state=(low[a],tuple(ff))
    if state in lookup:
     j=lookup[state];val=c*math.sqrt(f[n]+1);H[i,j]+=val;H[j,i]+=val
 return H
def partial(bs,rho):
 out=np.zeros((8,8),complex)
 for i,(a,f) in enumerate(bs):
  for j,(b,g) in enumerate(bs):
   if f==g:out[a,b]+=rho[i,j]
 return out
def unit(H,t):
 e,V=eigh(H);return (V*np.exp(-1j*t*e))@V.T
rows=[];saved=None
for M in [2,4,8,16]:
 b1=basis(M,1);b2=basis(M,2);assert len(b1)==4+M and len(b2)==3+4*M+M*(M+1)//2
 H1=ham(M,b1);H2=ham(M,b2);U1=unit(H1,16);U2=unit(H2,16);zero=(0,)*M;i0=b1.index((0,zero));v=U1[:,i0];rv=partial(b1,np.outer(v,v.conj()))
 delta=-16+(np.arange(M)+.5)*32/M;n=1/np.expm1((5/16)*(64+delta));hot=np.zeros((8,8),complex)
 for j in range(M):
  f=[0]*M;f[j]=1;w=U2[:,b2.index((0,tuple(f)))];hot+=n[j]*partial(b2,np.outer(w,w.conj()))
 D=hot-sum(n)*rv;ev=np.linalg.eigvalsh(D);half=float(sum(abs(ev))/2)
 assert np.linalg.norm(D-D.conj().T)<1e-10 and abs(np.trace(D))<1e-10
 blocks=max(abs(D[a,b]) for a in range(8) for b in range(8) if charges[a]!=charges[b]);assert blocks<1e-10
 rows.append({'M':M,'Q1_dimension':len(b1),'Q2_dimension':len(b2),'half_trace_Delta2':half,'trace_residual':float(abs(np.trace(D))),'offcharge_block_max':float(blocks),'occupation_trace':float(sum(n)),'retained_Delta2_real':D.real.tolist(),'retained_Delta2_imag':D.imag.tolist(),'scope':'SIMULATED finite-midpoint-bath implementation control; no continuum transfer certificate'})
 print('M',M,'Delta2',half,flush=True)
 if M==2:saved=D
# Independent joint-bath triangular double-commutator integral, M2 only.
M=2;bs=sum((basis(M,q) for q in [0,1,2]),[]);H=ham(M,bs);e,W=eigh(H);lut={s:i for i,s in enumerate(bs)};low={3:4,5:0,6:1,7:2};S=np.zeros_like(H)
for i,(a,f) in enumerate(bs):
 if a in low:S[lut[(low[a],f)],i]=1
psi=np.zeros(len(bs),complex);psi[lut[(0,(0,0))]]=1;rho=np.outer(psi,psi.conj());UT=(W*np.exp(-1j*e*16))@W.T;Se=W.T@S@W
freq=np.array([-8,8]);nw=1/np.expm1((5/16)*(64+freq));weights=(128/(math.pi*M))*nw
def SI(t):
 phase=np.exp(1j*e*t);return W@(phase[:,None]*Se*phase.conj()[None,:])@W.T
def comm(A,B):return A@B-B@A
checks=[]
for N in [256,512]:
 x,w=leggauss(N);ans=np.zeros_like(rho)
 for i in range(N):
  s=8*(x[i]+1);As=SI(s);Ad=As.conj().T
  for j in range(N):
   u=s*(x[j]+1)/2;Bu=SI(u);Bd=Bu.conj().T;c=np.dot(weights,np.exp(-1j*freq*(s-u)))
   ans-=8*w[i]*s*w[j]/2*(c*comm(Ad,comm(Bu,rho))+c.conjugate()*comm(As,comm(Bd,rho)))
 D=partial(bs,UT@ans@UT.conj().T);diff=np.linalg.norm(D-saved);checks.append({'order':N,'frobenius_difference':float(diff),'trace_residual':float(abs(np.trace(D)))})
 print('QUAD',N,diff,flush=True)
assert checks[-1]['frobenius_difference']<1e-10
res={'status':'SIMULATED finite bath controls; exact response identity formally derived','rows':rows,'independent_double_commutator':checks,'scope':'Eight-dimensional retained response requires joint system-reservoir propagation. No continuum second-order interval certificate or complete thermal trajectory.','primary_target_status':'OPEN','physical_promotion':0}
(R/'results/RESPONSE_AUDIT.json').write_text(json.dumps(res,indent=2)+'\n')
