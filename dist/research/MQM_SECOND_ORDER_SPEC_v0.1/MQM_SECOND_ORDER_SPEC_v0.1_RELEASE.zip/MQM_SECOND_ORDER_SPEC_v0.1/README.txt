MQM SECOND ORDER SPEC v0.1

Passing replay:
python freeze.py
python audit_algebra.py
python audit_response_repaired.py

Original audit_response.py intentionally reproduces the failed128-order double-integral tolerance and is preserved as a failure recipe. Original and repaired run receipts are separate. No source parameters or tolerance changed.

Exact dual fractions verify thermal-state first derivatives and correlated covariance transformation. Initial optional SymPy dependency was unavailable; DEPENDENCY_AMENDMENT records replacement with standard-library exact fractions.

DERIVED finite response identity uses Q1/Q2 conserved sectors, retaining noncommuting bath dynamics. Eight-state retainedmatrix doesnot imply closed8-state propagation. The one-photon identity is an exact second-order derivative, not a full thermal truncation.

SIMULATED controls M2,4,8,16 do not certify continuum response or share the inherited vacuum continuum ceiling. Global initial thermal photon tails depend onM and do not certify uniforminfinitecontinuum cutoff.

IEEEtran journal,a4paper,10pt two-column PDF. Run python build_pdf.py; requires pdflatex. Class/license included.

Primary beta5/16,time16,target2^-16 remainsOPEN. Physicalpromotion0; no permanenthold, physicalcompilation, hardwareperformance, advantage or independentreview claim.
