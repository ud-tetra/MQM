"""Exact rational Banach certificate for a regular second-moment zero slice."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json
import numpy as np
from scipy.linalg import qr
from moment_geometry import D,B,F,E,W,R,labels,NAMES
geo=json.loads((R/'results'/'MOMENT_GEOMETRY.json').read_text());rows=geo['independent_components'];Dq=D[rows]
best=json.loads((R/'results'/'BRANCH_SEARCH.json').read_text())['best']
theta=np.array([float(Q(v)) for v in best['kernel_coordinates_exact']])
J=np.einsum('kab,b->ka',Dq,theta);_,_,pivot=qr(J,pivoting=True,mode='economic');ports=pivot[:15].tolist()
initial=theta.copy()
# Numerical refinement only supplies a center; the rational proof below is
# independent of the Newton stopping criterion and of floating zero tests.
for k in range(12):
    linear=np.einsum('kab,b->ka',Dq,theta);q=np.einsum('ka,a->k',linear,theta)/2
    step=np.linalg.solve(linear[:,ports],q);theta[ports]-=step
    if max(abs(step))<1e-12:break
def dyadic(a):
    fractions=[Q(float(x)) for x in a.ravel()];den=max(v.denominator for v in fractions)
    assert all(den%v.denominator==0 for v in fractions)
    return np.array([v.numerator*(den//v.denominator) for v in fractions],dtype=object).reshape(a.shape),den
tn,td=dyadic(theta);Jnum=np.einsum('kab,b->ka',Dq.astype(object),tn)[:,ports]
Jfloat=np.array(Jnum,dtype=float)/td
Rn,Rd=dyadic(np.linalg.inv(Jfloat))
qnum=np.array([int(tn@(dq.astype(object)@tn)) for dq in Dq],dtype=object)
res=Rn@qnum;eta=max(Q(abs(int(v)),Rd*2*td**2) for v in res)
RJ=Rn@Jnum;beta0=max(Q(sum(abs(int(v)) for v in row),Rd*td) for row in (np.eye(15,dtype=int).astype(object)*(Rd*td)-RJ))
restricted=Dq[:,ports,:][:,:,ports].astype(object)
preconditioned=np.einsum('ij,jkl->ikl',Rn,restricted)
kappa=max(Q(sum(abs(int(v)) for v in a.ravel()),Rd) for a in preconditioned)
radius=Q(1,1<<50)
while radius<=2*eta:radius*=2
beta=beta0+kappa*radius
checks=[]
def check(name,p):
    assert p,name;checks.append(name)
check('fifteen independent quadratic constraints',len(rows)==len(ports)==15)
check('unvaried coordinates preserved exactly',all(Q(float(theta[j]))==Q(float(initial[j])) for j in range(97) if j not in ports))
check('preconditioner defect strictly below one',beta0<1)
check('box contraction constant strictly below one',beta<1)
check('closed box maps strictly inside itself',eta+beta*radius<radius)
center_theta=[Q(int(v),td) for v in tn]
coeff=[sum((int(b)*t for b,t in zip(row,center_theta)),Q(0)) for row in B]
L=sum(abs(c) for c in coeff)
coupling_slope=sum(int(np.sum(abs(B[:,j]))) for j in ports)
debit=radius*coupling_slope;Lroot=L+debit
check('root full-domain Pauli budget within deadline cap',Lroot<=512)
check('nonzero generator budget',L>debit)
check('shared zero component follows exact global row relations',rows==list(range(1,16)))
receipt={'status':'EXACT rational contraction certificate: unique real root in the declared 15-coordinate slice','parent_selected_run':best['run'],'varied_coordinates':ports,'fixed_coordinate_count':82,'center_kernel_coordinates_exact':[str(q) for q in center_theta],'center_phase_diagnostic':best['phase'],'preconditioner_exact':[[str(Q(int(v),Rd)) for v in row] for row in Rn],'eta_preconditioned_residual_inf':str(eta),'beta0_preconditioner_defect_inf':str(beta0),'preconditioned_Hessian_lipschitz':str(kappa),'box_radius_inf':str(radius),'contraction_beta':str(beta),'root_Hamiltonian_norm_distance_upper':str(debit),'center_Pauli_norm_upper':str(L),'root_Pauli_norm_upper':str(Lroot),'exact_count':len(checks),'checks':checks,'root_definition':'Unique zero of all 15 independent rational quadratic forms with the other 82 exact center coordinates fixed and varied coordinates inside center +/- radius. Defines real algebraic coefficients implicitly, not binary-rational root coefficients.','proof':'For q(y)=1/2 theta(y)^T D_j theta(y), define T(y)=y-R q(y). Exact residual eta and derivative bound beta0+kappa*r give ||T(y)-center||inf <= eta+beta*r<r and ||DT||inf<=beta<1. Banach gives one unique fixed point in the slice. beta0<1 makes R and Jcenter invertible; beta<1 keeps RJ(y) invertible throughout the box. Hence the fixed point is a root with full Jacobian rank15. The implicit-function theorem supplies a local real second-moment-zero manifold of dimension97-15=82.','spectral_or_endpoint_status':'Not inferred from moment equality; separate all-time spectral audit required.','physical_promotion':0}
(R/'results'/'ROOT_CERTIFICATE.json').write_text(json.dumps(receipt,indent=2))
center={'run':best['run'],'kernel_coordinates_exact':[str(q) for q in center_theta],'phase':best['phase'],'Pauli_coefficients_exact':{l:str(c) for l,c in zip(labels,coeff)}}
(R/'results'/'ROOT_CENTER.json').write_text(json.dumps({'best':center},indent=2))
print({'checks':len(checks),'radius':str(radius),'eta':float(eta),'beta':float(beta),'root_norm_upper':float(Lroot),'regular_local_dimension':82},flush=True)
