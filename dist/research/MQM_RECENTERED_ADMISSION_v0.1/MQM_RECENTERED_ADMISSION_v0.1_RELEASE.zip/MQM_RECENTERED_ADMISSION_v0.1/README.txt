Recentered Planar Joint Admission: A Scoped Search and Full-Spectrum Audit
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM v0.1

RESULT
Recentered exploratory search:424 attempts,309 accepted,115 rejected.
Sampled residual0.222881819 ->0.222846101. Conservative norm<=1 deadline
increases358.894545 ->373.851497: no resource gain. The newly certified
regular algebraic root exactly matches first/second moments but has complete
half-diamond error>1/16 at EVERY deadline. Target1/65536 remains OPEN.
This excludes one root, not the planar family. No stationarity/global optimum,
encoder, fault tolerance, hardware evidence or comparative advantage claimed.
Physical promotion0; independent review and novelty comparison pending.
252 scoped exact checks (including rerun inherited checks),166 numerical
derivative checks. This is not252 new theorems or an independent evaluation.

CERTIFICATE REPLAY (numpy,scipy,sympy,networkx)
  python3 moment_geometry.py
  python3 verify_frozen.py
  python3 certify_root.py
  python3 spectral_certificate.py --root-center
  python3 certify_root_spectral_floor.py
  python3 shared_return_witness.py
Numerical Newton/eigenvectors propose data; rational contraction and exact
Gaussian-integer residuals establish scoped conclusions. The dyadic center
is not the implicitly algebraic root; its root-box debit is charged.

OPTIONAL SEARCH (overwrites receipts; repeat all certificates afterward)
  python3 search_branch.py
Protocol was declared before this successor run but after parent exposure.
New center,free radius4,cap1000 are disclosed tuning. No independent prediction.
Initial reference is the parent's certified center, not a rational root claim.
EXPLORATION_PROTOCOL.json records acceptance and rollback boundaries.

PDF (pdflatex,IEEEtran,balance,PyMuPDF)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png before:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two columns. Class license included.
NEXT_GATE.json recommends independent regular regions rather than endless
same-basin recentering. Native admission closes before encoded SWAP composition.
User instruction amendment is captured in MQM_WORKING_INSTRUCTIONS_v0.3.txt.
Parent releases immutable. SHA256SUMS.txt covers distributed files.
