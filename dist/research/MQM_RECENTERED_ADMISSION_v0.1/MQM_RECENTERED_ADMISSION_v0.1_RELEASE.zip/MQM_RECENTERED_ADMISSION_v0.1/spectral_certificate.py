"""Exact dyadic backward-error enclosure for an all-time Choi trace-error floor."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
from math import isqrt
import json,argparse
import numpy as np
from scipy.linalg import eigh
from complex_objective import load_model
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--moment',action='store_true');ap.add_argument('--root-center',action='store_true');args=ap.parse_args()
name='ROOT_CENTER.json' if args.root_center else 'BRANCH_SEARCH.json'
best=json.loads((R/'results'/name).read_text())['best']
source,labels,B,P,Fbasis,E,W=load_model()
coeff=[Q(best['Pauli_coefficients_exact'][l]) for l in labels]
Hden=max(c.denominator for c in coeff)
assert all(Hden%c.denominator==0 for c in coeff)
HR=np.zeros((64,64),dtype=object);HI=np.zeros((64,64),dtype=object)
for c,p in zip(coeff,P):
    n=c.numerator*(Hden//c.denominator)
    HR+=np.rint(p.real).astype(int).astype(object)*n
    HI+=np.rint(p.imag).astype(int).astype(object)*n
H=np.array(HR,dtype=float)/Hden+1j*np.array(HI,dtype=float)/Hden
lam,V=eigh(H)
def dyadic_array(values):
    flat=[Q(float(v)) for v in values.ravel()];den=max(q.denominator for q in flat)
    assert all(den%q.denominator==0 for q in flat)
    nums=np.array([q.numerator*(den//q.denominator) for q in flat],dtype=object).reshape(values.shape)
    return nums,den
Vr,dr=dyadic_array(V.real);Vi,di=dyadic_array(V.imag);Vden=max(dr,di)
Vr*=Vden//dr;Vi*=Vden//di
Ln,Lden=dyadic_array(lam)
GRe=Vr.T@Vr+Vi.T@Vi-np.eye(64,dtype=int).astype(object)*Vden**2
GIm=Vr.T@Vi-Vi.T@Vr
Gsq=Q(sum(int(a)**2+int(b)**2 for a,b in zip(GRe.ravel(),GIm.ravel())),Vden**4)
RRe=(HR@Vr-HI@Vi)*Lden-(Vr*Ln[None,:])*Hden
RIm=(HR@Vi+HI@Vr)*Lden-(Vi*Ln[None,:])*Hden
Rsq=Q(sum(int(a)**2+int(b)**2 for a,b in zip(RRe.ravel(),RIm.ravel())),(Hden*Vden*Lden)**2)
def sqrt_upper(q,p=80):
    assert q>=0
    scaled=q.numerator*(1<<(2*p));den=q.denominator
    r=isqrt(scaled//den)
    if r*r*den!=scaled:r+=1
    out=Q(r,1<<p);assert out*out>=q
    return out
delta=sqrt_upper(Gsq);rho=sqrt_upper(Rsq)
ledger=sum((abs(c) for c in coeff),Q(0));Lmax=max(abs(Q(int(n),Lden)) for n in Ln)
eta=rho+(ledger+Lmax)*delta
gamma=min(Q(int(Ln[k+1]-Ln[k]),Lden) for k in range(63))
checks=[]
def check(n,p):
    assert p,n
    checks.append(n)
check('Gaussian-integer Hamiltonian Hermitian',np.array_equal(HR,HR.T) and np.array_equal(HI,-HI.T))
check('dyadic Gram enclosure square dominates exact residual',delta**2>=Gsq)
check('dyadic eigen-residual enclosure square dominates exact residual',rho**2>=Rsq)
check('polar normalization well defined',delta<1)
check('full Pauli norm budget positive',ledger>0)
check('eigenvalue grid separated beyond backward error',gamma>2*eta)
projector_debit=eta/(gamma-eta)+3*delta
ss=[8,24,40,56];tt=[8,4,2,1]
overlaps=[]
for n in range(64):
    ar=sum(int(Vr[t,n])*int(Vr[e,n])+int(Vi[t,n])*int(Vi[e,n]) for e,t in zip(ss,tt))
    ai=sum(int(Vr[t,n])*int(Vi[e,n])-int(Vi[t,n])*int(Vr[e,n]) for e,t in zip(ss,tt))
    sq=Q(ar*ar+ai*ai,Vden**4);bound=sqrt_upper(sq)
    check('spectral overlap radical enclosure '+str(n),bound*bound>=sq)
    overlaps.append(bound)
S0=sum(overlaps,Q(0));Sup=S0+256*projector_debit
check('certified spectral overlap below channel dimension',Sup<4)
floor_square=1-(Sup/4)**2;den=1
while Q(1,den)**2>=floor_square:den*=2
simple=Q(1,den)
check('strict dyadic complete-channel floor',simple*simple<floor_square)
check('certified all-time floor exceeds target',simple>Q(1,65536))
receipt={
 'status':'Exact dyadic/Gaussian-integer backward-error and spectral-projector certificate for one frozen generator',
 'batch':'retracted_branch','best_run':best['run'],'dimension':64,'logical_dimension':4,
 'exact_count':len(checks),'exact_checks':checks,
 'Gram_Frobenius_squared':str(Gsq),'eigen_residual_Frobenius_squared':str(Rsq),
 'delta_Gram_upper':str(delta),'rho_eigen_residual_upper':str(rho),'Pauli_norm_upper':str(ledger),'lambda_norm_upper':str(Lmax),
 'Hermitian_backward_error_eta':str(eta),'minimum_grid_gap_gamma':str(gamma),'projector_norm_debit':str(projector_debit),
 'approximate_overlap_sum_upper':str(S0),'exact_projector_overlap_sum_upper':str(Sup),
 'all_time_half_diamond_floor_squared':str(floor_square),'strict_dyadic_channel_floor':str(simple),
 'floor_decimal_diagnostic':float(floor_square)**.5,'overlap_upper_decimal':float(Sup),
 'uniform_norm_one_generator':'H / Pauli_norm_upper; full norm <= 1 by exact triangle inequality',
 'scope':'Frozen exact binary-rational Hamiltonian only, arbitrary deadline, common global phase and uniform norm rescaling. Maximally entangled logical/reference input supplies the trace-error witness.',
 'proof':'Let Qpolar be the polar unitary of the binary-rational eigenvector matrix V. ||Qpolar-V||<=delta. ||H-Qpolar*Lambda*Qpolar^dagger||<=eta. Grid gap gamma>2eta identifies rank-one true projectors, each within eta/(gamma-eta)+3delta of V_n V_n^dagger. Each four-column trace overlap changes by at most four times that debit; sum 64 overlaps. For any deadline, Choi overlap <= Sup/4, so half-diamond >=sqrt(1-(Sup/4)^2). All enclosure arithmetic is exact.',
 'physical_promotion':0,'independent_review':'pending','joint_admission':'OPEN'}
dest='ROOT_CENTER_SPECTRAL_CERTIFICATE.json' if args.root_center else 'SPECTRAL_CERTIFICATE.json'
(R/'results'/dest).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('exact_count','best_run','strict_dyadic_channel_floor','floor_decimal_diagnostic','overlap_upper_decimal')}))
