"""Exact task data for a derived shared-return spectral-weight criterion."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json
import numpy as np
from scipy.linalg import eigh
from moment_geometry import E,W,F,R
checks=[]
def check(name,p):
    assert p,name;checks.append(name)
delta=W-E
check('input and target share column00',np.array_equal(E[:,0],W[:,0]))
check('difference Gram is exactly diag(0,2,2,2)',np.array_equal(delta.conj().T@delta,np.diag([0,2,2,2])))
check('input isometry',np.array_equal(E.conj().T@E,np.eye(4)))
check('target isometry',np.array_equal(W.conj().T@W,np.eye(4)))
epsilon=Q(1,65536);threshold=(epsilon/(1-epsilon))**2
check('target three-mode weight threshold is exact rational',threshold==Q(1,65535**2))
check('shared-return Krylov codimension is at least three',64-3==61)
check('three independent target-difference directions from exact Gram',np.count_nonzero(np.diag(delta.conj().T@delta))==3)
center=json.loads((R/'results'/'ROOT_CENTER.json').read_text())['best']
theta=np.array([float(Q(v)) for v in center['kernel_coordinates_exact']])
lam,V=eigh(np.einsum('a,aij->ij',theta,F));weights=np.sort(abs(V[8,:])**2)
receipt={'status':'DERIVED theorem with exact task data; theorem-level novelty comparison pending','exact_count':len(checks),'checks':checks,'simple_spectrum_necessary_bound':'sum of three smallest weights |<eigenmode|input00>|^2 <= (epsilon/(1-epsilon))^2, if half-diamond admission error<=epsilon<1','target_epsilon':str(epsilon),'target_three_mode_weight_upper':str(threshold),'perfect_admission_necessary_Krylov_dimension_upper':61,'Krylov_definition':'span{G^k input00 : k>=0}; reducing for Hermitian G','exact_no_go_class':'Generators whose shared-input Krylov dimension exceeds61 cannot perfectly implement this task. This is not a no-go for the entire planar family.','numerical_center_three_smallest_weights':weights[:3].tolist(),'numerical_center_three_weight_sum':float(sum(weights[:3])),'numerical_scope':'Floating spectral diagnostics only; no enclosed positive support or finite-error target admission inferred. Passing this necessary screen is insufficient.','proof_outline':'Isometric-channel numerical-range geometry gives a common phase with eta=||UE-exp(i phi)W||<=sqrt(2)*epsilon. A=U-exp(i phi)I is normal in the simple G eigenbasis. Since delta=W-E has three singular values sqrt(2), A has at least three eigenmodes with phase displacement >=sqrt(2)-eta. The shared return column gives ||A input00||<=eta, so the sum of those three launch weights is <=eta^2/(sqrt(2)-eta)^2 <=epsilon^2/(1-epsilon)^2. For perfect admission U acts as the same phase on the entire shared-input Krylov space; all three independent target differences are orthogonal to that space, giving dimension<=61 even without simple spectrum.','standard_channel_ingredient':'John Watrous, The Theory of Quantum Information, 2018, Chapter3, Theorem3.55 and the numerical-range proof','physical_promotion':0}
(R/'results'/'SHARED_RETURN_WITNESS.json').write_text(json.dumps(receipt,indent=2))
print({'checks':len(checks),'weight_threshold':str(threshold),'floating_three_weight_sum':receipt['numerical_center_three_weight_sum'],'Krylov_upper_for_perfect_admission':61})
