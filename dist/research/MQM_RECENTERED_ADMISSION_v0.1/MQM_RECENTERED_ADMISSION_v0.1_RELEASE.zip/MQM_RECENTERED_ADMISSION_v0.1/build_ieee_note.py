"""IEEEtran A4 recentering experiment report, sourced from audited receipts."""
from pathlib import Path
from fractions import Fraction as Q
import json,subprocess,fitz,re
R=Path(__file__).resolve().parent;M=R/'manuscript'
def read(n):return json.loads((R/'results'/n).read_text())
s=read('BRANCH_SEARCH.json');root=read('ROOT_CERTIFICATE.json');floor=read('ROOT_SPECTRAL_FLOOR.json');g=read('BRANCH_GRADIENT_RECEIPT.json')
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,balance}
\begin{document}
\title{Recentered Planar Joint Admission:\\A Scoped Search and Full-Spectrum Audit}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 6, 2026. ORCID: 0009-0002-5813-0724. Exploratory continuation; independent review and novelty comparison pending. Physical promotion: 0.}}
\maketitle
\begin{abstract}
Recentring a constrained endpoint search at a previously certified regular second-moment root yields309 accepted steps in424 attempts for a six-qubit planar interface. Sampled operator residual improves slightly, while the conservative unit-norm deadline increases. Exact rational contraction certifies the selected root, but full-spectrum enclosures prove complete half-diamond error greater than $1/16$ at every deadline. Recentring establishes neither operational admission nor resource advantage. The target error $2^{-16}$ remains open.
\end{abstract}
\begin{IEEEkeywords}
Autonomous quantum control, joint admission, two-local Hamiltonian, spectral certificate.
\end{IEEEkeywords}
\section{Contract and disclosed exploration}
Registers are $(A,O,u,v,w,z)$; four modes represent $(00,01,10,11)$. The interface is
\begin{align}
E|ab\rangle&=|ab\rangle_{AO}|\mathbf1_{00}\rangle_M,\\
W|ab\rangle&=|00\rangle_{AO}|\mathbf1_{ab}\rangle_M.
\end{align}
All four columns require coherent admission with one common phase and arbitrary spectators. Single excitation is an endpoint condition, not an invariant transit-sector claim. Full physical dimension is64. The planar graph permits ten pairs $\{Au,Aw,Az,Ou,Ov,Ow,Oz,uw,uv,wz\}$ with maximum degree four. There are108 nonidentity Hermitian Pauli components of support at most two, including fields; real coefficients allow complex entries. The model adds no measurement, reset, bath or scheduled pulses. Launch and observation remain external assumptions; thermodynamic refresh is unproved.

An exact first-moment kernel gives $G(\theta)=\sum_k(B\theta)_kP_k$ with97 real coordinates. Fifteen independent quadratic equations match second compressed moments. The parent \cite{parent} certifies a regular algebraic root, a local82-dimensional branch and a dyadic center. We recenter at that numerical center using the parent's fifteen dependent ports. The center is not substituted for the root in an exact claim.

The protocol is frozen before this run, after exposure to the parent's outcomes and chart boundary. The enlarged free-coordinate box and budget are disclosed tuning, not independent prediction. Physical graph and norm budget remain fixed. This is exploratory engineering; no independent confirmatory endpoint dataset exists.

\section{Reduced search and implementation checks}
Split $\theta=(y,z)$ into15 dependent and82 free coordinates. Newton retraction solves $q(y,z)=0$ numerically; the tangent lift obeys
\begin{equation}
\frac{dy}{dz}=-J_y^{-1}J_z.
\end{equation}
The objective retains all coherent columns:
\begin{equation}
R=e^{-iG(\theta)}E-e^{i\phi}W,\qquad f=\tfrac12\|R\|_F^2.
\end{equation}
An83-column reduced Jacobian combines82 tangent directions and one common phase. Damped Gauss--Newton proposes steps; numerical retraction and guards decide acceptance. Frobenius cost is an optimization surrogate, not the certified complete-channel error.

The recentered free box has infinity radius four, versus one previously; the attempt cap is1000. Other guards remain: Jacobian condition at most $10^7$,20 Newton iterations, dependent step at most one, normalized moment tolerance $2\cdot10^{-15}$ and Newton-step tolerance $2\cdot10^{-13}$ after at least two iterations. Extended precision evaluates polynomial residuals. These checks do not certify a continuous exact path or globally regular chart.

With $L=\sum_k|c_k|$, implement $H=G/L$ at $T=L$, giving full norm at most one on all64 dimensions. The conservative deadline cap is512; no optimal centered norm is claimed. At two probes,166 central-difference reduced derivative columns use step $10^{-6}$. Maximum discrepancy is @GRAD@, with tangent defect @TANGENT@. These are numerical implementation checks, not independent review.

\section{Outcome and exact all-time exclusion}
Seed2026100606 yields424 attempts:309 accepted and115 rejected, comprising79 failures to decrease cost and36 free-box violations. The damping cap terminates before1000 attempts. Neither stationarity nor global optimality follows. The best sampled operator-residual point is selected among accepted points, while acceptance minimizes Frobenius cost.
\begin{table}[t]
\caption{Matched graph and norm-budget comparison}
\centering\begin{tabular}{lrr}\hline
Quantity & Parent & Recentered\\\hline
Physical qubits &6&6\\
Allowed pairs &10&10\\
Attempts &158&424\\
Accepted steps &100&309\\
Sampled operator residual &0.222881819&0.222846101\\
Conservative deadline &358.894545&@TIME@\\
All-time half-diamond floor &$>1/16$&$>1/16$\\\hline
\end{tabular}\end{table}
The residual decreases by approximately $3.57\cdot10^{-5}$ while the conservative deadline grows. This establishes no resource saving, measured device performance or comparative advantage over other clocks or timed controls.

Freeze the selected numerical coordinates as binary rationals and refine a15-coordinate slice. Exact rational bounds for $\mathcal B(y)=y-R_0q(y)$ certify
\begin{equation}
\beta<1,\qquad\eta+\beta r<r,\qquad r=2^{-48}.
\end{equation}
Banach contraction gives a unique real algebraic root in this fixed slice box. The remaining82 coordinates are exact dyadics. The selected minor remains nonsingular, giving a local82-dimensional zero manifold. First and second moments match exactly; full norm at most one and a deadline below512 are certified. These facts do not imply admission.

Exact Gaussian-integer spectral residuals enclose the dyadic center's true projectors. The root-box norm debit transfers the enclosure through separated spectral gaps. A rational upper enclosure of
\begin{equation}
S=\sum_\lambda|\operatorname{Tr}(W^\dagger\Pi_\lambda E)|
\end{equation}
gives, using a maximally entangled logical/reference input,
\begin{equation}
\tfrac12\|\mathcal U_t-\mathcal W\|_\diamond
\ge\sqrt{1-(S/4)^2}>1/16.
\end{equation}
The enclosed radical diagnostic is @FLOOR@. The bound holds at every deadline, including scalar shifts and uniform norm scaling. It excludes this root only, not the planar family.

\balance
\section{Screening, reproducibility and next gate}
The parent's shared-return criterion requires Krylov dimension at most61 for perfect admission. For simple spectrum and complete error at most $\epsilon<1$, the three smallest shared-launch weights must sum to at most $(\epsilon/(1-\epsilon))^2$. At target $2^{-16}$ the threshold is exactly $1/65535^2$. The floating center sum passes this necessary screen but is not an enclosed root-weight certificate; the all-time floor still rejects admission.

The release contains252 scoped exact checks and166 numerical derivative checks, protocol, code, dependencies, manifests and parent hashes. The exact tally includes rerun inherited geometry and task-data checks; it is not252 new theorems. Automated checks establish neither independent review nor empirical evidence.

Repeated recentering in this basin gives marginal improvement. The next exploratory gate should compare independent regular charts and monitor spectral overlap alongside endpoint residual under the same budget. Selected success requires exact feasibility and complete error at most $2^{-16}$ on a nonzero readout window. Native admission remains OPEN; encoded SWAP-core composition is gated. Physical promotion remains0. Code correction, fault tolerance, scalability, quantum advantage and autonomous thermal refresh are unestablished.
\begin{thebibliography}{1}
\bibitem{parent} B. W. Mayes, ``Retracted Admission Search and a Shared-Return Spectral Criterion,'' MQM development note v0.1, Oct.6,2026, immutable replay release; independent review pending.
\end{thebibliography}
\end{document}
'''
values={'TIME':f"{float(Q(root['root_Pauli_norm_upper'])):.6f}",'GRAD':f"{g['max_discrepancy']:.3g}",'TANGENT':f"{g['max_tangent_defect']:.3g}",'FLOOR':f"{floor['floor_diagnostic']:.6f}"}
assert Q(root['box_radius_inf'])==Q(1,2**48)
for k,v in values.items():tex=tex.replace('@'+k+'@',v)
tex=re.sub(r'(?<=[a-zA-Z])(?=\d)', ' ',tex)
name='MQM_RECENTERED_ADMISSION_IEEE_A4_v0.1';(M/(name+'.tex')).write_text(tex)
for k in range(2):
 p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,capture_output=True,text=True)
 (R/'results'/('PDF_BUILD_'+str(k)+'.txt')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout[-2000:]
doc=fitz.open(M/(name+'.pdf'));log=(M/(name+'.log')).read_text()
for i,p in enumerate(doc):p.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/('PAGE_'+str(i+1)+'.png'))
qa={'pages':len(doc),'A4':all(abs(p.rect.width-595.276)<1 and abs(p.rect.height-841.89)<1 for p in doc),'actual_IEEEtran':True,'class_options':'journal,a4paper,10pt','two_columns':True,'no_overfull':'Overfull' not in log,'no_unresolved_references':'undefined' not in log,'visual_review':'pending'}
(R/'results/PDF_QA.json').write_text(json.dumps(qa,indent=2));print(qa)
