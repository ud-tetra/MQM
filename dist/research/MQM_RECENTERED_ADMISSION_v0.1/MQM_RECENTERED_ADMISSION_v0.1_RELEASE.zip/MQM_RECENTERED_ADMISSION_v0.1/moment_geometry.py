"""Integer quadratic second-moment forms on the inherited first-moment kernel."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json
import numpy as np
import sympy as sp
from complex_objective import load_model
R=Path(__file__).resolve().parent
source,labels,B,P,F,E,W=load_model()
SS=[8,24,40,56];TT=[8,4,2,1]
def forms():
    fr=np.rint(F.real).astype(np.int64);fi=np.rint(F.imag).astype(np.int64)
    assert np.array_equal(fr,F.real) and np.array_equal(fi,F.imag)
    er=fr[:,:,SS];ei=fi[:,:,SS];wr=fr[:,:,TT];wi=fi[:,:,TT]
    matrices=[];names=[]
    for i in range(4):
        for j in range(i,4):
            re=er[:,:,i]@er[:,:,j].T+ei[:,:,i]@ei[:,:,j].T-wr[:,:,i]@wr[:,:,j].T-wi[:,:,i]@wi[:,:,j].T
            im=er[:,:,i]@ei[:,:,j].T-ei[:,:,i]@er[:,:,j].T-wr[:,:,i]@wi[:,:,j].T+wi[:,:,i]@wr[:,:,j].T
            matrices.append(re+re.T);names.append(f'Re M2[{i},{j}]')
            if i!=j:matrices.append(im+im.T);names.append(f'Im M2[{i},{j}]')
    return np.array(matrices,dtype=np.int64),names
D,NAMES=forms()
class MomentConstraint:
    def __init__(self,independent):self.rows=np.array(independent);self.D=D[self.rows]
    def evaluate(self,x):
        theta=x[:-1];c=B@theta;s=1+c@c;ds=2*B.T@c
        linear=np.einsum('kab,b->ka',self.D,theta)
        m=np.einsum('ka,a->k',linear,theta)/2
        jac=linear/s-m[:,None]*ds[None,:]/s**2
        return m/s,np.column_stack([jac,np.zeros(len(self.rows))])
def main():
    # Full symmetric matrices, including both off-diagonal coordinates, span
    # exactly the same polynomial row space; no numerical rank threshold used.
    flat=D.reshape(16,-1)
    checks=[]
    def check(name,p):
        assert p,name;checks.append(name)
    check('sixteen real Hermitian components',D.shape==(16,97,97))
    for i,di in enumerate(D):check('quadratic form symmetric '+NAMES[i],np.array_equal(di,di.T))
    check('shared input00/target00 second moment identically zero',not np.any(D[0]))
    sm=sp.Matrix(flat.tolist())
    independent=list(sm.T.rref()[1]);rank=len(independent)
    basis=sm[independent,:];pivots=list(basis.rref()[1]);minor=basis[:,pivots]
    determinant=minor.det();check('independent polynomial minor nonzero',determinant!=0)
    relations=sm[:,pivots]*minor.inv()
    check('all polynomial components reconstructed exactly',relations*basis==sm)
    rng=np.random.default_rng(2026100603);probes=[]
    for k in range(3):
        theta=rng.integers(-2,3,size=97);J=np.einsum('kab,b->ka',D[independent],theta)
        sj=sp.Matrix(J.tolist());jr=sj.rank()
        probes.append({'integer_theta':theta.tolist(),'Jacobian_rank_exact':jr})
        check('integer-probe Jacobian rank bounded by polynomial rank '+str(k),jr<=rank)
        check('integer-probe Jacobian achieves full polynomial rank '+str(k),jr==rank)
    # A zero first moment for X_z gives a unit coordinate in this integer kernel.
    z=labels.index('IIIIIX');columns=[j for j in range(97) if np.count_nonzero(B[:,j])==1 and B[z,j] in [-1,1]]
    assert columns;theta=np.zeros(97,dtype=np.int64);theta[columns[0]]=int(B[z,columns[0]])
    check('X_z exact kernel seed',np.array_equal(B@theta,np.eye(108,dtype=np.int64)[z]))
    xz_m=np.einsum('a,kab,b->k',theta,D,theta)
    check('X_z lies on full second-moment zero set',not np.any(xz_m))
    xzj=sp.Matrix(np.einsum('kab,b->ka',D[independent],theta).tolist());xzrank=xzj.rank()
    check('X_z feasible control is rank deficient',xzrank==13 and xzrank<rank)
    check('origin Jacobian vanishes',not np.any(np.einsum('kab,b->ka',D,np.zeros(97,dtype=int))))
    # Independent direct matrix checks at integer probes avoid self-validation
    # by a second evaluation of the same quadratic expression.
    for k,p in enumerate(probes):
        t=np.array(p['integer_theta']);H=np.einsum('a,aij->ij',t,F)
        M=(H@E).conj().T@(H@E)-(H@W).conj().T@(H@W)
        actual=[]
        for i in range(4):
            for j in range(i,4):
                actual.append(M[i,j].real)
                if i!=j:actual.append(M[i,j].imag)
        value=np.einsum('a,kab,b->k',t,D,t)/2
        check('integer quadratic forms equal direct full-domain products '+str(k),np.array_equal(value,np.array(actual)))
    receipt={'status':'EXACT integer quadratic geometry; no global endpoint or regularity claim','components':16,'kernel_coordinates':97,'polynomial_row_rank_exact':rank,'independent_components':independent,'component_names':NAMES,'independent_minor_columns':pivots,'independent_minor_determinant':str(determinant),'all_component_relations_exact':[[str(v) for v in row] for row in relations.tolist()],'integer_Jacobian_probes':probes,'X_z_kernel_coordinates':theta.tolist(),'X_z_Jacobian_rank_exact':xzrank,'origin_Jacobian_rank_exact':0,'exact_count':len(checks),'checks':checks,'geometry_scope':'Polynomial row independence does not guarantee Jacobian independence at every point or smoothness of the zero fiber. X_z is a feasible all-moment counterexample, not an encoder.'}
    (R/'results'/'MOMENT_GEOMETRY.json').write_text(json.dumps(receipt,indent=2))
    np.savez_compressed(R/'results'/'MOMENT_FORMS.npz',twice_quadratic_forms=D)
    print({k:receipt[k] for k in ['polynomial_row_rank_exact','independent_components','X_z_Jacobian_rank_exact','exact_count']},flush=True)
if __name__=='__main__':main()
