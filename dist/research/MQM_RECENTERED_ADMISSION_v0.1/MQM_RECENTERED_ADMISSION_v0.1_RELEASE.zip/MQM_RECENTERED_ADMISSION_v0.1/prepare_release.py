"""Freeze the audited successor, without modifying immutable parents."""
from pathlib import Path
import argparse,json,hashlib,zipfile,platform
import numpy,scipy,sympy,networkx,fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args();assert args.visual_review_confirmed
def read(n):return json.loads((R/n).read_text())
def write(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
names=['MOMENT_GEOMETRY.json','FROZEN_AUDIT.json','ROOT_CERTIFICATE.json','ROOT_CENTER_SPECTRAL_CERTIFICATE.json','ROOT_SPECTRAL_FLOOR.json','SHARED_RETURN_WITNESS.json']
receipts=[read('results/'+n) for n in names];total=sum(d['exact_count'] for d in receipts);assert total==252
root=receipts[2];floor=receipts[4];s=read('results/BRANCH_SEARCH.json');g=read('results/BRANCH_GRADIENT_RECEIPT.json');qa=read('results/PDF_QA.json')
assert g['columns_checked']==166 and g['max_discrepancy']<2e-6
assert s['iterations_attempted']==424 and s['accepted_steps']==309
assert floor['strict_dyadic_error_floor']=='1/16' and floor['exact_second_moment_zero']
assert qa['pages']==2 and all(qa[k] for k in ['A4','actual_IEEEtran','two_columns','no_overfull','no_unresolved_references'])
qa['visual_review']='PASSED: both final pages inspected; readable IEEE two-column layout, no clipping or overlap.';write('results/PDF_QA.json',qa)
parent=R.parent/'MQM_RETRACTED_BRANCH_SEARCH_v0.1_RELEASE.zip'
write('INPUT_ANCHORS.json',{'parent_library_zip_id':'libfile_e68f11ff80088191a58d72a4e1ccd437','parent_library_pdf_id':'libfile_ae8486c527688191b0de41c5c2745682','parent_zip_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'parent_immutable':True,'author':'Benjamin Walker Mayes','orcid':'0009-0002-5813-0724','user_instruction_amendment':'MQM_WORKING_INSTRUCTIONS_v0.3.txt; user directions apply to this task, not a platform configuration change.'})
write('CLAIM_REGISTER.json',{'exploration':{'status':'SIMULATED exploratory tuning after parent evaluation exposure','attempts':424,'accepted':309,'rejected':115,'attempt_cap':1000,'free_box_radius':4,'initial_residual':s['initial']['isometry_operator_residual'],'best_residual':s['best']['isometry_operator_residual'],'resource_gain':False,'stationarity_or_global_optimum':False},'root':{'status':'EXACT / AUTO_LOCK scoped','first_second_moments_exact':True,'root_type':'Unique implicitly defined real algebraic root in a fixed rational slice box','box_radius':root['box_radius_inf'],'dependent_coordinates':15,'fixed_coordinates':82,'local_zero_manifold_dimension':82,'deadline_upper':root['root_Pauli_norm_upper'],'full_norm_budget':1,'all_time_half_diamond_floor':'strictly greater than1/16','scope':'One selected root; not planar-family no-go or path certification'},'complete_admission':{'status':'OPEN','target':'1/65536 on nonzero readout window','certified_encoder':False,'SWAP_composition':'gated'},'scoped_exact_checks':252,'numerical_derivative_checks':166,'physical_promotion':0,'independent_review':'pending','novelty_comparison':'pending'})
write('NEXT_GATE.json',{'status':'OPEN','recommended':'Independent regular-chart exploration with spectral-overlap screening alongside coherent endpoint optimization','reason':'Two successive local searches yield small residual gains while increasing conservative execution-time ledger; another same-basin recenter is low value.','constraints':'Six physical qubits, ten allowed pairs; all64 dimensions; norm<=1, conservative deadline<=512','development_policy':'Freeze new seeds, initialization/chart-selection policy and tuning budgets before running; mark exposed tuning exploratory.','strengthening_test':'Separate rational root certificate and all-time spectral audit; a selected candidate must overcome the projector floor before attempting a complete readout-window certificate.','success':'Complete half-diamond error<=1/65536 on a nonzero window with all spectator correlations preserved','failure_scope':'Frozen roots only; no family exclusion from finite failed exploration','trajectory_score':84,'score_type':'Prioritization judgment for architecture feasibility and reproducible performance; not measured closure percentage','adjacent_frontier':'Explore expanded multi-excitation admission carrier if matched-budget independent charts remain unproductive; new model needs its own interface and resource contract.'})
write('ARITHMETIC_COUNTS.json',{'physical_dimension':'64=2^6','kernel_coordinates':'97 is prime','free_coordinates':'82=2*41','free_plus_phase':'83 is prime','attempts':'424=2^3*53','accepted':'309=3*103','rejected':'115=5*23','exact_checks':'252=2^2*3^2*7','derivative_checks':'166=2*83','target_denominator':'65536=2^16','deadline_cap':'512=2^9','scope':'Counts have separate provenance; factorization is bookkeeping, not geometric evidence.'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'networkx':networkx.__version__,'pymupdf':fitz.VersionBind})
(R/'README.txt').write_text('''Recentered Planar Joint Admission: A Scoped Search and Full-Spectrum Audit
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM v0.1

RESULT
Recentered exploratory search:424 attempts,309 accepted,115 rejected.
Sampled residual0.222881819 ->0.222846101. Conservative norm<=1 deadline
increases358.894545 ->373.851497: no resource gain. The newly certified
regular algebraic root exactly matches first/second moments but has complete
half-diamond error>1/16 at EVERY deadline. Target1/65536 remains OPEN.
This excludes one root, not the planar family. No stationarity/global optimum,
encoder, fault tolerance, hardware evidence or comparative advantage claimed.
Physical promotion0; independent review and novelty comparison pending.
252 scoped exact checks (including rerun inherited checks),166 numerical
derivative checks. This is not252 new theorems or an independent evaluation.

CERTIFICATE REPLAY (numpy,scipy,sympy,networkx)
  python3 moment_geometry.py
  python3 verify_frozen.py
  python3 certify_root.py
  python3 spectral_certificate.py --root-center
  python3 certify_root_spectral_floor.py
  python3 shared_return_witness.py
Numerical Newton/eigenvectors propose data; rational contraction and exact
Gaussian-integer residuals establish scoped conclusions. The dyadic center
is not the implicitly algebraic root; its root-box debit is charged.

OPTIONAL SEARCH (overwrites receipts; repeat all certificates afterward)
  python3 search_branch.py
Protocol was declared before this successor run but after parent exposure.
New center,free radius4,cap1000 are disclosed tuning. No independent prediction.
Initial reference is the parent's certified center, not a rational root claim.
EXPLORATION_PROTOCOL.json records acceptance and rollback boundaries.

PDF (pdflatex,IEEEtran,balance,PyMuPDF)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png before:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two columns. Class license included.
NEXT_GATE.json recommends independent regular regions rather than endless
same-basin recentering. Native admission closes before encoded SWAP composition.
User instruction amendment is captured in MQM_WORKING_INSTRUCTIONS_v0.3.txt.
Parent releases immutable. SHA256SUMS.txt covers distributed files.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'pages':qa['pages'],'exact_checks':total}))
