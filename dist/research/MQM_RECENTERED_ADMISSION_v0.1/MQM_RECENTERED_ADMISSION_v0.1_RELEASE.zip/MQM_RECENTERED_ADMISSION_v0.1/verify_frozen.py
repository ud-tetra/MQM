"""Exact coefficient-assembly and complete-domain admission audit."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json
import numpy as np
import networkx as nx
from complex_objective import load_model
R=Path(__file__).resolve().parent
source,labels,B,P,F,E,W=load_model()
best=json.loads((R/'results'/'BRANCH_SEARCH.json').read_text())['best']
theta=[Q(v) for v in best['kernel_coordinates_exact']]
coeff=[Q(best['Pauli_coefficients_exact'][l]) for l in labels]
checks=[]
def check(name,condition):
    assert condition,name
    checks.append(name)
for l,row,c in zip(labels,B,coeff):
    check('integer-kernel coefficient '+l,c==sum((int(b)*t for b,t in zip(row,theta)),Q(0)))
den=max(c.denominator for c in coeff)
HR=np.zeros((64,64),dtype=object);HI=HR.copy()
for c,p in zip(coeff,P):
    n=c.numerator*(den//c.denominator)
    HR+=np.rint(p.real).astype(int).astype(object)*n
    HI+=np.rint(p.imag).astype(int).astype(object)*n
ss=[8,24,40,56];tt=[8,4,2,1]
check('complete-domain Hermitian real block',np.array_equal(HR,HR.T))
check('complete-domain Hermitian imaginary block',np.array_equal(HI,-HI.T))
check('exact first-moment real block',np.array_equal(HR[np.ix_(ss,ss)],HR[np.ix_(tt,tt)]))
check('exact first-moment imaginary block',np.array_equal(HI[np.ix_(ss,ss)],HI[np.ix_(tt,tt)]))
check('input isometry',np.array_equal(E.conj().T@E,np.eye(4)))
check('target isometry',np.array_equal(W.conj().T@W,np.eye(4)))
pairs=[(0,2),(0,4),(0,5),(1,2),(1,3),(1,4),(1,5),(2,4),(2,3),(4,5)]
g=nx.Graph();g.add_nodes_from(range(6));g.add_edges_from(pairs)
check('permitted graph planar',nx.check_planarity(g)[0])
check('permitted graph maximum degree four',max(dict(g.degree()).values())==4)
check('all frozen nonzero terms have support at most two on permitted pairs',all(len(s:=[k for k,x in enumerate(l) if x!='I'])<=2 and (len(s)<2 or tuple(s) in pairs) for l,c in zip(labels,coeff) if c))
check('nonzero exact full-spectrum Pauli norm budget',sum(abs(c) for c in coeff)>0)
check('exact conservative unit-norm deadline does not exceed declared 512 cap',sum(abs(c) for c in coeff)<=512)
check('same input and target source indices retained',ss==[8,24,40,56] and tt==[8,4,2,1])
H2R=HR@HR-HI@HI;H2I=HR@HI+HI@HR
M2R=H2R[np.ix_(ss,ss)]-H2R[np.ix_(tt,tt)]
M2I=H2I[np.ix_(ss,ss)]-H2I[np.ix_(tt,tt)]
check('second-moment difference real block symmetric',np.array_equal(M2R,M2R.T))
check('second-moment difference imaginary block skew-symmetric',np.array_equal(M2I,-M2I.T))
L=sum(abs(c) for c in coeff)
floors=[abs(Q(int(M2R[j,j]),den**2))/(2*L**2) for j in range(4)]
for j,v in enumerate(floors):check('exact basis second-moment witness nonnegative '+str(j),v>=0)
receipt={'status':'EXACT, scoped to frozen best kernel combination','exact_count':len(checks),'checks':checks,'Pauli_norm_upper':str(L),'second_moment_real_exact':[[str(Q(int(x),den**2)) for x in row] for row in M2R],'second_moment_imaginary_exact':[[str(Q(int(x),den**2)) for x in row] for row in M2I],'basis_second_moment_all_time_error_floors':[str(v) for v in floors],'largest_basis_moment_floor_diagnostic':float(max(floors)),'exact_second_moment_zero':bool(np.all(M2R==0) and np.all(M2I==0)),'moment_witness_proof':'For normalized generator G/L, ||(G/L)^2||<=1. Its expectation is conserved during evolution. Trace duality gives D_tr>=abs(input-target H^2 expectation difference)/(2 L^2). This is a basis-input witness, hence also a complete-channel lower bound.','full_dimension':64,'logical_dimension':4,'physical_qubits':6,'allowed_pairs':10,'physical_promotion':0}
(R/'results'/'FROZEN_AUDIT.json').write_text(json.dumps(receipt,indent=2))
print({'exact_count':len(checks),'Pauli_norm_upper_decimal':float(sum(abs(c) for c in coeff))})
