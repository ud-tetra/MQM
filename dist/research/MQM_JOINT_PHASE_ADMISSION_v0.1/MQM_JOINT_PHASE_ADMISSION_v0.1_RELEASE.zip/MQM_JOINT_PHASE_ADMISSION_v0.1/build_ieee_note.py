"""Build actual IEEEtran A4 joint-phase note; render all pages for QA."""
from pathlib import Path
from fractions import Fraction as Q
import json,subprocess
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript'
def read(n):return json.loads((R/'results'/n).read_text())
s=read('JOINT_SEARCH.json');g=read('JOINT_GRADIENT_RECEIPT.json');a=read('FROZEN_AUDIT.json');c=read('SPECTRAL_CERTIFICATE.json')
rows='\n'.join(f"{r['run']} & {r['orientation_weight']:.2f} & {r['isometry_operator_residual']:.6f} & {float(Q(r['Pauli_norm_upper_exact'])):.3f} \\\\" for r in s['runs'])
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\begin{document}
\title{Finite-Budget Joint Phase Optimization\\for a Planar Qubit-Admission Interface}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 6, 2026. ORCID: 0009-0002-5813-0724. Scoped conditional derivation and finite search; independent review and theorem-level novelty comparison pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We execute a finite-budget joint endpoint and spectral-orientation continuation for a six-qubit planar admission interface. The inherited 97-coordinate Hermitian first-moment kernel is retained. A conservative Pauli-norm budget guarantees a full-domain unit-norm implementation with deadline at most 512 for each frozen feasible fit. Four bounded searches improve the sampled common-phase operator residual from approximately 0.329 to @BEST@. This is not a certified endpoint or resource improvement. Exact binary-rational assembly and Gaussian-integer spectral enclosures instead exclude the selected fit at every deadline: complete half-diamond error is strictly greater than $1/16$. The release supplies 199 scoped exact checks, 490 numerical derivative checks, refreshed MQM governance and a second-moment-manifold handoff. Joint admission remains open; no planar-family impossibility is inferred.
\end{abstract}
\begin{IEEEkeywords}
Autonomous control, joint admission, two-local Hamiltonian, bounded optimization, spectral certification.
\end{IEEEkeywords}
\section{Contract and fixed physical domain}
Order six physical qubits as $(A,O,u,v,w,z)$, with mode labels $(00,01,10,11)$. Define four-column isometries
\begin{align}
E\ket{ab}&=\ket{ab}_{AO}\ket{\mathbf1_{00}}_M,\\
W\ket{ab}&=\ket{00}_{AO}\ket{\mathbf1_{ab}}_M.
\end{align}
The target requires one common phase on all coherent logical inputs, including arbitrary spectator entanglement. Basis populations alone do not close this contract. Single excitation is required at the endpoint, not necessarily during transit.

Allowed pairs remain
\begin{equation}
\{Au,Aw,Az,Ou,Ov,Ow,Oz,uw,uv,wz\}.
\end{equation}
This graph is planar with maximum degree four. Its 108 nonidentity support-at-most-two Pauli terms include one-body fields. The inherited integer kernel $B\in\mathbb Z^{108\times97}$ enforces
\begin{equation}
E^\dagger GE=W^\dagger GW,\qquad
G(\theta)=\sum_k(B\theta)_kP_k.
\end{equation}
The constraint rank is eleven. The 97 real Hermitian coordinates split into 55 real-entry and 42 imaginary-entry directions, not physical qubits. The preceding study \cite{parent} improved spectral orientation alone without completing phase matching. This note resumes the coherent endpoint obligation. No gravitational or gauge-theory correspondence is derived.

\section{Declared finite deadline and full norm}
The optimization uses accumulated generator $G$, not an already normalized Hamiltonian. Write $c=B\theta$ and
\begin{equation}
L=\sum_k|c_k|,\qquad H=G/L,\qquad T=L.
\end{equation}
For $L>0$, $\|H\|\le1$ on all 64 physical dimensions and $e^{-iTH}=e^{-iG}$. Thus $L\le512$ certifies a finite unit-norm deadline. This conservative Pauli budget is not the optimal centered spectral norm; comparisons must retain that distinction.

The differentiable search constraint is
\begin{equation}
L_s=\sum_k\sqrt{c_k^2+\ell^2}\le512,\qquad\ell=10^{-8}.
\end{equation}
Since $L\le L_s$, it is conservative. Floating feasibility is not the certificate: frozen $L$ is separately audited using exact fractions. For slack $h=1-L_s/512$,
\begin{equation}
\partial_a h=-\frac1{512}\sum_k
\frac{c_kB_{ka}}{\sqrt{c_k^2+\ell^2}},\qquad\partial_\phi h=0.
\end{equation}

\section{Joint objective and checked derivatives}
Retain all four columns and one phase:
\begin{equation}
R=e^{-iG(\theta)}E-e^{i\phi}W,\qquad
f_\mu=\tfrac12\|R\|_F^2+\mu\Gamma_\tau.
\end{equation}
For resolved simple eigenvalues with projectors $\Pi_n$, define
\begin{equation}
a_n=\operatorname{Tr}(W^\dagger\Pi_nE),\qquad
\Gamma_\tau=4-\sum_n\sqrt{|a_n|^2+\tau^2},
\end{equation}
where $\tau=10^{-10}$ and $\mu\in\{0,1/50\}$. Reported $S=\sum_n|a_n|$ is unsmoothed. The bias is at most $64\tau=6.4\cdot10^{-9}$, too large to certify the ultimate orientation tolerance; this is a declared search debit.

For $G=V\Lambda V^\dagger$ and $F_a=\partial_aG$, use
\begin{equation}
\partial_a(e^{-iG}E)=V(D\odot V^\dagger F_aV)V^\dagger E,
\end{equation}
where
\begin{equation}
D_{nr}=-ie^{-i(\lambda_n+\lambda_r)/2}
\operatorname{sinc}\big((\lambda_n-\lambda_r)/2\big).
\end{equation}
Here $\operatorname{sinc}x=\sin x/x$, extended at zero, and $\partial_\phi R=-ie^{i\phi}W$. Projector differentiation for $\Gamma_\tau$ is inherited from \cite{parent}. The orientation implementation stops at unresolved simple-spectrum gaps; arbitrary eigenvectors within a degenerate eigenspace cannot receive independent physical phases.

Two resolved probes for each weight check $98\cdot2\cdot2=392$ objective-gradient columns. Another 98 check the budget derivative. With central-difference step $10^{-6}$, maximum discrepancies are @GRAD@ and @CONSTRAINT@. These are numerical implementation checks, not optimizer or endpoint certificates.

\section{Bounded search and exact selected-fit exclusion}
Four SLSQP starts have a 500-iteration cap. Runs zero and one resume the earlier endpoint fit; runs two and three initialize from the spectral fit at its preceding numerical phase-scan point. Two report optimizer success, one at the 500-iteration boundary; two terminate at the cap without success. Neither status establishes exact admission or global optimality.
\begin{table}[t]
\caption{Finite search diagnostics; $L$ is the conservative unit-norm deadline.}
\centering
\begin{tabular}{c|c|c|c}
Run & $\mu$ & $\|R\|$ & $L$\\\hline
@ROWS@
\end{tabular}
\end{table}
Run two minimizes the computed common-phase operator residual among exactly budget-feasible fits. Its Choi trace-error diagnostic is @CHOI@ and unsmoothed spectral sum is @S@. The sampled residual improvement is not a resource advantage: its conservative deadline is approximately @TIME@ and admission is incomplete.

Freeze 97 binary64 coordinates as exact binary fractions and assemble 108 coefficients through integer $B$. The structural audit checks coefficient identities, Hermiticity, exact first moments, locality, planarity, deadline feasibility and exact second-moment matrices. It contains 126 scoped exact checks. Every frozen fit has an exact $L\le512$; the full structural and spectral certificate concerns the selected fit.

\begin{proposition}[All-time exclusion of the selected fit]
The selected frozen generator has complete half-diamond admission error strictly greater than $1/16$ at every deadline, including scalar shifts and uniform norm rescaling.
\end{proposition}
\begin{proof}
For true spectral projectors put $S=\sum_\lambda|\operatorname{Tr}(W^\dagger\Pi_\lambda E)|$. A maximally entangled four-dimensional logical/reference input gives all-time error at least $\sqrt{1-(S/4)^2}$. Exact Gaussian-integer Gram and eigen residuals bound backward error of dyadic eigensolver outputs; a certified grid gap identifies the true simple projectors. Integer square-root enclosures yield rational $S_{\rm up}$ satisfying
\begin{equation}
S\le S_{\rm up},\qquad
1-(S_{\rm up}/4)^2>(1/16)^2.
\end{equation}
All 73 spectral checks pass. The radical diagnostic is @FLOOR@, an enclosed lower bound, not the exact channel distance. Scalar shifts and uniform nonzero rescaling preserve projectors and cannot defeat this witness.
\end{proof}
This excludes one generator, not the planar family. Waiting longer cannot repair this frozen fit.

\section{Next nonlinear gate and refreshed governance}
The selected fit has nonzero exact second-moment mismatch
\begin{equation}
M_2=E^\dagger G^2E-W^\dagger G^2W\ne0.
\end{equation}
Conservation of the expectation of $(G/L)^2$, its norm at most one, and trace duality give a basis-input all-time witness
\begin{equation}
D_{\rm tr}\ge |(M_2)_{jj}|/(2L^2).
\end{equation}
The largest basis diagnostic is @MOMENT@, weaker than the spectral bound. The complete rational matrix is supplied for the next exact nonlinear second-moment-manifold continuation. Enforcing $M_2=0$ removes this particular mismatch; it is still insufficient without projector orientation and one common finite phase deadline. A finite search on that manifold is not a family proof.

The instruction block v0.2 separates constructor search from proof, charges smoothing and degeneracy, retains complete-input contracts and immutable parent releases, and fixes IEEEtran A4 two-column publication formatting. It is a working convention, not a platform-level settings mutation. Native joint admission must close at error at most $2^{-16}$ on a nonzero readout window with an audited full norm and finite deadline before connection to the encoded SWAP core. The publication target remains a matched operational resource improvement or informative lower bound across competing architectures. Neither is claimed here. Independent review is pending; physical promotion remains zero.
\begin{thebibliography}{1}
\bibitem{parent} B. W. Mayes, ``Spectral Orientation Before Phase Matching for Autonomous Joint Qubit Admission,'' MQM development note v0.1, Oct. 6, 2026, immutable replay release. DOI not assigned; independent review pending.
\end{thebibliography}
\end{document}
'''
values={'BEST':f"{s['best']['isometry_operator_residual']:.6f}",'GRAD':f"{g['largest_objective_discrepancy']:.3g}",'CONSTRAINT':f"{g['largest_constraint_discrepancy']:.3g}",'ROWS':rows,'CHOI':f"{s['best']['Choi_trace_error_diagnostic']:.6f}",'S':f"{s['best']['S']:.9f}",'TIME':f"{float(Q(s['best']['Pauli_norm_upper_exact'])):.3f}",'FLOOR':f"{c['floor_decimal_diagnostic']:.6f}",'MOMENT':f"{a['largest_basis_moment_floor_diagnostic']:.3g}"}
for k,v in values.items():tex=tex.replace('@'+k+'@',v)
name='MQM_JOINT_PHASE_ADMISSION_IEEE_A4_v0.1';(M/(name+'.tex')).write_text(tex)
for k in range(2):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,capture_output=True,text=True)
    (R/'results'/('PDF_BUILD_'+str(k)+'.txt')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout[-3000:]
doc=fitz.open(M/(name+'.pdf'));log=(M/(name+'.log')).read_text()
for i,p in enumerate(doc):p.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/('PAGE_'+str(i+1)+'.png'))
qa={'pages':len(doc),'A4':all(abs(p.rect.width-595.276)<1 and abs(p.rect.height-841.89)<1 for p in doc),'actual_IEEEtran':True,'class_options':'journal,a4paper,10pt','two_columns':True,'no_overfull':'Overfull' not in log,'no_unresolved_references':'undefined' not in log,'visual_review':'pending'}
(R/'results'/'PDF_QA.json').write_text(json.dumps(qa,indent=2));print(qa)
