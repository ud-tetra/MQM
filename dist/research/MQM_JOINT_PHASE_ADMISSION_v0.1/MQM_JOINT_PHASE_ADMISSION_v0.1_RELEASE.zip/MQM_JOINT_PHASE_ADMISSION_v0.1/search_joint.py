"""Finite joint endpoint/orientation continuation with a conservative deadline cap."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json,time
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import minimize
from complex_objective import load_model,Objective
R=Path(__file__).resolve().parent
source,labels,B,P,F,E,W=load_model()
CAP=512.;TAU=1e-10;LT=1e-8

def orientation(theta,derivative=True):
    H=np.einsum('a,aij->ij',theta,F);lam,V=eigh(H)
    gap=float(np.min(np.diff(lam)))
    if gap<1e-12*max(1.,np.max(abs(lam))):raise ValueError('Simple-spectrum orientation gradient unresolved')
    C=(V.conj().T@E)@(W.conj().T@V);a=np.diag(C)
    r=np.sqrt(abs(a)**2+TAU**2);value=4-float(sum(r))
    if not derivative:return 4-float(sum(abs(a))),gap,lam,V
    A=np.einsum('ia,kij,jb->kab',V.conj(),F,V,optimize=True)
    denominator=lam[:,None]-lam[None,:];np.fill_diagonal(denominator,np.inf)
    da=np.sum((A*C.T[None,:,:]+A.transpose(0,2,1)*C[None,:,:])/denominator[None,:,:],axis=2)
    grad=-np.real(np.sum(da*a.conj()[None,:]/r[None,:],axis=1))
    return value,grad

class Joint:
    def __init__(self,weight):self.endpoint=Objective(B,F,E,W);self.weight=weight
    def __call__(self,x):
        r,j=self.endpoint.evaluate(x);value=float(r@r/2);grad=j.T@r
        if self.weight:
            deficit,derivative=orientation(x[:-1]);value+=self.weight*deficit;grad[:-1]+=self.weight*derivative
        return value,grad
def constraint(x):
    c=B@x[:-1];r=np.sqrt(c*c+LT*LT)
    return 1-float(sum(r))/CAP
def constraint_grad(x):
    c=B@x[:-1];return np.r_[-(B.T@(c/np.sqrt(c*c+LT*LT)))/CAP,0.]
def freeze(x):
    q=[Q(float(v)) for v in x[:-1]]
    coeff=[sum((int(b)*v for b,v in zip(row,q)),Q(0)) for row in B]
    return {l:str(v) for l,v in zip(labels,coeff)}
def main():
    parent=json.loads((R/'PARENT_ENDPOINT_SEARCH.json').read_text())['best']
    theta=np.array([float(Q(v)) for v in parent['kernel_coordinates_exact']]);xp=np.r_[theta,parent['phase']]
    spectral=json.loads((R/'PARENT_ALIGNMENT_SEARCH.json').read_text())['best']
    ts=np.array(spectral['theta']);H=np.einsum('a,aij->ij',ts,F);lam,V=eigh(H)
    radius=(lam[-1]-lam[0])/2;ts*=287.01003208002527/radius
    val,V=eigh(np.einsum('a,aij->ij',ts,F));UE=V@(np.exp(-1j*val)[:,None]*(V.conj().T@E))
    xs=np.r_[ts,np.angle(np.trace(W.conj().T@UE))]
    rng=np.random.default_rng(2026100602)
    errors=[];constraint_errors=[]
    for weight in [0.,.02]:
        obj=Joint(weight)
        for x in [xp,xp+.01*rng.normal(size=98)]:
            _,g=obj(x);h=1e-6
            for k in range(98):
                step=np.zeros(98);step[k]=h
                errors.append(abs((obj(x+step)[0]-obj(x-step)[0])/(2*h)-g[k]))
    cg=constraint_grad(xp)
    for k in range(98):
        step=np.zeros(98);step[k]=1e-6
        constraint_errors.append(abs((constraint(xp+step)-constraint(xp-step))/(2e-6)-cg[k]))
    assert max(errors)<2e-6,max(errors)
    assert max(constraint_errors)<2e-8,max(constraint_errors)
    (R/'results'/'JOINT_GRADIENT_RECEIPT.json').write_text(json.dumps({'endpoint_orientation_columns':392,'constraint_columns':98,'largest_objective_discrepancy':max(errors),'largest_constraint_discrepancy':max(constraint_errors),'step':1e-6,'orientation_weights':[0.,.02],'status':'NUMERICAL implementation checks'},indent=2))
    runs=[]
    for i,(x,weight,kind) in enumerate([(xp,0.,'endpoint_parent'),(xp,.02,'endpoint_parent'),(xs,0.,'spectral_parent_phase_scan'),(xs,.02,'spectral_parent_phase_scan')]):
        assert constraint(x)>0
        obj=Joint(weight);start=time.monotonic()
        fit=minimize(obj,x,jac=True,method='SLSQP',constraints=[{'type':'ineq','fun':constraint,'jac':constraint_grad}],options={'maxiter':500,'ftol':1e-12})
        r,_=obj.endpoint.evaluate(fit.x);complexR=r[:256].reshape(64,4)+1j*r[256:512].reshape(64,4)
        deficit,gap,lam,V=orientation(fit.x[:-1],derivative=False)
        coeff=freeze(fit.x);L=sum((abs(Q(v)) for v in coeff.values()),Q(0))
        UE=V@(np.exp(-1j*lam)[:,None]*(V.conj().T@E))
        choi=float(np.sqrt(max(0.,1-abs(np.trace(W.conj().T@UE)/4)**2)))
        run={'run':i,'seed_type':kind,'orientation_weight':weight,'success':bool(fit.success),'message':str(fit.message),'iterations':int(fit.nit),'evaluations':int(fit.nfev),'seconds':time.monotonic()-start,'cost':float(fit.fun),'isometry_operator_residual':float(np.linalg.norm(complexR,2)),'Choi_trace_error_diagnostic':choi,'S':4-deficit,'minimum_gap_diagnostic':gap,'smooth_budget_slack':constraint(fit.x),'Pauli_norm_upper_exact':str(L),'strict_deadline_cap_exact':L<=512,'kernel_coordinates_exact':[str(Q(float(v))) for v in fit.x[:-1]],'phase':float(fit.x[-1]),'Pauli_coefficients_exact':coeff}
        runs.append(run)
        receipt={'seed':2026100602,'scope':'FINITE NUMERICAL exploration, not global optimum or endpoint certificate','starts':4,'iteration_cap':500,'unit_full_norm_deadline_cap':512,'budget':'sum sqrt(c_k^2+1e-16)<=512; exact frozen sum |c_k| audited separately','smoothing_bias_upper':64e-10,'runs':runs,'best':min([r for r in runs if r['strict_deadline_cap_exact']],key=lambda r:r['isometry_operator_residual'])}
        (R/'results'/'JOINT_SEARCH.json').write_text(json.dumps(receipt,indent=2))
        print({k:run[k] for k in ['run','iterations','isometry_operator_residual','Choi_trace_error_diagnostic','S','strict_deadline_cap_exact','seconds']},flush=True)
if __name__=='__main__':main()
