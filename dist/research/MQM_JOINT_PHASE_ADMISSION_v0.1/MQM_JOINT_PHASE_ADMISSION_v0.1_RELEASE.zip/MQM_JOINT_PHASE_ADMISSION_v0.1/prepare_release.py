"""Freeze verified successor, refreshed project instructions and replay code."""
from pathlib import Path
from fractions import Fraction as Q
import argparse,json,hashlib,zipfile,platform
import numpy,scipy,networkx,fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args()
assert args.visual_review_confirmed,'Inspect every current PDF page before freezing.'
def read(n):return json.loads((R/n).read_text())
def write(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
s=read('results/JOINT_SEARCH.json');a=read('results/FROZEN_AUDIT.json');c=read('results/SPECTRAL_CERTIFICATE.json');g=read('results/JOINT_GRADIENT_RECEIPT.json');qa=read('results/PDF_QA.json')
assert qa['pages']==2 and qa['A4'] and qa['actual_IEEEtran'] and qa['no_overfull'] and qa['no_unresolved_references']
assert len(s['runs'])==4 and all(Q(r['Pauli_norm_upper_exact'])<=512 for r in s['runs'])
assert c['strict_dyadic_channel_floor']=='1/16' and c['best_run']==s['best']['run']==2
assert a['exact_count']+c['exact_count']==199 and not a['exact_second_moment_zero']
qa['visual_review']='PASSED: both final IEEE/A4 page renders inspected, equations and table readable, no clipping or overlap'
write('results/PDF_QA.json',qa)
parent=R.parent/'MQM_SPECTRAL_ALIGNMENT_ADMISSION_v0.1_RELEASE.zip'
write('INPUT_ANCHORS.json',{'parent_library_zip_id':'libfile_7481c999abb48191a9e30765581e3369','parent_library_pdf_id':'libfile_ea63fd3ad8dc8191ada73203c818af0a','parent_zip_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'parent_immutable':True,'author':'Benjamin Walker Mayes','orcid':'0009-0002-5813-0724','instruction_refresh_source':'Visible project governance and immutable preceding computational handoff; current constructor safeguards added. No platform-level setting mutation.','user_task':'Refresh chat instruction block and continue next steps.'})
write('CLAIM_REGISTER.json',{'instruction_block':{'version':'0.2','status':'Refreshed and adopted as project working conventions','source_boundary':'Does not override platform instructions or authorization boundaries'},'joint_objective':{'status':'DERIVED, implementation numerically checked','complete_columns':4,'common_phase':True,'objective_columns_checked':392,'constraint_columns_checked':98,'largest_objective_gradient_discrepancy':g['largest_objective_discrepancy'],'largest_constraint_gradient_discrepancy':g['largest_constraint_discrepancy']},'finite_search':{'status':'NUMERICAL, finite exploration only','starts':4,'iteration_cap':500,'deadline_cap':512,'best_sampled_operator_residual':s['best']['isometry_operator_residual'],'global_optimum':False,'certified_endpoint':False,'operational_resource_improvement':False},'norm_budget':{'status':'EXACT SCOPED','implementation':'H=G/L, deadline T=L, L=sum abs(exact Pauli coefficient)','full_norm_upper':1,'all_frozen_L_at_most':512,'selected_exact_L':a['Pauli_norm_upper'],'physical_dimension':64},'all_time_selected_candidate_exclusion':{'status':'EXACT ENCLOSED / AUTO_LOCK SCOPED','half_diamond_error':'strictly greater than 1/16','scope':'Selected frozen binary-rational fit; arbitrary deadline, common phase, spectator entanglement, scalar shifts and uniform scaling. Not a planar-family no-go.','spectral_exact_checks':73},'second_moment':{'status':'EXACT selected fit does not satisfy M2=0','matrix_supplied':True,'scope':'Necessary endpoint condition only; moment equality alone is insufficient.'},'total_scoped_exact_checks':199,'joint_admission':'OPEN','physical_promotion':0,'independent_review':'pending','theorem_level_novelty_comparison':'pending'})
write('NEXT_GATE.json',{'status':'OPEN','target':'Nonlinear exact second-moment manifold continuation, then complete deadline/window certification','interface':'Six-qubit four-mode carrier with all four logical columns and arbitrary spectators','constraints':['Retain declared planar ten-pair graph and first-moment integer kernel initially.','Enforce full Hermitian 4x4 M2=E^dagger G^2E-W^dagger G^2W=0 as nonlinear constraints; audit rank rather than assuming sixteen independent conditions.','Keep one common phase and a declared finite deadline/norm budget; compare against current and preceding endpoint baselines.','Do not infer sufficiency from moment equality, even if all compressed moments match.','Use true grouped spectral projectors if eigenvalues merge.','Certify frozen coefficients, full physical norm, complete error<=2^-16 and a nonzero readout window before promotion.'],'search_policy':'Finite failure excludes only frozen candidates. Do not revisit the selected failed generator merely at later times. No automatic graph/carrier abandonment.','publication_target':'Matched operational resource saving or informative architecture-comparison lower bound','downstream_gate':'Native joint admission remains prerequisite to connection with the 16-mode SWAP core.'})
write('ARITHMETIC_COUNTS.json',{'deadline_cap':'512=2^9','target_error_denominator':'65536=2^16','strict_all_time_error_floor_denominator':'16=2^4','physical_dimension':'64=2^6','logical_dimension':'4=2^2','kernel_dimension':'97 is prime','total_exact_checks':'199 is prime','gradient_columns':'490=2*5*7^2','scope':'Typed accounting counts; prime decomposition does not infer a physical identity.'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'networkx':networkx.__version__,'pymupdf':fitz.VersionBind})
(R/'README.txt').write_text('''Finite-Budget Joint Phase Optimization for a Planar Qubit-Admission Interface
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM note v0.1

INSTRUCTIONS
MQM_PROJECT_RESPONSE_INSTRUCTIONS_v0.2.txt is the refreshed reusable project
block. It is adopted as working conventions, not a platform settings change.

RESULT
Four constrained joint endpoint/orientation fits improve the sampled operator
residual to 0.21778889718537925. No endpoint at target error is certified.
The exact selected fit is excluded at every deadline: half-diamond error >1/16.
This is not a planar-family no-go. Its exact second-moment matrix is nonzero.
All four frozen fits satisfy exact L=sum|c_k|<=512; H=G/L has full norm<=1
with deadline T=L. Selected L is approximately 353.694849, not a clock time
in physical seconds. Improved residual is not an operational resource saving.
199 scoped exact checks; 392 objective and 98 constraint derivative checks.
Independent review/novelty comparison pending. Physical promotion 0.

CERTIFICATE REPLAY (numpy, scipy, networkx)
  python3 verify_frozen.py
  python3 spectral_certificate.py
Exact kernel assembly, full-domain Pauli norm, second-moment matrix, dyadic
Gram/eigen residuals and spectral-projector enclosures. No re-optimization needed.

OPTIONAL RE-OPTIMIZATION (overwrites numerical receipts)
  python3 search_joint.py
  python3 verify_frozen.py
  python3 spectral_certificate.py
Four starts, SLSQP, 500 iterations each, declared cap 512, weights 0 and 1/50.
Simple-spectrum orientation calculus; stop at unresolved gaps. Additional Pauli
components remain charged. Library versions can change finite numerical fits.
Floating success is not endpoint proof; rerun all audits after any change.

PDF (PyMuPDF, pdflatex)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png files before freezing:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two-column PDF; class license bundled.

NEXT
Read NEXT_GATE.json: constrain the nonlinear second-moment manifold before
further continuation. Check actual constraint rank. Matching moments alone does
not prove spectral orientation or a common finite deadline. Native admission
must close before composing the encoded SWAP core. Parent releases immutable.
SHA256SUMS.txt covers all distributed artifacts except itself.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'pages':qa['pages'],'exact_checks':199}))
