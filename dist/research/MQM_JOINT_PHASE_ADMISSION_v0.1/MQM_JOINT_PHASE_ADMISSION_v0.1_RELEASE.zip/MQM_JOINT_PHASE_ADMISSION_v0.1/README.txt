Finite-Budget Joint Phase Optimization for a Planar Qubit-Admission Interface
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM note v0.1

INSTRUCTIONS
MQM_PROJECT_RESPONSE_INSTRUCTIONS_v0.2.txt is the refreshed reusable project
block. It is adopted as working conventions, not a platform settings change.

RESULT
Four constrained joint endpoint/orientation fits improve the sampled operator
residual to 0.21778889718537925. No endpoint at target error is certified.
The exact selected fit is excluded at every deadline: half-diamond error >1/16.
This is not a planar-family no-go. Its exact second-moment matrix is nonzero.
All four frozen fits satisfy exact L=sum|c_k|<=512; H=G/L has full norm<=1
with deadline T=L. Selected L is approximately 353.694849, not a clock time
in physical seconds. Improved residual is not an operational resource saving.
199 scoped exact checks; 392 objective and 98 constraint derivative checks.
Independent review/novelty comparison pending. Physical promotion 0.

CERTIFICATE REPLAY (numpy, scipy, networkx)
  python3 verify_frozen.py
  python3 spectral_certificate.py
Exact kernel assembly, full-domain Pauli norm, second-moment matrix, dyadic
Gram/eigen residuals and spectral-projector enclosures. No re-optimization needed.

OPTIONAL RE-OPTIMIZATION (overwrites numerical receipts)
  python3 search_joint.py
  python3 verify_frozen.py
  python3 spectral_certificate.py
Four starts, SLSQP, 500 iterations each, declared cap 512, weights 0 and 1/50.
Simple-spectrum orientation calculus; stop at unresolved gaps. Additional Pauli
components remain charged. Library versions can change finite numerical fits.
Floating success is not endpoint proof; rerun all audits after any change.

PDF (PyMuPDF, pdflatex)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png files before freezing:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two-column PDF; class license bundled.

NEXT
Read NEXT_GATE.json: constrain the nonlinear second-moment manifold before
further continuation. Check actual constraint rank. Matching moments alone does
not prove spectral orientation or a common finite deadline. Native admission
must close before composing the encoded SWAP core. Parent releases immutable.
SHA256SUMS.txt covers all distributed artifacts except itself.
