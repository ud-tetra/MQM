from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json,sys
import numpy as np
sys.set_int_max_str_digits(30000)
P=Path(__file__).resolve().parent
p=json.loads((P/'PROTOCOL.json').read_text())
L=p['chain_sites']; z=p['sector_norm_ceiling']*p['source']['T']
# Ratio of successive positive terms is at most z/(L+1).
tail=F(z**L,factorial(L))/(1-F(z,L+1))
debit=F(131072,31457265)*tail
assert debit<F(1,2**128)
# Save exact numerator/denominator, with a separately exact dyadic enclosure.
bits=0
while debit<F(1,2**(bits+1)):bits+=1

def control(cut):
 M=cut+2; charges=[1,1,1,1,0,2,2,2]
 states=[]
 for s,q in enumerate(charges):
  for n in range(3-q):
   from itertools import combinations_with_replacement
   for photons in combinations_with_replacement(range(M),n):
    occ=tuple(photons.count(j) for j in range(M));states.append((s,occ))
 idx={v:i for i,v in enumerate(states)};d=len(states)
 H=np.zeros((d,d),dtype=object);K=np.zeros((d,d),dtype=object)
 S=np.zeros((d,d),dtype=object);R=np.zeros((d,d),dtype=object)
 def add(a,b,v,keep=True):
  H[a,b]+=v
  if keep:K[a,b]+=v
 for col,(s,occ) in enumerate(states):
  for a,b in [(0,1),(1,2),(2,3),(5,6),(6,7)]:
   if s==a:add(idx[(b,occ)],col,1)
   if s==b:add(idx[(a,occ)],col,1)
  for lo,hi in [(4,3),(0,5),(1,6),(2,7)]:
   if s==hi:S[idx[(lo,occ)],col]=1
   if s==lo:R[idx[(hi,occ)],col]=1
   if s==hi:
    o=list(occ);o[0]+=1
    if (lo,tuple(o)) in idx:add(idx[(lo,tuple(o))],col,1)
   if s==lo and occ[0]:
    o=list(occ);o[0]-=1
    if (hi,tuple(o)) in idx:add(idx[(hi,tuple(o))],col,occ[0])
  for j in range(M-1):
   for a,b in [(j,j+1),(j+1,j)]:
    if occ[a]:
     o=list(occ);o[a]-=1;o[b]+=1
     add(idx[(s,tuple(o))],col,occ[a],j!=cut-1)
 psi=np.zeros(d,dtype=object);psi[idx[(0,(0,)*M)]]=1
 hp=[np.eye(d,dtype=object)];kp=[np.eye(d,dtype=object)]
 for n in range(cut+1):hp.append(H@hp[-1]);kp.append(K@kp[-1])
 count=0
 for n in range(cut):
  assert np.array_equal(hp[n]@psi,kp[n]@psi);count+=1
  for a in range(n+1):
   b=n-a
   for op in [S,R]:
    assert np.array_equal(hp[a]@op@hp[b]@psi,kp[a]@op@kp[b]@psi);count+=1
   for b in range(n-a+1):
    c=n-a-b
    for x,y in [(S,R),(R,S)]:
     assert np.array_equal(hp[a]@x@hp[b]@y@hp[c]@psi,kp[a]@x@kp[b]@y@kp[c]@psi);count+=1
 witness=hp[cut+1]@R@psi-kp[cut+1]@R@psi
 assert any(witness)
 return {'cut_sites':cut,'exact_equalities':count,'first_boundary_witness_degree':cut+1,'witness_nonzero':True,'control_only':True}
controls=[control(k) for k in [2,3,4]]
res={'status':'DERIVED conditional transfer, exact arithmetic checks PASS','chain_sites':L,'Q2_dimension':3+4*L+L*(L+1)//2,'complex_vector_bytes':16*(3+4*L+L*(L+1)//2),'transfer_upper_numerator':str(debit.numerator),'transfer_upper_denominator':str(debit.denominator),'exact_dyadic_upper':'1/2^'+str(bits),'target_2_minus_128_pass':True,'locality_controls':controls,'full_response_evaluated':False,'physical_promotion':0}
(P/'results/EXACT_AUDIT.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:v for k,v in res.items() if not k.startswith('transfer_upper')},indent=2))
