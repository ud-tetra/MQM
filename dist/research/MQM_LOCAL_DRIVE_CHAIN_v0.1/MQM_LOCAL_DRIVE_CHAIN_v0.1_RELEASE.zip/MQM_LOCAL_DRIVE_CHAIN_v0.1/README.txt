MQM LOCAL DRIVE CHAIN v0.1

Reproduce: python3 audit.py
Rebuild IEEE A4 PDF: python3 build_pdf.py (pdflatex, Poppler).

The exact continuum covariance remains unchanged. Only vacuum propagation is truncated in a Legendre chain. The derived response transfer bound is below2^-451 at L3072. The complete Delta2 response was not computed. This is not a thermal target, hardware, permanence, or advantage certificate. Physical promotion0.

Frozen protocol precedes evaluation. Initial Q-sector constructor indexing repair is recorded in AMENDMENT_REGISTER.json; initial failed recipe is preserved for provenance and is not the release entrypoint. Source snapshots and hashes are included. The enlarged Q2 reference has4732419 states, so implementation feasibility must still be audited. Numerical workspaces are not measured.
