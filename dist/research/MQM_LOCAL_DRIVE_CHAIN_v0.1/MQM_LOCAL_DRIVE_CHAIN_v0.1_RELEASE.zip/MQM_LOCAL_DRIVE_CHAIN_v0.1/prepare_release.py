from pathlib import Path
import json,hashlib,shutil,sys,platform,subprocess,tempfile,zipfile
import numpy as np
P=Path(__file__).resolve().parent
A=json.loads((P/'results/EXACT_AUDIT.json').read_text())
def save(name,obj):(P/name).write_text(json.dumps(obj,indent=2)+'\n')
(P/'inputs').mkdir(exist_ok=True)
anchors=[]
for parent,file in [('MQM_SPARSE_TRANSFER_v0.1','PROTOCOL.json'),('MQM_THERMAL_KERNEL_v0.1','results/THERMAL_AUDIT.json'),('MQM_FREQUENCY_BOUND_v0.1','PROTOCOL.json'),('MQM_SECOND_ORDER_SPEC_v0.1','PROTOCOL.json')]:
 src=P.parent/parent/file;dst=P/'inputs'/(parent+'_'+Path(file).name);shutil.copyfile(src,dst)
 anchors.append({'parent':parent,'source_path':file,'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'snapshot':str(dst.relative_to(P))})
save('SOURCE_ANCHORS.json',{'inputs':anchors,'prior_art':'Chin et al., J.Math.Phys.51 092109 (2010), doi10.1063/1.3490188; established mapping, no novelty claim'})
save('CLAIM_REGISTER.json',{'chain_mapping':'EXACT inherited prior art','locality_theorem':'DERIVED conditional all-size proof, pending independent review','rational_tail':'EXACT numerator-denominator audit, less than2^-451','constructor_controls':'EXACT 115 equalities plus3 boundary witnesses; finite controls only','full_second_order_response':'OPEN not evaluated','numerical_roundoff_certificate':'OPEN','thermal_target_2_minus_16':'OPEN','physical_promotion':0})
save('RESOURCE_LEDGER.json',{'chain_sites':3072,'midpoint_parent_modes':768,'representations_distinct':True,'Q2_dimension':A['Q2_dimension'],'combined_Q_le_2_dimension':A['Q2_dimension']+3072+5,'complex_binary64_vector_bytes':A['complex_vector_bytes'],'full_workspace_unmeasured':True,'physical_qubit_budget':'not compiled or certified'})
save('NEXT_GATE.json',{'target':'1/65536','unchanged_beta':'5/16','unchanged_T':16,'sufficient_condition':'half trace norm Delta2_L + delta_chain + directed numerical debit <127/2^25-2^-128','next':'Matrix-free complex restarted propagation and covariance-weighted double-commutator quadrature with directed error bounds','parallel':'Independent check of eight dyad factors and locality support; smaller certified chain bound if possible','cooling_necessity':'not established'})
save('ENVIRONMENT.json',{'python':sys.version,'numpy':np.__version__,'platform':platform.platform()})
(P/'requirements.txt').write_text('numpy=='+np.__version__+'\nPyMuPDF==1.26.6\n# pdflatex and Poppler required only for PDF rebuild\n')
(P/'README.txt').write_text('MQM LOCAL DRIVE CHAIN v0.1\n\nReproduce: python3 audit.py\nRebuild IEEE A4 PDF: python3 build_pdf.py (pdflatex, Poppler).\n\nThe exact continuum covariance remains unchanged. Only vacuum propagation is truncated in a Legendre chain. The derived response transfer bound is below2^-451 at L3072. The complete Delta2 response was not computed. This is not a thermal target, hardware, permanence, or advantage certificate. Physical promotion0.\n\nFrozen protocol precedes evaluation. Initial Q-sector constructor indexing repair is recorded in AMENDMENT_REGISTER.json; initial failed recipe is preserved for provenance and is not the release entrypoint. Source snapshots and hashes are included. The enlarged Q2 reference has4732419 states, so implementation feasibility must still be audited. Numerical workspaces are not measured.\n')
initial=(P/'audit.py').read_text().replace('if s==lo and (hi,occ) in idx:R[idx[(hi,occ)],col]=1','if s==lo:R[idx[(hi,occ)],col]=1')
(P/'audit_initial_constructor.py').write_text(initial)
with tempfile.TemporaryDirectory() as t:
 q=Path(t)
 for f in ['audit.py','PROTOCOL.json']:shutil.copyfile(P/f,q/f)
 (q/'results').mkdir()
 r=subprocess.run([sys.executable,str(q/'audit.py')],capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 assert (q/'results/EXACT_AUDIT.json').read_bytes()==(P/'results/EXACT_AUDIT.json').read_bytes()
 save('results/REPLAY_QA.json',{'fresh_directory':True,'audit_receipt_byte_identical':True,'frozen_protocol_sha256':hashlib.sha256((P/'PROTOCOL.json').read_bytes()).hexdigest(),'PDF_visual_review':'Both Poppler pages inspected; legible IEEEtran A4; no clipping or overlaps'})
files=[f for f in P.rglob('*') if f.is_file() and f.suffix not in ['.aux','.log','.out','.pyc'] and '__pycache__' not in f.parts and f.name!='SHA256SUMS']
(P/'SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(P))+'\n' for f in sorted(files)))
files.append(P/'SHA256SUMS')
z=P.parent/(P.name+'_RELEASE.zip')
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for f in sorted(files):out.write(f,str(Path(P.name)/f.relative_to(P)))
print(json.dumps({'zip':str(z),'files':len(files),'sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'fresh_replay':'PASS'},indent=2))
