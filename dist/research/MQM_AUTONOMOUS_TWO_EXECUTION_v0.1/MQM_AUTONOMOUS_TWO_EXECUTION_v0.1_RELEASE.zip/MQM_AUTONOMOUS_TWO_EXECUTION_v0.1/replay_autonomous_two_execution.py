"""Compiled finite two-execution episode; constructor verification, not independent review.

Run: OPENBLAS_NUM_THREADS=1 python3 replay_autonomous_two_execution.py
Dependencies: NumPy and SciPy. All output paths are relative to this script.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb, sin, cos, sqrt, pi, log, ceil
import csv, json, hashlib, time
import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import expm_multiply
from scipy.linalg import eigh

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
TOL=2e-10
exact=[]; numerical=[]; qualitative=[];residuals=[];started=time.perf_counter()
def ex(name,condition):
    if not condition:raise AssertionError(name)
    exact.append(name)
def qual(name,condition):
    if not condition:raise AssertionError(name)
    qualitative.append(name)
def num(name,error):
    error=float(error)
    if not np.isfinite(error) or error>TOL:raise AssertionError((name,error))
    numerical.append(name);residuals.append(error)
def upper(name,value,bound):num(name,max(0,float(value)-float(bound)))
def pure_distance(a,b):
    a=a/np.linalg.norm(a);b=b/np.linalg.norm(b)
    return float(np.linalg.norm(a-b*np.vdot(b,a)))

# Nine body qubits, in big-endian order; Y is an arbitrary spectator input reference.
names=['A','J','D1A','D1J','D2A','D2J','O1','O2','E'];qb={n:i for i,n in enumerate(names)}
BQ=len(names);BD=2**BQ;YD=2;JD=BD*YD
I=sp.eye(BD,format='csr',dtype=complex)
def bit(i,q):return (i>>(BQ-1-q))&1
def embed_one(U,q):
    rows=[];cols=[];data=[];mask=1<<(BQ-1-q)
    for c in range(BD):
        old=bit(c,q)
        for new in range(2):
            if U[new,old]!=0:
                rows.append((c & ~mask)|(new*mask));cols.append(c);data.append(U[new,old])
    return sp.csr_matrix((data,(rows,cols)),shape=(BD,BD))
def permutation_gate(kind,q,r):
    rows=[]
    for c in range(BD):
        z=c
        if kind=='SWAP' and bit(c,q)!=bit(c,r):z^=(1<<(BQ-1-q))|(1<<(BQ-1-r))
        if kind=='CNOT' and bit(c,q):z^=1<<(BQ-1-r)
        rows.append(z)
    return sp.csr_matrix((np.ones(BD), (rows,np.arange(BD))),shape=(BD,BD),dtype=complex)
H=np.array([[1,1],[1,-1]],complex)/sqrt(2)
T=np.diag([1,np.exp(1j*pi/4)])
X=np.array([[0,1],[1,0]],complex)
ops=[
 ('H(A)',embed_one(H,qb['A'])),
 ('T(A)',embed_one(T,qb['A'])),
 ('CNOT(A,J)',permutation_gate('CNOT',qb['A'],qb['J'])),
 ('SWAP(A,O1)',permutation_gate('SWAP',qb['A'],qb['O1'])),
 ('SWAP(A,D1A)',permutation_gate('SWAP',qb['A'],qb['D1A'])),
 ('SWAP(J,D1J)',permutation_gate('SWAP',qb['J'],qb['D1J'])),
 ('T(A)',embed_one(T,qb['A'])),
 ('H(A)',embed_one(H,qb['A'])),
 ('CNOT(A,J)',permutation_gate('CNOT',qb['A'],qb['J'])),
 ('SWAP(A,O2)',permutation_gate('SWAP',qb['A'],qb['O2'])),
 ('SWAP(A,D2A)',permutation_gate('SWAP',qb['A'],qb['D2A'])),
 ('SWAP(J,D2J)',permutation_gate('SWAP',qb['J'],qb['D2J'])),
 ('X(E)',embed_one(X,qb['E'])),
]
m=len(ops)
joint_ops=[sp.kron(G,sp.eye(YD,format='csr'),format='csr') for _,G in ops]
for label,G in ops:
    num(label+' body unitary',sp.linalg.norm(G.getH()@G-I))

def input_vector(kind):
    v=np.zeros(JD,complex)
    if kind=='bell':
        for a in range(2):
            for donor in range(2):
                idx=(a<<(BQ-1))|(donor<<(BQ-1-qb['D1A']))
                v[idx*YD+a]=.5
    else:
        rng=np.random.default_rng(int(kind));w=rng.normal(size=4)+1j*rng.normal(size=4);w/=np.linalg.norm(w)
        for a in range(2):
            for y in range(2):
                for donor in range(2):
                    idx=(a<<(BQ-1))|(donor<<(BQ-1-qb['D1A']))
                    v[idx*YD+y]=w[2*a+y]/sqrt(2)
    return v
def prefixes(v):
    z=[v]
    for G in joint_ops:z.append(G@z[-1])
    return z
def clock_amplitudes(N,theta):
    return np.array([(-1j)**j*sqrt(comb(N,j))*sin(theta)**j*cos(theta)**(N-j) for j in range(N+1)])
def history_state(ps,N,theta):
    c=clock_amplitudes(N,theta)
    a=np.array([c[j]*ps[min(j,m)] for j in range(N+1)])
    return c,a.reshape(-1)
def tail_exact(N):return F(sum(comb(N,j) for j in range(m)),2**N)
def tail_float(N,theta):
    z=sin(theta)**2
    return sum(comb(N,j)*z**j*(1-z)**(N-j) for j in range(m))
def reduced(v,keep):
    nq=BQ+1;other=[q for q in range(nq) if q not in keep]
    a=v.reshape([2]*nq).transpose(keep+other).reshape(2**len(keep),-1)
    return a@a.conj().T
def entropy(r):
    e=np.linalg.eigvalsh((r+r.conj().T)/2);e=e[e>1e-14]
    return float(-sum(e*np.log2(e)))
def mutual_information(v,q,r):return entropy(reduced(v,[q]))+entropy(reduced(v,[r]))-entropy(reduced(v,[q,r]))

# Exact rational endpoint resource frontier, without floating threshold decisions.
frontier=[]
for den in [2,4,8,16,32,64,128,1024]:
    eps=F(1,den);N=m
    while True:
        p=tail_exact(N)
        if 2*p-p*p<=eps*eps:break
        N+=1
    ex(f'epsilon1/{den} exact minimal clock succeeds',2*p-p*p<=eps*eps)
    if N>m:
        old=tail_exact(N-1)
        ex(f'epsilon1/{den} preceding clock fails',2*old-old*old>eps*eps)
    eta=3*log(3)/4-log(2)
    suff=max(m,4*(m-1),ceil(log(2/float(eps*eps))/eta))
    q=tail_exact(suff)
    ex(f'epsilon1/{den} simple sufficient bound succeeds',2*q-q*q<=eps*eps)
    # Algebraic Markov bound p <= 3^(m-1)*(2/3)^N.
    ex(f'epsilon1/{den} Markov bound exact arithmetic',p<=F(3**(m-1)*2**N,3**N))
    frontier.append(dict(epsilon_numerator=1,epsilon_denominator=den,m=m,N_min=N,clock_addresses=N+1,p_bad_numerator=p.numerator,p_bad_denominator=p.denominator,joint_error=sqrt(float(2*p-p*p)),reduced_error=float(p),N_simple_sufficient=suff,fixed_g1_window=pi*N/2))
with (OUT/'EXACT_RESOURCE_FRONTIER.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(frontier[0]));w.writeheader();w.writerows(frontier)

# Numerical channel witnesses for three distinct inputs; general equality relies on proof.
rows=[]
for seed in ['bell','17','91']:
    ps=prefixes(input_vector(seed));final=ps[-1]
    for j in range(m):num(f'{seed} prefix{j} orthogonal exhaustion',abs(np.vdot(final,ps[j])))
    num(f'{seed} final E1',abs(sum(abs(final[i])**2 for i in range(JD) if bit(i//YD,qb['E'])==1)-1))
    for N in [m,24,40,64]:
        for theta in [pi/4,pi/3,pi/2,2*pi/3,3*pi/4,pi]:
            c,v=history_state(ps,N,theta);target=np.kron(c,final)
            p=tail_float(N,theta);delta=pure_distance(v,target)
            exact_formula=sqrt(max(0,2*p-p*p))
            num(f'{seed} N{N} theta{theta} exact joint error',abs(delta-exact_formula))
            # Evaluate reduced trace distance in the low-rank prefix span independently.
            K=np.column_stack(ps);Q,_=np.linalg.qr(K)
            rho=np.zeros((len(ps),len(ps)),complex)
            for j,cj in enumerate(c):
                z=Q.conj().T@ps[min(j,m)];rho+=abs(cj)**2*np.outer(z,z.conj())
            z=Q.conj().T@final;rho-=np.outer(z,z.conj())
            red=float(sum(abs(np.linalg.eigvalsh((rho+rho.conj().T)/2)))/2)
            num(f'{seed} N{N} theta{theta} exact reduced error',abs(red-p))
            if pi/4<=theta<=3*pi/4:upper(f'{seed} N{N} uniform endpoint maximum',p,float(tail_exact(N)))
            rows.append(dict(input=seed,N=N,theta=theta,p_bad=p,joint_actual=delta,joint_exact_formula=exact_formula,reduced_actual=red))
    c,v=history_state(ps,24,pi);num(f'{seed} projective recurrence',pure_distance(v,np.kron(c,ps[0])))
    qual(f'{seed} permanent exhaustion rejected',tail_float(24,pi)>1-1e-12)
with (OUT/'JOINT_MARGINAL_SWEEP.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

# Full body renewal: the active two-qubit module is fresh while output correlations survive.
ps=prefixes(input_vector('bell'));final=ps[-1]
fresh=np.zeros((4,4));fresh[0,0]=1
num('final complete active module fresh',np.linalg.norm(reduced(final,[qb['A'],qb['J']])-fresh))
mi1=mutual_information(final,qb['D1J'],BQ)
mi2=mutual_information(final,qb['O2'],qb['D2J'])
num('first outgoing donor retains one bit of spectator mutual information',abs(mi1-1))
qual('second outgoing donor retains output correlations',mi2>.5)
pair=reduced(final,[qb['O2'],qb['D2J']])
partial_transpose=pair.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4)
negative_eigenvalue=float(min(np.linalg.eigvalsh(partial_transpose)))
num('second output/donor pair partial transpose negative eigenvalue',abs(negative_eigenvalue+sqrt(2)/4))
mid=ps[6]
plus=np.ones((2,2))/2;fresh_mid=np.kron(plus,np.diag([1,0]))
num('first renewal supplies full matched module',np.linalg.norm(reduced(mid,[qb['A'],qb['J']])-fresh_mid))

def history_hamiltonian(N,kappa,uniform_edge=None):
    blocks=[[None]*(N+1) for _ in range(N+1)]
    ji=sp.eye(JD,format='csr')
    for j in range(N):
        G=joint_ops[j] if j<m else ji
        weight=uniform_edge if uniform_edge is not None else kappa*sqrt((j+1)*(N-j))
        blocks[j+1][j]=weight*G;blocks[j][j+1]=weight*G.getH()
    return sp.bmat(blocks,format='csr')

# Independent sparse propagator verifies the dressed-prefix identity and perturbation bound.
pert=[]
for N in [m,24,63]:
    kappa=1/N if N==63 else .7
    Hp=history_hamiltonian(N,kappa)
    num(f'N{N} sparse generator Hermitian',sp.linalg.norm(Hp-Hp.getH()))
    hc=np.diag([kappa*sqrt((j+1)*(N-j)) for j in range(N)],1)
    hc=hc+hc.T
    ev=eigh(hc,eigvals_only=True)
    num(f'N{N} admitted spectral norm',abs(max(abs(ev))-kappa*N))
    v0=np.kron(np.eye(N+1)[0],ps[0])
    Z=np.diag([1.,-1.]);ZA=sp.kron(embed_one(Z,qb['A']),sp.eye(YD),format='csr')
    d=2**-21 if N==63 else .012
    delta=sp.kron(sp.eye(N+1),d*ZA,format='csr')
    for theta in [pi/4,pi/2,3*pi/4]:
        t=theta/kappa;c,expected=history_state(ps,N,theta)
        computed=expm_multiply((-1j*t)*Hp,v0,traceA=0)
        num(f'N{N} theta{theta} sparse ideal propagation',np.linalg.norm(computed-expected))
        actual=expm_multiply((-1j*t)*(Hp+delta),v0,traceA=0)
        target=np.kron(c,final);p=tail_float(N,theta)
        measured=pure_distance(actual,target);bound=min(1,t*d+sqrt(max(0,2*p-p*p)))
        upper(f'N{N} theta{theta} perturbation target bound',measured,bound)
        upper(f'N{N} theta{theta} actual/comparator bound',pure_distance(actual,expected),t*d)
        if N==63:
            upper(f'N{N} theta{theta} specified complete budget with bank debit',bound+2**-16,2**-10)
        pert.append(dict(N=N,theta=theta,time=t,d=d,measured_joint_error=measured,certified_upper_bound=bound))
with (OUT/'PERTURBATION_FIXTURES.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(pert[0]));w.writeheader();w.writerows(pert)

# A flag-flipping perturbation exercises nonzero false-tag and no-completion diagnostics.
N=24;kappa=.7;d=.012;t=pi/(4*kappa)
hp=history_hamiltonian(N,kappa)
XE=sp.kron(embed_one(X,qb['E']),sp.eye(YD),format='csr')
flag_error=sp.kron(sp.eye(N+1),d*XE,format='csr')
v0=np.kron(np.eye(N+1)[0],ps[0]);actual=expm_multiply((-1j*t)*(hp+flag_error),v0,traceA=0)
cube=actual.reshape(N+1,BD,YD);flag1=np.array([bit(i,qb['E'])==1 for i in range(BD)])
false_tag=float(np.sum(abs(cube[:m,flag1,:])**2))
no_complete=float(np.sum(abs(cube[:,~flag1,:])**2));p=tail_float(N,kappa*t)
num('flag perturbation nonzero false-tag exact relation',abs(false_tag-p*sin(d*t)**2))
upper('flag perturbation false-tag amplitude bound',false_tag,(d*t)**2)
upper('flag perturbation no-completion amplitude bound',no_complete,(sqrt(p)+d*t)**2)
qual('false-tag perturbation witness is nonzero',false_tag>1e-8)
(OUT/'FLAG_DIAGNOSTIC_FIXTURE.json').write_text(json.dumps({'N':N,'kappa':kappa,'d':d,'time':t,'p_bad_ideal':p,'false_tag_actual':false_tag,'no_complete_actual':no_complete,'false_tag_bound':(d*t)**2,'no_complete_bound':min(1,(sqrt(p)+d*t)**2),'supply_error':0,'scope':'Flag diagnostics are consequences of the same joint perturbation budget, not independent state-error charges.'},indent=2)+'\n')

# A deliberately correlated donor becomes an entangled active input, rather than an independent reset.
bad=np.zeros(JD,complex)
for d in range(2):
    idx=d<<(BQ-1-qb['D1A']);bad[idx*YD+d]=1/sqrt(2)
for G in joint_ops[4:6]:bad=G@bad
bad_mi=mutual_information(bad,qb['A'],BQ)
num('correlated donor negative control gives active/spectator entanglement',abs(bad_mi-2))
qual('good renewal product guarantee rejected for correlated donor',bad_mi>1)

# Clock-only baseline, with the same word, legal dimension, initial address and norm budget.
# Preparation variance and individual edge norms differ and are reported, not hidden.
N=63;g=1.;kappa=g/N
spin_edges=np.array([kappa*sqrt((j+1)*(N-j)) for j in range(N)])
uniform_J=g/(2*cos(pi/(N+2)))
clock_matrices={'engineered_spin':np.diag(spin_edges,1)+np.diag(spin_edges,-1),
                'uniform_path':np.diag(np.full(N,uniform_J),1)+np.diag(np.full(N,uniform_J),-1)}
times=np.linspace(pi/(4*kappa),3*pi/(4*kappa),1001)
benchmark=[];summaries=[]
for name,Hc in clock_matrices.items():
    values,Q=eigh(Hc)
    num(name+' common clock norm',abs(max(abs(values))-g))
    amps=Q@(np.exp(-1j*values[:,None]*times[None,:])*Q[0,:,None].conj())
    probs=abs(amps)**2
    p=probs[:m].sum(axis=0)
    edge_max=float(max(abs(np.diag(Hc,1))));cut_edge=float(abs(Hc[m,m-1]))
    var=float(np.vdot(Hc[:,0],Hc[:,0]).real)
    for j,t in enumerate(times):
        upper(name+f' speed check{j}',float(np.arange(N+1)@probs[:,j]),2*edge_max*t)
        benchmark.append(dict(clock=name,N=N,g=g,time=float(t),p_bad=float(p[j]),joint_error=sqrt(max(0,2*p[j]-p[j]**2)),reduced_error=float(p[j])))
    pmax=float(max(p));step=float(times[1]-times[0]);p_lip=min(1,pmax+cut_edge*step/2)
    summaries.append(dict(clock=name,N=N,g=g,max_edge_norm=edge_max,initial_clock_energy_variance=var,grid_worst_p_bad=pmax,grid_worst_joint_error=sqrt(2*pmax-pmax*pmax),grid_spacing=step,tail_sampling_lipschitz_allowance=cut_edge*step/2,tail_lipschitz_bound_using_numeric_grid=p_lip,scope='Matched word, dimension, address-0 preparation, norm and requested observation interval. Energy variance and edge norms differ. Numerical samples plus analytic Lipschitz allowance, not interval-arithmetic certification or an optimized cross-family comparison.'))
    if name=='engineered_spin':num('spin benchmark endpoint tail equals exact frontier',abs(pmax-float(tail_exact(N))))
    if name=='uniform_path':qual('uniform baseline fails same requested complete error target at a sampled time',sqrt(2*pmax-pmax*pmax)>2**-10)
    if name=='uniform_path':
        at=int(np.argmax(p));t=float(times[at]);c=amps[:,at]
        expected=np.array([c[j]*ps[min(j,m)] for j in range(N+1)]).reshape(-1)
        hu=history_hamiltonian(N,kappa,uniform_edge=uniform_J)
        propagated=expm_multiply((-1j*t)*hu,np.kron(np.eye(N+1)[0],ps[0]),traceA=0)
        num('uniform baseline sparse full-joint prefix identity',np.linalg.norm(propagated-expected))
        num('uniform baseline sparse worst-grid channel distance',abs(pure_distance(propagated,np.kron(c,final))-sqrt(2*pmax-pmax*pmax)))
with (OUT/'CLOCK_BASELINE_COMPARISON.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(benchmark[0]));w.writeheader();w.writerows(benchmark)
(OUT/'CLOCK_BASELINE_SUMMARY.json').write_text(json.dumps(summaries,indent=2)+'\n')

result=dict(status='PASS',date='2026-10-05',exact_checks=len(exact),numerical_checks=len(numerical),qualitative_numerical_controls=len(qualitative),max_numerical_residual=max(residuals),numerical_tolerance=TOL,primitive_steps=m,body_qubits=BQ,spectator_qubits=1,first_donor_spectator_mutual_information_bits=mi1,second_output_outgoing_donor_mutual_information_bits=mi2,second_output_donor_partial_transpose_min_eigenvalue=negative_eigenvalue,correlated_donor_negative_control_bits=bad_mi,elapsed_seconds=time.perf_counter()-started,exact_check_names=exact,numerical_check_names=numerical,qualitative_numerical_control_names=qualitative,scope='Finite constructor fixtures, exact endpoint arithmetic, sparse dynamics, clock baseline and negative controls. Repeated grid diagnostics are not independent experiments. General channel equality/scaling rely on written proofs. Not independent review, hardware validation, new autonomous-computation priority or universal lower bound.')
(OUT/'REPLAY_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'COMPILED_WORD.json').write_text(json.dumps({'body_order':names,'spectator':'Y','gate_word':[name for name,_ in ops],'m':m,'clock_initial_address':0,'body_free_Hamiltonian':'0 (declared degenerate logical registers)','prepared_bank':'J,D1J,D2A,D2J,O1,O2,E all |0>; D1A |+>; A is arbitrary input, possibly correlated with Y','final_active_module':'A,J in |00>; supervisor clock remains live; output correlations retained in donor junk registers','permanent_halt':False},indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','exact_checks','numerical_checks','max_numerical_residual','primitive_steps','elapsed_seconds']}),flush=True)
