from pathlib import Path
from fractions import Fraction as F
from math import comb, sqrt, pi, log
import csv,json,hashlib,subprocess
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R=Path(__file__).resolve().parent
(R/'figures').mkdir(exist_ok=True)
(R/'manuscript').mkdir(exist_ok=True)
receipt=json.loads((R/'results/REPLAY_RECEIPT.json').read_text())
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180,'font.family':'DejaVu Sans'})
m=13
ns=np.arange(m,81)
ps=np.array([float(F(sum(comb(int(n),j) for j in range(m)),2**int(n))) for n in ns])
ds=np.sqrt(2*ps-ps*ps)
fig,ax=plt.subplots(figsize=(7.3,4.1))
ax.semilogy(ns,ds,color='#164f79',lw=2,label='Complete channel: sqrt(2p - p²)')
ax.semilogy(ns,ps,color='#a55422',lw=2,label='Clock traced out: p')
ax.axhline(2**-10,color='#617486',ls='--',lw=1,label='Target 1/1024')
ax.axvline(63,color='#7d8992',ls=':',lw=1)
ax.annotate('N = 63: 64 addresses',xy=(63,2**-10),xytext=(44,.025),arrowprops={'arrowstyle':'->','color':'#617486'},fontsize=9)
ax.set(xlabel='Clock steps N (addresses = N + 1)',ylabel='Worst error over the declared window',title='Complete-state and reduced-state requirements differ')
ax.grid(True,which='both',alpha=.16);ax.legend(loc='lower left',fontsize=9)
fig.tight_layout();fig.savefig(R/'figures/JOINT_VERSUS_MARGINAL.png');plt.close(fig)

N=63;k=1/N;theta=np.linspace(0,pi,401)
tail=np.array([sum(comb(N,j)*(np.sin(z)**2)**j*(np.cos(z)**2)**(N-j) for j in range(m)) for z in theta])
joint=np.sqrt(np.maximum(0,2*tail-tail*tail));noise=np.minimum(1,joint+(theta/k)*2**-21+2**-16)
fig,ax=plt.subplots(figsize=(7.3,4.1))
ax.plot(theta/pi,joint,color='#164f79',lw=2,label='Ideal complete channel error')
ax.plot(theta/pi,noise,color='#a55422',lw=1.8,ls='--',label='Bound including stated supply and mismatch')
ax.axvspan(.25,.75,color='#dceaf4',alpha=.8,label='Certified finite readout window')
ax.set(xlabel='Scaled time κt / π',ylabel='Trace/normalized diamond distance',ylim=(-.025,1.04),title='Completion is a finite window; static reversal remains')
ax.grid(alpha=.15);ax.legend(loc='center',fontsize=8.5)
fig.tight_layout();fig.savefig(R/'figures/FINITE_WINDOW_AND_RETURN.png');plt.close(fig)

bench=list(csv.DictReader((R/'results/CLOCK_BASELINE_COMPARISON.csv').open()))
fig,ax=plt.subplots(figsize=(7.3,4.1))
for label,color in [('engineered_spin','#164f79'),('uniform_path','#a55422')]:
    data=[x for x in bench if x['clock']==label]
    values=[]
    for x in data:
        if label=='engineered_spin':
            z=np.sin(float(x['time'])/N)**2
            p=sum(comb(N,j)*z**j*(1-z)**(N-j) for j in range(m))
            value=sqrt(max(0,2*p-p*p))
        else:value=float(x['joint_error'])
        values.append(max(value,1e-15))
    ax.semilogy([float(x['time']) for x in data],values,color=color,lw=1.8,label=label.replace('_',' ').capitalize())
ax.axhline(2**-10,color='#617486',ls='--',lw=1,label='Target 1/1024')
ax.set(xlabel='Model time at admitted clock norm g = 1',ylabel='Complete channel error',title='Two clock choices under the same requested window')
ax.grid(True,which='both',alpha=.15);ax.legend(loc='lower right',fontsize=9)
fig.tight_layout();fig.savefig(R/'figures/CLOCK_BASELINE_COMPARISON.png');plt.close(fig)

