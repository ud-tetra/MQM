MQM autonomous two-execution development v0.1 | 5 October 2026

Read manuscript/MQM_PAPER_A_AUTONOMOUS_ADDENDUM_v0.1.pdf. This is a new research addendum to Paper A development 0.1. Parent sources are unchanged and identified by hashes in INPUT_ANCHORS.json. This is not an IEEE submission or a theorem-priority certificate.

Run: OPENBLAS_NUM_THREADS=1 python3 replay_autonomous_two_execution.py
Requires Python 3, NumPy and SciPy. The script writes its own results/ receipts and CSVs. It tests specified finite instances, sparse dynamics and negative controls, not the full space of all inputs. General equalities and scaling rely on written proofs.

What was achieved: a compiled static two-execution episode with output exchange, full WORK-module renewal, exhaustion marker, finite idle window; exact complete/reduced channel relation; exact integer clock-size criterion and matching asymptotic order WITHIN THE SPECIFIED FAMILY.

What remains open: autonomy/renewal of the supervising clock; nondegenerate energy/reference/fuel realization; reusable quantum program register; geometric hardware coupling; broader clock-family optimality; independent review; theorem-level novelty comparison. Static reversal undoes the episode later, so exhaustion is a finite-window record.

Figures show analytic model values and specified mathematical error allowances, not observed physical errors. The pure prepared bank, legal one-excitation clock domain and final exhaustion-bit assumptions matter. A correlated-donor negative control rejects independent-reset claims.

The single-column PDF is a reading draft. Editable TeX and Markdown-syntax text source are included. All artifacts are versioned separately from the original UD and MQM baseline releases.

Regenerate figures: python3 render_research_figures.py (requires Matplotlib).
Rebuild PDF from the text source with Pandoc and XeLaTeX, using manuscript/pdf-header.tex and the package root as resource path. Included TeX can be compiled with XeLaTeX from the manuscript directory.

SHA256_MANIFEST.json records packaged payload hashes. Rerunning the replay may change timings and numerical receipts, so compare scientific values and tolerance checks rather than expecting byte-identical regenerated files.
