import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,time
import numpy as np
P=Path(__file__).resolve().parent
parent=P/'inputs';ns={'__file__':str(parent/'response_model.py')};exec((parent/'response_model.py').read_text(),ns)
M=192;H,H1,n=ns['models'](M)
assert np.max(np.diff(H.indptr))<=196
# Real CSR products applied separately to real and imaginary parts;
# each row <=196 entries, all stored generator entries nonnegative off diagonal.
def prop(K,V,label):
 R=V.real.copy();I=V.imag.copy()
 for step in range(128):
  ar=R.copy();ai=I.copy();tr=R.copy();ti=I.copy()
  for k in range(1,49):
   nr=(K@ti)/ (8*k);ni=-(K@tr)/(8*k)
   ar+=nr;ai+=ni;tr,ti=nr,ni
  R,I=ar,ai
  if (step+1)%16==0:print(label,step+1,flush=True)
 return R+1j*I
seed=np.zeros((H.shape[0],M),complex);seed[3+np.arange(M),np.arange(M)]=1
start=time.monotonic();W=prop(H,seed,'hot');psi=np.zeros((M+4,1),complex);psi[0,0]=1;u=prop(H1,psi,'cold')[:,0]
hot=ns['retained'](W,n,M);cold=np.zeros((8,8),complex);cold[:4,:4]=np.outer(u[:4],u[:4].conj());cold[4,4]=np.vdot(u[4:],u[4:]);D=hot-n.sum()*cold
# Returned entries become exact binary rational data for the next audit.
row={'status':'BINARY64 Taylor output; promotion requires complete error ledger','steps':128,'degree':48,'max_row_nonzeros':int(np.max(np.diff(H.indptr))),'M':M,'Q2_dimension':H.shape[0],'Delta_real':D.real.tolist(),'Delta_imag':D.imag.tolist(),'half_eigenvalue_diagnostic':float(abs(np.linalg.eigvalsh(D)).sum()/2),'occupation_trace':float(n.sum()),'hot_trace':float(np.trace(hot).real),'cold_trace':float(np.trace(cold).real),'seconds':time.monotonic()-start}
(P/'results/TAYLOR_RESPONSE.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps({k:v for k,v in row.items() if k not in ['Delta_real','Delta_imag']}),flush=True)
