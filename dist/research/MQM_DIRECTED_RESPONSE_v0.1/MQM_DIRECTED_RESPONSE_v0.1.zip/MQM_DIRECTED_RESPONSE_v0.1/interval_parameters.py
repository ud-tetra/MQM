from decimal import Decimal as D,localcontext,ROUND_FLOOR,ROUND_CEILING,getcontext
from fractions import Fraction as F
from pathlib import Path
import numpy as np,json,math
P=Path(__file__).resolve().parent
PREC=200
getcontext().prec=PREC
getcontext().rounding=ROUND_CEILING
def op(a,b,sign):
 with localcontext() as c:
  c.prec=PREC;c.rounding=sign
  return a+b
class I:
 def __init__(self,a,b=None):self.l=D(a);self.h=D(a if b is None else b)
 def __add__(a,b):
  b=b if isinstance(b,I) else I(b)
  return I(op(a.l,b.l,ROUND_FLOOR),op(a.h,b.h,ROUND_CEILING))
 __radd__=__add__
 def __neg__(a):return I(a.h.copy_negate(),a.l.copy_negate())
 def __sub__(a,b):return a+(-b if isinstance(b,I) else -I(b))
 def __rsub__(a,b):return I(b)-a
 def __mul__(a,b):
  b=b if isinstance(b,I) else I(b)
  with localcontext() as c:
   c.prec=PREC;c.rounding=ROUND_FLOOR;l=min(x*y for x in [a.l,a.h] for y in [b.l,b.h])
   c.rounding=ROUND_CEILING;h=max(x*y for x in [a.l,a.h] for y in [b.l,b.h])
  return I(l,h)
 __rmul__=__mul__
 def __truediv__(a,b):
  b=b if isinstance(b,I) else I(b);assert not b.l<=0<=b.h
  with localcontext() as c:
   c.prec=PREC;c.rounding=ROUND_FLOOR;l=min(1/b.l,1/b.h)
   c.rounding=ROUND_CEILING;h=max(1/b.l,1/b.h)
  return a*I(l,h)
 def sqrt(a):
  assert a.l>=0
  with localcontext() as c:
   c.prec=PREC;l=a.l.sqrt().next_minus();h=a.h.sqrt().next_plus()
  return I(l,h)
 def exp(a):
  with localcontext() as c:
   c.prec=PREC;l=a.l.exp().next_minus();h=a.h.exp().next_plus()
  return I(l,h)
 def error(a,x):
  q=a-I(D.from_float(float(x)))
  return max(q.l.copy_abs(),q.h.copy_abs())
def fraction(q):return I(q.numerator)/q.denominator
def atan_bounds(q,N):
 s=sum((F(-1 if j%2 else 1,(2*j+1)*q**(2*j+1)) for j in range(N)),F(0));r=F(1,(2*N+1)*q**(2*N+1))
 return fraction(s)+I(-fraction(r).h,fraction(r).h)
pi=16*atan_bounds(5,160)-4*atan_bounds(239,60)
def leg(x,n):
 p0=I(1);p1=x;d0=I(0);d1=I(1)
 for k in range(1,n):
  p2=((2*k+1)*x*p1-k*p0)/(k+1)
  d2=((2*k+1)*(p1+x*d1)-k*d0)/(k+1)
  p0,p1=p1,p2;d0,d1=d1,d2
 return p1,d1
M=192;x,w=np.polynomial.legendre.leggauss(M);r=fraction(F(1,2**44));mark=F((M-1)*M*(M+1)*(M+2),8)
c=np.sqrt(64*w/math.pi);delta=16*x;n=1/np.expm1((5/16)*(64+delta));rows=[]
for j,z in enumerate(x):
 z=I(D.from_float(float(z)));lo=(z-r).l;hi=(z+r).h
 pl,_=leg(I(lo),M);ph,_=leg(I(hi),M)
 assert pl.h<0<ph.l or ph.h<0<pl.l
 _,dp=leg(z,M);err=(fraction(mark)*r).h;dp=dp+I(-err,err)
 root=I(lo,hi);weight=I(2)/((1-root*root)*(dp*dp));coupling=(64*weight/pi).sqrt()
 occ=I(1)/((fraction(F(5,16))*(64+16*root)).exp()-1)
 rows.append({'root_lo':str(lo),'root_hi':str(hi),'c_error':str(coupling.error(c[j])),'n_error':str(occ.error(n[j])),'delta_error':str((16*root).error(delta[j])),'n_upper':str(occ.h),'weight_lo':str(weight.l),'weight_hi':str(weight.h)})
for j in range(1,M):assert D(rows[j-1]['root_hi'])<D(rows[j]['root_lo'])
# All192 disjoint sign changes account for every simple root of P192.
with localcontext() as ctx:
 ctx.prec=PREC;ctx.rounding=ROUND_CEILING
 ce2=sum(D(q['c_error'])**2 for q in rows);ce=ce2.sqrt().next_plus()
 de=max(D(q['delta_error']) for q in rows);ne=sum(D(q['n_error']) for q in rows)
 nu=sum(D(q['n_upper']) for q in rows)
 lam=(4*I(2).sqrt()).sqrt();le=lam.error(math.sqrt(4*math.sqrt(2)))
 # Conservative creation/annihilation factors sqrt2<3/2.
 dh=2*de+3*ce+le
 out={'status':'DIRECTED Decimal intervals','precision':PREC,'root_sign_brackets':M,'all_roots_disjoint':True,'coupling_l2_error_upper':str(ce),'Hamiltonian_Q2_error_upper':str(dh),'occupation_l1_error_upper':str(ne),'occupation_trace_upper':str(nu),'pi_lo':str(pi.l),'pi_hi':str(pi.h),'rows':rows}
(P/'results/PARAMETER_INTERVALS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'}),flush=True)
