from fractions import Fraction as F
from pathlib import Path
import numpy as np,itertools,json
P=Path(__file__).resolve().parent
cells=[s for k in range(1,5) for s in itertools.combinations(range(4),k)];lut={s:j for j,s in enumerate(cells)};D=np.zeros((15,15),dtype=object)
for s,j in lut.items():
 if len(s)>1:
  for k in range(len(s)):D[lut[s[:k]+s[k+1:]],j]=F((-1)**k)
A=D-D.T;I=np.eye(15,dtype=object);assert np.array_equal(D@D,np.zeros((15,15),dtype=object));assert np.array_equal(A@A@A,-4*A)
Z=I+A@A*F(1,4);R=-A@A*F(1,8);Q=-A*F(1,4)
# Positive projector for H=-iA: Pplus=R+iQ.
assert np.array_equal(Z@Z,Z);assert sum(Z.diagonal())==1
assert np.array_equal(R@R-Q@Q,R);assert np.array_equal(R@Q+Q@R,Q)
assert np.array_equal(Z@R,np.zeros((15,15),dtype=object));assert np.array_equal(Z@Q,np.zeros((15,15),dtype=object));assert sum(R.diagonal())==7
R8=Z+R;assert sum(R8.diagonal())==8
checks=0
for perm in itertools.permutations(range(4)):
 U=np.zeros((15,15),dtype=object)
 for s,j in lut.items():
  image=[perm[v] for v in s];inversions=sum(image[a]>image[b] for a in range(len(image)) for b in range(a+1,len(image)))
  U[lut[tuple(sorted(image))],j]=(-1)**inversions
 assert np.array_equal(U@A,A@U);checks+=1
res={'status':'EXACT conditional spectral-carrier construction','source_carrier_coordinates':15,'nonzero_incidence_count':int(np.count_nonzero(D)),'boundary_squared_zero':True,'A_cubic_identity':'A^3=-4A','zero_projector_rank':1,'positive_frequency_projector_rank':7,'oriented_spectral_carrier_rank':8,'S4_commutators_checked':checks,'reference_in_this_carrier':'unique normalized zero eigenspace','active_expectation_in_uniform_8_state':'7/8','original_three_bit_Theta_identification':'OPEN','192_basis_source_dynamics':'OPEN','factor24_allocation':'OPEN','factor4_admissibility':'OPEN','latch_map':'OPEN','development_exposure':'Spectrum and target7/768 already known; spectral-carrier proposal is post-exposure construction, not independent prediction','physical_promotion':0}
(P/'results/SELECTION_AUDIT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
