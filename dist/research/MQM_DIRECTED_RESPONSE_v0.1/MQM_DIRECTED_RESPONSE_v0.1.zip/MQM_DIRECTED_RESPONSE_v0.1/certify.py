from pathlib import Path
from fractions import Fraction as F
from math import factorial
import json
P=Path(__file__).resolve().parent
par=json.loads((P/'results/PARAMETER_INTERVALS.json').read_text());out=json.loads((P/'results/TAYLOR_RESPONSE.json').read_text())
# Exact fractions parsed from directed decimal upper endpoints and IEEE754 output.
tail=F(8**49,factorial(49))/(1-F(8,50));gamma=F(1,2**43)
s=32*gamma*3**8+tail+F(1,2**800)
assert 128*s<F(1,100000);prop=2*128*s;assert prop<F(1,2**17)
nu=F(par['occupation_trace_upper']);dn=F(par['occupation_l1_error_upper']);dh=F(par['Hamiltonian_Q2_error_upper'])+F(1,2**40)
assert nu<F(1,2**16);assert dh<F(1,2**16)
# The same bound controls Q1; trace triangle for hot and cold normalized launches.
eps=16*dh+prop;response_prop=nu*(2*eps+eps*eps)
# Initial weight changes are a separate trace-l1 debit after contractions.
# Half matrix trace norm <= half entrywise l1 of real + imaginary parts.
matrix=sum((abs(F(float(x))) for k in ['Delta_real','Delta_imag'] for row in out[k] for x in row),F(0))/2
readout=F(1,2**36)
second=matrix+response_prop+dn+readout+F(1,2**30)+F(1,2**57)
budget=F(127,2**25)-F(1,2**128)
total=F(3,2**18)+F(1,2**128)+F(1,2**25)+second
assert second<budget and total<F(1,2**16)
def f(q):return {'numerator':str(q.numerator),'denominator':str(q.denominator),'diagnostic_decimal':float(q)}
r={'status':'DERIVED numerical upper certificate conditional on declared IEEE754 arithmetic and inherited continuum/Gaussian contracts','Taylor_global_vector_error':f(prop),'assembly_H_error_with_rounding':f(dh),'combined_vector_error':f(eps),'finite_response_entrywise_norm_upper':f(matrix),'weighted_propagation_debit':f(response_prop),'occupation_debit':f(dn),'readout_debit':'2^-36','vacuum_transfer_debit':'2^-30','covariance_transfer_debit':'2^-57','second_order_upper':f(second),'second_order_budget':f(budget),'retained_thermal_error_upper':f(total),'target':'2^-16','acceptance_pass':True,'scope':'Fixed p0 launch, stationary flat-band Gaussian reservoir, T16 beta5/16; spectator identity only. Not arbitrary-input diamond norm or permanent retention.','physical_promotion':0,'independent_external_review':'OPEN'}
(P/'results/CERTIFICATE.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k in ['status','second_order_upper','retained_thermal_error_upper','acceptance_pass']},indent=2))
