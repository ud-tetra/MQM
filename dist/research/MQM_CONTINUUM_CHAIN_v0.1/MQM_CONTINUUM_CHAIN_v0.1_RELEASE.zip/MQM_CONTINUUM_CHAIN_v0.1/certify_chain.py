from pathlib import Path
from fractions import Fraction as F
import json,math
from mpmath import iv
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text());iv.dps=P['interval_digits']
def rat(v):f=F(v);return iv.mpf(f.numerator)/f.denominator
L=P['chain_bath_sites'];dim=L+4;T=P['time'];B=P['B'];degree=P['Taylor_degree']
w=[rat(1),rat(1),iv.sqrt(4*iv.sqrt(2)),iv.sqrt(128/iv.pi)]+[iv.sqrt(rat(F(B*B*n*n,4*n*n-1))) for n in range(1,L)]
# Phase rotation (-i)^j converts zero-diagonal Hermitian hopping to real skew path.
# Taylor action on fixed launch; each coefficient is an outward interval.
term=[rat(0) for _ in range(dim)];term[0]=rat(1);v=term.copy()
for n in range(1,degree+1):
 old=term
 term=[-w[0]*old[1]*T/n]
 term.extend((w[j-1]*old[j-1]-w[j]*old[j+1])*T/n for j in range(1,dim-1))
 term.append(w[-1]*old[-2]*T/n);v=[a+b for a,b in zip(v,term)]
remainder=rat(P['Hermitian_norm_ceiling']*T)**(degree+1)/math.factorial(degree+1);rad=iv.mpf([-remainder.b,remainder.b]);q=sum((z+rad)*(z+rad) for z in v[:4]);ceil=F(3,2**18)
assert q.b<rat(ceil).a
D=L+3;x=F(P['Hermitian_norm_ceiling']*T,2);eps=2*B*T*x**D/F(math.factorial(D))/(1-x/F(D+1));assert eps<F(1,2**128)
full=ceil+F(1,2**128);assert full<F(1,2**16)
res={'status':'DIRECTED INTERVAL finite chain; DERIVED continuum fixed-launch channel target pass','q_chain_interval':str(q),'finite_chain_ceiling_exact':str(ceil),'tail_ceiling_exact':str(F(1,2**128)),'continuum_ceiling_exact':str(full),'continuum_target_exact':'1/65536','B':B,'bath_chain_sites':L,'dimension':dim,'time':T,'digits':iv.dps,'Taylor_degree':degree,'method':'Real phase-rotated path,240-digit outward Taylor1280; skew-Hermitian integral remainder<=384^1281/1281!; independent exact rational Chebyshev/Duhamel tail. Norm ceiling24 holds on one-excitation sector only.','scope':'Flat compact-band vacuum continuum; fixed cold admitted port launch and arbitrary identity spectators. Point-time capture only. Not thermal, old Ohmic spectrum, whole word, or physical realization.','physical_promotion':0}
(R/'results/CONTINUUM_CERTIFICATE.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
