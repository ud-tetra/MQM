import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as F
import json,math
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import expm_multiply
from scipy.linalg import eigh
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text());checks=[]
polys=[[F(1)],[F(0),F(1)]]
for n in range(1,10):
 a=[F(0)]+[F(2*n+1,n+1)*c for c in polys[n]];b=[F(n,n+1)*c for c in polys[n-1]]
 for j,c in enumerate(b):a[j]-=c
 polys.append(a)
def integral_product(p,q):return sum((a*b*F(2,i+j+1) for i,a in enumerate(p) for j,b in enumerate(q) if (i+j)%2==0),F(0))
for n in range(10):
 for m in range(10):
  assert integral_product(polys[n],polys[m])==(F(2,2*n+1) if n==m else 0);checks.append('Legendre inner product '+str((n,m)))
for n in range(1,10):
 # <phi_(n-1), x phi_n>^2 = n^2/(4n^2-1).
 moment=integral_product(polys[n-1],[F(0)]+polys[n]);sq=moment**2*F((2*n-1)*(2*n+1),4)
 assert sq==F(n*n,4*n*n-1);checks.append('link coefficient squared '+str(n))
B=P['B'];L=P['chain_bath_sites'];T=P['time'];D=L+3;x=F(P['Hermitian_norm_ceiling']*T,2)
eps=2*B*T*x**D/F(math.factorial(D))/(1-x/F(D+1));assert eps<F(1,2**128)
finiteceil=F(3,2**18);totalceil=finiteceil+F(1,2**128);assert totalceil<F(1,2**16)
rows=[]
for ell in [64,L]:
 weights=[1.,1.,math.sqrt(4*math.sqrt(2)),math.sqrt(128/math.pi)]+[B*n/math.sqrt(4*n*n-1) for n in range(1,ell)]
 H=diags([weights,weights],[-1,1],shape=(ell+4,ell+4),format='csr');launch=np.zeros(ell+4,complex);launch[0]=1;v=expm_multiply(-1j*T*H,launch,traceA=0)
 assert abs(np.vdot(v,v)-1)<1e-9
 cross=None
 if ell==64:
  e,Q=eigh(H.toarray());other=Q@(np.exp(-1j*T*e)*Q[0]);cross=float(np.linalg.norm(v-other));assert cross<1e-9
 rows.append({'bath_chain_sites':ell,'one_excitation_dimension':ell+4,'q_numeric':float(np.vdot(v[:4],v[:4]).real),'norm_error':float(abs(np.vdot(v,v)-1)),'dense_cross_check_difference':cross,'certifying_length':ell==L})
res={'status':'EXACT finite rational recurrence checks; DERIVED continuum tail bound; SIMULATED propagation','exact_check_count':len(checks),'exact_checks':checks,'mapping':'phi_n(delta)=sqrt((2n+1)/(2B)) P_n(delta/B); G=sqrt(kappa B/pi); chain link b_n=B n/sqrt(4n^2-1), n>=1; rotating onsite0','basis_completeness':'Polynomials dense in L2 of compact flat interval; normalized Legendre family yields exact unitary bath-coordinate map, not grid quadrature.','rows':rows,'tail_bound_exact':str(eps),'tail_ceiling_exact':'1/'+str(2**128),'distance_to_cut_endpoint':D,'proof':'Cut only bath link L, retain tail as disconnected block. Duhamel difference norm<=b_L integral_0^T |<last|exp(-iH_L s)|launch>|ds. Endpoint graph distance D=L+3. Chebyshev degree<D has zero endpoint amplitude, ||T_n(H_L/Lambda)||<=1. Poisson integral gives |J_n(Lambda s)|<=(Lambda s/2)^n/n!. Sum geometric factorial tail and use b_L<=B for printed bound.','conditional_continuum_ceiling_exact':str(totalceil),'temperature_covariance':'<a_n^dag a_m>=integral_-B^B phi_n(delta)phi_m(delta)/(exp(beta(Omega+delta))-1) ddelta; generally non-diagonal. At beta5/16,Omega64,B16 point occupation<=1/(exp15-1). Not an evaluated thermal channel or multiphoton certificate.','physical_promotion':0}
(R/'results/CHAIN_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k not in ['exact_checks','tail_bound_exact']},indent=2))
