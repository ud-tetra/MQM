MQM CONTINUUM CHAIN v0.1
Replay from this directory:
python3 freeze.py
python3 audit_chain.py
python3 certify_chain.py
python3 build_pdf.py
python3 prepare_release.py

Conditional target: fixed admitted cold port launch, flat-bandB16,kappa8,Omega64,vacuum and arbitrary identity spectator. Exact infinite-chain mapping, finite768-coordinate interval and exact truncation bound certify q_inf(16)<2^-16. This is not the thermal Ohmic spectrum, full word, hardware or permanent storage. Physical promotion0. Norm24 is one-excitation only. All chain coordinates are mathematical oscillator modes, not physical qubits. Classical chain-map construction is prior art. Independent theorem review pending.
