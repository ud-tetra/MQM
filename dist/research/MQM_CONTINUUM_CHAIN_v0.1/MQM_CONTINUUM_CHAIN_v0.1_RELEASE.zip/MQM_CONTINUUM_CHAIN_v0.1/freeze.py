from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
P={'version':'0.1','status':'FROZEN before successor chain evaluation','source_model':'same flat vacuum band as MQM_MICRO_REFERENCE_v0.1; no replacement spectral hypothesis','B':16,'Omega':64,'kappa':8,'lambda_squared':'4sqrt2','time':16,'initial':'port pR0 with bath vacuum, fixed launch and arbitrary identity spectator','orthogonal_basis':'phi_n(delta)=sqrt((2n+1)/(2B))*LegendreP_n(delta/B), L2[-B,B]','G_squared':'kappa B/pi=128/pi','bath_link_squared':'B^2 n^2/(4n^2-1), n>=1','rotating_on_sites':0,'chain_bath_sites':768,'finite_dimension':772,'Hermitian_norm_ceiling':24,'interval_digits':240,'Taylor_degree':1280,'finite_error_ceiling':'3/262144','continuum_target':'1/65536','tail_bound':'D=L+3; x=Lambda*T/2; epsilon<=2 B T x^D / D! /(1-x/(D+1)); finite launch, vacuum','tail_acceptance':'epsilon<1/2^128','numerical_cross_check':'scipy expm_multiply versus dense eigensolver at L64; no pass inference from convergence','post_exposure_disclosure':'B16 and time16 preserved from successful finite-grid engineering; L768 chosen before chain evaluation from analytic truncation scale, not fitted to a new measured outcome','thermal_extension':'formal transformed Gaussian covariance only; no finite-temperature simulation or certification','physical_promotion':0}
p=R/'PROTOCOL.json'
if p.exists():assert json.loads(p.read_text())==P
else:p.write_text(json.dumps(P,indent=2)+'\n')
print(hashlib.sha256(p.read_bytes()).hexdigest())
