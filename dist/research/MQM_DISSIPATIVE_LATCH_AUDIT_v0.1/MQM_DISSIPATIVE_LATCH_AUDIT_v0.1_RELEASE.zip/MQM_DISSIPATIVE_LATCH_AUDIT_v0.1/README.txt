MQM DISSIPATIVE LATCH AUDIT v0.1 -- 5 October 2026

Primary paper: manuscript/MQM_DISSIPATIVE_LATCH_IEEE_A4_v0.1.pdf
Four pages; actual IEEEtran journal class, A4, two columns, 10pt.
This release is a new conditional open-system branch, not a replacement for the
certified 53-address closed-clock result or its error certificate.

Results:
1. A prefix-dressed endpoint jump gives exact complete operational error S(t),
   the no-jump survival; all body outputs/donors/spectator registers are retained.
   The external Markov bath is traced out and needs its own physical contract.
2. Isolated latch mean: 2/Gamma+Gamma/(4g^2)+Delta^2/(g^2 Gamma).
   Mean optimum: Gamma=2sqrt(2g^2+Delta^2); resonance Gamma/g=2sqrt2.
3. Uniform n-level transient path mean: n/Gamma+(n-1)Gamma/(4g^2).
   Mean optimum: Gamma/g=2sqrt(n/(n-1)). For the 13-step episode n=15.
4. Uniform g=1/8,Gamma=1/4 has exact mean 116. Markov inequality gives an ideal
   complete-error guarantee<=1/1024 for all t>=118784 (very conservative).
   This is not the old clock deadline and includes no physical imperfection budget.

Replay:
  OPENBLAS_NUM_THREADS=1 python3 replay_latch.py
  python3 build_ieee_note.py
The replay uses rational identities plus separate numerical diagnostics.
Deadline search is local/grid-based within a specified range; no globally
certified deadline optimum is asserted. Finite-time numerical curves have no
rigorous rounding enclosure in this release.

PROPOSAL_AUDIT_v0.1.json captures the corrections, including non-Hermitian
conditionality, dephasing/loss distinctions, dark-body hold and heat-cost scope.
All original numerical citation placeholders supplied in the draft are unresolved;
they are not used as evidence. Primary published sources are in INPUT_ANCHORS.json.

The expanded 53-address-parent latch uses 55 clock/auxiliary levels; exact norm
admission passes, but every tested rate fails the dark-clock target at the old
window endpoint. This is a useful negative control, not a global impossibility.
Long-lived modes make an ordinary floating Lyapunov mean solve ill-conditioned;
no such shaped-clock mean is promoted.

Independent mathematical review, priority comparison, finite bath derivation,
noise-admitted long hold and physical realization remain pending.
Physical promotion=0. No reusable autonomous supervisor is established.
IEEEtran and its LPPL1.3c license are included. PUBLICATION_FORMAT_POLICY_v1.0.json
preserves the user's IEEE/A4 requirement for future paper PDFs.
