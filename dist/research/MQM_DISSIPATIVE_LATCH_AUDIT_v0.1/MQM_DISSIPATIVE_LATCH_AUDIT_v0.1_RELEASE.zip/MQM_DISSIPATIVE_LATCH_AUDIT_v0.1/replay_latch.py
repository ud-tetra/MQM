"""MQM open-latch audit: analytic identities and numerical diagnostics, not physical evidence.
Run OPENBLAS_NUM_THREADS=1 python3 replay_latch.py
The numerical exponential/deadline results are diagnostics, not verified enclosures.
"""
from pathlib import Path
from fractions import Fraction as F
from math import sqrt,pi
import json,csv,hashlib
import numpy as np
import scipy.sparse as sp
from scipy.linalg import expm,solve_continuous_lyapunov
from scipy.sparse.linalg import expm_multiply
from scipy.optimize import brentq,minimize_scalar
R=Path(__file__).resolve().parent;O=R/'results';O.mkdir(exist_ok=True)
exact=[];diagnostics=[]
def check(name,c):
 if not c:raise AssertionError(name)
 exact.append(name)
def diagnostic(name,residual,tol=5e-10):
 z=float(residual)
 if not np.isfinite(z) or z>tol:raise AssertionError((name,z))
 diagnostics.append({'name':name,'residual':z,'tolerance':tol})
def matrix(n,g,G):
 A=np.diag(np.full(n-1,g),-1)-np.diag(np.full(n-1,g),1);A[-1,-1]=-G/2;return A
# Exact rational verification of the uniform-chain integrated covariance.
# X diagonal = 1/G+G/(4g^2), except last=1/G; neighbors=1/(2g), other entries0.
for n in range(2,17):
 for g,G in [(F(1,8),F(1,4)),(F(2,3),F(7,5))]:
  A=[[F(0) for _ in range(n)] for _ in range(n)];X=[[F(0) for _ in range(n)] for _ in range(n)]
  for i in range(n-1):A[i+1][i]=g;A[i][i+1]=-g;X[i][i+1]=X[i+1][i]=1/(2*g)
  A[-1][-1]=-G/2
  for i in range(n):X[i][i]=1/G+(G/(4*g*g) if i<n-1 else 0)
  residual=[[sum(A[i][k]*X[k][j]+X[i][k]*A[j][k] for k in range(n))+(F(1) if i==j==0 else F(0)) for j in range(n)] for i in range(n)]
  check(f'n{n},g{g},G{G}: exact integrated covariance identity',all(z==0 for row in residual for z in row))
  check(f'n{n},g{g},G{G}: exact mean trace',sum(X[i][i] for i in range(n))==F(n)/G+F(n-1)*G/(4*g*g))
# Exact integrated isolated detuned equations, deriving mean and optimum.
for g,G,D in [(F(1),F(2),F(0)),(F(1,4),F(3,5),F(7,8)),(F(2,3),F(5,7),F(1,3))]:
 Qe=1/G;Y=1/(2*g);X=-D/(g*G);Qm=Qe+G/(4*g*g)+D*D/(g*g*G)
 check('isolated detuned integrated flux '+str((g,G,D)),2*g*Y==1 and G*Qe==1 and -G*X/2-D*Y==0 and g*(Qm-Qe)+D*X-G*Y/2==0)
 check('isolated detuned mean '+str((g,G,D)),Qm+Qe==2/G+G/(4*g*g)+D*D/(g*g*G))
n=15;g=F(1,8);G=F(1,4);mean=F(n)/G+F(n-1)*G/(4*g*g);eps=F(1,1024);T=mean/eps
check('uniform thirteen-step episode mean116',mean==116)
check('uniform all-future Markov deadline118784',T==118784 and mean/T==eps)
# Isolated finite-time survival and deadline optimization.
def survival(t,G,g=1.,D=0.):
 B=np.array([[0.,-1j*g],[-1j*g,-G/2-1j*D]],complex);u=expm(t*B)[:,0];return float(np.vdot(u,u).real)
def deadline(G,eps):
 hi=1.
 while survival(hi,G)>eps:hi*=2
 return brentq(lambda t:survival(t,G)-eps,0,hi,xtol=1e-11)
ratio=np.geomspace(.1,20,151)
mean_rows=[{'Gamma_over_g':float(x),'g_mean_isolated':2/x+x/4,'g_mean_uniform_n15':15/x+14*x/4} for x in ratio]
with (O/'MEAN_CAPTURE_SWEEP.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(mean_rows[0]));w.writeheader();w.writerows(mean_rows)
deadlines=[]
for epsfloat in [1/1024,2**-16]:
 # Grid multiple basins rather than claiming one bounded solve globally optimizes.
 grid=np.linspace(.1,8,321);vals=np.array([deadline(x,epsfloat) for x in grid]);candidates=[]
 for i in range(1,len(grid)-1):
  if vals[i]<=vals[i-1] and vals[i]<=vals[i+1]:
   sol=minimize_scalar(lambda G:deadline(G,epsfloat),bounds=(grid[i-1],grid[i+1]),method='bounded',options={'xatol':1e-10});candidates.append((float(sol.fun),float(sol.x)))
 best=min(candidates+[(float(vals[0]),float(grid[0])),(float(vals[-1]),float(grid[-1]))])
 deadlines.append({'epsilon':epsfloat,'searched_Gamma_over_g_range':[.1,8.],'best_local_Gamma_over_g':best[1],'g_deadline':best[0],'mean_optimum_g_deadline':deadline(2*sqrt(2),epsfloat),'critical_g_deadline':deadline(4.,epsfloat),'global_certificate':False})
for G in [.2,1.,2*sqrt(2),4.,8.,20.]:
 B=matrix(2,1.,G);X=solve_continuous_lyapunov(B,-np.diag([1.,0.]))
 diagnostic(f'isolated mean Lyapunov G{G}',abs(np.trace(X)-(2/G+G/4)))
 for t in [.1,1.,5.]:
  v=expm(t*B)[:,0];diagnostic(f'isolated complex/real survival G{G},t{t}',abs(v@v-survival(t,G)))
# Full, always-on uniform thirteen-step clock; time series includes incomplete flag weight.
A=matrix(15,1/8,1/4);ts=np.linspace(0,1600,1601);vectors=expm_multiply(sp.csr_matrix(A),np.eye(15)[:,0],start=0,stop=1600,num=1601)
S=np.sum(vectors*vectors,axis=1);p=np.sum(vectors[:,:13]**2,axis=1)
diagnostic('uniform survival non-increasing',max(0.,float(np.max(np.diff(S)))))
diagnostic('uniform complete/body error order',max(0.,float(np.max(p-S))))
Q=solve_continuous_lyapunov(A,-np.diag([1.]+[0.]*14));diagnostic('uniform mean numerical vs exact116',abs(np.trace(Q)-116))
rows=[{'time':float(t),'survival_complete_error':float(s),'clock_traced_body_error':float(q),'mean_Markov_bound':min(1.,116/float(t)) if t else 1.} for t,s,q in zip(ts,S,p)]
with (O/'UNIFORM_EPISODE_TRACE.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Independent small full Lindblad fixture: body(A,E,Y), word H(A),X(E).
Ib=np.eye(8);Hgate=np.array([[1,1],[1,-1]])/sqrt(2);Xgate=np.array([[0,1],[1,0]]);I2=np.eye(2)
G1=np.kron(np.kron(Hgate,I2),I2);G2=np.kron(np.kron(I2,Xgate),I2);P=[Ib,G1,G2@G1];P+= [P[-1],P[-1]]
K=np.zeros((5,5));K[0,1]=K[1,0]=.25;K[1,2]=K[2,1]=.25;K[2,3]=K[3,2]=.25
V=sp.block_diag(P,format='csr');Htot=V@sp.csr_matrix(np.kron(K,Ib))@V.getH();Lclock=np.zeros((5,5));Lclock[4,3]=sqrt(.5);L=sp.csr_matrix(np.kron(Lclock,Ib));I=sp.eye(40,format='csr');LdL=L.getH()@L
Li=-1j*(sp.kron(I,Htot)-sp.kron(Htot.T,I))+sp.kron(L.conjugate(),L)-.5*(sp.kron(I,LdL)+sp.kron(LdL.T,I))
# Entangled and mixed inputs; final flag allows independent traced-body distance check.
w=np.zeros(8,complex);w[0]=w[5]=1/sqrt(2)
w2=np.zeros(8,complex);w2[1]=1
inputs=[np.outer(w,w.conj()),.7*np.outer(w,w.conj())+.3*np.outer(w2,w2.conj())]
for idx,rho in enumerate(inputs):
 r0=np.zeros((40,40),complex);r0[:8,:8]=rho;target=P[2]@rho@P[2].conj().T
 for t in [.5,4.,12.]:
  actual=expm_multiply(Li*t,r0.reshape(-1,order='F')).reshape(40,40,order='F')
  B=-1j*K[:4,:4].astype(complex);B[-1,-1]-=.25;u=expm(B*t)[:,0];s=float(np.vdot(u,u).real)
  predicted=np.zeros((40,40),complex)
  for j in range(4):
   for k in range(4):predicted[8*j:8*(j+1),8*k:8*(k+1)]=u[j]*u[k].conjugate()*P[j]@rho@P[k].conj().T
  predicted[32:40,32:40]=(1-s)*target
  diagnostic(f'full Lindblad vs trajectory input{idx},t{t}',np.linalg.norm(actual-predicted))
  tar=np.zeros_like(actual);tar[32:40,32:40]=target
  d=.5*np.sum(np.abs(np.linalg.eigvalsh(actual-tar)));diagnostic(f'complete error equals survival input{idx},t{t}',abs(d-s))
  reduced=sum(actual[8*j:8*(j+1),8*j:8*(j+1)] for j in range(5));p_inc=float(np.sum(abs(u[:2])**2));d_body=.5*np.sum(np.abs(np.linalg.eigvalsh(reduced-target)))
  diagnostic(f'body error equals incomplete population input{idx},t{t}',abs(d_body-p_inc))
  diagnostic(f'full Lindblad normalization input{idx},t{t}',abs(np.trace(actual)-1))
# Existing53 clock plus endpoint e,d: finite-time diagnostics only, not the parent certificate.
parent=json.loads((R/'PARENT_53_CLOCK.json').read_text());edges=np.array(parent['edge_numerators'])/2**parent['coupling_denominator_bits'];full_rows=[]
for G in [.125,.25,.5,1/sqrt(2),1.,2.,4.]:
 ee=np.r_[edges,.25];A=np.diag(ee,-1)-np.diag(ee,1);A[-1,-1]=-G/2
 for label,t in [('parent_a',63*pi/4),('parent_b',189*pi/4)]:
  u=expm(t*A)[:,0];u2=expm_multiply(sp.csr_matrix(t*A),np.eye(54)[:,0]);diagnostic(f'53clock finite-time dense/sparse G{G},{label}',np.linalg.norm(u-u2))
  full_rows.append({'Gamma':G,'g_latch':.25,'time_label':label,'time':t,'survival_complete_latched_error':float(u@u),'clock_traced_body_error':float(u[:13]@u[:13])})
# Exact norm admission of parent+one coherent auxiliary with edge1/4.
fr=[F(x,2**parent['coupling_denominator_bits']) for x in parent['edge_numerators']]+[F(1,4)];d0=d1=F(1)
for i,e in enumerate(fr):
 d2=d1-e*e*d0;check('53clock+e exact positive norm minor '+str(i+2),d2>0);d0,d1=d1,d2
with (O/'PARENT_53_LATCH_DIAGNOSTICS.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(full_rows[0]));w.writeheader();w.writerows(full_rows)
# Trivial projector commutation does not imply body preservation: Z maps+to- atpi/2.
plus=np.array([1,1])/sqrt(2);minus=expm(-1j*pi/2*np.diag([1.,-1.]))@plus
diagnostic('counterexample projector commutation insufficient',abs(np.vdot(plus,minus)))
receipt={'status':'PASS','exact_check_count':len(exact),'numerical_diagnostic_count':len(diagnostics),'largest_diagnostic_residual':max(x['residual'] for x in diagnostics),'isolated_resonant_mean_optimum_Gamma_over_g':2*sqrt(2),'isolated_detuned_optimum':'Gamma=2*sqrt(2*g^2+Delta^2)','uniform_chain_mean':'n/Gamma+(n-1)*Gamma/(4*g^2)','uniform_chain_optimum_Gamma_over_g':'2*sqrt(n/(n-1))','uniform_episode':{'m':13,'history_addresses':14,'transient_levels':15,'dark_levels':1,'total_clock_latch_levels':16,'g':'1/8','Gamma':'1/4','exact_mean':'116','exact_all_future_ideal_error_target':'1/1024','exact_Markov_sufficient_deadline':'118784','optimal_mean_Gamma_over_g':2*sqrt(15/14)},'deadline_search':deadlines,'parent_53_latch_diagnostics':full_rows,'exact_checks':exact,'numerical_diagnostics':diagnostics,'status_boundary':'Conditional ideal Markov model and analytic derivations; independent proof/priority review pending; finite-time numerical trajectories are diagnostics, not certified enclosures; physical promotion0','not_claimed':['Finite-time exact total absorption','A finite closed reservoir implementing permanent Markov decay','A universal energy lower bound','Generic address dephasing formula','Inherited64vs53 resource improvement for this open task','Global deadline optimum']}
(O/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['status','exact_check_count','numerical_diagnostic_count','largest_diagnostic_residual','isolated_resonant_mean_optimum_Gamma_over_g','uniform_episode','deadline_search']},indent=2))
