"""Build the IEEEtran A4 open-latch research note after replay_latch.py."""
from pathlib import Path
import json,csv,subprocess
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript';O=R/'results';F=R/'figures'
r=json.loads((O/'REPLAY_RECEIPT.json').read_text())
plt.rcParams.update({'font.size':8,'axes.spines.top':False,'axes.spines.right':False})
x=np.geomspace(.15,15,500)
fig,ax=plt.subplots(figsize=(3.5,2.35));ax.semilogx(x,2/x+x/4,label='Isolated latch: g E[tau]');ax.semilogx(x,(15/x+14*x/4)/15,label='Uniform 15 levels: g E[tau]/15');ax.axvline(2*np.sqrt(2),color='#315f89',ls=':',lw=.8);ax.axvline(2*np.sqrt(15/14),color='#ac622d',ls=':',lw=.8);ax.set(xlabel='Decay-to-coupling ratio Gamma/g',ylabel='Normalized mean capture time');ax.legend(fontsize=6.8);ax.grid(alpha=.15);fig.tight_layout();fig.savefig(F/'MEAN_CAPTURE_OPTIMA.pdf');fig.savefig(F/'MEAN_CAPTURE_OPTIMA.png',dpi=220);plt.close(fig)
rows=list(csv.DictReader((O/'UNIFORM_EPISODE_TRACE.csv').open()));t=np.array([float(a['time']) for a in rows]);s=np.array([float(a['survival_complete_error']) for a in rows]);p=np.array([float(a['clock_traced_body_error']) for a in rows]);b=np.array([float(a['mean_Markov_bound']) for a in rows])
fig,ax=plt.subplots(figsize=(3.5,2.4));ax.semilogy(t,np.maximum(s,1e-15),label='Complete latched-state error S(t)');ax.semilogy(t,np.maximum(p,1e-15),label='Clock-traced body error p(t)');ax.semilogy(t,b,label='Analytic mean bound min(1,116/t)',ls='--');ax.axhline(1/1024,ls=':',color='grey',lw=.8);ax.set(xlabel='Model time',ylabel='Trace distance');ax.legend(fontsize=6.0);ax.grid(alpha=.15);fig.tight_layout();fig.savefig(F/'UNIFORM_CAPTURE_TRACE.pdf');fig.savefig(F/'UNIFORM_CAPTURE_TRACE.png',dpi=220);plt.close(fig)
tex=r'''\documentclass[a4paper,journal,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,graphicx,booktabs,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{\lvert#1\rangle}
\newcommand{\bra}[1]{\langle#1\rvert}
\newcommand{\norm}[1]{\lVert#1\rVert}
\begin{document}
\title{An Open-System Latch for Finite Quantum Episodes: Exact Capture Error and Objective-Dependent Damping}
\author{Benjamin Walker Mayes\thanks{Independent researcher. ORCID: 0009-0002-5813-0724. MQM development v0.1, October 5, 2026. Independent mathematical review and theorem-level priority comparison are pending. Physical promotion remains zero.}}
\markboth{MQM Research Development, Version 0.1, October 2026}{Mayes: Open-System Quantum Episode Latch}
\maketitle
\begin{abstract}
We audit a proposed dissipative terminal latch for a finite execute, capture, and renewal episode. An auxiliary excited level coherently coupled to a completed clock address decays into an absorbing dark level under an explicitly assumed Markov semigroup. The construction changes the closed-system contract; it does not contradict the finite static unitary obstruction or provide a finite replenished reservoir. For a prefix-dressed terminal jump and degenerate body benchmark, the exact complete retained-system error relative to a dark-clock completed-word target equals no-jump survival. A uniform finite path gives an exact mean absorption time $n/\Gamma+(n-1)\Gamma/(4g^2)$ and a mean-optimal ratio $\Gamma/g=2\sqrt{n/(n-1)}$. An isolated resonant latch instead has mean-optimal ratio $2\sqrt2$; a detuned isolated latch has $\Gamma=2\sqrt{2g^2+\Delta^2}$. These objectives differ from optimizing a finite deadline. A fourteen-address history clock with one excited and one dark level implements the thirteen-step logical episode in the ideal model. At $g=1/8$, $\Gamma=1/4$, its mean is exactly 116 model units; a conservative analytic all-future error bound reaches $1/1024$ at 118784 units. We correct unsupported address-dephasing and universal heat-cost assertions and retain explicit reservoir, hold, and perturbation requirements. Numerical replay is diagnostic rather than experimental evidence.
\end{abstract}
\begin{IEEEkeywords}
Quantum control, Lindblad dynamics, history Hamiltonians, absorbing states, first-passage time, resource accounting.
\end{IEEEkeywords}

\section{Motivation and Contract Change}
\IEEEPARstart{D}{issipation} can stabilize quantum states and encode computation in steady states; this is established prior art \cite{verstraete}. Effective-operator elimination is also standard \cite{reiter}. The question here is narrower: can an ideal terminal sink capture the completed finite MQM word while retaining outputs, outgoing donors and input correlations, and what damping objective can be optimized exactly?

Theorem 9 of the earlier Paper A draft \cite{paperA} states that an invariant subspace of a finite time-independent Hermitian generator is reducing. Population cannot first enter such an exactly invariant subspace from its orthogonal complement. It explicitly leaves open-reservoir models outside that closed contract. A Lindblad jump supplies directed population transfer, so its use changes assumptions rather than refutes the obstruction. A finite register labelled ``reservoir'' does not by itself justify a permanent memoryless semigroup.

This note develops that open branch separately from the certified 53-address closed-clock result \cite{clock53}. Different targets, auxiliary levels, reservoir assumptions and deadlines must be counted. Neither the closed $16\!\le\!D_\star\!\le\!53$ bracket nor its original imperfection certificate is promoted by the present construction.

\section{A Correct Terminal-Latch Model}
\subsection{History path and reservoir reduction}
Let $G_1,\ldots,G_m$ be supplied primitives, $P_0=I$, $P_j=G_j\cdots G_1$, with $P_j=P_m$ after completion. A clock has addresses $0,\ldots,r$, $r\ge m$, with nonzero nearest-neighbor edges. Add orthogonal excited and dark levels $e,d$, with prefix dressings $P_e=P_d=P_m$. Put
\begin{align}
\widetilde K={}&K+g(\ket e\bra r+\ket r\bra e)
                  +\Delta\ket e\bra e,\label{eq:K}\\
V={}&\sum_{j=0}^r\ket j\bra j\otimes P_j
 + (\ket e\bra e+\ket d\bra d)\otimes P_m,\\
H={}&V(\widetilde K\otimes I_B)V^\dagger,\quad
L=\sqrt\Gamma\ket d\bra e\otimes I_B.\label{eq:HL}
\end{align}
Here $\widetilde K$ acts as zero on $d$, $g,\Gamma>0$, and spectator identities are implicit. We use $\hbar=1$, model units. Because $P_r=P_e$, the latch coupling is the body identity in the physical history frame. If an additional capture operation is still required at the latch, its prefix must instead be included in the coherent edge; identity coupling cannot silently perform it twice or supply a missing gate.

The retained-system density operator evolves as
\begin{equation}\label{eq:L}
\dot\rho=\mathcal L(\rho)=-i[H,\rho]+L\rho L^\dagger
-\tfrac12\{L^\dagger L,\rho\}.
\end{equation}
The clock, body and finite auxiliary levels are retained. The external Markov bath is traced out. It is not part of the finite density operator in \eqref{eq:L}. A bath-inclusive state claim requires a specified dilation and target.

\subsection{No-jump evolution and dark hold}
On the transient levels $Q=\{0,\ldots,r,e\}$ the correct conditional amplitude generator is
\begin{equation}\label{eq:B}
B=-i\widetilde K_Q-\tfrac\Gamma2\ket e\bra e,\quad
u(t)=e^{tB}\ket0.
\end{equation}
Equivalently, the conditional Hamiltonian is $\widetilde K_Q-i\Gamma\ket e\bra e/2$. It includes the excited level, detuning and coherent latch coupling. It describes absence of a jump; the feeding term in \eqref{eq:L} is required for unconditional density evolution \cite{reiter}.

Write $S(t)=\norm{u(t)}^2$. Then
\begin{equation}\label{eq:flux}
S'(t)=-\Gamma|u_e(t)|^2,\quad F(t)=1-S(t).
\end{equation}
The dark sector is absorbing because the specified Hamiltonian has no coherent edge out of it and $L\ket d=0$. In a larger model require every additional jump to preserve the sector and its information, not merely a commutator with a clock projector.

Indeed, $[\ket d\bra d\otimes I_B,I_C\otimes H_B]=0$ for every $H_B$. This does not make a captured body state stationary. For a fixed target $\tau$, require $[H_d,\tau]=0$ and absence of destructive dark-sector noise, or compare with its declared free evolution. This note sets all bare body Hamiltonians to zero. It does not infer preservation of an involution $J_*$ from a clock-only commutator.

\section{Exact Operational Capture Error}
The initial bank is fixed and pure, the clock launches at zero, and the computational input may be mixed and correlated with an arbitrary spectator. All outputs, donors, records and spectators stay in $B$. The target is
\begin{equation}
\rho_\star=\ket d\bra d\otimes\tau,\quad
\tau=P_m\rho_B P_m^\dagger.
\end{equation}
The completed word includes a fresh final flag whose value is zero on every prefix $j<m$ and one after step $m$.

\begin{theorem}[Complete absorbing-target error]\label{thm:error}
For \eqref{eq:HL}--\eqref{eq:L}, every admitted input has retained-system trace distance and normalized diamond distance from the ideal completed dark-clock channel equal to $S(t)$. After tracing the clock and auxiliary levels, the body error equals
\begin{equation}\label{eq:p}
p_{\rm inc}(t)=\sum_{j<m}|u_j(t)|^2.
\end{equation}
\end{theorem}
\begin{proof}
The no-jump map is
$A_t=\sum_{j\in Q}u_j(t)\ket j\otimes P_j$
and $A_t^\dagger A_t=S(t)I$. Every jump from $e$ carries $P_m\rho_B P_m^\dagger$ into $d$. The state is exactly
\begin{equation}\label{eq:rho}
\rho_t=A_t\rho_BA_t^\dagger+(1-S(t))\rho_\star.
\end{equation}
The two clock sectors are orthogonal. Subtracting $\rho_\star$ gives one positive block of trace $S$ and one negative block of trace $-S$, hence half trace norm $S$. Spectator extension and the channel supremum preserve this equality. Clock reduction leaves all completed prefixes equal to $\tau$. The incomplete mixture of trace $p_{\rm inc}$ is in the opposite final-flag sector, proving its half trace norm is $p_{\rm inc}$.
\end{proof}
The error differs from the closed-clock $\sqrt{2p-p^2}$ because both the target clock and the operational channel have changed. Desired capture is part of the ideal open generator, not an additional generic ``dephasing debit.'' The bath is excluded from this operational target.

\begin{proposition}[Eventual absorption, not finite-time exact absorption]
For a connected finite path with the latch at its endpoint, all transient modes of \eqref{eq:B} have strictly negative real eigenvalues. Thus $S(t)\to0$, but $S(t)>0$ at every finite time for a nonzero launch.
\end{proposition}
\begin{proof}
For an eigenvector $Bw=\lambda w$, taking the real part yields
$\operatorname{Re}\lambda\norm w^2=-\Gamma|w_e|^2/2$.
A zero real part forces $w_e=0$. The endpoint eigenvalue equation then forces $w_r=0$; nonzero edges recursively force all remaining components to zero, a contradiction. Finite matrix stability gives decay. The matrix exponential is invertible at finite time, so it cannot annihilate the initial vector.
\end{proof}
A latch attached to an interior address instead needs a separate no-dark-mode proof; connectedness alone is insufficient on that geometry. Once a jump has occurred, its branch stays in the dark sector in the ideal model. Unconditional absorption reaches unity only asymptotically.

\section{Optimal Damping Depends on the Objective}
\subsection{Exact isolated-latch mean}
First remove the history path and launch directly at its completed terminal level. The isolated latch has transient Hamiltonian $g(\ket m\bra e+\ket e\bra m)+\Delta\ket e\bra e$. Define integrated populations $Q_m,Q_e$ and integrated coherence $X+iY=\int_0^\infty a(t)b(t)^*dt$. Integrated equations give
\begin{align}
Q_e&=1/\Gamma,\qquad Y=1/(2g),\qquad X=-\Delta/(g\Gamma),\\
Q_m-Q_e&=\Gamma/(4g^2)+\Delta^2/(g^2\Gamma).
\end{align}
Since $\mathbb E\tau=\int_0^\infty S(t)dt=Q_m+Q_e$,
\begin{equation}\label{eq:isolated}
\mathbb E\tau=\frac{2}{\Gamma}+\frac{\Gamma}{4g^2}
                         +\frac{\Delta^2}{g^2\Gamma}.
\end{equation}
For fixed $g,\Delta$, differentiation, or the arithmetic--geometric mean inequality, proves
\begin{align}
\Gamma_{\rm mean}^\star&=2\sqrt{2g^2+\Delta^2},\label{eq:detopt}\\
(\mathbb E\tau)_{\min}&=\sqrt{2g^2+\Delta^2}/g^2.
\end{align}
On resonance $\Gamma/g=2\sqrt2$ and $g\mathbb E\tau=\sqrt2$. This is a global optimum for the stated mean objective. It does not assume $\Gamma\gg g$.

\subsection{A full uniform history path}
Take $n\ge2$ transient levels on a zero-diagonal uniform path, with every edge $g$, and decay only from the last level. Its real-phase amplitude generator has lower diagonal $g$, upper diagonal $-g$ and final diagonal $-\Gamma/2$. Write it as $A$ and launch at the first level.

\begin{theorem}[Uniform-path mean]\label{thm:mean}
The mean absorption time and its fixed-$g$ optimum are
\begin{align}
\mathbb E\tau&=\frac n\Gamma+\frac{(n-1)\Gamma}{4g^2},\label{eq:uniform}\\
\frac{\Gamma_{\rm mean}^\star}{g}&=2\sqrt{\frac n{n-1}},\quad
(\mathbb E\tau)_{\min}=\frac{\sqrt{n(n-1)}}g.
\end{align}
\end{theorem}
\begin{proof}
Stability follows from the endpoint argument. The integrated covariance
$X=\int_0^\infty v(t)v(t)^Tdt$
is the unique solution of
\begin{equation}
AX+XA^T=-\ket0\bra0.
\end{equation}
An explicit solution has diagonal $1/\Gamma+\Gamma/(4g^2)$ except for its final diagonal $1/\Gamma$, adjacent entries $1/(2g)$, and every other entry zero. Direct substitution proves the identity. Its trace is \eqref{eq:uniform}; minimizing its two positive reciprocal terms gives the remaining formulas.
\end{proof}
Here $n=m+2$: $m+1$ history addresses plus $e$. The dark level is additional. For $m=13$, $n=15$ gives $\Gamma/g=2\sqrt{15/14}\approx2.070197$. The isolated mean-optimal ratio $2\sqrt2$ cannot be used as a universal full-clock optimum. Arbitrary weighted clocks require their own first-passage analysis.

\begin{figure}[t]\centering
\includegraphics[width=\columnwidth]{../figures/MEAN_CAPTURE_OPTIMA.pdf}
\caption{Exact mean-time curves. The full uniform path is divided by its transient dimension for display. Vertical lines show the distinct analytic minima. Neither curve includes an unspecified dephasing penalty.}
\end{figure}

\subsection{Deadline error and asymptotic rate}
For the resonant isolated latch, let $\Omega=\sqrt{g^2-\Gamma^2/16}$. In the underdamped regime,
\begin{equation}\label{eq:S}
S(t)=e^{-\Gamma t/2}\left[
\left(\cos\Omega t+\frac\Gamma{4\Omega}\sin\Omega t\right)^2
+\frac{g^2}{\Omega^2}\sin^2\Omega t\right].
\end{equation}
The critical limit $\Gamma=4g$ is
$S(t)=e^{-2gt}[(1+gt)^2+(gt)^2]$;
hyperbolic continuation applies above it. Maximizing the asymptotic exponential decay rate gives the critical ratio 4, distinct from the mean optimum. A finite deadline is yet another objective.

For illustration, numerical grid and local refinement over $0.1\le\Gamma/g\le8$ give ratios about 3.07887 for $S(T)\le1/1024$ and 3.51218 for $S(T)\le2^{-16}$, with $gT$ about 4.19110 and 5.96719. These are best candidates within a numerical search, not globally certified deadline optima. Initial-terminal launch is assumed. Adding latency and a dimensionless error directly is not meaningful without weights, constraints and an actual unwanted-noise generator.

\section{A Thirteen-Step Open Episode}
The body is $(A,J,D_{1A},D_{1J},D_{2A},D_{2J},O_1,O_2,E)$, nine qubits. Input $A$ may be correlated with a spectator. The fixed bank has $D_{1A}=\ket+$, with all other non-input body qubits in $\ket0$. Bare body Hamiltonians vanish. The same logical word as the closed reference is
\begin{align}
(G_1,\ldots,G_{13})={}&(H_A,T_A,\mathrm{CNOT}_{A,J},\nonumber\\
&\mathrm{SWAP}_{A,O_1},\mathrm{SWAP}_{A,D_{1A}},\nonumber\\
&\mathrm{SWAP}_{J,D_{1J}},T_A,H_A,\mathrm{CNOT}_{A,J},\nonumber\\
&\mathrm{SWAP}_{A,O_2},\mathrm{SWAP}_{A,D_{2A}},\nonumber\\
&\mathrm{SWAP}_{J,D_{2J}},X_E).
\end{align}
Here $T=\operatorname{diag}(1,e^{i\pi/4})$. Use fourteen addresses $0,\ldots,13$, latch at 13, and add $e,d$. The total is sixteen clock/latch levels, with the reservoir uncounted until a separate physical contract is supplied. This dimension is not an improvement within the closed comparison class.

Set every coherent path and latch edge to $g=1/8$, and $\Gamma=1/4$. On the transient legal sector the coherent norm is below $2g=1/4$, largest edge is $1/8$, and launch variance is $1/64$. The dissipative rate is a separate resource. Theorem~\ref{thm:mean} gives exactly $\mathbb E\tau=116$. Since $S$ is a non-increasing survival function,
\begin{equation}\label{eq:Markov}
S(t)\le\min\{1,\mathbb E\tau/t\}.
\end{equation}
Thus complete ideal error is at most $1/1024$ for every $t\ge118784$. This exact mean-based bound is conservative; numerical trajectories fall sooner. It is not the previous $[63\pi/4,189\pi/4]$ window.

\begin{figure}[t]\centering
\includegraphics[width=\columnwidth]{../figures/UNIFORM_CAPTURE_TRACE.pdf}
\caption{Numerical uniform-episode diagnostics versus the rigorous analytic mean-based tail bound. The dotted target is $1/1024$. Numerical curves have no interval certificate here; the all-future analytic guarantee uses \eqref{eq:Markov}.}
\end{figure}

As a separate diagnostic we attach $e,d$ to endpoint 52 of the earlier 53-address dyadic clock with $g=1/4$. Exact leading-minor checks admit its enlarged coherent norm below one. There are now 55 clock/latch levels. Tested rates $\Gamma\in\{1/8,1/4,1/2,1/\sqrt2,1,2,4\}$ leave survival at the old window endpoint approximately $\{0.662,0.463,0.253,0.177,0.141,0.211,0.413\}$. These choices fail the dark-clock target at that deadline; they do not prove all rates fail. Finite-time dense and sparse exponentials agree within recorded tolerances. Very long-lived modes can make a numerical Lyapunov mean solve ill-conditioned, so no such mean is promoted for this shaped extension.

\section{Correcting Detuning and Error Assertions}
For an isolated weak coupling to an excited level with detuning $\Delta$, effective-operator elimination \cite{reiter} gives, up to an irrelevant jump phase,
\begin{align}
L_{\rm eff}&=\frac{\sqrt\Gamma g}{\Delta-i\Gamma/2}\ket d\bra m,\\
H_{\rm shift}&=-\frac{g^2\Delta}{\Delta^2+(\Gamma/2)^2}\ket m\bra m,\\
\kappa(\Delta)&=\frac{g^2\Gamma}{\Delta^2+(\Gamma/2)^2}
               =\frac{4g^2\Gamma}{4\Delta^2+\Gamma^2}.\label{eq:kappa}
\end{align}
On resonance this recovers $4g^2/\Gamma$. It is an approximate population-loss rate, not a generic address-dephasing law. Loss also damps coherences; it is not a jump returning population to the original level. Genuine phase noise requires specifying its jump channels. The mean optima above are generally outside the fast-decay regime and use exact dynamics instead.

Clock addresses are not energy eigenmodes. For clock mode $\phi_\alpha$ of energy $E_\alpha$, a perturbative secular treatment involves detuning $E_e-E_\alpha$ and squared overlap $g^2|\bra r\phi_\alpha\rangle|^2$. Both are absent from the proposed address-indexed expression. Mode cross terms and secular validity need review. A claimed suppression below the supply allowance $2^{-16}$ cannot be inferred without that model and its time horizon. The supply allowance is not an automatic budget for a new dissipative mechanism.

A valid composition bound compares actual and ideal open generators. If initial discrepancy is $\epsilon_B$, Hamiltonian mismatch is at most $d_H$, and the additional generator discrepancy is a bounded superoperator $\mathcal R$ with diamond norm at most $r_{\mathcal R}$, Duhamel and channel contractivity give
\begin{equation}\label{eq:ledger}
D(\rho_t^{\rm act},\rho_\star)
\le\min\{1,S(t)+\epsilon_B+td_H+tr_{\mathcal R}/2\}.
\end{equation}
Norms must cover the same retained domain; a channel claim additionally needs a uniform preparation guarantee. For one jump perturbation $L\mapsto L+E$, submultiplicativity gives
\begin{equation}
\norm{\mathcal D[L+E]-\mathcal D[L]}_\diamond
\le4\norm L\norm E+2\norm E^2.
\end{equation}
This is one explicit debit, not a sum of unspecified rates. Applying the old $d_H=2^{-21}$ at the conservative 118784-unit deadline already makes the perturbation allowance about 0.0566; it cannot certify the old total target. A tighter finite-time open certificate and a newly admitted noise ledger are needed.

\section{Reservoir and Publication Boundaries}
No universal $\Delta E\ge\hbar\omega_e$ follows from \eqref{eq:L}. If a physical, energy-resolved downward transition carries a specified positive Bohr energy $\hbar\omega_{ed}$, its emitted-event count can determine a heat contribution; coherent-drive work and interaction energies must also be counted. The present zero-diagonal logical latch is not itself an energy-resolved thermal derivation. Irreversibility alone supplies neither that photon energy nor a reservoir-capacity number. We make no finite reservoir or entropy-export cost theorem.

At nonzero temperature, an additional upward jump
$L_\uparrow=\sqrt\nu\ket e\bra d$
gives
$\mathcal D[L_\uparrow](\ket d\bra d)=\nu(\ket e\bra e-\ket d\bra d)$.
It removes exact dark invariance. Leakage, body noise, finite bath memory and rate drift likewise require a hold-horizon ledger. The ideal asymptotic semigroup does not renew the supervisor, create fresh donors or validate an indefinitely reusable processor.

The replay passes __EXACT__ rational identity/admission checks and __NUM__ numerical diagnostics. Its independent small full-Lindblad fixture uses a two-step word, entangled and mixed spectator inputs, and compares the resulting density operator with \eqref{eq:rho}, complete distance with $S$, and body distance with $p_{\rm inc}$. Full nine-qubit word correctness uses its anchored parent constructor and the prefix theorem; this note does not rerun every body register of that episode under an explicit bath dilation.

The publishable next target is a resource-matched finite-time open-clock certificate, with a specified unwanted-noise generator and reservoir contract, compared against established dissipative computing \cite{verstraete}. Independent review should verify the retained-domain theorem, exact covariance identity, elimination assumptions and thermodynamic scope. Permanent Markov capture is an ideal-model mechanism; priority, physical realization and resource advantage remain unpromoted.

\begin{thebibliography}{4}
\bibitem{verstraete} F. Verstraete, M. M. Wolf, and J. I. Cirac, ``Quantum computation and quantum-state engineering driven by dissipation,'' \emph{Nature Physics}, vol. 5, pp. 633--636, 2009, doi: 10.1038/nphys1342.
\bibitem{reiter} F. Reiter and A. S. S\o rensen, ``Effective operator formalism for open quantum systems,'' \emph{Phys. Rev. A}, vol. 85, p. 032111, 2012, doi: 10.1103/PhysRevA.85.032111.
\bibitem{paperA} B. W. Mayes, ``Joint error bounds for finite quantum controllers, output capture, and module renewal,'' MQM IEEE-focused Paper A, development draft v0.1, Oct. 2026, unpublished.
\bibitem{clock53} B. W. Mayes, ``A certified 53-address clock for finite quantum execution, capture, and renewal,'' MQM development v0.1, Oct. 5, 2026, unpublished.
\end{thebibliography}
\end{document}
'''
tex=tex.replace('__EXACT__',str(r['exact_check_count'])).replace('__NUM__',str(r['numerical_diagnostic_count']))
p=M/'MQM_DISSIPATIVE_LATCH_IEEE_A4_v0.1.tex';p.write_text(tex)
for i in range(3):
 run=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',p.name],cwd=M,capture_output=True,text=True);(O/f'PDF_BUILD_{i+1}.txt').write_text(run.stdout+run.stderr)
 if run.returncode:raise RuntimeError('pdfLaTeX failed; inspect build receipt')
doc=fitz.open(p.with_suffix('.pdf'))
assert all(abs(page.rect.width*25.4/72-210)<.1 and abs(page.rect.height*25.4/72-297)<.1 for page in doc)
assert '??' not in ''.join(page.get_text() for page in doc)
assert 'Overfull' not in p.with_suffix('.log').read_text()
print(f'Built {len(doc)}-page IEEEtran A4 note with resolved references and no overfull boxes.')
