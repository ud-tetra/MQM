MQM COARSE GRAINED WORD v0.1
Two separate workloads; physical promotion0.

Replay:
 python3 audit_bath.py
 python3 audit_word.py
 python3 certify_word.py
PDF: python3 build_pdf.py; inspect PAGE_*.png.
Dependencies in requirements.txt; pdflatex external.

21 exact word checks;46 numerical bath/word checks; independent interval complete-word certificate.
All5 frozen filtered bath choices fail port target at16. PSD is not a physical accuracy certificate.
Comparison bound is between specified generators; no microscopic reference or approximation closure.
Complete13-step bank word conditional history-gauge certificate at1024+/-1/1024, local bath.
Local reverse sufficient range2^-31 with exact bound3145729/274877906944 <1/65536.
Entire output/donor bank and arbitrary references retained; bath traced.
No physical2local compiler, joint admission closure, hardware or advantage.
Original quadrature recipe retained; numerical repair disclosed.
Word clock native17-levels+F,R,body9; not clock qubit compression proof.
IEEEtran distributed under LPPL,license retained.
