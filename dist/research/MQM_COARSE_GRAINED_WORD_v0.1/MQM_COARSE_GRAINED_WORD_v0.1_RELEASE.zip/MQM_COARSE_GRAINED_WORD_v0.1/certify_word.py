"""Independent directed interval left-edge certificate plus monotone survival."""
from pathlib import Path
from fractions import Fraction
import json,math
from mpmath import iv
iv.dps=80
R=Path(__file__).resolve().parent

def rat(v):f=Fraction(v);return iv.mpf(f.numerator)/f.denominator
n=17;lam=iv.sqrt(4*iv.sqrt(rat(2)));A=[[rat(0) for _ in range(n)] for _ in range(n)]
for i in range(n-1):w=lam if i==15 else rat(1);A[i][i+1]=-w;A[i+1][i]=w
A[16][16]=rat(-4)
t=rat(Fraction(1024)-Fraction(1,1024));scale=20;B=[[a*t/2**scale for a in row] for row in A]
def eye():return [[rat(int(i==j)) for j in range(n)] for i in range(n)]
def mul(V,W):return [[sum(V[i][k]*W[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
V=eye();term=eye()
# Taylor multiplication by tridiagonal B only.
for order in range(1,25):
 term=[[sum(term[i][k]*B[k][j] for k in range(max(0,j-1),min(n,j+2)))/order for j in range(n)] for i in range(n)]
 V=[[V[i][j]+term[i][j] for j in range(n)] for i in range(n)]
b=(2+lam+4)*t/2**scale;remainder=iv.exp(b)*b**25/math.factorial(25);rad=iv.mpf([-remainder.b,remainder.b]);V=[[v+rad for v in row] for row in V]
for _ in range(scale):V=mul(V,V)
q=sum(V[i][0]*V[i][0] for i in range(n));ceil=Fraction(1,2**17);assert q.b<rat(ceil).a
reverse=ceil+8*Fraction(1,2**31)*(1024+Fraction(1,1024));assert reverse<Fraction(1,2**16)
res={'status':'INTERVAL VERIFIED cold complete-word retained-channel window; DERIVED local reverse-jump allowance','selected_center':1024,'half_width':'1/1024','selection_disclosure':'First passing frozen numerical sample selected for independent directed interval verification; not minimum deadline or independent prediction','left_time_exact':str(Fraction(1024)-Fraction(1,1024)),'error_interval_at_left':str(q),'exact_cold_ceiling':str(ceil),'window_proof':'A+A^T=-8 P_last gives qprime=-8|amplitude_last|^2<=0. Left-edge interval bounds whole window and later cold times.','method':'80-digit directed intervals, Taylor24 scale2^20, analytic infinity-norm remainder and interval squaring','exact_reverse_ratio_max':str(Fraction(1,2**31)),'exact_reverse_total_bound':str(reverse),'target':'1/65536','scope':'Abstract history-gauge bank word; fixed launch; full donor/output bank and spectators retained; original bath traced; local Markov generator only. Not coarse-grained Ohmic bath or physical2local compiler.','physical_promotion':0}
(R/'results/WORD_INTERVAL_CERTIFICATE.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
