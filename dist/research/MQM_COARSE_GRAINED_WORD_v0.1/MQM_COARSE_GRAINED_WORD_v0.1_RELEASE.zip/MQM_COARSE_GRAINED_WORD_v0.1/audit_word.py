"""History-gauge composition of complete 13-step bank word and terminal marker."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,math
import numpy as np
import sympy as s
from scipy.linalg import expm
R=Path(__file__).resolve().parent
roles=['A','J','O1','O2','D1A','D1J','D2A','D2J','E']
word=[('H',['A']),('T',['A']),('CNOT',['A','J']),('SWAP',['A','O1']),('SWAP',['A','D1A']),('SWAP',['J','D1J']),('T',['A']),('H',['A']),('CNOT',['A','J']),('SWAP',['A','O2']),('SWAP',['A','D2A']),('SWAP',['J','D2J']),('X',['E'])]
P={'status':'FROZEN before word evaluation','word':word,'body_roles':roles,'body_dimension':512,'clock_addresses':'0..13,p=13; plus m,e,d =17 native levels','flag_F':'separate fresh completion qubit, not body exhaustion E','auxiliary_R':'qubit; cold local rate8','live_path_vertices':17,'uniform_hopping':1,'final_e_to_dR1_coupling_squared':'4sqrt2','initial_clock_flag_aux':'address0,F0,R0','fixture_body':'all nine qubits0, explicitly chosen; general certificate via history gauge','times':[16,64,256,1024,4096,16384],'target':'1/65536 fixed-launch full retained word channel; bath traced, arbitrary body/reference retained','locality':'abstract gate-labelled history edge; controlled two-body data gates are generally three-subsystem terms; no physical2local compiler claim','physical_promotion':0}
(R/'WORD_PROTOCOL.json').write_text(json.dumps(P,indent=2));ex=[];nu=[]
def ck(n,v,L):assert bool(v),n;L.append(n)
H=s.Matrix([[1,1],[1,-1]])/s.sqrt(2);T=s.diag(1,(1+s.I)/s.sqrt(2));X=s.Matrix([[0,1],[1,0]]);CNOT=s.Matrix([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]]);SWAP=s.Matrix([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]])
gates={'H':H,'T':T,'X':X,'CNOT':CNOT,'SWAP':SWAP}
for name,g in gates.items():ck('exact unitary '+name,s.simplify(g.conjugate().T*g)==s.eye(g.rows),ex)
ck('exhaustion and completion roles differ',roles.index('E')==8 and 'F' not in roles,ex)
ck('word length13',len(word)==13,ex)
# Gauge identities rely on P_j=U_j...U_1, P_{j+1}=U_{j+1}P_j, and identical terminal prefixes.
for j,(name,bits) in enumerate(word,1):ck('declared gate support '+str(j),all(v in roles for v in bits) and len(bits)==int(math.log2(gates[name].rows)),ex)
# Exact physical positivity/cold survival of scalar no-jump system.
kappa=s.Rational(8);lam=s.sqrt(4*s.sqrt(2));A=s.zeros(17)
for j in range(16):w=lam if j==15 else s.Integer(1);A[j,j+1]=-w;A[j+1,j]=w
A[16,16]=-4
ck('dissipative no-jump symmetric part',A+A.T==s.diag(*([0]*16+[-8])),ex)
# Whole-bank fixture preserves donor correlations.
def apply(v,gate,bits):
 idx=[roles.index(b) for b in bits];other=[i for i in range(9) if i not in idx];perm=idx+other
 z=v.reshape([2]*9).transpose(perm).reshape(2**len(idx),-1);z=np.array(gate,complex)@z
 return z.reshape([2]*9).transpose(np.argsort(perm)).reshape(-1)
v=np.zeros(512,complex);v[0]=1
for j,(name,bits) in enumerate(word,1):v=apply(v,gates[name],bits);ck('bank state norm '+str(j),abs(np.vdot(v,v)-1)<1e-12,nu)
def reduced_pair(bits):
 idx=[roles.index(b) for b in bits];perm=idx+[i for i in range(9) if i not in idx]
 a=v.reshape([2]*9).transpose(perm).reshape(4,-1);return a@a.conj().T
negs={}
for bits in [['O1','D1J'],['O2','D2J']]:
 rho=reduced_pair(bits);pt=rho.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4);neg=float((sum(abs(np.linalg.eigvalsh(pt)))-np.trace(rho).real)/2)
 ck('captured donor pair Bell negativity '+str(bits),abs(neg-.5)<1e-12,nu);negs['_'.join(bits)]=neg
for b in ['A','J','E']:
 pr=float(sum(abs(v[j])**2 for j in range(512) if ((j>>(8-roles.index(b)))&1)))
 ck('endpoint bit '+b,abs(pr-int(b=='E'))<1e-12,nu)
rows=[];aa=np.array(A,float)
for t in P['times']:
 launch=np.zeros(17);launch[0]=1;vec=expm(aa*t)@launch;q=float(vec@vec)
 rows.append({'time':t,'retained_channel_error':q,'target_pass_numerical':q<1/65536})
 ck('survival nonnegative '+str(t),0<=q<=1+1e-12,nu)
# Full 68-state scalar spectrum is unitarily equivalent to bank-labelled history spectrum.
clock=np.zeros((17,17));
for j in range(13):clock[j,j+1]=clock[j+1,j]=1
mark=np.zeros((17,17));mark[13,14]=mark[14,13]=1
entry=np.zeros((17,17));entry[14,15]=entry[15,14]=1
ss=np.zeros((17,17));ss[16,15]=1
xx=np.array([[0,1],[1,0]]);sm=np.array([[0,1],[0,0]]);f1=np.diag([0,1])
scalar=np.kron(clock,np.eye(4))+np.kron(np.kron(mark,xx),np.eye(2))+np.kron(np.kron(entry,f1),np.eye(2))+float(lam)*(np.kron(np.kron(ss,np.eye(2)),sm.T)+np.kron(np.kron(ss.T,np.eye(2)),sm))
interaction_norm=float(np.linalg.norm(scalar,2));ck('full spectrum within row-sum bound',interaction_norm<1+float(lam)+1e-12,nu)
charge=np.kron(np.diag([1]*16+[0]),np.eye(4))+np.kron(np.eye(34),np.diag([0,1]))
labe=np.linalg.eigvalsh(64*charge+scalar);labnorm=float((labe[-1]-labe[0])/2)
res={'status':'EXACT gate/gauge construction; SIMULATED scalar arrival and whole-bank fixture','exact_count':len(ex),'exact_checks':ex,'numerical_count':len(nu),'numerical_checks':nu,'rows':rows,'endpoint_fixture_pair_negativity':negs,'channel_identity':'For V=sum_j|j><j| tensor P_j, P0=I and Pj=Uj...U1; use P13 on m,e,d. V-dressed history Hamiltonian and R bath have exact scalar-gauge dynamics. Every dark branch carries P13, preserving full output/donor bank and arbitrary references. Orthogonal live versus dark supports yield half-diamond error q(t) for fixed launch.','resources':{'full_interaction_norm_numeric':interaction_norm,'interaction_norm_upper':'1+sqrt(4sqrt2)','laboratory_centered_norm_numeric_for_Omega64':labnorm,'native_clock_levels':17,'completion_qubits':1,'auxiliary_qubits':1,'body_qubits':9,'native_full_dimension':17*4*512,'admitted_dimension':17*2*512,'binary_clock_embedding_bits':5,'binary_implementation_is_2local':False},'scope':'Abstract history-word composition, not reuse of earlier direct2local SWAP compiler; no physical geometry, admission or bath promotion','physical_promotion':0}
(R/'results/WORD_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k not in ['numerical_checks','exact_checks']},indent=2))
