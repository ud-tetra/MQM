MQM IEEE conversion baseline v0.1 | 5 October 2026

This is a development package. It contains a first IEEE-focused adaptation of the finite-controller manuscript and a four-paper publication crosswalk. It is not a submission-ready four-paper release. The input M5 release is unchanged.

Start with MQM_IEEE_CONVERSION_ASSESSMENT_v0.1.html. Read the PDF in manuscript/; its .source.txt contains Markdown with TeX mathematics, and the .tex is editable. The reading PDF uses a conventional single-column article layout. The official target-journal template remains a submission-preparation step.

Paper A carries the conditional claims of UD Paper IV, with proof labels 1-13 mapped in MQM_PAPER_A_CLAIM_CROSSWALK_v0.1.csv. The channel interpretation and fixed-norm substitutions are explicitly marked corollaries. Preparation, launch, pulse-off, routing, exhaustion refusal, and independent donors remain premises. No quantum-error-correction threshold, hardware result, or advantage is claimed.

From ud_validation/ run:
python3 replay/baseline/verify.py
python3 replay/m4/verify_m4_exact.py
OPENBLAS_NUM_THREADS=1 python3 replay/verify_paper_iv.py
The last command requires NumPy and SciPy. The historical SymPy repair scripts are included as inherited material and were not rerun. Execution writes receipts inside ud_validation/; do not confuse those future outputs with the immutable ingestion execution receipt in verification/.

The ud_sources/ files are byte-preserved copies of the four current M5 manuscript sources. The original payload manifest verifies the complete original release, whose full nested archives are not duplicated here. verification/ identifies the input ZIP by SHA-256 and records the actual principal replay executions. All checks have shared constructor lineage; independent review remains pending.

Candidate order: A controller/capture/renewal, B reconstruction/readout, C simplicial quantum-walk benchmarks, D symmetry-resolved operator families. These are research-development candidates, not a promise of four acceptable IEEE publications. Paper A absorbs Paper III section 13 to avoid duplicating the same result as another article.
