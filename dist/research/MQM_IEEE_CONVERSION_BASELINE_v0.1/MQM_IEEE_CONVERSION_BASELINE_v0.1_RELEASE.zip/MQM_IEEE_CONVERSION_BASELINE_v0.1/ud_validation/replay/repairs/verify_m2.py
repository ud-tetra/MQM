"""Exact M2 replay: reconstructed claims and deliberate-error controls.
General proofs are in the manuscripts; finite fixtures do not certify apparatus.
Requires SymPy. No historical complex certificate recovery is claimed.
"""
from pathlib import Path
import itertools,json
import sympy as s
OUT=Path(__file__).resolve().parent
checks=[]
def check(name,ok):
 if not ok:raise AssertionError(name)
 checks.append(name)

# Full filled-tet incidence graph and Matrix-Tree cofactor, not merely factor arithmetic.
nodes=[t for k in range(1,5) for t in itertools.combinations(range(4),k)]
idx={v:i for i,v in enumerate(nodes)}
edges=[(idx[t[:j]+t[j+1:]],idx[t],(-1)**j) for t in nodes if len(t)>1 for j in range(len(t))]
L=s.zeros(15)
for a,b,_ in edges:L[a,a]+=1;L[b,b]+=1;L[a,b]-=1;L[b,a]-=1
tau=L[:14,:14].det()
check('filled-tet 15 nodes and 28 incidences',len(nodes)==15 and len(edges)==28)
check('exact Matrix-Tree determinant',tau==2**8*3*17**3==3773184)

# Induced support forests: includes full, disconnected and isolated nonzero nodes.
ph=[1,(3+4*s.I)/5,s.I,(-5+12*s.I)/13]
fixture_count=0
for support in [(0,1,2,3),(0,2,3),(0,2),(3,)]:
 c=[s.Rational(i+1,5)*ph[i] if i in support else s.Integer(0) for i in range(4)]
 E=[(a,b,B) for a,b,B in [(0,1,-1),(1,2,1),(2,3,-1),(3,0,1)] if c[a]!=0 and c[b]!=0]
 S=sum(s.conjugate(v)*v for v in c)
 seen={};roots=[]
 for root in support:
  if root in seen:continue
  roots.append(root);seen[root]=ph[root];queue=[root]
  while queue:
   a=queue.pop(0)
   for u,v,B in E:
    if a not in (u,v):continue
    b=v if a==u else u
    J=2*B*s.conjugate(c[u])*c[v]
    ratio=s.simplify(B*J/(2*abs(c[u])*abs(c[v])))
    if a==v:ratio=s.conjugate(ratio)
    if b not in seen:seen[b]=s.simplify(seen[a]*ratio);queue.append(b)
    else:check(f'cycle consistency support {support} edge {u}-{v}',s.simplify(seen[a]*ratio-seen[b])==0)
 for a in support:
  check(f'complex normalization support {support} coordinate {a}',s.simplify(s.sqrt(s.conjugate(c[a])*c[a]/S)*seen[a]-c[a]/s.sqrt(S))==0)
 fixture_count+=1
check('isolated components demand independent roots',len([i for i in (0,2)])==2)
# Re-part does not identify a phase; explicitly test a pair and its conjugate.
c=s.Matrix([1,(3+4*s.I)/5]);J=2*s.conjugate(c[0])*c[1]
check('conjugate state shares Re receipt but not full phase',s.re(J)==s.re(s.conjugate(J)) and J!=s.conjugate(J))
check('deliberate inconsistent unit-cycle rejected',s.simplify(1*1*(-1))!=1)
check('real-skew complex stock continuity',s.simplify(2*s.re(s.conjugate(c[0])*(-c[1]))+s.re(J))==0)

H=s.Matrix([[1,1,1,0,1,1,0,0,0,1,0,0],[0,1,1,1,0,0,0,1,1,0,1,0],[0,0,0,0,1,1,1,1,1,0,0,1]])
kernel=[]
for word in itertools.product([0,1],repeat=12):
 if all(v%2==0 for v in H*s.Matrix(word)):kernel.append(word)
check('[12,9,2] exact code cardinality',len(kernel)==512)
check('[12,9,2] exact minimum distance',min(sum(w) for w in kernel if any(w))==2)
for a,b in [(1,10),(2,3),(4,11),(5,6),(7,12),(8,9)]:check(f'ambiguous single-error positions {a},{b}',H[:,a-1]==H[:,b-1])
check('all twelve single-sign errors detected',all(H[:,i]!=s.zeros(3,1) for i in range(12)))

# A visible coordinate can fail autonomous closure; a hidden signed mode matters.
A=s.Matrix([[0,1],[-1,0]]);P=s.Matrix([[1,0]]);v=s.Matrix([0,1])
check('noninvariant observed kernel prevents closure',P*v==s.zeros(1,1) and P*A*v!=s.zeros(1,1))
A2=s.diag(1,2);F=s.Matrix([[1]])
check('invariant kernel admits autonomous closure',P*A2==F*P)
Q=s.Matrix([[1,-1,-1,-1],[-1,1,-1,-1],[-1,-1,1,-1],[-1,-1,-1,1]])/4
V=s.Matrix([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]])/2
check('tetrahedral frame projector',V*V.T==s.eye(4)-s.ones(4)/4 and V.T*V==s.eye(3))
for m in range(1,9):check(f'stacked ball Euler identity m={m}',(m+3)-(3*m+3)+(3*m+1)-m==1)
initial=s.Rational(9271,5712)
check('source star memory change',s.Rational(2903,2856)-initial==-s.Rational(165,272))
check('source chain memory change',s.Rational(1733,952)-initial==s.Rational(161,816))
check('marginal success without any joint success',all(sum(w[i] for w in [(1,1,0),(1,0,1),(0,1,1)])==2 for i in range(3)) and not any(all(w) for w in [(1,1,0),(1,0,1),(0,1,1)]))
receipt={'status':'PASS','checks_passed':len(checks),'checks':checks,'complex_support_fixtures':fixture_count,'exact_tree_count':str(tau),'scope':'Finite exact replay plus written general proofs; original complex release and alternative-tree optimum not recovered.','independent_review':'PENDING','physical_promotion':0}
(OUT/'M2_EXACT_REPLAY.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','checks_passed','complex_support_fixtures','exact_tree_count']}))
