"""Reconstruct explicit compatible S4 bases for the supplied Gamma tensor.
No original author action matrices or physical coupling are claimed recovered.
"""
from pathlib import Path
import csv,json,itertools,hashlib
import sympy as s
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'T2_CONTEXT_GAMMA_MATRICES.csv'
OUT=ROOT
g=[s.zeros(3,2) for _ in range(3)]
for r in csv.DictReader(SRC.open()):
 for j in range(2):g[int(r['context_component'])-1][int(r['row'])-1,j]=s.sympify(r['E'+str(j+1)])
M=[s.Matrix.hstack(*[a[:,j] for a in g]) for j in range(2)]
Q=s.Matrix.hstack(s.Matrix([0,s.sqrt(2),1]),s.Matrix([s.sqrt(6)/2,-s.sqrt(2)/2,1]),s.Matrix([-s.sqrt(6)/2,-s.sqrt(2)/2,1]))/s.sqrt(3)
D=[s.diag(s.sqrt(3)/2,-s.sqrt(3)/2,0),s.diag(s.Rational(1,2),s.Rational(1,2),-1)]
P=s.Matrix.hstack(2*M[0]*Q[:,0]/s.sqrt(3),-2*M[0]*Q[:,1]/s.sqrt(3),-M[1]*Q[:,2])
sim=lambda X:X.applyfunc(s.simplify)
assert sim(Q.T*Q)==s.eye(3) and sim(P.T*P)==s.eye(3)
assert all(sim(M[i]-P*D[i]*Q.T)==s.zeros(3) for i in range(2))
# Rows of V are tetrahedral-frame vertices; this is the standard T2 action.
V=s.Matrix([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]])/2
assert V.T*V==s.eye(3)
actions=[];equiv=0
serialize=lambda A:[[str(s.simplify(v)) for v in A.row(i)] for i in range(A.rows)]
for perm in itertools.permutations(range(4)):
 R4=s.zeros(4)
 for j in range(4):R4[perm[j],j]=1
 R=V.T*R4*V
 Tctx=sim(Q*R*Q.T);Tout=sim(P*R*P.T)
 E=s.Matrix(2,2,lambda i,j:s.Rational(2,3)*s.trace(D[i]*R*D[j]*R.T))
 assert sim(E.T*E)==s.eye(2)
 for j in range(2):assert sim(R*D[j]*R.T-sum((E[i,j]*D[i] for i in range(2)),s.zeros(3)))==s.zeros(3)
 for b in range(3):
  rhs=sim(Tout*g[b]);lhs=sim(sum((Tctx[a,b]*g[a] for a in range(3)),s.zeros(3,2))*E)
  assert lhs==rhs;equiv+=1
 actions.append({'vertex_permutation':list(perm),'T2_standard':serialize(R),'T2_context':serialize(Tctx),'T2_output':serialize(Tout),'E':serialize(E)})
record={'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'scope':'New explicit source-derived compatible basis convention; does not recover unspecified historical basis matrices.','context_basis_change_Q':serialize(Q),'output_basis_change_P':serialize(P),'diagonal_E_basis':list(map(serialize,D)),'tetrahedral_vertex_frame_V':serialize(V),'actions':actions,'exact_equivariance_matrix_checks':equiv,'status':'PASS','physical_promotion':0,'independent_review':'PENDING','source_amplitude':'OPEN'}
(OUT/'GAMMA_BASIS_AND_S4_ACTIONS.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'PASS','actions':len(actions),'exact_equivariance_matrix_checks':equiv,'Q':serialize(Q),'P':serialize(P)}))
