"""Bounded reconstruction from Paper III pp. 4-5. Not recovered author certificates."""
from pathlib import Path
import sympy as s,json
z=s.Symbol('z')
def block(sector,k):
 if sector=='A1': return s.Matrix([[9,-6,-9],[-1,8,-3],[-1,-2,11]]) if k==1 else s.Matrix([[2*k+13,-6,-9],[-1,2*k+6,-3],[-1,-2,2*k+9]])
 return s.Matrix([[13,-2,1],[-1,8,1],[1,2,11]]) if k==1 else s.Matrix([[2*k+17,-2,1],[-1,2*k+6,1],[1,2,2*k+9]])
def matrix(sector,N):
 c=int(sector=='A1'); H=s.zeros(3*N+c)
 if c:H[0,0]=4;H[0,1]=H[1,0]=-2
 for k in range(1,N+1):
  a=c+3*(k-1);H[a:a+3,a:a+3]=block(sector,k)
  if k<N:
   b=a+3;B=s.Matrix([[-1,0,0],[-1,0,0],[-1 if sector=='A1' else 1,0,0]])
   Bt=s.Matrix([[-1,-6 if sector=='A1' else -2,-9 if sector=='A1' else 1],[0,0,0],[0,0,0]])
   H[a:a+3,b:b+3]=B;H[b:b+3,a:a+3]=Bt
 return H
intervals={'A1': [('2.066766567633982','2.066766567637642'),('4.191538100153076','4.191538100335074')], 'T2':[('6.686030497697500','6.686030497697504'),('8.967031711187236','8.967031711187948')]}
result={'scope':'Exact rational reconstruction of stated N=8 finite variational brackets; no general Weyl cyclicity theorem or original certificate recovery.','sectors':{}}
for sec in intervals:
 H=matrix(sec,8);L=H.copy();norm=4 if sec=='A1' else 2
 for j in range(H.rows-3,H.rows):L[j,j]-=norm
 pH=s.Poly(H.charpoly(z).as_expr(),z);pL=s.Poly(L.charpoly(z).as_expr(),z)
 rows=[]
 for k,(lo,hi) in enumerate(intervals[sec],1):
  a,b=s.Rational(lo),s.Rational(hi)
  # exact count via Sturm: lower bracket's kth eigenvalue above a; upper bracket's kth eigenvalue below b
  nL=int(pL.count_roots(-s.oo,a)); nH=int(pH.count_roots(-s.oo,b))
  rows.append({'k':k,'lo':str(a),'hi':str(b),'L_roots_below_lo':nL,'H_roots_below_hi':nH,'printed_bracket_supported':nL==k-1 and nH>=k})
 # e_first finite cyclicity by Krylov rank; finite truncation only.
 e=s.zeros(H.rows,1);e[int(sec=='A1'),0]=1
 cols=[];v=e
 for _ in range(H.rows):cols.append(v);v=H*v
 rank=s.Matrix.hstack(*cols).rank()
 result['sectors'][sec]={'N':8,'dimension':H.rows,'H_charpoly':list(map(str,pH.all_coeffs())),'L_charpoly':list(map(str,pL.all_coeffs())),'first_shell_Krylov_rank':rank,'checks':rows}
(Path(__file__).resolve().parent/'RADIAL_RECONSTRUCTION_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({sec:{'rank':v['first_shell_Krylov_rank'],'checks':v['checks']} for sec,v in result['sectors'].items()},indent=2))
