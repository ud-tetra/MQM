# Finite ladder reference and certified admission — v0.1

3 October 2026. Constructor: Codex, requested by Benjamin Walker Mayes. **Development — no registry entry; CRL-2a proposed interface. Physical promotion 0.** This is a conditional apparatus construction and an integer interval calculation. It establishes neither native reference production nor autonomous control, locality, hardware feasibility, empirical accuracy or independent review.

The previous exact coordinate carrier is preserved. Here a declared finite energy ladder replaces its enormous tensor box by accepting a bounded mismatch during each coupling pulse. The native ring Hamiltonian continues to run and is never rounded or replaced in the actual evolution. The mismatch is charged both to state accuracy and to controller switching work.

## 1. Source and admission

Use the parent oriented ring with native eigenvalues and selected input eigenstate:

$$
E_k=2J\sin\frac{2\pi k}{K},\qquad g=0,\qquad E_g=0.
$$

The declared packet has amplitudes proportional to exp[-w²(2πk/K)²], with separately admitted phases. For the native spectral projector P_b onto |k|≤b, let φ_b=P_bφ/√(1-q_b), q_b=||(I-P_b)φ||². Projection here specifies a prepared source; it is not a successful-outcome postselection. The full Gibbs-bank admission and outside-cutoff inputs remain in the prior full-joint budget.

For K=59049=3^10, h=19683=3^9: 59049=3·19683+0 and 59049≡0 (mod 3). The exact parent rank h remains valid in its rational/integer generator architecture. This ladder does not refute that theorem: it uses an operational approximation and a supplied controller. It does not provide an exact one-generator representation of the sine spectrum.

## 2. Declared finite carrier

Admit a resource spacing Δ>0, positive integers L,m, and pulse duration τ>0. These are apparatus inputs, not fitted native coefficients. On the admitted source subspace choose integers a_0=0, a_-k=-a_k, with a_k the nearest integer to E_k/Δ. Every rounding decision in the reported example is enclosed away from a tie. Define the comparator energies and mismatch:

$$
\bar E_k=\Delta a_k,\qquad D=H_S-\bar H_S,\qquad d=\|D\|\leq\frac{\Delta}{2}.
$$

Set comparator energies equal to native energies outside the cutoff, so D=0 there. The actual H_S remains native everywhere. Set C=max|a_k| and M=L+2(m+1)C. The reference has levels n=0,...,M-1, H_R=Δn, and initial pure state

$$
|\eta\rangle=\frac{1}{\sqrt L}\sum_{n=(m+1)C}^{(m+1)C+L-1}|n\rangle.
$$

There is no modulo translation on this reference. T_-a denotes translation only when its support remains inside the finite carrier. The initial margins accommodate all m admitted uses and the largest single transition. Incomplete blocks act as identity. At the admitted use-count limit, the supplied controller's specified acquisition policy refuses another pulse and appends END_OF_SUPPLY to the full history. This is not derived automatic shutdown. Incomplete-block identity is not itself a boundary-measurement instrument; any such monitor must be supplied and charged. The model contains no wrap, refill, automatic reset or successful-only renormalization.

For each complete q=n+a_k block of the cutoff system and reference, insert a desired cutoff unitary V; extend by identity on incomplete blocks and the source complement. This defines a finite unitary U satisfying

$$
[U,\bar H_S+H_R]=0,\qquad G=\frac{i\log U}{\tau},\qquad\|G\|\leq\frac{\pi}{\tau}.
$$

Choose a Hermitian principal logarithm blockwise. G is constant during a declared pulse. Its block interactions and their synthesis are supplied; nothing proves pairwise locality. Choose V_j|g>=Σ_k c_k exp(i\bar E_k t_j)|k>, where t_j is that pulse's actual endpoint relative to the initial reference phase. This supplies the reference phase compensation. Output clocks subsequently evolve with actual native H_S. It is an externally scheduled phase law, not an autonomous clock or a free classical phase ruler.

## 3. Native motion and the uniform pulse debit

The actual propagator and comparison propagator for a pulse are

$$
A=\exp[-i\tau(H_S+H_R+G)],\qquad B=\exp[-i\tau(\bar H_S+H_R)]U.
$$

Duhamel's integral identity, with unitary factors on both sides of D, gives

$$
\|A-B\|\leq\tau d.
$$

This operator bound applies to arbitrary inputs entangled with spectators and to every prior-use correlation. In the convention D_tr=||ρ-σ||_1/2, the associated trace-distance error is at most τd, including after an arbitrary CPTP extension or reduction. A telescoping channel comparison over m pulses gives at most Σ_j τ_j d_j; for identical pulses, mτΔ/2. Between pulses, both paths use the same actual native free dynamics, storage and acquisition maps. No future idle duration is multiplied by Δ, because the actual/comparison channel difference is confined to the pulses. Phase compensation above is selected consistently with the actual endpoint schedule.

This is a uniform pulse comparison, not a diamond bound for the source-preparation state admission. Pulse imperfections, timer jitter, phase-control errors and finite work-supply implementation remain separate debits. In the presence of an additional bounded concurrent contact h(t), charge its integrated operator norm by the same argument; do not assume the contact vanishes because native H_S is running.

## 4. Correlated multi-use state and admission budget

**Operating assumption:** the certified word-state budget describes the bank-production schedule with R coupled only to the declared preparation pulses and otherwise evolving freely. Downstream maps may be interleaved on emitted cells and separate acquisition resources; these commute with later preparation contacts on fresh cells and R. A detector, reset or storage operation that also contacts this same R does not satisfy that assumption. Supply an integrated contact bound and add it through a full channel comparison, or replay the actual joint schedule with the resulting reference backaction. The arbitrary-input pulse mismatch bound remains valid in that case, but the isolated word-overlap budget cannot be inherited unchanged.

Remove common actual output free phases and the common reference free evolution. The ideal comparator's full word state is

$$
|\Psi_m\rangle=\sum_{\boldsymbol k}\Big(\prod_jc_{k_j}\Big)|\boldsymbol k\rangle\otimes T_{-s(\boldsymbol k)}|\eta\rangle,\qquad s(\boldsymbol k)=\sum_ja_{k_j}.
$$

Its overlap with the independent admitted packet bank and untouched reference is

$$
A_m=\mathbb E\left(1-\frac{|s|}{L}\right)_+,\qquad \beta_m=\mathbb E|s|,\qquad\mu=\sum_k|c_k|^2|a_k|.
$$

Thus A_m≥(1-β_m/L)_+≥(1-mμ/L)_+. The expectation is over independent word coefficients of the comparator expansion; it does **not** assert that the emitted clocks and reference are independent states. Resource translations keep all output/reference/history correlations.

Against the original uncut pure packet bank and initial reference, the exact comparator trace distance and the conservative actual construction bound are

$$
\eta_{\mathrm{comp}}=\sqrt{1-(1-q_b)^m A_m^2},
$$

$$
\eta_{\mathrm{ladder}}\leq\min\left\{1,\sqrt{1-(1-q_b)^m\left(1-\frac{m\mu}{L}\right)_+^2}+\frac{m\tau\Delta}{2}\right\}.
$$

Charge this combined expression once. Do not add the same cutoff/reference errors again. Parent thermal admission, storage/export/reset, detector and implementation debits still apply on their established domains. The detector ε term applies only after the matching five-word/data/reference reduction, not to the global detector-pointer-environment state. Native six-quadrature pairing, gauge limits, failure posteriors, history ownership and source-selected zero amplitudes are unchanged.

For any complete readout instrument {I_z}, including every failure z, compare Σ_z|z><z|⊗I_z(ρ). This full CPTP record channel contracts the joint trace distance. All outcome probabilities, including failure probabilities, differ by at most that distance. A conditional successful posterior requires a separately charged probability-dependent bound; no such unconditional guarantee is converted into a success-only posterior claim here.

## 5. First law and controller supply

During a constant pulse the actual total H_S+H_R+G is conserved. The free energy H_0=H_S+H_R need not be. Switching on and off supplies mean work

$$
W_{\mathrm{ctrl}}=\langle G\rangle_{\mathrm{in}}-\langle G\rangle_{\mathrm{out}}=\Delta\langle H_0\rangle.
$$

Since [G,\bar H_S+H_R]=0, d<G>/dt=i<[D,G]> and

$$
|W_{\mathrm{ctrl}}|\leq2\tau d\|G\|\leq2\pi d\leq\pi\Delta.
$$

This bounds signed mean switching work, not its distribution, work fluctuations, peak control power, fabrication cost or a finite controller's return error. Work supply and phase-control resources must enter a later closed-system model. Exact free-energy conservation is deliberately not claimed for the native pulse.

For the comparator, reference energy change is -mΔ E[a], its variance increases by mΔ² Var(a), and the covariance of total native output energy with reference energy is -mΔ Cov(E,a). These are grid-shift receipts, not the old exact-gap energy receipts. Symmetric source weights give zero signed mean displacement but nonzero variance, entropy and correlations. For the actual state, a bounded-observable expectation changes by at most its spectral range times the pulse comparison trace distance; higher moments and covariance require their own range bounds. No two-point measurement of a coherent input bank is inserted to manufacture a work distribution.

Initial reference mean energy is Δ[(m+1)C+(L-1)/2]; its variance is Δ²(L²-1)/12. Returning it to the initial pure coherent state requires a supplied reset channel, outgoing waste/correlations and admitted error. None is implicit in the ladder's state-vector specification. Parent matched SWAP preparation/export still consumes independent supplied cells and exports old states/correlations. Native upstream coherent-bank production and autonomous pulse start/shutoff remain open.

## 6. Integer interval certificate

The replay uses integer endpoints on a 10^-60 grid. Addition, multiplication and positive division round outward by exact integer floor/ceiling. Square-root endpoints use integer square roots. π is enclosed by Machin's identity, π=16 arctan(1/5)-4 arctan(1/239), with 100 alternating-series terms and the next-term remainder for each arctangent.

To enclose exp(-x), halve x until 0≤y≤1/8. Sum the first 61 terms of exp(y), including the constant term. The omitted positive remainder is at most 2y^61/61!, since the subsequent ratios are bounded by y/62. Invert the positive interval and square for every halving. The sine-gap rounding checks use the sine series through x^41/41!, enclosing the next term x^43/43!; all example angles are below 1/8. Every interval operation is outward; a floating comparison with NumPy is only a sanity check.

For α=8w²π²/K², sum exp(-αk²) through B=2048. The remaining infinite two-sided tail is bounded by

$$
2\sum_{k=B+1}^{\infty}e^{-\alpha k^2}\leq\frac{2e^{-\alpha(B+1)^2}}{1-e^{-\alpha(2B+3)}}.
$$

The finite native tail contains the computed annulus b+1,...,B and is bounded above by that annulus plus this infinite remainder. Normalize by a correspondingly enclosed full finite partition sum. This encloses the **actual finite source tail**, without discarding it or using floating erfc as a certificate.

For the preserved b-coordinate exact carrier and m=3, each coordinate has signed increments with total moving probability p_j. Exact enumeration gives E|s_j|=3p_j-3p_j²+3p_j³/2. Sum these enclosed expressions to certify β_3. Linearity of expectation does not assert independent coordinates. The ladder instead uses the conservative mμ bound.

Certified outward short decimal intervals are shown below. Full 60-place integer-endpoint enclosures and all 769 nonnegative ladder shifts are in the replay JSON. Intervals for an error bound enclose the bound formula, not the unknown actual apparatus error.

| Quantity | Certified lower | Certified upper |
|---|---:|---:|
| Finite Gaussian q_b | 0.00000016633241863435248 | 0.00000016633241863435249 |
| Three-use cutoff trace distance | 0.00070639731943407145 | 0.00070639731943407146 |
| Exact coordinate β_3 | 2.98039293669532405 | 2.98039293669532406 |
| Preserved coordinate combined bound | 0.07624371979528230 | 0.07624371979528231 |
| Ladder μ | 1021.20914506065111377 | 1021.20914506065111378 |
| Ladder combined bound before pulse mismatch | 0.07638956301929898 | 0.07638956301929899 |
| Ladder combined bound plus pulse mismatch | 0.07653956301929898 | 0.07653956301929899 |

All entries use K59049,w32,b768,m3. The preserved coordinate example uses L1024=2^10. The ladder uses J4096=2^12, Δ=1/10, τ=1/1000 and L1048576=2^20. The certified maximum shift C is 6687, hence reference dimension M=1102072. Its free-energy span is 110207.1 in the declared energy units; initial mean energy is 55103.55, and variance 916259689.8125 in squared units. The finite three-use pulse mismatch debit is exactly 0.000150. The per-pulse signed mean switching-work absolute bound is below 0.314160.

The old exact coordinate reference dimension has log10 approximately 2314.506 for this cutoff. The ladder dimension is an exact integer, but its source/reference/coupling controls remain highly nonlocal and supplied. The timer and acquisition registers add further Hilbert space; no hardware dimension or total cost is inferred from M alone.

## 7. Replay and scope

The replay checks every admitted positive-gap rounding enclosure, explicit Taylor and geometric calculations, exact three-step trinomial identities, and finite K3,K5,K9 lifts. Native-pulse checks include unitarity, nonzero native free-energy commutator, approximate-energy commutation, finite logarithmic coupling, arbitrary spectator-entangled input, Duhamel bound, first-law switching work, safe signed translations, full-record probability contraction and phase-compensated preparation overlap. Results and exact counts are frozen in the replay JSON; equalities are numerical unless the replay uses integer/Fraction arithmetic.

Correction LB01, before freeze: floating inequality checks initially shared the exact-check counter. They now have a separate numerical counter. LB02, final scope review: the word-overlap budget explicitly excludes uncharged intervening detector/reset contacts on the same ladder; the uniform pulse bound still allows arbitrary correlated inputs. The final replay passes 1659 integer/structural/Fraction checks and 186 numerical checks; maximum equality residual is 4.679827440320725e-13 at tolerance 8e-9. The phase-preparation and two-endpoint correlated native-motion checks were added before freeze and passed. Parent TR01/TSP01/RBP01 corrections, failure records, rejected alternatives and risks are retained in the enclosed prior release. No constructor replay is promoted into a non-constructor review.

This construction is related to finite energy-ladder coherence reservoirs discussed by Åberg, *Catalytic Coherence*, arXiv:1304.1060, and to the explicit correlation concerns in Vaccaro, Croke and Barnett, *Is coherence catalytic?*, arXiv:1804.05154. The interval algorithm, native-mismatch debit and finite-margin proposal above are the present conditional derivation; those papers do not certify this apparatus or its numbers.

**Next gate:** model a finite work/phase controller and an explicit coherent-ladder production/reset channel, including its supply, waste, correlations, start/stop errors and return requirement. Reduce the nonlocal synthesis burden before discussing autonomous hardware. Native donor and empirical validation remain open. Ledger baseline 235 and Q06=0, native action and LC thresholds remain unchanged.
