# Terminal capture, guarded latch and finite renewal — v0.1

3 October 2026. Constructor: Codex, requested by Benjamin Walker Mayes. **Development — no registry entry; CRL-2a proposed interface; physical promotion 0.** This release derives a conditional timed capture and protected-output model, not autonomous pulse timing, a complete autonomous cycle, local fabrication or native coherent-fuel production. No empirical data or non-constructor review is present.

The held finite history controller prepares the bank and reverses if capture is missed. Here a completion-controlled quantum exchange transfers the emitted source bank to a separate matched output register and writes a flag. That flag guards the production Hamiltonian. After the supplied capture pulse is switched off, output and flag are protected from controller reversal under the declared background. Native source/output evolution continues. Capture contact, false tags, records, switching work, fresh output slots, renewal supply and outgoing correlations are explicit.

## 1. Held source and carrier ownership

Keep the parent native H_S, packet cutoff and tail, certified ladder shifts, binary coherent-fuel producer and 23-edge integrated controller. Its work module contains emitted source bank S, reference R and fuel F. The auxiliary controller is C. Parent signed-word source/reference error and isolated-production conditions remain in force; no native energy, coefficient, gauge limit, LC threshold or Q06=0 is changed.

Add a matched output register O with H_O=H_S and the same finite carrier, a fresh two-state flag L in |0>, and supplied record/witness cells M,E in |0>. L,M,E have degenerate bare Hamiltonians. These are apparatus memory dimensions, not extra native spatial dimensions. S can be the chosen finite composite record carrier when every owned register and its matching Hamiltonian is included. The small replay captures source-bank cells; it does not assert capture of the entire detector-pointer-environment universe.

For matched owned operators, SWAP† A_O SWAP=A_S. The complex-paired readout operators transfer along with their carrier, so the held source selection and gauge transformation law are preserved rather than redefined. Transfer is a quantum SWAP, not cloning. Any active detector/core coupling to S,R,C or O requires an additional full contact bound or actual joint replay.

## 2. Explicit guarded background

Let H_p be the parent's dressed history hopping operator, with norm κn. Its restriction to initial flag 0 is exactly the held production controller. Admit the flag-guarded background

$$
H_{\mathrm{bg}}=H_W+H_O+|0\rangle\langle0|_L\otimes H_p.
$$

H_W contains actual native source energies and the exact reference/fuel energies; independent spectator dynamics is implicit. The auxiliary clock is parked when L=1. This is a new engineered conditional coupling, not a derivation of a native disconnect. The controller energy has not disappeared: it resides in the guarded interaction. If a positive total energy convention is needed, add one global constant; an offset conditioned on L would change the model and must be separately charged.

Starting with L=0 leaves the parent's constant-Hamiltonian one-shot production unchanged. Starting with L=1 gives native free work/output evolution with no controller hopping. The background commutes with the flag and has no interaction with O:

$$
[H_{\mathrm{bg}},|1\rangle\langle1|_L]=0,\qquad H_{\mathrm{bg}}=H_O+H_{\mathrm{rest}}.
$$

These identities establish protected propagation only **after** the capture contact is off. The capture pulse changes L and therefore does not commute with this background.

## 3. Terminal-controlled exchange and finite-duration contact

Let P_n=|n><n|_C and S_SO=SWAP between the matched source/output banks. Define the Hermitian involution

$$
J=P_n\otimes S_{SO}\otimes X_L+(I-P_n)\otimes I,
\qquad J^\dagger=J,\qquad J^2=I.
$$

With a fresh flag 0, the ideal terminal branch transfers S into O, leaves the supplied O state in S and flips L to 1. The nonterminal branch acts as identity and keeps L=0. Unknown source quantum states and all their R/history correlations move to O without successful-only normalization. A blank output register is a consumed supplied state; it is not made blank by this exchange.

For supplied duration τ_c, use G_c=π(I-J)/(2τ_c), norm π/τ_c. Since the carriers are matched and the auxiliary clock/flag are bare-degenerate, J and G_c commute with H_free=H_W+H_O. The comparison capture and actual capture are

$$
B_c=e^{-i\tau_c H_{\mathrm{free}}}J,\qquad A_c=e^{-i\tau_c(H_{\mathrm{bg}}+G_c)}.
$$

The production controller remains active during the pulse; it is not silently disconnected. Duhamel's bound gives

$$
\|A_c-B_c\|\leq\gamma_c,\qquad\gamma_c=\tau_c\kappa n.
$$

This is uniform on arbitrary source/reference/controller inputs entangled with spectators. If additional active contacts have integrated norm h_c, replace γ_c by γ_c+h_c; physical contact norms remain open. Supply errors and pulse implementation errors are additional. Native free evolution during the pulse is common to comparison and actual routes.

## 4. Completion, missed capture and false terminal tags

For the parent's controller captured at t=T+s, |s|≤σ, with initial clock |0>, arbitrary work input and native mismatch norm d≤mΔ/2, a purification argument improves the earlier probability-only bound:

$$
\sqrt{p_{\mathrm{FAIL\_C}}}\leq a_C,\qquad a_C=\sqrt n\,\kappa\sigma+(T+\sigma)d.
$$

Indeed the comparison nonterminal amplitude is at most √nκσ, and the actual/comparison propagator differs by at most td on any purification. The probability is at most min{1,a_C²}; this remains valid for mixed correlated work inputs with the supplied initial clock fixed.

For ideal capture on a fresh flag, its flag-0 probability equals the incoming nonterminal probability. The additional capture operator difference therefore gives

$$
p_{L=0}\leq\min\{1,(a_C+\gamma_c)^2\}.
$$

Also define Q_bad=(I-P_n)⊗|1><1|_L. Ideal capture satisfies Q_bad B_c P_L0=0 for **every** incoming work/controller state. Hence

$$
p_{\mathrm{false\ terminal\ tag}}\leq\min\{1,\gamma_c^2\}.
$$

An actual flag 1 is thus not asserted to imply an exact terminal controller state. The false-tag debit is explicit. These probability bounds precede initial flag/clock, supplied-state, record-write and contact implementation errors; full-joint supply error can be added once as a probability deviation. The false-tag probability is already covered by the unconditional capture error; do not add it again to that state budget.

## 5. Full records and preserved output

Copy the commuting flag value to M, then to E, using controlled X gates. This is a standard finite unitary premeasurement of a two-valued record; it does not clone S or its six noncommuting quadratures. Both copies commute with H_bg, since L only controls its block and the record cells are degenerate. A principal-log coupling can therefore implement each copy while the background runs, without an additional ideal background-contact debit. Fresh memory/witness states, finite copy control and implementation error remain supplied resources.

The full dilation retains L,M,E and their correlations. Reducing over the witness for the operational record produces the complete flag instrument

$$
\mathcal R(\rho)=\sum_{\ell=0,1}|\ell\rangle\langle\ell|_M\otimes P_{L\ell}\rho P_{L\ell}.
$$

Keep both **unnormalized** branches, labeled CAPTURED and NO_CAPTURE, together with every earlier detector/acquisition failure. The witness is retained as an outgoing resource in the ledger; the whole pure dilation is not asserted to be a classical mixture. Detector ε remains restricted to the held matching readout reduction, not the global pointer/environment state.

After pulse-off, any actual capture state, including failures and false tags, obeys

$$
\rho_{OM}(u)=(e^{-iuH_O}\otimes I_M)\rho_{OM}(0)(e^{iuH_O}\otimes I_M).
$$

O is decoupled even on flag 0; on flag 1 the controller is additionally parked. Flag probabilities remain fixed. Controller recurrence cannot recover transferred data from O under this background. This is an exact algebraic isolated-storage property, not a measured coherence lifetime. Perturbations coupling to O or flipping L need their own time-integrated norm/error budget.

The parent's ideal target has only the CAPTURED branch. Common post-capture background evolution consequently preserves the full unconditional comparison to that protected target. It does not introduce a new native-spectral mismatch debit growing with storage time. Native O and R phases are kept rather than frozen.

With unconditional operational cq error ε and accepted capture probability p>0 against an ideal all-CAPTURED target, the normalized capture posterior obeys D_tr≤min{1,ε/p}. The cq norm contains both ||pρ_capture-σ||_1/2 and (1-p)/2, proving this inequality. This restricted lemma does not supply conditional bounds for arbitrary detector outcomes whose ideal acceptance probability is below one.

## 6. Why this is not an autonomous absorbing latch

The capture pulse and its shutoff are supplied controls. If G_c remains enabled, J²=I allows reversal: two ideal pulse durations return the flag and undo the quantum exchange. The small actual-background replay confirms this reversal with its explicit perturbation bound.

There is a broader finite closed-system obstruction. If a proper captured subspace is invariant for all future evolution under one time-independent finite Hermitian Hamiltonian, unitary invertibility makes it invariant in both directions, so its population cannot first grow from zero. Even a weaker single-trajectory claim of an exact permanent plateau fails: the finite spectral expression for its captured probability is real analytic; being constant on an open late interval makes it constant at all times.

A time-dependent supplied pulse followed by the guarded park avoids that **restricted** obstruction because the Hamiltonian changes. Approximate finite-horizon retention, an open reservoir, an autonomous finite latch with admitted return error, or a fully modeled switch/controller remain lawful development routes. No permanent autonomous first-entry latch or complete autonomous renewal is claimed here.

For the uncaptured parent endpoint clock at integer ℓT, retain ℓ=2u+r and ℓ≡r (mod 2), with start r=0 and completion r=1. This modulus 2 is prime. The guarded output is not a modular energy bank and is never refilled by clock wraparound.

## 7. Switching work and active renewal

During a constant capture pulse, H_bg+G_c is conserved. Switching the coupling on/off supplies signed mean work

$$
W_c=\langle G_c\rangle_{\mathrm{in}}-\langle G_c\rangle_{\mathrm{out}}=\Delta\langle H_{\mathrm{bg}}\rangle.
$$

Because [H_free,G_c]=0, its derivative depends only on the guard. Thus

$$
|W_c|\leq2\tau_c\kappa n\|G_c\|\leq2\pi\kappa n.
$$

This is a signed mean switching-work bound, not a work-distribution, power or fabrication certificate. Copy coupling commutes with the background and has zero ideal net signed mean switching work, but it consumes blank memory and produces record correlations; no free record erasure follows.

Renew the machine module A=(S,R,F,C,L) from a supplied matched donor D. O and its record/witness/history registers stay outside A. Choose matched native/free donor energies, degenerate clock/flag cells, and a phase-prepared initial target σ_D for fresh source eigenstates, reference seed, coherent fuel, clock |0> and flag |0>. For arbitrary old A/Y state, ideal exchange gives

$$
\rho_{AY}\otimes\sigma_D\ \longmapsto\ \sigma_A\otimes\rho_{DY}.
$$

Here Y includes protected outputs, records, witnesses and all prior waste. Every old correlation is exported to D/Y. If renewal occurs on NO_CAPTURE, the failed module is still exported and the failed output/history remains retained. Renewal never conditions on success to avoid a supply charge.

A matched exchange of duration τ_r commutes with H_free; if the guarded machine remains active, its full-joint additional contact error is at most τ_rκn. This differs from the parent's 2τ_rκn contact estimate because this explicit guard architecture compares to a degenerate parked clock and charges the full guarded hopping operator, not a bare-clock interaction subtraction. The clock energy/variance resource remains in the guarded machine and its initialization; it is not erased from the ledger. Reset switching work has the same absolute signed mean bound 2πκn. Complete finite-controller work distribution remains open.

Every attempt consumes one actual donor slot and one fresh matched output slot. The old O must stay retained; reusing it as a blank would exchange previous captured data back into the machine. Label attempts j=0,...,N-1, then refuse j=N and append END_OF_SUPPLY without wrapping. Slot routing and this refusal policy are supplied control, not a derived autonomous counter.

Charge one full-bank admission ε_F for the supplied donors, outputs, initial flags and record cells, including their correlations with prior histories. Across N admitted attempts, a conservative complete-joint budget is ε_F plus the sum of matching production, capture, copy, contact, renewal, thermal and detector/storage contributions, capped at 1. Do not charge ε_F independently for each marginal slot or erase the outgoing D/Y correlations.

## 8. Certified example and scope

Use the held integrated producer: n23, κ4096=2^12, m3, native K59049=3^10 and the frozen parent packet/ladder certificate. Capture timing uncertainty is σ=1/4194304=2^-22. Admit τ_c=τ_r=1/1073741824=2^-30. The guard norm bound is 94208=23·2^12; its contact debit is exactly 23/262144, with 262144=2^18. Clock/fuel/source admissions remain external apparatus inputs, not native tuning.

| Model quantity | Certified upper |
|---|---:|
| Production nonterminal probability, improved amplitude bound | 0.000022476979204376 |
| Capture contact state debit | 0.000087738037109375 |
| NO_CAPTURE probability after active capture | 0.000023316607351547 |
| False terminal-tag probability | 0.000000007697963155807 |
| Production plus capture joint-state bound | 0.081218326083512880 |
| Production plus capture plus active renewal joint-state bound | 0.081306064120622255 |

Full 60-place outward intervals are frozen in the replay JSON. These are conditional model bounds before supplied-state, extra contact, copy/pulse implementation, thermal, detector and other parent apparatus errors. Neither total acquisition precision nor empirical failure rate is inferred. The pulse generator norm is below 3373259426.130505 and the signed mean-work absolute bound below 591926.321419 in declared units; those large demands remain implementation burdens.

The replay passes **947 integer/structural/Fraction checks and 99 numerical checks**, maximum equality residual 1.1102230246251565e-13 at tolerance 8e-9. It checks exact stored capture permutations, grid and native-sine backgrounds, arbitrary spectator-entangled input, amplitude failure bounds, false tags, complete flag copies, protected output/record propagation through 11T, active-pulse first law, always-on capture reversal, matched renewal/waste and finite supply refusal.

Correction CL01, found during construction review: an initial exact energy-label check wrote an arithmetic identity instead of inspecting the stored capture map. It now checks the actual permutation preserves the clock/reference labels and source/output energy-label multiset. Matrix Hamiltonian commutation and all final counts pass. Parent TR01/TSP01/RBP01/LB01/LB02 and their failure routes remain preserved.

The flag-copy construction uses standard controlled-unitary premeasurement; see Fedor Herbut, *A Review of Unitary Quantum Premeasurement Theory*, [arXiv:1412.7862](https://arxiv.org/abs/1412.7862). That reference does not certify this apparatus, its switching resource or the model numbers.

**Next gate:** replace supplied capture timing/shutoff and slot routing by a finite autonomous switch/renewal controller with an admitted retention horizon, then derive upstream coherent-fuel supply and local coupling tolerances. Native action, ledger235/Q06=0, gauge limits, LC thresholds and physical promotion0 remain unchanged; non-constructor review is still required for registry promotion.
