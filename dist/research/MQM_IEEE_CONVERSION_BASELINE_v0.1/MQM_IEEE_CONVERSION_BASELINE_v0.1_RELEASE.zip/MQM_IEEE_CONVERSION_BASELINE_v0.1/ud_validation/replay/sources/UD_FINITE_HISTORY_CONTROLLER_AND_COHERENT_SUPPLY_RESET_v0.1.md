# Finite history controller and coherent supply/reset — v0.1

3 October 2026. Constructor: Codex, requested by Benjamin Walker Mayes. **Development — no registry entry; CRL-2a proposed interface; physical promotion 0.** Exact conditional constructions, integer interval enclosures and small quantum replays are distinguished below. No empirical data, native donor mechanism, local fabrication model, permanent autonomous shutdown or non-constructor review is established.

This release replaces individually timed preparation pulses by a finite constant-Hamiltonian history controller. It also produces the ladder packet from an explicit bank of coherent fuel qubits and an energy-loaded reference seed, and specifies a matched supply/reset map that exports old states and correlations. The source native Hamiltonian continues to run. Controller recurrence, timing failures, fuel depletion and active reset contact are charged rather than treated as automatic closure.

## 1. Held source and new apparatus inputs

Preserve the parent native oriented-ring spectrum E_k=2J sin(2πk/K), Gaussian packet, declared cutoff |k|≤b, cutoff tail q_b and exact rank theorem. Comparator gaps are bar E_k=Δa_k with certified nearest-integer labels, a_-k=-a_k, and native mismatch d_S≤Δ/2 on each admitted cell; comparator and native energies coincide outside the cutoff. Actual native H_S is never rounded. Ledger baseline 235, source-selected Q06=0, action normalization, gauge limits and LC thresholds remain unchanged.

The ladder has M=L+2(m+1)C levels, C=max|a_k|, initial support n_0,...,n_0+L-1 with n_0=(m+1)C, and H_R=Δn. Parent q_b and the full signed-word comparator overlap A_m remain charged jointly, once:

$$
\eta_{\mathrm{bank}}=\sqrt{1-(1-q_b)^m A_m^2},\qquad A_m\geq\left(1-\frac{m\mu}{L}\right)_+.
$$

Apparatus admissions here are Δ,L,m, the controller scale κ, its programmed gate list and the capture/reset durations. Binary fuel gaps, controller couplings and phase precompensation are supplied apparatus laws, not native coefficients or fitted physical constants. Native donor production remains open.

## 2. Explicit upstream ladder production from finite coherent fuel

For L=2^q, supply q qubits F_j with H_Fj=Δ2^j|1><1| and initial |+>=(|0>+|1>)/√2. Supply the reference seed |n_0>, with its energy n_0Δ explicitly loaded. Within the admitted reference window, define the reversible swaps

$$
|1\rangle_{F_j}|n_0+r\rangle_R\ \longleftrightarrow\ |0\rangle_{F_j}|n_0+r+2^j\rangle_R
$$

for r with its j-th binary bit zero. All other states act as identity. These pairs are disjoint; each preserves H_Fj+H_R exactly. Process j=0,...,q-1. Previously populated lower bits leave the current bit zero, so on the admitted input

$$
|+\rangle^{\otimes q}_F|n_0\rangle_R\ \longmapsto\ |0\rangle^{\otimes q}_F\frac{1}{\sqrt L}\sum_{r=0}^{L-1}|n_0+r\rangle_R.
$$

No outcome is discarded. Fuel energy and coherence are transferred into R; they are not created. Gate extensions outside the supported window are identity, never reference wraparound. This map works for arbitrary coherent fuel amplitudes and correlations, but then produces their corresponding joint output rather than silently replacing them by independent |+> qubits.

The integer bit rule has clock notation: r=2^(j+1)u+v and r≡v (mod 2^(j+1)); require 0≤v<2^j, then transfer to r+2^j. For instance r=5=1·4+1 and 5≡1 (mod 4); transferring bit j=1 takes it to 7=1·4+3 and 7≡3 (mod 4). These residue labels specify disjoint finite pairs, not resource refilling. Moduli are powers of the prime 2; 5 and 7 are prime.

For independent ideal fuel,

$$
\langle H_F\rangle=\frac{\Delta(L-1)}2,\qquad\operatorname{Var}H_F=\frac{\Delta^2(L^2-1)}{12},\qquad F_Q=4\operatorname{Var}H_F.
$$

For general correlated pure fuel, retain 4 Var(Σ_j H_Fj), including every covariance. For mixed fuel, QFI is generally not 4 Var; no marginal-QFI sum is substituted. The ideal output fuel is ground-state waste with no energy or coherence; its outgoing carrier remains part of the ledger. Installing fresh fuel requires a new supplied nonstationary bank.

## 3. Finite static history controller

Take a programmed list U_1,...,U_n. The first q gates may be the binary producer above, followed by m finite parent preparation lifts. Each gate commutes with the comparison work Hamiltonian bar H_W=H_R+Σ_j H_Fj+Σ_i bar H_Si. Define prefix products P_0=I and P_j=U_j...U_1 and

$$
\mathcal W=\sum_{j=0}^{n}|j\rangle\langle j|_C\otimes P_j.
$$

Choose a controller clock

$$
H_C=\kappa\sum_{j=0}^{n-1}\sqrt{(j+1)(n-j)}\bigl(|j+1\rangle\langle j|+|j\rangle\langle j+1|\bigr),
$$

and the **actual constant** machine Hamiltonian

$$
H_{\mathrm{act}}=H_W+\mathcal W(H_C\otimes I)\mathcal W^\dagger.
$$

Tensor identities are implicit. Actual H_W contains every native H_S, exact ladder/fuel energies and any independent free spectator dynamics. Gate-dependent edges contain U_j and U_j†. Their synthesis is supplied and generally nonlocal; a nearest-neighbor clock graph is not a proof of local system/reference interactions.

In the symmetric subspace of n abstract spin-1/2 systems, H_C equals κΣX. Acting on |0>^n therefore gives

$$
e^{-itH_C}|0\rangle=\sum_{j=0}^n(-i)^j\sqrt{\binom nj}\sin^j(\kappa t)\cos^{n-j}(\kappa t)|j\rangle.
$$

Thus its spectrum is κ(n-2j), norm κn, and **derived completion time** T=π/(2κ). At T the comparator reaches (-i)^n|n>⊗P_nψ for every work input ψ, including arbitrary spectators and correlations, up to common comparison free evolution. Since [bar H_W,mathcal W]=0, this identity follows by unitary conjugation, not by assuming instantaneous physical gates.

Each preparation gate is programmed with V_i|g>=Σ_k c_k exp(i bar E_k T)|k>. At the common endpoint, comparison source phases cancel and the output clocks are the admitted packets; R has the common free phase and the signed history displacement. The fuel ends in |0>^q. Subsequent output evolution uses actual native H_S. All phases reside in the supplied initial fuel and static edge program. No free external phase ruler is inferred.

The four-level controller, n=m=3, assumes R was already supplied. The **integrated producer/controller** has q=20, m=3, n=23, hence 24 clock levels. Adding the producer changes clock precision and resource costs even though this engineered spin clock's exact T is independent of n.

## 4. Native-dynamics and capture budget

The actual/comparison machine difference is Σ_i(H_Si-bar H_Si), with norm d≤mΔ/2. Duhamel's identity gives a uniform operator and full-joint trace-distance bound

$$
\|e^{-itH_{\mathrm{act}}}-e^{-itH_{\mathrm{comp}}}\|\leq |t|d.
$$

Unlike the earlier separately timed pulse construction, this comparison runs over the **whole controller interval**. The old mτΔ/2 pulse debit is replaced by Td; it is not also added. At exactly T the source/reference/native comparison is bounded by η_bank+Td. Additional implementation, supplied-state, parent thermal, acquisition and reset debits remain separate.

At time t=T+s the comparator's terminal probability is p_n(t)=cos^(2n)(κs). For |s|≤σ,

$$
1-p_n(t)\leq n\kappa^2\sigma^2,\qquad \sqrt{1-p_n(t)}\leq\sqrt n\,\kappa\sigma.
$$

Compare the endpoint branch with the desired native freely evolved packet at the actual capture time. Besides the controller evolution debit td, comparison/native phases after T cost at most |s|d. Hence a conservative complete-record state budget is

$$
\eta_{\mathrm{window}}\leq\min\{1,\eta_{\mathrm{bank}}+\sqrt n\,\kappa\sigma+(T+2\sigma)d\}.
$$

Before supply or capture errors, the actual probability of controller-completion failure obeys

$$
p_{\mathrm{FAIL\_C}}\leq\min\{1,n\kappa^2\sigma^2+(T+\sigma)d\}.
$$

Use the full instrument with P_n=|n><n| and I-P_n. Append the two **unnormalized** output branches as SUCCESS_C and FAIL_C records, preserving all prior acquisition failures and histories. This CPTP record map contracts the unconditional joint comparison. Successful posterior precision needs its own acceptance-probability bound; it is not obtained by renormalizing away FAIL_C.

The word-overlap formula covers isolated bank production. Downstream maps can interleave on emitted systems and separate resources. Contacts on this same R, fuel or controller require their integrated channel bound or actual joint replay, as held correction LB02 requires. Native running does not make detector backaction disappear.

## 5. Recurrence and absence of autonomous stop

At 2T=π/κ the comparison clock is (-1)^n|0> and the circuit prefix returns to P_0=I, with common comparison free evolution. Preparation is undone by coherent reverse traversal if the output is not captured. At integer multiples ℓT: ℓ=2u+r and ℓ≡r (mod 2); r=0 gives the starting endpoint and r=1 the completion endpoint. This two-state endpoint clock is not a cyclic energy reservoir. The relevant modulus 2 is prime; n=23 is prime, while its 24-level carrier has 24=2^3·3 levels.

A bounded timing window and a supplied capture/export map remain necessary. This is autonomous **one-shot propagation under a constant engineered Hamiltonian**, not permanent shutdown or an autonomous prepare/acquire/export/reset cycle. An irreversible latch, finite dissipative memory or output routing must carry its own resource, backaction and recurrence accounting. No success plateau is asserted.

## 6. Constant-machine first law and interaction receipts

Use bare H_C+κnI if a nonnegative controller energy convention is required. Write H_act=H_free+V, where H_free=H_W+H_C and V=mathcal W(H_C⊗I)mathcal W†-H_C⊗I. The additive offset cancels from all differences. During the constant machine evolution,

$$
\Delta\langle H_{\mathrm{act}}\rangle=0,\qquad\Delta\langle H_{\mathrm{free}}\rangle=-\Delta\langle V\rangle,\qquad\|V\|\leq2\kappa n.
$$

The controller/interaction energy replaces the earlier external timed-pulse switching receipt for this different architecture. No per-edge switched mean-work debit is inherited without a physical switch. Initializing the static device, capturing outputs and resetting it still require supply/contact accounting. Do not claim exact conservation of the bare native free energy alone.

The initial |0> clock has mean κn in the nonnegative convention and variance κ²n; at the ideal completion |n> the same moments hold. During the run it is correlated with circuit prefixes and work states. Return to the initial state has not happened merely because the mean energies agree. Actual first-law equality is checked on arbitrary spectator-entangled inputs, without a two-point measurement of coherent fuel.

## 7. Matched supply/reset with outgoing correlations

Let A include the consumed reference, fuel and controller; include source cells as well when fresh selected input cells are needed for the next bank. Supply one independent matched donor D with H_D=H_A and declared initial state σ_D. For the integrated producer, σ_A consists of reference |n_0>, q coherent |+> fuel qubits, controller |0>, and fresh source eigenstates |g> as required. The thermal/eigenstate supply errors retain their parent full-joint admission. Prephase the donor for the actual reset endpoint under H_D.

For arbitrary old A/Y state, the matched exchange sends

$$
\rho_{AY}\otimes\sigma_D\ \xrightarrow{\mathrm{SWAP}_{AD}}\ \sigma_A\otimes\rho_{DY}.
$$

Every old correlation moves to D/Y. D's source-cell partition can be retained as output data; its consumed reference/fuel/controller partitions are outgoing resource waste. None is traced away to claim a free reset. The ideal exchange is implemented in duration τ_r by G_r=π(I-SWAP)/(2τ_r), norm π/τ_r, commuting with the matched bare free Hamiltonian. Native independent Y dynamics continues.

If the production machine's V remains active during reset, compare the actual reset to that matched exchange with a **full-joint contact debit**

$$
\eta_{\mathrm{reset,contact}}\leq\tau_r\|V\|\leq2\kappa n\tau_r.
$$

An actual disconnect instead needs a switching/controller receipt. There is no silent assumption that the static machine stops for reset. This reset is still a specified supplied finite-duration control, not a derived autonomous trigger. Small replays exchange a reference/controller module while retaining an entangled spectator; the algebraic full-module extension covers arbitrary finite matched A, including all source cells and fuel.

For N runs, supply N actual donor slots. Refuse the next exchange and preserve END_OF_SUPPLY in the record. Donors are consumed once; outgoing coherent waste is not presumed reusable. Marginal fuel fidelities do not determine the joint supply admission: three mutually exclusive single-slot errors have marginal fidelity 2/3 in each slot but joint target fidelity 0, not (2/3)^3=8/27. Here 8=2^3, 27=3^3; 8=0·27+8 and 8≡8 (mod 27).

Admit the whole supplied bank via ε_F=D_tr(ω_FY,σ_F⊗ω_Y), where σ_F includes all declared independent fresh donors/fuel and ω_Y includes retained prior histories. Charge ε_F **once**, not once per slot. With joint pure-bank fidelity f and fixed ω_Y, a conservative gentle-measurement bound is ε_F≤min{1,√(1-f)+(1-f)/2}. The projected Y deficit is positive with trace 1-f; this also charges supply/history correlations. Direct full-joint admission is preferred.

An unconditional telescoping budget across supplied runs is bounded by ε_F plus the sum of declared production/capture/contact/reset and other matching apparatus errors, capped at 1. Joint source thermal admission is charged once on its held bank domain. In a repeated ideal comparison, matched reset restores fresh inputs and exports each old correlated state; it does not remove correlation from the complete universe.

## 8. Stationary-supply obstruction and resource frontier

If all input resources are stationary under the admitted free-energy generator and the production map is energy covariant, the reference output is stationary. Against the uniform pure L-level reference packet, any stationary reference has overlap at most 1/L. Measuring the target projector therefore gives D_tr≥1-1/L, achieved by the uniform diagonal mixture. For L=1048576 the minimum is exactly 1048575/1048576. This is a sharp restricted-supply obstruction, not a universal impossibility of reference production.

The binary fuel provides exactly the missing nonstationary resource. Pure-state QFI under its own admitted energy is 4 Var H_F=Δ²(L²-1)/3. QFI monotonicity under covariant channels applies only after checking the complete supplied generator and all asymmetry resources; arbitrary active controllers are not free covariant operations. This is an exact pure independent-fuel receipt, not a robust approximate-error QFI lower bound for every architecture.

For the stated example, fuel mean energy is 52428.75, reference seed energy 2674.8, fuel variance 916259689.8125 and pure fuel QFI 3665038759.25. The initial/reference production accounting is explicit. Native generation of the coherent fuel, a physical frequency hierarchy Δ2^j, low-error coherent supply and autonomous waste handling remain open. Finite thermal supplies cannot be relabeled coherent |+> fuel without a source.

## 9. Certified numerical example and replay

Hold K59049=3^10, w32, b768, J4096=2^12, Δ=1/10, L1048576=2^20, m3 and parent M1102072. Use κ4096, σ=1/4194304=1/2^22 and τ_r=1/1073741824=1/2^30. The reference packet and native mismatch inputs are retained from the frozen parent interval certificate. Integer endpoints on the 10^-60 grid and exact integer square roots certify the new expressions; π uses the parent Machin enclosure.

| Quantity | Already supplied ladder, 4 clock levels | Integrated 20-qubit producer, 24 clock levels |
|---|---:|---:|
| Controller edges n | 3 | 23 |
| Completion time T | 0.00038349519697141031 | Same derived T |
| Source/reference/native endpoint bound, upper | 0.07644708729884470 | 0.07644708729884470 |
| Window joint bound, upper | 0.07813861469118491 | 0.08113058804640351 |
| Completion-failure bound in window, upper | 0.00006042106528180 | 0.00007949455160993 |
| Controller norm κn | 12288 | 94208 |
| Active interaction norm upper | 24576 | 188416 |
| Initial clock variance κ²n | 50331648 | 385875968 |
| Active reset contact debit | 0.00002288818359375 | 0.00017547607421875 |

T in the table is a rounded evaluation; exact outward T endpoints and all bound enclosures are in the JSON. The reset generator norm is below 3373259426.130505 in the declared units. That enormous control norm, weighted fuel energy span, static gate synthesis and timing precision remain feasibility burdens. Reset contact is an additional contribution; it is not already included in either window column. Neither column is total acquisition precision.

The frozen replay passes **7644 integer/structural/Fraction checks and 108 numerical checks**, maximum equality residual 3.552713678800501e-15 at tolerance 8e-9. It covers K3/K5 static native machines, arbitrary spectator entanglement, word overlap, terminal/return laws, total/free/interaction energy receipts, matched reset/export, finite supply refusal, sharp stationary controls and every integer energy equality in one- through five-qubit binary producers. A two-fuel-qubit producer and native K3 preparation are replayed together under one static clock (384 joint levels).

No new implementation correction occurred in this replay. Parent TR01/TSP01/RBP01/LB01/LB02 and rejected logic remain preserved. The clock construction is related to Christandl et al., *Perfect state transfer in quantum spin networks*, arXiv:quant-ph/0309131, and Feynman clock constructions discussed by Caha, Landau and Nagaj, arXiv:1712.07395. The conditional native-dynamics, fuel and reset derivations above are the present proposal; these sources do not validate this apparatus or the numerical example.

**Next gate:** derive a finite capture/latch and renewal controller that preserves output/failure histories despite coherent return, and an upstream coherent-fuel supply with its own work, phase, entropy and correlation receipts. Audit local synthesis and amplitude/timing tolerances. Physical promotion remains 0; non-constructor review remains required for registry promotion.
