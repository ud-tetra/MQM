# Conditional collective objective proofs

All claims here concern the declared shared-edge integration contract on prepared carriers. They do not supply a native collective admission law. Claim bin: CANDIDATE_DEVELOPMENT_MATHEMATICS; correspondence NOT_PROPOSED; physical promotion 0; independent review PENDING.

## Compatible endpoint optimization

Opposite-edge equalities and shared unique-edge identity identify three global closure classes on each retained representative. For the passing-integrity, one-closed-class comparison sector, there are three compatible endpoints. If class p is closed, the unique-edge quadratic score is `R_p = (sum_q W_q - W_p)/4`. The term `sum_q W_q` is target independent. Maximizing R is therefore equivalent to minimizing W_p. Exact equal coefficients yield a set of optimum endpoints; no tie break or publication follows from the algebra.

Each class has five unique edges but two local edges in every cell. A compatible mask with k closed classes has 5k closed unique edges, k closed pair bits per cell, and 8k closed edge incidences summed over the four cells. Consequently those three counting conventions must not be used interchangeably when sourcing a closure budget.

## Localized burden theorem

Prepare `b = a*1 + h*e_v`. Every edge incident on v has squared gradient h^2; all other edges have weight zero. In a tetrahedron containing v, every opposite pair has exactly one incident edge. Thus each local pair weight is h^2; if the cell does not contain v all three local pair weights vanish. The local strict event rule returns NO_EVENT for every class baseline because its two open addresses tie.

For a global class p, summing distinct incident edges gives `W_p = h^2 d_p(v)`. The class-degree counts can differ. Hence local address ties do not imply a global objective tie. This establishes a general family of unrequested candidate global preferences, not a derived native global event.

## Partition of shared edge weights

For positive integer incidence multiplicity m_e, allocate `w_e/m_e` to each incident cell. The sum of allocations is exactly w_e. Exchanging the finite sums yields `sum_cell W_alloc(cell,p) = W_p` and the corresponding gain identity.

If every cell's strict allocated selector requests target q, its allocated coefficient at q is strictly below each other class coefficient. Summing the inequalities establishes `W_q < W_p` for every p different from q. Thus the global minimum is unique and the global gain from any different baseline is strictly positive.

Using original local scores does not yield that theorem: their sum weights edge e by m_e. The retained chain-2 witness has local gains (2,2,2,2) but global gain -7/4. Its allocated gains (1/8,1/8,-1,-1) sum to -7/4. This exact witness falsifies unrestricted original-score unanimity as a sufficient global improvement condition. It does not falsify the earlier bounded-grid counts.

The source support-allocation theorem is a partition result for squared support stocks. Applying its finite-sum argument to burden edge weights is valid mathematics. Applying those weights inside the local B2 selector changes its dynamics and requires a source decision. Partition correctness alone is not native admission.

## Exact chain burden family

On history 4, prepare `b(t) = (0,0,t,1,0,1,1)` with t positive. Direct edge expansion produces local score coefficients `((t-1)^2, t^2+1, t^2+1)` in every cell, and unique global coefficients `(3(t-1)^2, 2t^2+3, t^2+4)`.

Starting C closed, all four original strict selectors request A because the gain is t/2 and A is the unique local minimum. The unique-edge global gain is `(-2t^2+6t+1)/4`, whose positive zero is `alpha = (3+sqrt(11))/2`.

For `0 < t < alpha`, global B minus A equals `t(6-t)` and global C minus A equals `-2t^2+6t+1`; both are positive. At alpha, A and C tie while B is larger. For t above alpha, B minus C is `t^2-1` and A minus C is positive, so C is the unique global minimum. Original local preference for A persists across this entire objective reversal.

For centered `x = 7b - sum(b)*1`, the squared norm polynomial is `42(t^2-t+2)`. With the frozen exact inverse matrices, the numerator of `x^T (L_A^+ - L_C^+) x` is `(2512t^2-7160t-3320)/105`. Dividing by the norm gives the retained integrated autocorrelation change:

```text
Delta M = 4(314t^2-895t-415) / (2205(t^2-t+2))
beta = (895+sqrt(1322265))/628
```

The denominator is positive since `t^2-t+2 = (t-1/2)^2+7/4`. The memory numerator has one negative and one positive root because its leading coefficient is positive and its constant is negative. Hence Delta M is negative for positive t below beta and positive above beta. Exact bisection enclosures establish `alpha < 16/5 < beta`. At 16/5 the global gain is -7/100 while Delta M is -3182/249165. At 4 they are -7/4 and +2/15.

These are thresholds in an exogenous preparation ratio, not times of native onset or fitted internal constants. Translation and positive scaling preserve selector signs and normalized memory, while raw score gains scale quadratically. The verifier retains a strictly positive normalized witness as an additional exact check.

## Memory normalization

For symmetric connected positive-semidefinite L, centered x has no zero-eigenvalue component. Autocorrelation is `C(s)=x^T exp(-Ls)x/||x||^2`, while actual squared contrast is `D(s)=||exp(-Ls)x||^2/||x||^2=C(2s)`. Integrating each positive eigenmode gives `integral C=x^T L^+x/||x||^2` and `integral D=(integral C)/2`.

The exact verifier independently checks the matrix identity `L (L^+/2) + (L^+/2) L = P_centered` for all nine fixed operators. This is the Lyapunov equation for integrated squared contrast. It resolves the previous report's diagnostic-label error without altering any score or memory sign. The erratum identifies affected historical text and fields.

## Limits of the finite checks

The three nested complete grids contain 870264 evaluated snapshot fixtures; they overlap. They certify the listed counts in their domains and provide exact counterexamples. They supply neither a native ensemble measure nor perturbation persistence or a source-owned switching schedule. The root code and frozen matrix helpers share implementation lineage, so independent review remains pending despite exact arithmetic. Physical promotion remains zero.
