# Static capture clock and finite retention horizon — v0.1

**Development — no registry entry; CRL-2a proposed interface. Constructor: Codex for Benjamin Walker Mayes, 2026-10-03. Physical promotion0.** No empirical data, fitting, independent review or native apparatus synthesis. This is an alternative to the held timed pulse-off architecture, not a replacement of its exact post-switch theorem.

The preceding release required a supplied capture pulse and off-switch. Here one time-independent engineered Hamiltonian executes capture and writes its flag/record after launch. Identity padding makes return to the capture boundary unlikely over a finite interval. There is no exact permanent park: clock recurrence reverses the capture. Launch alignment with the production completion window, output/donor routing, renewal and upstream clock/fuel supply remain supplied or open.

## 1. Owned carrier, records and source law

Retain parent source S, matched fresh output O with H_O=H_S, production clock C, reference R, coherent fuel F, fresh flag L=0, memory M=0 and witness E=0. The native free Hamiltonian H_f=H_W+H_O remains unchanged; record cells and controller addresses use a declared zero bare park reference. The parent running background is H_b=H_f+V_p, where V_p=P_L0 H_p and its norm is at most h_p=kappa*n. Reference isolation and all parent acquisition/detector failures remain binding. Add Q, an auxiliary controller address of dimension N+1, initially |0>. It is not a new native spatial dimension.

Let P_n project onto the parent's terminal production clock. Define

$$
J_*=P_n\otimes\mathrm{SWAP}_{SO}\otimes X_LX_MX_E+(I-P_n)\otimes I,
\qquad J_*^2=I,\qquad [J_*,H_f]=0.
$$

Tensor identities are implicit. For fresh L,M,E, the terminal branch transfers the owned quantum bank and all its correlations, flips three record bits, and the nonterminal branch is unchanged. This is finite unitary premeasurement and state transfer, not cloning. Memory and witness blanks are explicit resources. The involution acts on the full domain; later recurrence also flips the records back.

For every matched source operator, SWAP† A_O SWAP=A_S. The six-quadrature composite and source-selected complex-paired/gauge readout law therefore transfer without redefining their selection. This does not capture the whole detector/pointer/environment universe. Reducing E gives operational CAPTURED and NO_CAPTURE blocks; the complete dilation including E and Q is retained as a quantum state.

## 2. Constant engineered capture Hamiltonian

On Q define the finite spin generator

$$
H_Q=\lambda\sum_{q=0}^{N-1}\sqrt{(q+1)(N-q)}
\bigl(|q+1\rangle\langle q|+|q\rangle\langle q+1|\bigr).
$$

Set W_0=I, W_q=J_* for q>=1, and the block unitary W=sum_q |q><q| tensor W_q. The dressed generator is H_d=W(H_Q tensor I)W†. Only edge0–1 carries J_*; all N-1 later edges carry identity. Its norm is lambda*N and spectrum lambda*(N-2j), j=0,...,N. These are exact consequences of the finite spin representation, rederived here. Engineered fixed-coupling perfect transfer is a known comparison construction: Christandl et al., *Perfect State Transfer in Quantum Spin Networks*, PRL92,187902 (2004), DOI10.1103/PhysRevLett.92.187902, https://arxiv.org/abs/quant-ph/0309131. That work does not establish this capture proposal or a UD native implementation.

The actual and comparison Hamiltonians are

$$
H_a=I_Q\otimes H_b+H_d,
\qquad H_0=I_Q\otimes H_f+H_d,
\qquad \|H_a-H_0\|\le h_p.
$$

All couplings are constant after launch. The parent controller is retained and runs during capture. Since H_f commutes with J_*, comparison evolution from Q0 and any body/spectator purification psi is exactly

$$
|\Psi_0(t)\rangle=\sum_{q=0}^N c_q(t)|q\rangle\otimes
 e^{-itH_f}W_q|\psi\rangle,
\qquad |c_q(t)|^2={N\choose q}\sin^{2q}(\lambda t)\cos^{2(N-q)}(\lambda t).
$$

This follows by realizing H_Q as lambda times the sum of N Pauli X operators on the symmetric spin sector. The binomial identity sums the probabilities to1; c_0(t)=cos^N(lambda*t).

Q is not a classical scheduler. During capture it is entangled with pre/post body states; discarding these correlations would understate the complete-joint error. Padding consists of explicit finite clock states and couplings, not free elapsed time.

## 3. Joint, branch and false-tag bounds

Let r(t)=|c_0(t)|²=cos^(2N)(lambda*t), gamma(t)=t*h_p. Duhamel gives a uniform propagator norm error at most gamma, hence a full-joint trace-distance error at most gamma, including arbitrary prior spectators. Unknown additional contacts contribute their integrated operator norms on the admitted domain, capped together at1.

Compare with the fully transferred target whose clock is the undressed freely evolved clock chi(t), independent of the transferred body. The vector difference is c_0(t)|0> tensor e^(-itH_f)(I-J_*)psi. Thus the conservative complete-joint bound is

$$
D\bigl(\rho_a(t),|\chi(t)\rangle\langle\chi(t)|\otimes
 e^{-itH_f}J_*\rho J_*e^{itH_f}\bigr)
\le\min\{1,\gamma(t)+2\sqrt{r(t)}\}.
$$

Purification proves this for arbitrary mixed and correlated body inputs; contractivity transfers it to the declared detector/readout reductions. In contrast, reducing Q in the comparison gives exactly the mixture r*rho_pre+(1-r)*rho_post, with reduced-body debit at most r. The smaller marginal debit must not replace the full-joint 2sqrt(r) in resource reuse or renewal budgets.

For fresh L,M,E and actual incoming production failure probability p, the comparison NO_CAPTURE probability is p+(1-p)r. If sqrt(p)<=a, actual acquisition satisfies

$$
\Pr_a(\mathrm{NO\_CAPTURE})\le
 \min\{1,(a+\sqrt r+\gamma)^2\}.
$$

The false terminal-tag event Q_bad=(I-P_n)P_L1 has zero comparison amplitude for every fresh-record input, regardless of r. Therefore Pr_a(Q_bad)<=min(1,gamma²). Its probability is already controlled by the joint comparison error; do not add it again as a separate joint debit.

Reduce witness E to obtain both unnormalized flag/memory branches and their full source/output/controller/clock histories. All parent failure outcomes remain. Do not infer a normalized success-posterior accuracy from these unconditional bounds without accounting for success probability and the correct ideal branch.

## 4. Finite retention interval and recurrence

For

$$
\frac{\pi}{4\lambda}\le t\le\frac{3\pi}{4\lambda},
\qquad r(t)\le2^{-N},
$$

The bound is pointwise and uniform over the interval; it is not a probability that no failure ever occurs during continuously monitored storage. Monitoring changes the dynamics and requires its own backaction/contact budget.

The whole-joint static-capture debit is at most 3*pi*h_p/(4*lambda)+2*2^(-N/2). The actual output is only approximately freely stored on this horizon: H_d continues coupling the capture boundary. Unlike the held pulse-off architecture, no exact decoupling theorem is claimed.

At t=pi/(2*lambda), the comparison clock reaches N and transfer is exact. At t=pi/lambda, it returns to0 and J_* is undone, including record flips. This is a rejected permanent-storage route retained with its failure mode. The exact finite closed absorbing-sector obstruction from the parent is respected.

A useful general resource tradeoff follows from a required window duration H=pi/(2*lambda): lambda=pi/(2H), and the running-parent contact bound over that window is 3*H*h_p/2. With N>=1, reducing the boundary tail requires extra address states and a generator norm pi*N/(2H). Increasing padding does not remove running-parent contact. A long autonomous retention interval requires a better model of production shutdown, an output-routing mechanism or an open reservoir, each with its own receipts.

These time units are the parent's declared model units; no conversion to laboratory seconds is supplied. Lambda and N are apparatus resource inputs, not tuned UD native coefficients.

## 5. Energy, clock coherence, launch and renewal

The constant H_a conserves total mean energy after launch. Background energy change equals negative change in H_d. For fresh Q0, <H_d>=0 and <H_d²>=lambda²*N for every body state. Since H_d is off-diagonal in Q, covariance with any body-only H_b vanishes initially: Var(H_a)=Var(H_b)+lambda²*N whenever the body variance is finite. On a pure full admitted state, time-translation QFI is4*Var(H_a); this formula is not asserted for arbitrary mixed states.

The supplied Q0 state is nonstationary under the engineered generator; preparation cannot be declared free. This release does not derive the upstream physical clock or a stationary-supply conversion theorem for the full interacting machine. Mean zero generator energy reflects the declared spectrum origin, not zero energy variance, coherence or implementation cost. A global lambda*N identity shift changes mean energy bookkeeping without altering trajectories; no flag-conditioned offset is silently allowed. Clock-state preparation, phase alignment, purity, couplings and outgoing clock/body correlations require supply accounting.

If coupling is activated at the declared launch boundary, its signed mean switch-on work is <H_d> on the admitted prelaunch state, zero for ideal Q0. Finite supply errors can change that expectation. Launch is synchronized to the parent completion window by a supplied intervention; no upstream autonomous trigger is derived. There is no capture off-switch within the retention interval. Eventual disconnection, output export or renewal must be modeled separately.

For renewal, include Q in the consumed production module B=(S,R,F,C,L,Q), excluding protected outputs, records and witnesses Y. A matched fresh donor D gives the full ideal exchange

$$
\rho_{BY}\otimes\sigma_D\longmapsto\sigma_B\otimes\rho_{DY}.
$$

This exports every old clock/waste/history correlation on success or failure. Under zero bare park references for C,L,Q and matched free energies, the reset principal-log SWAP commutes with matched free dynamics. During its supplied duration tau_r, the actual production-plus-capture generators add contact at most tau_r*(h_p+lambda*N). Its signed mean switching-work bound is2*pi*(h_p+lambda*N); this is not a work-distribution or autonomously supplied controller model. The donor state must include any free-evolution phase preparation required at reset completion.

Renewal also requires supplied rerouting to fresh O,M,E slots and disconnection of the old ones. Resetting Q alone while leaving the old output coupled does not protect a record through the next cycle. No autonomous routing theorem or numerical reset implementation is added here; the full matched exchange and norm bound are algebraic continuations of the parent's correlation accounting.

For A admitted attempts, a conservative complete-joint budget is one full-bank supply admission epsilon_F plus the sum over attempts of parent production, gamma, full clock-tail, renewal, routing, extra contacts and matching detector/storage/thermal/implementation debits, capped at1. Each attempt consumes fresh clock/donor/output/record cells even on failure. No marginal-fidelity product assumption, postselection discount or deleted outgoing correlation is allowed. A finite slot count requires an explicit END_OF_SUPPLY refusal policy; this release does not automate that policy.

## 6. Outward certificate and replay

Resource example: parent n23,kappa4096 gives h_p=94208; Q has N40 edges,41 states, lambda=2^32. Prime structure: N=2^3*5;41 is prime; lambda*N=5*2^35; h_p=23*2^12. The held parent completion-window production bound and failure amplitude are reused once. No parent release is edited.

| Quantity | Outward certified upper bound |
|---|---:|
| Clock boundary probability over retention window | 2^-40 = 1/1099511627776 |
| Full-joint clock-tail debit | 2^-19 = 1/524288 |
| Running-parent contact over entire horizon | 0.000051681969904351 |
| Production plus static capture joint bound | 0.081184177364940668 |
| NO_CAPTURE probability | 0.000022978839763760 |
| False terminal-tag probability | 0.000000002671026014 |
| Renewal contact at tau_r=2^-50 | 41943063/274877906944 |
| Joint bound including one supplied renewal | 0.081336765339239180 |
| Capture generator norm | 171798691840 |
| Fresh-clock generator variance | 737869762948382064640 |

Retention starts at pi/2^34 and ends at3*pi/2^34 after the supplied launch; duration pi/2^33. These are model units and a very short horizon relative to parent production. The large rate/norm and fresh coherent clock are explicit feasibility debts. Every numerical certificate excludes supplied-state, extra-contact, routing, implementation and matching parent apparatus errors.

Replay: **1195 exact integer/structural/Fraction checks and192 numerical checks**, maximum equality residual7.275957614183426e-12 at tolerance1e-8. Exact stored-map checks inspect actual source/output energy-label preservation and record flips. Binomial/tail identities, clock spectrum, arbitrary spectator-correlated native-sine and grid fixtures, full-joint versus marginal errors, false tags, cq record reduction, constant energy, variance and recurrence pass. The new renewal bound is exact algebra only, not an implemented reset replay. Parent CL01 and all earlier corrections are retained. An initial interval-helper interface failure was repaired before any certificate existed; it produced no mathematical result or frozen claim.

**Next gate:** integrate an autonomous production-to-capture trigger and a finite output/donor router with retained return errors; derive upstream clock/fuel supply and local contact tolerances. No complete autonomous cycle, permanent storage, local geometry or physical promotion. Native action, ledger235/Q06=0, gauge limits and LC Stage0 thresholds remain unchanged. A non-constructor review remains necessary before registry promotion.
