# UD public theorem supplement

Version 1.0 · 3 October 2026 · Benjamin Walker Mayes

This supplement promotes the scoped mathematical results below into the public theorem layer at Benjamin Mayes's explicit direction. It extends the public review surface beyond Papers I–II without changing their frozen PDFs, original releases, source proposals, or coefficient ledger. Constructor proofs and replays are available; independent review is pending. Publication is not a completed CRL review or empirical validation. Physical promotion remains **0**.

Each statement has three independent fields: internal claim bin **EXACT_CONDITIONAL_MATHEMATICAL_RESULT**, correspondence status **NOT_PROPOSED**, physical promotion **0**. The publication status is **PUBLIC_THEOREM_SUPPLEMENT**. A theorem conditional on a proposed primitive proves an implication; it does not admit that primitive as bedrock. Original candidate/development labels remain visible in the preserved sources.

The equations use dimensionless source or apparatus units. Observer grids, programmed gates, apparatus scales, initial carriers and supplied resources retain their declared roles. Assertion counts measure replay coverage, not scientific confidence or independent evidence.

## Public statements and proofs

### PT01 — The four-vertex projection fixes a tetrahedral frame

For $P=I-\mathbf1\mathbf1^T/4$, the projected coordinate vectors satisfy $P^2=P$, squared norms $3/4$, distinct inner products $-1/4$, and pair cosine $-1/3$ in the three-dimensional zero-sum subspace.

**Proof.** Multiply the projector and inspect its diagonal and off-diagonal entries. Dividing $-1/4$ by $3/4$ gives the cosine. This is a representation theorem conditional on four coordinates; it supplies neither their creation nor a physical embedding or radius. Dependency: shape screen.

### PT02 — Capped coface extension terminates at a unique multiplicity class

For an alphabet of size $q$, counts $c_i\in\{0,1,2\}$, and the proposed rule that every extension adds one vertex of an unsaturated label and connects it to the existing simplex, every maximal extension-only history terminates after $D=\sum_i(2-c_i)$ steps at $(2,\ldots,2)$. Its terminal simplex has $2q$ vertices and dimension $2q-1$; the binary case gives balanced $K_4$.

**Proof.** Every legal step decreases the nonnegative integer deficit by one. A positive deficit always leaves a legal label. At zero deficit no extension is legal. Idling or interposed retraction is outside the statement. The alphabet and cap are assumptions, and A3 remains a proposed primitive. Dependency: native shape growth.

### PT03 — Fresh boundary growth preserves a ball but selects no unique cluster

Beginning with one tetrahedron, repeatedly attach a tetrahedron along exactly one boundary triangle using a fresh vertex. After $m$ cells, the complex is a stacked three-ball with

$$f=(m+3,3m+3,3m+1,m),\qquad |\partial_2|=2m+2.$$

Its face-dual graph is a tree. Under the balanced binary restoration rule, every frontier triangle has a unique restoring label. Both a four-cell chain and a four-cell star are legal from the same seed; no finite stopping size follows from extension alone.

**Proof.** A step adds $(1,3,3,1)$ simplices, preserves Euler characteristic, replaces one boundary triangle by three, and adds one dual leaf. Boundary gluing preserves the ball. The replay supplies chain/star witnesses with degree lists $(1,1,2,2)$ and $(1,1,1,3)$, which cannot be isomorphic. Since $2m+2>0$, further extension remains possible. This branch cannot form a dual cycle such as the specified six-cell coordinate-order cube triangulation. Metric shape, transition rates and full event admission are separate. Dependency: native shape growth.

### PT04 — A fixed skew flow cannot attract distinct preparations

For a fixed finite real skew generator $A$, two solutions of $\dot x=Ax$ preserve their Euclidean separation. Such a flow alone cannot contract an open family of preparations into one state.

**Proof.** $e^{sA}$ is orthogonal, so $\|e^{sA}(x-y)\|=\|x-y\|$. This covers the fixed support lane, not dissipative burden, state-dependent feedback, carrier changes or coarse observation. Dependencies: Paper I and shape screen.

### PT05 — The isolated K4 burden lane recovers uniformity and spreads stock

Under the stated Q163 relaxational source, $P_0=\mathbf1\mathbf1^T/4$ and

$$T(s)=P_0+e^{-4s/3}(I-P_0).$$

For $b=\bar b\mathbf1+\delta$ with $\mathbf1^T\delta=0$, total burden is conserved and the contrast norm squared is $e^{-8s/3}\|\delta\|^2$. For nonnegative burden with positive total $B$,

$$\mathrm{IPR}(s)=\frac14+e^{-8s/3}\frac{\|\delta\|^2}{B^2}.$$

**Proof.** The orthogonal projections separate the conserved and decaying sectors. Squaring their orthogonal sum gives the stated concentration formula. Equal-total perturbations converge to the same uniform state; different totals select different limits. This proves a persistent uniform mode and contrast recovery on supplied K4, not compact clustering or agreement-driven formation. Dependency: persistence controls.

### PT06 — Compatible complete targets do not guarantee global improvement

On the declared connected four-cell carriers with three global opposite-edge classes, complete one-closed-class cell targets are jointly realizable exactly when all mapped triples agree. Under unique-edge Q162 accounting,

$$g_{\mathrm{global}}=\sum_c g_c-\frac14\sum_e(m_e-1)(b_i-b_j)^2(\mathbf1_{e\in a}-\mathbf1_{e\in d}).$$

The prepared chain $0123,1234,0125,1246$, burden $(0,0,4,1,0,1,1)$, and initial closed class C has four strict local C-to-A gains $+2$, yet unique-edge global gain $-7/4$.

**Proof.** A shared triangle contains one edge of each class, forcing equality across each dual edge; connectedness propagates it. The gain identity follows by collecting each edge's multiplicity. Exact local rows $(9,17,17)$ and global row $(27,35,20)$ give the witness. Therefore preserving every strict local target and imposing additional global nonworsening are incompatible at this checkpoint. Global nonworsening is an added diagnostic, not an established UD axiom. Passing integrity and supplied shared-admission semantics remain assumptions. Dependencies: collective motif and event admission proofs.

### PT07 — Identical initial propagation can yield opposite retention changes

For connected Q162 $L$, centered $x$, and $N=x^Tx>0$, integrated normalized memory is $I_L=x^T(L+\mathbf1\mathbf1^T/7)^{-1}x/N$. The prepared star $0123,1234,0125,0136$ and chain $0123,1234,0125,0156$ share the entire initial active operator and burden $(1,0,0,5,2,1,0)$. Their matching A-to-C exchanges change integrated memory by $-165/272$ and $+161/816$, respectively. The chain's after-minus-before curve crosses at least once in $(1,2)$.

**Proof.** Integrate the centered semigroup using the inverse on the zero-sum sector. Exact rational solves give common initial memory $9271/5712$, then $2903/2856$ and $1733/952$. Rational propagation enclosures give negative difference at 1 and positive at 2; continuity supplies a crossing. The positive chain conclusion persists in the declared positive preparation neighborhood of sup-norm radius $1/96$. Neither uniqueness of crossing, universal motif ranking nor a native retention objective follows. Dependency: collective motif proofs and interval receipts.

### PT08 — Gate quiescence can coexist with complete contrast decay

For the three declared post-swap preparations, exact open-pair ties prevent another event under the supplied unanimous strict-request contract. Meanwhile any source-free switching among their connected Q162 gates obeys

$$\|x(s)\|\le e^{-s/72}\|x(0)\|.$$

**Proof.** The score difference is linear on a 49-dimensional tensor-square carrier; 49 zero moments and Cayley–Hamilton force every higher moment to vanish. Thus at least one cell always lacks a unique strict proposal. For decay, path bounds on seven vertices give $\|x\|^2\le18\sum_e(x_i-x_j)^2$ and $x^TLx\ge\|x\|^2/72$; integrate the norm inequality. An unbounded accumulated clock is required for asymptotic decay. The fixed gate is not a protected burden pattern or native HOLD, and perturbed preparations need not retain exact ties. Dependency: collective motif proofs.

### PT09 — Unsigned interface stocks do not determine continuation

For a linear generator $A$ and observation $P$, an autonomous linear output law for all inputs exists exactly when $PA=FP$ for some $F$, equivalently when $\ker P$ is invariant under $A$. In the declared 30-to-23 visible face-gluing transform, seven signed difference-memory coordinates are retained and the memory-to-visible block has rank seven. Visible amplitudes plus unsigned memory stocks are insufficient generically.

**Proof.** Invariance makes $F(Pq)=PAq$ well defined; failure gives equal observations with unequal derivatives. Concretely, left/right vertex-0 amplitudes $(3/2,1/2)$ or $(1/2,3/2)$ with left edge-03 amplitude 1 give identical visible amplitudes, total support $7/2$ and memory stock $1/2$. Their visible derivatives differ by $-1$ on edge 03 and $+1$ on edge 04. This also excludes any deterministic derivative using only those observations. Signed receipts or an explicit invariant-sector restriction remain valid alternatives. The transform transports independent dynamics; it does not bind cells or prove failure of Paper II's complete signed receipts. Dependency: event admission proof and its preserved continuation package.

### PT10 — An exact icosahedral tetrahedral carrier has nonregular constituents

Cone the twenty supporting facets of the regular icosahedral vertices $(0,\pm1,\pm\varphi)$ and cyclic coordinate placements to the origin, with $\varphi=(1+\sqrt5)/2$. This fills the convex polyhedron by twenty nondegenerate tetrahedra, with $f=(13,42,50,20)$ and chain dimension 125. The filled carrier has zero reduced integral homology. Its constituent radial squared length $(5+\sqrt5)/2$ differs from exterior squared length 4; the constituents are congruent but nonregular.

**Proof.** Exact arithmetic in $\mathbb Q(\sqrt5)$ verifies all supporting facets and nondegenerate cones. Interior radial faces cancel in the oriented filling. The integer cone homotopy satisfies $\partial h+h\partial=I-\iota\epsilon$, establishing integral contraction including absence of torsion. Five radial dihedral sectors of $2\pi/5$ close; five regular Euclidean tetrahedra instead leave $2\pi-5\arccos(1/3)>0$. This is a supplied representation, not an assembly, persistence or molecular result. Dependency: icosahedral carrier.

### PT11 — A finite static history controller completes and then reverses

For programmed comparator-energy-preserving gates $U_1,\ldots,U_n$, prefix dressing $\mathcal W$, and clock edge weights $\kappa\sqrt{(j+1)(n-j)}$, the comparison constant-Hamiltonian machine has terminal probability $\sin^{2n}(\kappa t)$, completion time $T=\pi/(2\kappa)$, spectrum $\kappa(n-2j)$, and return to the initial prefix at $2T$. If actual/comparator work mismatch has norm $d$, the joint propagator error is at most $|t|d$.

**Proof.** The clock is the symmetric-sector representation of $\kappa\sum X$. Its binomial amplitudes give completion and reversal; conjugation by $\mathcal W$ appends each circuit prefix. Duhamel bounds the actual native mismatch. The exact completion/return identities belong to the comparator; actual native departure is charged, not asserted zero. The integrated example uses twenty supplied coherent fuel qubits, three preparation uses, and 24 clock levels; its certified pre-capture window bound is below 0.081130589. This is one-shot propagation, not permanent shutdown. Dependency: controller audit 0.26.

### PT12 — Coherent binary fuel prepares a ladder; stationary covariant supply cannot

The declared finite, energy-preserving conditional binary exchanges map $q$ supplied coherent qubits and reference seed $|n_0\rangle$ to ground-state fuel and the uniform $L=2^q$ ladder packet. Stationary inputs under the complete admitted energy generator, processed covariantly, cannot produce that nonstationary target: their reference trace distance is at least $1-1/L$.

**Proof.** Disjoint bit transfers preserve integer energy and inductively generate every binary reference label once. For a stationary reference, target overlap is at most $1/L$; measuring the target projector gives the bound, attained by the uniform diagonal mixture. Coherence, seed energy, correlations and fuel variance are supplied resources. This restricted obstruction does not forbid production from an admitted nonstationary source. Dependency: controller audit 0.26.

### PT13 — Timed terminal capture gives guarded output protection

For matched source/output Hamiltonians, a fresh flag, terminal projector $P_n$, and involution $J=P_n\otimes\mathrm{SWAP}\otimes X+(I-P_n)\otimes I$, the supplied capture contact has uniform joint error $\gamma_c=\tau_c\kappa n$. With $a_C=\sqrt n\kappa\sigma+(T+\sigma)d$,

$$p_{L=0}\le\min\{1,(a_C+\gamma_c)^2\},\qquad p_{\mathrm{false\ tag}}\le\min\{1,\gamma_c^2\}.$$

After pulse-off under the declared guarded background, the output and operational record evolve exactly by native free output evolution, while flag probabilities remain fixed.

**Proof.** $J^2=I$ and matched-energy exchange commutes with free evolution. Duhamel bounds the remaining active controller during contact. The nonterminal amplitude and contact difference yield the probability bounds. The post-contact background factorizes at O and commutes with the flag, proving output/record protection for arbitrary correlated states, including failures. The audit 0.27 production-plus-capture bound is below 0.081219; capture failure is below 0.000023317 and false terminal tag below $7.70\times10^{-9}$. These are conditional bounds before supply and implementation debits, not measured rates. Both CAPTURED and NO_CAPTURE remain in the instrument. Timing, shutoff, copies and routing are supplied. Dependency: capture audit 0.27.

### PT14 — Exact finite autonomous first-entry absorption is obstructed

A proper invariant captured subspace of a finite closed system with one time-independent Hermitian Hamiltonian cannot first acquire population from its orthogonal complement. A finite spectral captured-probability trajectory that is exactly constant on an open late interval is constant for all time.

**Proof.** Hermiticity makes an invariant subspace reducing, so its projector commutes with the Hamiltonian and population is conserved in both time directions. A finite spectral probability is real analytic; a constant open interval forces constant continuation. This excludes exact permanent first-entry absorption under those assumptions. Approximate finite-horizon retention, open reservoirs and explicitly modeled switching are distinct possibilities. Always-on ideal capture reverses because $J^2=I$. Dependency: capture audit 0.27, section 6.

### PT15 — Matched finite renewal exports correlations and consumes stock

For an independent matched donor $\sigma_D$ and arbitrary old machine/history state $\rho_{AY}$, ideal SWAP sends $\rho_{AY}\otimes\sigma_D$ to $\sigma_A\otimes\rho_{DY}$. In the guarded capture architecture, active renewal contact adds at most $\tau_r\kappa n$; each attempt consumes one donor and one fresh output slot. A full-bank supply error is charged once, with unconditional telescoping operation debits thereafter.

**Proof.** Relabel the factors under matched exchange; all correlations move to D/Y, including failures and waste. Duhamel bounds guarded hopping during contact, and trace-distance contractivity gives the joint telescoping budget. Marginal fidelities do not certify the bank: three mutually exclusive single-slot errors can each have marginal fidelity $2/3$ but zero joint target fidelity. For the stated example, production plus capture plus renewal is below 0.081306065 before further debits. Finite slot exhaustion requires the supplied END_OF_SUPPLY refusal, never resource wraparound. This is a conditional finite renewal map, not an autonomous complete cycle. Dependencies: controller audit 0.26 and capture audit 0.27.

### PT16 — Static post-launch capture admits a finite retention horizon

Supply a fresh finite capture clock with $N+1$ addresses, initial address 0, spin edge weights $\lambda\sqrt{(q+1)(N-q)}$, and the declared first-edge terminal-controlled matched exchange/record involution $J_*$. Later edges carry identity. Let $h_p$ bound the running parent's guarded hopping norm. The actual time-independent post-launch machine has complete-joint error relative to the fully transferred freely evolving target at most

$$\min\{1,t h_p+2|\cos(\lambda t)|^N\}.$$

Over $\pi/(4\lambda)\le t\le3\pi/(4\lambda)$, the boundary probability is at most $2^{-N}$ and the uniform complete-joint debit is at most $3\pi h_p/(4\lambda)+2\,2^{-N/2}$. The comparison transfer is exact at $\pi/(2\lambda)$ and reverses at $\pi/\lambda$.

**Proof.** Prefix dressing appends $J_*$ at every nonzero clock address. Binomial spin evolution leaves boundary probability $r=\cos^{2N}(\lambda t)$. The target/vector difference is supported on address 0 and bounded by $2\sqrt r$; Duhamel adds $t h_p$ on arbitrary body/spectator purifications. The cosine bound supplies the horizon; symmetric-clock recurrence undoes exchange and record flips. With fresh records and parent failure amplitude at most $a$, NO_CAPTURE is at most $\min\{1,(a+\sqrt r+t h_p)^2\}$ and false terminal tags at most $\min\{1,(t h_p)^2\}$. The declared 41-state example certifies production plus static capture below 0.081184178, before additional supply/implementation debits. This is a pointwise finite-window bound, not a monitored no-failure probability, exact decoupling or permanent storage. Fresh clock coherence, launch alignment, donor/output routing and renewal remain supplied or open. Dependency: static capture audit 0.28; this alternative preserves PT13's distinct exact post-switch protection theorem.

## Replay and source record

| Dependency | Replay scope | Constructor checks |
|---|---|---:|
| Shape screen | Nine supplied motifs and bounded five-vertex universe | 9,318 exact |
| Native shape growth | Local completion; 2,140 boundary attachments | 44,441 exact |
| Persistence controls | 80 nonnegative preparations; 14 conflict cases | 12,244 exact |
| Collective motif | 314,928 grid snapshots | 16,302 exact |
| Wider preparation | Retention witnesses and positive neighborhood | 859 exact |
| Collective intervals | Rational propagation and crossing signs | 716 interval + 77 carrier |
| Complete commits | Compatibility, deduplication, partial-publication controls | 762 exact |
| Event admission | Endpoint discriminator and signed memory; parent replay | 36 root assertions |
| Icosahedral carrier | Exact facets, integral contraction and metric | Exact replay PASS; no scalar count asserted |
| Static controller, audit 0.26 | Finite clock, fuel, native mismatch and renewal | 7,644 exact + 108 numerical |
| Capture and renewal, audit 0.27 | Capture, guard, records, first law and supply | 947 exact + 99 numerical |
| Static capture, audit 0.28 | Post-launch constant Hamiltonian; finite horizon and recurrence | 1,195 exact + 192 numerical |

All included checks were replayed for this publication. They remain constructor checks. The mathematical supplement does not raise CRL approval, physical correspondence, empirical status, closure scores, native-dimensionality claims, or independent-review status.

## Open frontier

The next apparatus target is an autonomous production-to-capture trigger and finite output/donor router, with explicit recurrence, preparation, work, correlations, failure and supply accounting. The static producer is a conditional one-shot theorem; PT16 now supplies constant post-launch capture over an admitted finite horizon. Autonomous launch, routing, a complete renewed cycle, upstream clock/fuel supply and local synthesis remain open.

For shape discovery, preserve **agreement → persistence → clustering availability → preference** as the study sequence. Full native event timing, integrity, shared authorization, signed state transfer, source magnitude, coupled formation/growth and fair competing-carrier ensembles remain unresolved. No universal winning shape, attraction to a polyhedron or physical identity is promoted.

## Promotion receipt

Authority: Benjamin Mayes's instruction on 3 October 2026 to promote the later frozen results to the public theorem layer and update the project site. Scope: public statements PT01–PT16 under their stated assumptions, including audit 0.28 received during publication. Original source statuses and historical locks are preserved. Public register and SHA-256 dependency manifest accompany this supplement. A dependency failure defers affected public statements pending repair; corrections are appended with provenance.
