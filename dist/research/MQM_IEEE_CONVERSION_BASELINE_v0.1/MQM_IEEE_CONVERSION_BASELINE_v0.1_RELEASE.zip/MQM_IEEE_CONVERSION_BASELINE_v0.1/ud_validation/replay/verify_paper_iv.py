"""Finite exact-map controls and numerical joint fixtures for Paper IV 0.1.
Same-constructor implementation; not independent review or apparatus validation.
Requires numpy and scipy. Run from the extracted release root.
"""
from pathlib import Path
from fractions import Fraction as F
import itertools,json,math
import numpy as np
from scipy.linalg import eigh
R=Path(__file__).resolve().parents[1];exact=[];numerical=[];residuals=[];TOL=2e-10

def ex(name,ok):
 if not ok:raise AssertionError(name)
 exact.append(name)
def num(name,err):
 err=float(err)
 if not math.isfinite(err) or err>TOL:raise AssertionError((name,err))
 numerical.append(name);residuals.append(err)
def bound(name,value,upper):num(name,max(0,float(value)-float(upper)))
def ket(n,j):v=np.zeros(n,complex);v[j]=1;return v
def kron(*args):
 a=np.array([1.],complex)
 for b in args:a=np.kron(a,b)
 return a
def td(a,b):return np.sum(np.abs(np.linalg.eigvalsh((a-b+a.conj().T-b.conj().T)/2)))/2
def puretd(a,b):
 # Projection residual avoids catastrophic cancellation near identical states.
 a=a/np.linalg.norm(a);b=b/np.linalg.norm(b)
 return np.linalg.norm(a-b*np.vdot(b,a))
def unitary(H,t):v,Q=eigh(H);return (Q*np.exp(-1j*t*v))@Q.conj().T
def spin(n,k):
 H=np.zeros((n+1,n+1),complex)
 for j in range(n):H[j+1,j]=H[j,j+1]=k*math.sqrt((j+1)*(n-j))
 return H
X=np.array([[0,1],[1,0]],complex);Z=np.diag([1.,-1.]);I2=np.eye(2)
# Exact binary fuel permutations, inspected on every stored pair and energy label.
for q in range(1,6):
 L=2**q;n0=2
 for j in range(q):
  pairs=[((1,n0+r),(0,n0+r+2**j)) for r in range(L) if (r>>j)&1==0]
  flat=[p for pair in pairs for p in pair]
  ex(f'q{q} bit{j} disjoint actual pairs',len(set(flat))==len(flat))
  ex(f'q{q} bit{j} actual pair energies',all(a[0]*2**j+a[1]==b[0]*2**j+b[1] for a,b in pairs))
 final=[]
 for bits in itertools.product([0,1],repeat=q):
  r=0;out=list(bits)
  for j in range(q):
   ex(f'q{q} bits{bits} step{j} current reference bit zero',((r>>j)&1)==0)
   if out[j]:r+=2**j;out[j]=0
  final.append(r)
  ex(f'q{q} bits{bits} fuel consumed',out==[0]*q)
 ex(f'q{q} every packet label once',sorted(final)==list(range(L)))
 mean=sum(F(r,L) for r in range(L));var=sum(F(r*r,L) for r in range(L))-mean*mean
 ex(f'q{q} exact fuel moments',mean==F(L-1,2) and var==F(L*L-1,12))
# History clock arbitrary prefixes, including a spectator-entangled work state.
Hgate=np.array([[1,1],[1,-1]],complex)/math.sqrt(2);psi=kron(ket(2,0),ket(2,0))+kron(ket(2,1),ket(2,1));psi/=math.sqrt(2)
for n in [1,2,3]:
 k=.7;Hc=spin(n,k);prefix=[I2]
 for j in range(n):prefix.append((Hgate if j%2==0 else Z)@prefix[-1])
 W=np.zeros((2*(n+1),2*(n+1)),complex)
 for j in range(n+1):W[2*j:2*j+2,2*j:2*j+2]=prefix[j]
 Hp=W@np.kron(Hc,I2)@W.conj().T;num(f'n{n} prefix unitary',np.linalg.norm(W@W.conj().T-np.eye(len(W))))
 num(f'n{n} clock spectrum',np.max(np.abs(np.linalg.eigvalsh(Hc)-np.sort(k*(n-2*np.arange(n+1))))))
 for t in [.31,math.pi/(2*k),math.pi/k]:
  cs=np.array([(-1j)**j*math.sqrt(math.comb(n,j))*math.sin(k*t)**j*math.cos(k*t)**(n-j) for j in range(n+1)])
  num(f'n{n} clock amplitudes t{t}',np.linalg.norm(unitary(Hc,t)@ket(n+1,0)-cs))
  inp=kron(ket(n+1,0),psi);act=np.kron(unitary(Hp,t),I2)@inp
  expected=sum((kron(ket(n+1,j),np.kron(prefix[j],I2)@psi)*cs[j] for j in range(n+1)),np.zeros_like(inp))
  num(f'n{n} joint prefix law t{t}',np.linalg.norm(act-expected))
 # perturb actual work operator; compare full spectator states.
 d=.09;delta=np.kron(np.eye(n+1),np.diag([0,d]));t=.8
 ua=unitary(Hp+delta,t);u0=unitary(Hp,t)
 bound(f'n{n} operator Duhamel',np.linalg.norm(ua-u0,2),t*d)
 bound(f'n{n} full state Duhamel',puretd(np.kron(ua,I2)@inp,np.kron(u0,I2)@inp),t*d)
# Stored timed capture permutations and matched-energy labels, C/S/O/L order.
for n in [1,2,3]:
 dims=(n+1,2,2,2);D=math.prod(dims);perm=[]
 for idx in itertools.product(*(range(d) for d in dims)):
  c,s,o,l=idx;out=(c,o,s,1-l) if c==n else idx;perm.append(np.ravel_multi_index(out,dims))
 ex(f'n{n} capture stored permutation bijective',sorted(perm)==list(range(D)))
 ex(f'n{n} capture actual involution',all(perm[perm[j]]==j for j in range(D)))
 energies=[s+o for c,s,o,l in itertools.product(*(range(d) for d in dims))]
 ex(f'n{n} capture actual matched energy preservation',all(energies[j]==energies[perm[j]] for j in range(D)))
 J=np.eye(D)[:,perm];free=np.diag(energies);Hc=spin(n,.23);Hp=np.kron(Hc,kron(Z,I2,I2));guard=np.kron(np.eye(n+1),kron(I2,I2,np.diag([1,0])))@Hp;bg=free+guard
 tau=.04;G=math.pi*(np.eye(D)-J)/(2*tau);uc=unitary(bg+G,tau);u0=unitary(free,tau)@J;gam=tau*.23*n
 num(f'n{n} capture pulse exact comparison',np.linalg.norm(unitary(free+G,tau)-u0))
 bound(f'n{n} capture operator contact',np.linalg.norm(uc-u0,2),gam)
 cvec=ket(n+1,n)*math.sqrt(.8)+ket(n+1,0)*math.sqrt(.2)
 inp=np.zeros((n+1,2,2,2,2),complex)
 for c in range(n+1):
  for s in range(2):inp[c,s,0,0,s]=cvec[c]/math.sqrt(2)
 inp=inp.ravel();out=np.kron(uc,I2)@inp;uout=out.reshape(n+1,2,2,2,2)
 no=np.sum(abs(uout[:,:,:,0,:])**2);bad=np.sum(abs(uout[:n,:,:,1,:])**2)
 bound(f'n{n} capture no branch',no,(math.sqrt(.2)+gam)**2);bound(f'n{n} false tag',bad,gam**2)
 # post-pulse O free reduced propagation, even on actual failure state.
 t=.63;post=np.kron(unitary(bg,t),I2)@out
 def redOM(v):
  # Append fresh M,E and copy L into both, then reduce L,E and the rest.
  # This operational O/M state has no cross-record blocks. O/L coherences
  # are a different reduction and are not the protected operational record.
  z=v.reshape(n+1,2,2,2,2).transpose(2,3,0,1,4).reshape(4,-1);rho=z@z.conj().T
  return rho*np.equal.outer(np.tile([0,1],2),np.tile([0,1],2))
 targetU=kron(unitary(np.diag([0,1]),t),I2)
 num(f'n{n} pulse-off OM factorization',np.linalg.norm(redOM(post)-targetU@redOM(out)@targetU.conj().T))
# Static full clock/body/spectator contract with three copied bits.
n=1;N=3;k=.13;lam=.9;dims=(2,2,2,2,2,2);D=64;indices=list(itertools.product(*(range(2) for _ in dims)));perm=[]
for c,s,o,l,m,e in indices:
 out=(c,o,s,1-l,1-m,1-e) if c==1 else (c,s,o,l,m,e);perm.append(np.ravel_multi_index(out,dims))
ex('static stored Jstar bijective',sorted(perm)==list(range(D)))
ex('static stored Jstar involutive',all(perm[perm[j]]==j for j in range(D)))
energies=np.array([s+o for c,s,o,l,m,e in indices]);ex('static stored free energy matched',all(energies[j]==energies[perm[j]] for j in range(D)))
J=np.eye(D)[:,perm];free=np.diag(energies);Hp=k*kron(X,Z,I2,I2,I2,I2);guard=np.diag([int(l==0) for c,s,o,l,m,e in indices])@Hp
V=np.zeros(((N+1)*D,(N+1)*D),complex)
for j in range(N+1):V[j*D:(j+1)*D,j*D:(j+1)*D]=np.eye(D) if j==0 else J
Hq=spin(N,lam);Hd=V@np.kron(Hq,np.eye(D))@V.conj().T;H0=np.kron(np.eye(N+1),free)+Hd;Ha=H0+np.kron(np.eye(N+1),guard)
psi=np.zeros(dims+(2,),complex)
for s in range(2):psi[1,s,0,0,0,0,s]=1/math.sqrt(2)
psi=psi.ravel();inp=kron(ket(N+1,0),psi)
num('static clock norm',abs(np.linalg.norm(Hd,2)-lam*N))
mean=np.vdot(inp,np.kron(Hd,I2)@inp);moment=np.vdot(inp,np.kron(Hd@Hd,I2)@inp)
num('fresh static mean',abs(mean));num('fresh static variance',abs(moment-lam*lam*N))
for t in [math.pi/(4*lam),math.pi/(2*lam),3*math.pi/(4*lam),math.pi/lam]:
 cs=unitary(Hq,t)@ket(N+1,0);bodypost=np.kron(unitary(free,t)@J,I2)@psi;target=kron(cs,bodypost)
 comp=np.kron(unitary(H0,t),I2)@inp;act=np.kron(unitary(Ha,t),I2)@inp;r=math.cos(lam*t)**(2*N)
 bound(f'static complete comparison t{t}',puretd(comp,target),2*math.sqrt(r))
 bound(f'static actual joint t{t}',puretd(act,target),t*k+2*math.sqrt(r))
 z=comp.reshape(N+1,2*D);marg=z.T@z.conj();bpre=np.kron(unitary(free,t),I2)@psi
 expected=r*np.outer(bpre,bpre.conj())+(1-r)*np.outer(bodypost,bodypost.conj())
 num(f'static marginal mixture t{t}',np.linalg.norm(marg-expected));bound(f'static marginal debit t{t}',td(marg,np.outer(bodypost,bodypost.conj())),r)
 # Same fixture has orthogonal pre/post flags: replacing joint debit by r is rejected.
 if abs(t-math.pi/(4*lam))<1e-12:ex('joint marginal substitution rejected',puretd(comp,target)>r+.1)
 if abs(t-math.pi/(2*lam))<1e-12:num('static comparison transfer',puretd(comp,target))
 if abs(t-math.pi/lam)<1e-12:
  return_target=kron(cs,bpre);num('static comparison return',np.linalg.norm(comp-return_target))
# Stationary sharp bound and full correlation export.
for L in [2,3,4]:
 eta=np.ones(L)/math.sqrt(L);diag=np.eye(L)/L
 num(f'L{L} sharp stationary distance',abs(td(diag,np.outer(eta,eta))-float(1-F(1,L))))
# A/D/Y ordering; A entangled with Y and independent D=|+>.
v=np.zeros((2,2,2),complex)
for a in range(2):
 for d in range(2):v[a,d,a]=.5
out=v.transpose(1,0,2).reshape(-1);target=kron(np.ones(2)/math.sqrt(2),np.array([1,0,0,1])/math.sqrt(2))
num('renewal full spectator correlation relabel',np.linalg.norm(out-target))
redA=out.reshape(2,-1)@out.reshape(2,-1).conj().T;num('renewal active fresh independent target',np.linalg.norm(redA-np.ones((2,2))/2))
ex('correlated three-slot marginals',all(sum(F(bits[j],3) for bits in [(1,1,0),(1,0,1),(0,1,1)])==F(2,3) for j in range(3)))
ex('correlated three-slot joint negative control',not any(all(bits) for bits in [(1,1,0),(1,0,1),(0,1,1)]))
# Parameter checks from manuscript, fractions first.
hp=23*2**12;lam=2**32;N=40
ex('timed contact exact',F(hp,2**30)==F(23,2**18))
ex('static horizon pi coefficient',F(3*hp,4*lam)==F(69,2**22))
ex('static renewal full generator debit',F(hp+lam*N,2**50)==F(41943063,274877906944))
result=dict(status='PASS',exact_checks=len(exact),numerical_checks=len(numerical),max_numerical_residual=max(residuals),numerical_tolerance=TOL,exact=exact,numerical=numerical,physical_promotion=0,independent_review='PENDING',scope='Small finite fixtures and negative controls; same-constructor implementation. General theorems rely on written proofs; no large apparatus replay or empirical result.')
(R/'audit/PAPER_IV_REPLAY_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','exact_checks','numerical_checks','max_numerical_residual','numerical_tolerance']}))
