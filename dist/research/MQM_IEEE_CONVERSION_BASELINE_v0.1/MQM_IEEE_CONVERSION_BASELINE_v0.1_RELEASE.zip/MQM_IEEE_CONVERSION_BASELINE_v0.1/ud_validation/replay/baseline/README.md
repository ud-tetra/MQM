# Exact reproduction — review edition 1.0

Benjamin Walker Mayes, independent researcher. 16 September 2026.

This supplement accompanies two separately reviewable papers:

- Paper I: Finite Tetrahedral Complexes and Skew Hodge–Dirac Support Flow.
- Paper II: Projective Reconstruction from Simplex Stocks and Incidence Currents.

## Run

Extract this ZIP, open a terminal in the extracted directory, and run:

```sh
python verify.py
```

Requires Python 3.10 or later. Only the standard library is used; no installation,
network access, device connection, random sampling or private conversation is needed.
A successful run prints `"status": "PASS"` and exits with code 0; any assertion
failure exits nonzero. The exact checks took approximately 0.2 seconds in the
build environment, before file-integrity checks. Allow under one minute on an
ordinary computer; actual timing is printed on your machine.

## Contents and proof obligations

| Paper / claims | What the program checks |
| --- | --- |
| I P3.1–P3.5 | Matching action, stabilizer distinction, equal edge fibers, Hamming ranks |
| I L4.1, T4.3–T4.4, P4.5 | Integer boundaries, boundary-square zero, skew symmetry, single-cell square, cut/cycle projectors |
| I T5.1–T5.2 | Cut-balance and unique-simplex ownership identities on the supplied examples |
| I T6.1–T6.4, NG6.5–NG6.6 | Oriented Pachner boundary, signed B/C permutation, A/B inclusion residual, exact rational nullities, binary-label obstruction; the irrational-frequency argument is in the paper |
| I T7.2–T7.3, P7.4 | All binary affine maps, transition ranks/commutators, extraction for all vertex permutations |
| I P8.1 | Explicit norm/second-form counterexample |
| II NG2.1, T3.2, P3.3, T4.1 | Parity ambiguity witness, positive-ray fixtures including zeros/disconnected support, current-square identity, two forest choices |
| II spanning-tree and covariance results | Exact ordered 14/14 split, H=CS, rank 14 for S, rank 10 for H, alternating path lengths, rational finite-population covariance pushforward |

The written proofs establish the general statements. This script verifies finite
algebraic instances and the archived matrices; it is not a formal proof assistant,
independent peer review or an optical acquisition scorer.

`data/exact_artifacts.json` contains the full bases, matrices, maps, spectra,
PSR fixtures, and covariance example. Rational values are serialized as strings.
`data/split.json` declares the ordered training/chord incidence identities.
`data/C.csv` is the 14 by 14 integer map: rows follow the held-out order and columns
the training order in `split.json`. `data/paper-I-claims.csv` is the public claim
index. `papers/` contains the two matching manuscript sources.

`SHA256SUMS.json` identifies all other files in this supplement. The verifier checks
it after regenerating the algebra and comparing the result with the stored artifact.
Hashes establish file identity, not mathematical validity. To intentionally rebuild
the JSON during development, use `python verify.py --write-artifacts`; doing so
requires reissuing the file manifest before redistribution. The versioned review
package should normally be run without that option.

## Limits

There is no empirical optical session here. No acceptance interval, apparatus
identity, physical field, physical coupling or physical unit is inferred. Covariance
transport is exact for the declared linear map; covariance alone is not coverage.
Noise propagation in current coordinates after exponentiation requires its stated
approximation or a separately declared full error model. The general source of
event receipts is not derived by these tests.
