"""Exact bounded review checks; standard library only. Not independent human review."""
from fractions import Fraction as F
from pathlib import Path
import ast,csv,itertools,json,sys,hashlib
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,ok):
    if not ok: raise AssertionError(name)
    checks.append(name)

class E(tuple):
    """Q(sqrt(2),sqrt(3)), basis 1,sqrt2,sqrt3,sqrt6."""
    def __new__(cls,x=0):
        return tuple.__new__(cls,tuple(map(F,x)) if isinstance(x,(list,tuple)) else (F(x),F(0),F(0),F(0)))
    def __add__(a,b):
        b=E(b); return E([a[i]+b[i] for i in range(4)])
    __radd__=__add__
    def __neg__(a): return E([-x for x in a])
    def __sub__(a,b):return a+-E(b)
    def __rsub__(a,b):return E(b)+-a
    def __mul__(a,b):
        b=E(b);r=[F(0)]*4
        for i in range(4):
            for j in range(4):
                common=i&j;factor=(2 if common&1 else 1)*(3 if common&2 else 1)
                r[i^j]+=a[i]*b[j]*factor
        return E(r)
    __rmul__=__mul__
    def __truediv__(a,b):
        b=E(b);assert all(x==0 for x in b[1:]) and b[0];return E([x/b[0] for x in a])
def sqrt(n):return E({2:[0,1,0,0],3:[0,0,1,0],6:[0,0,0,1]}[n])
def parse(s):
    def walk(n):
        if isinstance(n,ast.Constant):return E(n.value)
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -walk(n.operand)
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='sqrt':return sqrt(n.args[0].value)
        if isinstance(n,ast.BinOp):
            a,b=walk(n.left),walk(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.Div):return a/b
        raise ValueError(ast.dump(n))
    return walk(ast.parse(s,mode='eval').body)
def mm(a,b):return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]
def tr(a):return list(map(list,zip(*a)))
def eye(n):return [[E(i==j) for j in range(n)] for i in range(n)]
def scale(a,s):return [[x*s for x in row] for row in a]
def add(a,b):return [[x+y for x,y in zip(r,s)] for r,s in zip(a,b)]
def trace(a):return sum(a[i][i] for i in range(len(a)))

Q=[[E(0),sqrt(2)/2,-sqrt(2)/2],[sqrt(6)/3,-sqrt(6)/6,-sqrt(6)/6],[sqrt(3)/3]*3]
P=[[E(1),E(0),E(0)],[E(0),E(1),E(0)],[E(0),E(0),E(-1)]]
V=scale([[E(v) for v in r] for r in [[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]]],F(1,2))
D=[[[E(0) for _ in range(3)] for _ in range(3)] for _ in range(2)]
for i,v in enumerate([sqrt(3)/2,-sqrt(3)/2,E(0)]):D[0][i][i]=v
for i,v in enumerate([E(F(1,2)),E(F(1,2)),E(-1)]):D[1][i][i]=v
G=[[[E(0) for _ in range(2)] for _ in range(3)] for _ in range(3)]
csvpath=ROOT/'sources/T2_CONTEXT_GAMMA_MATRICES.csv'
for r in csv.DictReader(csvpath.open()):
    for j in range(2):G[int(r['context_component'])-1][int(r['row'])-1][j]=parse(r['E'+str(j+1)])
check('Q orthogonal',mm(tr(Q),Q)==eye(3));check('P orthogonal',mm(tr(P),P)==eye(3));check('frame columns orthonormal',mm(tr(V),V)==eye(3))
for j in range(2):check('supplied Gamma factorization column '+str(j),[[G[a][i][j] for a in range(3)] for i in range(3)]==mm(mm(P,D[j]),tr(Q)))
for perm in itertools.permutations(range(4)):
    R4=[[E(0) for _ in range(4)] for _ in range(4)]
    for j in range(4):R4[perm[j]][j]=E(1)
    R=mm(mm(tr(V),R4),V);ctx=mm(mm(Q,R),tr(Q));out=mm(mm(P,R),tr(P))
    ep=[[trace(mm(mm(mm(D[i],R),D[j]),tr(R)))*F(2,3) for j in range(2)] for i in range(2)]
    check('E action orthogonal '+str(perm),mm(tr(ep),ep)==eye(2))
    for b in range(3):
        lhs=mm([[sum(ctx[a][b]*G[a][i][j] for a in range(3)) for j in range(2)] for i in range(3)],ep)
        check('Gamma equivariance '+str(perm)+' context '+str(b),lhs==mm(out,G[b]))

nodes=[t for k in range(1,5) for t in itertools.combinations(range(4),k)];index={t:i for i,t in enumerate(nodes)}
edges=[(index[t[:j]+t[j+1:]],index[t]) for t in nodes if len(t)>1 for j in range(len(t))]
L=[[0]*15 for _ in range(15)]
for a,b in edges:L[a][a]+=1;L[b][b]+=1;L[a][b]-=1;L[b][a]-=1
def det(a):
    a=[r[:] for r in a];prev=1
    for k in range(len(a)-1):
        assert a[k][k]!=0
        pivot=a[k][k]
        for i in range(k+1,len(a)):
            for j in range(k+1,len(a)):
                num=a[i][j]*pivot-a[i][k]*a[k][j];assert num%prev==0;a[i][j]=num//prev
        prev=pivot
    return a[-1][-1]
tau=det([r[:-1] for r in L[:-1]])
check('Matrix Tree count integer cofactor',tau==3773184==2**8*3*17**3)
check('incidence count separate from tree factor',len(edges)==28 and 2**8!=28)

# Factor-two repair: positive eigenvalue 2 on centered two-vertex example.
lap=[[E(1),E(-1)],[E(-1),E(1)]];projector=scale(lap,F(1,2));pinv=scale(lap,F(1,4));sq=scale(pinv,F(1,2))
check('autocorrelation integral inverse solves on contrast',mm(lap,pinv)==projector)
check('squared contrast integral Lyapunov equation',add(mm(lap,sq),mm(sq,lap))==projector)
for alpha in [F(1,3),F(2),F(7,4)]:check('squared integral half autocorrelation alpha='+str(alpha),F(1,2)/alpha==F(1,1)/alpha/2)
initial=F(9271,5712);star=F(2903,2856);chain=F(1733,952)
check('autocorrelation star delta unchanged',star-initial==-F(165,272))
check('autocorrelation chain delta unchanged',chain-initial==F(161,816))
check('squared contrast deltas half', (star-initial)/2==-F(165,544) and (chain-initial)/2==F(161,1632))
# Shared-vertex orthogonal sum/difference transformation; edge03 is unshared.
for a,b in [(F(3,2),F(1,2)),(F(1,2),F(3,2))]:
    total=a*a+b*b+1;visible=(a+b)**2/2+1;memory=(a-b)**2/2
    check('interface stock partition '+str((a,b)),total==F(7,2) and visible==3 and memory==F(1,2) and total==visible+memory)
# Raw-versus-normalized receipt scaling negative control.
raw=[F(4),F(1)];current=F(-4);norm=sum(raw);rho=[q/norm for q in raw]
check('raw stock squared-current identity',current**2==4*raw[0]*raw[1])
check('normalized stock requires normalized current',(current/norm)**2==4*rho[0]*rho[1])
check('unnormalized current with normalized stock rejected',current**2!=4*rho[0]*rho[1])
result={'status':'PASS','checks':checks,'checks_passed':len(checks),'gamma_equivariance_checks':72,'exact_tree_count':tau,'memory_repair':'Autocorrelation unchanged; squared-contrast integral and changes are half.','interface_repair':'total 7/2 = visible 3 + memory 1/2 in stated orthogonal witness','scope':'Independent implementation by same AI constructor; bounded exact checks, not independent human review or full proof certification.','physical_promotion':0,'independent_review':'PENDING'}
(ROOT/'EXACT_REVIEW_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','checks_passed','gamma_equivariance_checks','exact_tree_count']}))
