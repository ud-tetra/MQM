A Capacity-Gated Boundary Latch: Conditional Coherence and Completion Contracts
Benjamin Walker Mayes | ORCID0009-0002-5813-0724 | MQM v0.1

RESULT
Finite declared occupancy encoding n/768,n=0..8,cap7/768. Completion is a
separate trusted flag. Productm launch with incomplete or unsaturated labels
cannot access the latch. Data-independent jump preserves arbitrary data and
spectators. For fixed eligible labels,g=1,Gamma=2sqrt2,no reverse jumps and
zero storage Hamiltonian, exact half-diamond error is survivalq(t).
A positive rational Taylor lower enclosure provesq<1/65536 throughout
[16-1/1024,16+1/1024]. Bath output is traced. This is a conditional ideal
constructor certificate, not the native joint-admission solution.

Restricted polar-normalized coboundary map is an exact two-mode isometry;
raw coboundary is not a full six-edge isometry. Standard D1D0=0 remains intact.
No autonomous/local implementation of this transfer is supplied.
Negative controls: saturation alone captures incomplete work; data-resolving
jump labels destroy captured Bell entanglement.35 exact checks,34 numerical
controls. No physical promotion, thermal refresh, fault tolerance or advantage.
Independent review/novelty pending. Historical source claims are not canon.

REPLAY
  python3 verify_latch.py
Uses sympy exact matrices,algebraic ODE identities and rational exponential
Taylor comparison. Binary64 Lindblad controls use tolerance1e-12 and are
not the window proof. No random seeds or shots; no device observations.
Time16 is an engineering deadline; this is not an independent prediction.

PDF
  python3 build_pdf.py
Requires pdflatex,IEEEtran,balance,PyMuPDF. Inspect both PAGE_*.png then:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two columns. Class license included.
NEXT_GATE.json records completion generation,coherent control and reverse-jump
tests. Source evidence levels and failed-control outcomes remain separated.
SHA256SUMS.txt covers distributed files. Earlier releases remain immutable.
