"""Finite conditional latch: exact identities and declared numerical controls."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,itertools
import sympy as s
import numpy as np
from scipy.linalg import expm
R=Path(__file__).resolve().parent;checks=[]
def check(name,value):
 assert bool(value),name
 checks.append(name)
edges=list(itertools.combinations(range(4),2));faces=list(itertools.combinations(range(4),3))
B1=s.zeros(4,6);B2=s.zeros(6,4)
for j,(a,b) in enumerate(edges):B1[a,j]=-1;B1[b,j]=1
for j,f in enumerate(faces):
 for k in range(3):B2[edges.index(tuple(x for i,x in enumerate(f) if i!=k)),j]=(-1)**k
D0=B1.T;D1=B2.T
check('coboundary composition zero',D1*D0==s.zeros(4,4))
check('edge-to-face coboundary rank3',D1.rank()==3)
K=s.zeros(6,2);K[0,0]=1;K[1,1]=1
A=D1*K;G=A.T*A
check('selected edge carrier Gram',G==s.Matrix([[2,-1],[-1,2]]))
V=s.Matrix([[1,1],[1,-1]])/s.sqrt(2)
inverse=V*s.diag(1,1/s.sqrt(3))*V.T
S=s.simplify(A*inverse)
check('restricted polar boundary map isometry',s.simplify(S.T*S)==s.eye(2))
check('recoverable on selected boundary image',s.simplify(S.T*S*s.eye(2))==s.eye(2))
check('four-face space insufficient for six-edge isometry',4<6)
capacity=s.Rational(7,768);occupancy=s.diag(*[s.Rational(n,768) for n in range(9)])
sat=s.diag(*[int(n>=7) for n in range(9)])
check('capacity fraction',capacity==s.Rational(7,4*192))
check('saturation projector',sat*sat==sat and sat.T==sat)
for n in range(9):check('occupancy trigger n='+str(n),sat[n,n]==int(bool(occupancy[n,n]>=capacity)))
F=s.diag(0,1);M=s.zeros(3);M[0,1]=M[1,0]=1
L=s.zeros(3);L[2,1]=1;Pd=s.diag(0,0,1)
gate=s.kronecker_product(sat,F)
check('joint saturation-completion projector',gate*gate==gate)
check('dark clock reducing for latch Hamiltonian',M*Pd==Pd*M==s.zeros(3))
check('jump annihilates dark clock',L*Pd==s.zeros(3))
check('jump range dark',Pd*L==L)
check('incomplete gate blocks every occupancy sector',all(sat[n,n]*F[0,0]==0 for n in range(9)))
check('saturated complete gate opens',sat[7,7]*F[1,1]==1)
# Conditional Hamiltonian gate*M; jump I_QF*L; transit e unoccupied for closed gates.
# Jump is NOT data-resolving. The data factor is exact identity throughout.
X=s.Matrix([[0,1],[1,0]]);Z=s.diag(1,-1)
for name,O in [('X',X),('Z',Z)]:
 check('Hamiltonian spectator-data covariance '+name,s.kronecker_product(M,s.eye(2))*s.kronecker_product(s.eye(3),O)==s.kronecker_product(s.eye(3),O)*s.kronecker_product(M,s.eye(2)))
 check('jump spectator-data covariance '+name,s.kronecker_product(L,s.eye(2))*s.kronecker_product(s.eye(3),O)==s.kronecker_product(s.eye(3),O)*s.kronecker_product(L,s.eye(2)))
check('sqrt2 rational lower',s.Rational(7,5)**2<2)
check('survival quadratic maximum less than4',(4-2)**2>2)
t=s.symbols('t',real=True);rt=s.sqrt(2);decay=s.exp(-t/rt)
a=decay*(s.cos(t/rt)+s.sin(t/rt));b=-s.I*rt*decay*s.sin(t/rt)
check('analytic no-jump m amplitude ODE',s.simplify(s.diff(a,t)+s.I*b)==0)
check('analytic no-jump e amplitude ODE',s.simplify(s.diff(b,t)+s.I*a+rt*b)==0)
check('analytic no-jump launch',a.subs(t,0)==1 and b.subs(t,0)==0)
check('survival quadratic spectrum',s.Matrix([[1,1],[1,3]]).charpoly().as_expr().expand()==s.Symbol('lambda')**2-4*s.Symbol('lambda')+2)
window=s.Rational(1,1024);lower_time=16-window;x=s.Rational(7,5)*lower_time
taylor=sum((x**k/s.factorial(k) for k in range(21)),s.Rational(0))
check('positive exponential Taylor lower beats2^18',taylor>2**18)
bound=s.Rational(4)/taylor
check('window survival below2^-16',bound<s.Rational(1,65536))
exact={'status':'EXACT scoped constructor identities and rational conditional readout-window bound','exact_count':len(checks),'checks':checks,'vertices':4,'edges':[list(x) for x in edges],'faces':[list(x) for x in faces],'B1':[[str(v) for v in row] for row in B1.tolist()],'B2':[[str(v) for v in row] for row in B2.tolist()],'restricted_isometry':[[str(v) for v in row] for row in S.tolist()],'capacity':'7/768','occupancy_levels':'n/768, n=0..8; declared normalized finite encoding, not measured flux','scope':'Two selected edge modes only; not full six-edge transport, physical implementation or2-local compilation','logical_dimension':2,'occupancy_dimension':9,'completion_dimension':2,'clock_dimension':3,'data_spectator_dimension':4,'total_test_model_dimension':216,'window_center':'16','window_half_width':str(window),'conditional_half_diamond_upper':str(bound),'window_proof':'Fixed eligible n>=7,F=1,product clock launch m,identity-data coupling,no reverse jumps,H_store=0,g=1,Gamma=2sqrt2. No-jump survival q=e^(-sqrt2 t)[(cos(t/sqrt2)+sin(t/sqrt2))^2+2sin(t/sqrt2)^2] <=4exp(-7t/5). A positive degree20 Taylor sum at7(16-1/1024)/5 lower bounds the exponential and yields4/sum<2^-16. Clock state is rank1 surviving block plus dark population; half-diamond distance to dark-clock identity-data target equals q for arbitrary data spectators. Bath is traced. Occupancy/completion coherences across differently gated sectors are not covered.'}
(R/'results/EXACT_RECEIPT.json').write_text(json.dumps(exact,indent=2))
def generator(H,jumps):
 d=len(H);I=np.eye(d);out=-1j*(np.kron(I,H)-np.kron(H.T,I))
 for J in jumps:
  C=J.conj().T@J;out+=np.kron(J.conj(),J)-.5*(np.kron(I,C)+np.kron(C.T,I))
 return out
def evolve(H,jumps,rho,t):return (expm(generator(H,jumps)*t)@rho.reshape(-1,order='F')).reshape(rho.shape,order='F')
def td(a,b):return float(np.sum(abs(np.linalg.eigvalsh((a-b+(a-b).conj().T)/2)))/2)
def negativity(rho):
 pt=rho.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4)
 return float((np.sum(abs(np.linalg.eigvalsh(pt)))-np.trace(rho).real)/2)
bell=np.array([1,0,0,1])/np.sqrt(2);BR=np.outer(bell,bell);m=np.diag([1.,0,0]);dark=np.diag([0.,0,1.])
Gamma=2*np.sqrt(2);h=np.array(M,float);j=np.sqrt(Gamma)*np.array(L,float)
tests=[];rows=[]
for n,f,t in itertools.product([0,6,7,8],[0,1],[0.,1.,4.,16.]):
 rho=evolve(int(n>=7)*f*h,[j],m,t);p=float(rho[2,2].real)
 assert abs(np.trace(rho)-1)<1e-12 and min(np.linalg.eigvalsh(rho))>-1e-12
 if n<7 or f==0:assert abs(p)<1e-13
 captured=p*BR
 assert abs(negativity(captured)-p/2)<1e-12
 if n>=7 and f==1:assert abs(td(rho,dark)-(1-p))<1e-12
 rows.append({'n':n,'complete':f,'time':t,'capture':p,'survival':1-p,'captured_Bell_negativity':negativity(captured)})
 tests.append('sector '+str((n,f,t)))
# Bad control: saturation-only latch captures incomplete output.
bad=evolve(h,[j],m,16);assert bad[2,2].real>.999;tests.append('saturation-only incomplete-capture counterexample')
# Bad control: reservoir resolves logical basis and destroys Bell coherence.
HB=np.kron(h,np.eye(2));badj=[np.kron(j,np.diag([1,0])),np.kron(j,np.diag([0,1]))]
# Evolve clock+data+reference; reference untouched.
full=evolve(np.kron(HB,np.eye(2)),[np.kron(x,np.eye(2)) for x in badj],np.kron(m,BR),16)
captured_bad=full[8:12,8:12];assert negativity(captured_bad)<1e-12
tests.append('data-resolving bath destroys captured Bell entanglement')
numeric={'status':'SIMULATED constructor controls; not interval-certified error or hardware data','numerical_count':len(tests),'tests':tests,'precision':'binary64','identity_tolerance':1e-12,'g':1,'Gamma_diagnostic':Gamma,'rows':rows,'saturation_only_incomplete_capture':float(bad[2,2].real),'data_resolving_bath_captured_negativity':negativity(captured_bad),'good_latch_complete_channel_relation':'For fixed eligible occupancy/completion and product launch: half-diamond distance to dark-clock identity-data target equals no-jump survival q(t). Reservoir output is traced; arbitrary data spectators retained.','target':'1/65536','deadline16_survival_diagnostic':next(x['survival'] for x in rows if x['n']==7 and x['complete']==1 and x['time']==16),'physical_promotion':0}
(R/'results/NUMERICAL_RECEIPT.json').write_text(json.dumps(numeric,indent=2));print({'exact':len(checks),'numerical':len(tests),'survival16':numeric['deadline16_survival_diagnostic']})
