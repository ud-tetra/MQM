"""Freeze conditional boundary-latch evidence with scoped provenance."""
from pathlib import Path
from fractions import Fraction
import argparse,json,hashlib,zipfile,platform
import numpy,scipy,sympy,fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args();assert args.visual_review_confirmed
def read(n):return json.loads((R/n).read_text())
def write(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
e=read('results/EXACT_RECEIPT.json');n=read('results/NUMERICAL_RECEIPT.json');q=read('results/PDF_QA.json')
assert e['exact_count']==35 and n['numerical_count']==34
assert Fraction(e['conditional_half_diamond_upper'])<Fraction(1,65536)
assert q['pages']==2 and q['A4'] and q['no_overfull'] and q['no_unresolved_references']
q['visual_review']='PASSED: both final IEEE A4 pages inspected; no overlap, clipping or unreadable equations.';write('results/PDF_QA.json',q)
write('SOURCE_ANCHORS.json',{'archived_capacity_source':{'library_file_id':'libfile_b3b911a5ae588191b6ee27e9518aaf74','file_id':'file_000000009f6471f5ad7268953a4653e3','name':'Project_1_2026-05-28_233852 (1).pdf','date':'May29,2026','section':'III','status':'Historical specification, not current canon or verified physical law'},'archived_architecture_source':{'library_file_id':'libfile_b631b76e565081918bd1ac3536d16029','file_id':'file_00000000606c822fa089711318e74bb1','name':'UD Tetra Quantum architecture.pdf','status':'Proposal blueprint; material enforcement not derived in retrieved text'},'continued_native_admission_release':{'library_file_id':'libfile_36f75ed64b70819188c71aa7b87bb4da','sha256':hashlib.sha256((R.parent/'MQM_RECENTERED_ADMISSION_v0.1_RELEASE.zip').read_bytes()).hexdigest(),'native_admission':'OPEN; this conditional latch does not close that problem'},'user_direction':'Execute occupancy/boundary specification and completion/spectator controls; inherited MQM working instructionsv0.3'})
write('CLAIM_REGISTER.json',{'capacity':{'status':'SOURCE-CONFIRMED definition; physical enforcement OPEN','threshold':'7/768','finite_encoding':'n/768 for n=0..8; newly declared normalized encoding','measured_flux':False},'boundary_isometry':{'status':'EXACT / AUTO_LOCK scoped','domain':'span of oriented edge01 and edge02','codomain':'four-dimensional face register','operator':'D1 K (K^dagger D1^dagger D1 K)^(-1/2)','full_edge_isometry':False,'physical_compilation':'OPEN'},'conditional_latch':{'status':'DERIVED / EXACT rational window certificate, AUTO_LOCK scoped','g':1,'Gamma':'2sqrt2','full_Hamiltonian_norm':1,'window':'[16-1/1024,16+1/1024]','complete_half_diamond_upper':e['conditional_half_diamond_upper'],'target':'1/65536','assumptions':['Fixed eligible n>=7,F=1; product clock launchm','Trusted occupancy/completion flags; arbitrary data spectators','Identity data factors; no logical information in bath jump labels','No reverse jumps, zero storage Hamiltonian, ideal Markovian dynamics','Bath traced; cross-sector control coherences excluded'],'isolation':'Incomplete or unsaturated productm launch cannot be captured','completion_generation':'OPEN','two_local_implementation':'OPEN','thermodynamic_refresh':'OPEN'},'negative_controls':{'status':'SIMULATED','saturation_only_incomplete_capture':n['saturation_only_incomplete_capture'],'data_resolving_bath_Bell_negativity':n['data_resolving_bath_captured_negativity'],'scope':'Constructor counterexamples; not a theorem about all baths'},'exact_checks':35,'numerical_controls':34,'physical_promotion':0,'hardware_or_quantum_advantage':False,'native_joint_admission':'OPEN','independent_review':'pending','novelty_comparison':'pending'})
write('NEXT_GATE.json',{'status':'OPEN','recommended':'Generate and certify the completion flag within a fixed compiled episode before enabling latch access','strengthening_test':'False-completion fault controls, control/data coherence and small reverse thermal jumps under declared rates and storage times','bridge_gate':'Explicit autonomous/local implementation of restricted boundary isometry plus latch; include all ancillas and couplings','capacity_gate':'Define measured occupancy/backlog normalization and derive or calibrate scattering correspondence; arithmetic ratio is not physical proof','priority_score':90,'score_type':'Prioritization judgment for implementation correctness and architecture feasibility; not measured closure percentage','native_admission':'Separate gate remainsOPEN; conditional latch error cannot replace native admission certificate'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'pymupdf':fitz.VersionBind})
write('ARITHMETIC_COUNTS.json',{'threshold_denominator':'768=2^8*3','occupancy_dimension':'9=3^2','test_model_dimension':'216=2^3*3^3; includes data spectator, not physical qubit count','exact_checks':'35=5*7','numerical_controls':'34=2*17','target_denominator':'65536=2^16','window_half_width':'1/1024=2^-10','scope':'Factorization records typed resource arithmetic; no geometric or material inference.'})
(R/'README.txt').write_text('''A Capacity-Gated Boundary Latch: Conditional Coherence and Completion Contracts
Benjamin Walker Mayes | ORCID0009-0002-5813-0724 | MQM v0.1

RESULT
Finite declared occupancy encoding n/768,n=0..8,cap7/768. Completion is a
separate trusted flag. Productm launch with incomplete or unsaturated labels
cannot access the latch. Data-independent jump preserves arbitrary data and
spectators. For fixed eligible labels,g=1,Gamma=2sqrt2,no reverse jumps and
zero storage Hamiltonian, exact half-diamond error is survivalq(t).
A positive rational Taylor lower enclosure provesq<1/65536 throughout
[16-1/1024,16+1/1024]. Bath output is traced. This is a conditional ideal
constructor certificate, not the native joint-admission solution.

Restricted polar-normalized coboundary map is an exact two-mode isometry;
raw coboundary is not a full six-edge isometry. Standard D1D0=0 remains intact.
No autonomous/local implementation of this transfer is supplied.
Negative controls: saturation alone captures incomplete work; data-resolving
jump labels destroy captured Bell entanglement.35 exact checks,34 numerical
controls. No physical promotion, thermal refresh, fault tolerance or advantage.
Independent review/novelty pending. Historical source claims are not canon.

REPLAY
  python3 verify_latch.py
Uses sympy exact matrices,algebraic ODE identities and rational exponential
Taylor comparison. Binary64 Lindblad controls use tolerance1e-12 and are
not the window proof. No random seeds or shots; no device observations.
Time16 is an engineering deadline; this is not an independent prediction.

PDF
  python3 build_pdf.py
Requires pdflatex,IEEEtran,balance,PyMuPDF. Inspect both PAGE_*.png then:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two columns. Class license included.
NEXT_GATE.json records completion generation,coherent control and reverse-jump
tests. Source evidence levels and failed-control outcomes remain separated.
SHA256SUMS.txt covers distributed files. Earlier releases remain immutable.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'exact_checks':35,'numerical_controls':34,'files':len(files)+1}))
