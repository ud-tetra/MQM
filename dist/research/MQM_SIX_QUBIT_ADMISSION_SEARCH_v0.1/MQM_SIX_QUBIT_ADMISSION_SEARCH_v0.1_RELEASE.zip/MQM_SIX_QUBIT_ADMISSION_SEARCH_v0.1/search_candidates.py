"""Bounded exploratory real two-local fit. Numerical search is not a proof."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,time
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import least_squares
import networkx as nx
R=Path(__file__).resolve().parent;(R/'results').mkdir(exist_ok=True)
I=np.eye(2);X=np.array([[0,1],[1,0]]);Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1])
ops=dict(I=I,X=X,Y=Y,Z=Z)
def pauli(label):
    m=np.array([[1.]])
    for c in label:m=np.kron(m,ops[c])
    return m.real
pairs=[(0,2),(0,4),(0,5),(1,2),(1,3),(1,4),(1,5),(2,4),(2,3),(4,5)]
labels=[]
for q in range(6):
    for p in 'XZ':
        l=['I']*6;l[q]=p;labels.append(''.join(l))
for x,y in pairs:
    for p,q in [('X','X'),('Y','Y'),('Z','Z'),('X','Z'),('Z','X')]:
        l=['I']*6;l[x]=p;l[y]=q;labels.append(''.join(l))
P=np.array([pauli(l) for l in labels])
E=np.zeros((64,4));W=np.zeros((64,4))
for a in range(4):E[16*a+8,a]=1;W[1<<(3-a),a]=1
G=nx.Graph(pairs);assert nx.check_planarity(G)[0]
np.savez(R/'results/SEARCH_BASIS.npz',P=P,E=E,W=W)
cache={}
def evaluate(x):
    if 'x' in cache and np.array_equal(cache['x'],x):return cache['r'],cache['j']
    H=np.einsum('k,kij->ij',x[:-1],P)
    val,V=eigh(H,check_finite=False)
    phase=np.exp(-1j*val);target=np.exp(1j*x[-1])*W
    VE=V.T@E;UE=V@(phase[:,None]*VE);err=UE-target
    derivative=-1j*np.exp(-1j*(val[:,None]+val[None,:])/2)*np.sinc((val[:,None]-val[None,:])/(2*np.pi))
    B=np.einsum('ia,kij,jb->kab',V,P,V,optimize=True)
    dU=np.einsum('ia,kab,bj->kij',V,B*derivative[None,:,:],VE,optimize=True)
    derivatives=np.concatenate([dU,(-1j*target)[None,:,:]],axis=0).reshape(len(x),-1).T
    residual=np.concatenate([err.real.ravel(),err.imag.ravel()])
    jac=np.concatenate([derivatives.real,derivatives.imag],axis=0)
    cache.update(x=x.copy(),r=residual,j=jac)
    return residual,jac
rng=np.random.default_rng(20261005);runs=[];best=None
probe=np.r_[rng.normal(0,.2,len(P)),.3]
analytical=evaluate(probe)[1];gradient_error=0.
for column in [0,10,31,61,62]:
    h=np.zeros(len(probe));h[column]=1e-6
    finite=(evaluate(probe+h)[0]-evaluate(probe-h)[0])/(2e-6)
    gradient_error=max(gradient_error,float(np.max(abs(finite-analytical[:,column]))))
assert gradient_error<1e-7,gradient_error
rng=np.random.default_rng(20261005)
for run in range(4):
    x0=np.r_[rng.normal(0,.6 if run<2 else 1.5,len(P)),0.]
    if run==0:
        x0[:]=0
        # Two prior one-qubit primitives sharing seed u, leaving z initially uncoupled.
        for native,target in [(0,4),(1,3)]:
            terms=[({native:'Z'},-1),({target:'Z'},-1),({2:'X'},1),
               ({2:'X',native:'Z'},-.5),({2:'X',target:'Z'},-.5),
               ({native:'X',target:'X'},.5),({native:'Y',target:'Y'},.5)]
            for term,v in terms:
                label=''.join(term.get(k,'I') for k in range(6))
                x0[labels.index(label)]+=v*np.pi/2
        x0+=rng.normal(0,.04,len(x0))
    started=time.monotonic()
    result=least_squares(lambda x:evaluate(x)[0],x0,jac=lambda x:evaluate(x)[1],
        bounds=(-4*np.pi,4*np.pi),max_nfev=1000,ftol=1e-10,xtol=1e-10,gtol=1e-10)
    H=np.einsum('k,kij->ij',result.x[:-1],P);vals,V=eigh(H)
    UE=V@(np.exp(-1j*vals)[:,None]*(V.T@E))
    phi=np.angle(np.trace(W.T@UE));err=UE-np.exp(1j*phi)*W
    rec=dict(run=run,nfev=result.nfev,status=int(result.status),cost=float(result.cost),
      seconds=time.monotonic()-started,phase=float(phi),isometry_operator_error=float(np.linalg.norm(err,2)),
      basis_trace_errors=[float(np.sqrt(max(0,1-abs(W[:,a]@UE[:,a])**2))) for a in range(4)],
      spectral_center=float((vals[-1]+vals[0])/2),centered_norm=float((vals[-1]-vals[0])/2))
    runs.append(rec)
    if best is None or rec['isometry_operator_error']<best['isometry_operator_error']:
        best=rec.copy();best['coefficients']={l:float(c) for l,c in zip(labels,result.x[:-1])}
    receipt=dict(status='NUMERICAL EXPLORATION ONLY; no all-family impossibility or exact certificate',
       ansatz='62 real Pauli parameters on fixed planar 10-pair graph, plus one global target phase',
       order=['A','O','m00','m01','m10','m11'],pair_graph=pairs,graph_planar=True,maximum_degree=4,
       seed=20261005,starts=4,max_nfev_per_start=1000,coordinate_box='[-4*pi,4*pi]',
       gradient_finite_difference_error=gradient_error,runs=runs,best=best)
    (R/'results/SEARCH_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(rec),flush=True)
