"""Freeze a replayable, explicitly scoped IEEE A4 research release."""
from pathlib import Path
import hashlib,json,zipfile,platform,argparse
import numpy,scipy,sympy,fitz
R=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--visual-review-confirmed',action='store_true',help='Confirm that every current rendered PDF page was inspected.')
args=parser.parse_args()
def write(name,obj):
    (R/name).write_text(json.dumps(obj,indent=2)+'\n')
exact=json.loads((R/'results/EXACT_RECEIPT.json').read_text())
qa=json.loads((R/'results/PDF_QA.json').read_text())
assert qa['pages']==3 and qa['no_overfull'] and qa['no_unresolved_references']
assert args.visual_review_confirmed,'Inspect all current page renders, then pass --visual-review-confirmed.'
qa['visual_review']='passed: all three rendered pages inspected; readable two-column text and equations; no clipping or overlap'
write('results/PDF_QA.json',qa)
write('INPUT_ANCHORS.json',{
 'author':'Benjamin Walker Mayes','orcid':'0009-0002-5813-0724',
 'source_boundary':'Parent admission PDF read from its current authoritative file; user supplied summaries identify the joint interface. No new source ZIP was supplied in this turn.',
 'parent_admission_pdf_library_id':'libfile_96a060a1ba2c8191a3deab15f740b45d',
 'parent_admission_zip_sha256':'2905086270c065ebc29bd4f37e889659d9b74daa90a885295846a1c7053b7338',
 'parent_encoded_swap_zip_sha256':'c9d720cb497519ba268ab9be2c67c56b7a54be35bb00d6d6b341ca0b3ed56335',
 'release_policy':'Separate addendum; preceding releases not modified.',
 'primary_prior_art_checked':['https://arxiv.org/abs/1803.07119','https://arxiv.org/pdf/1803.07119','https://journals.aps.org/pra/abstract/10.1103/PhysRevA.74.030303'],
 'priority_status':'Partial comparison only; theorem-level novelty and independent review pending.'})
write('CLAIM_REGISTER.json',{
 'status':'Scoped mathematical results; independent review pending; physical evidence promotion 0',
 'optimal_single_native_admission':{'state':'EXACT, SCOPED','theorem':3,'generator':'Hstar_g = K_g - 2*g*N_A*N_v - 2*g*I; g=1/2',
  'same_contract_as_parent':True,'deadline':'pi','previous_deadline':'3*pi/2','full_norm':1,'spectrum':[-1,0,1],
  'optimality_scope':'Static Hermitian two-local generator, specified native computational-basis seed contract, full centered operator norm <= 1.',
  'physical_qubits':3,'interaction_pairs':3,'maximum_degree':2,'planar':True,
  'maximum_Pauli_coefficient':'1/2 versus 1/3 in parent','maximum_two_body_Pauli_coefficient':'1/4 versus 1/6 in parent',
  'fixed_per_coupling_speed_improvement':False,'coefficient_rounding_debit':0,
  'uniform_spectator_channel_window':'|t-pi| <= 2^-18 gives half-diamond error <= 2^-18 under ideal preparation and implementation'},
 'joint_charge_family':{'state':'EXACT EXCLUSION','theorem':1,'scope':'Exactly six qubits, two-local Hermitian, commutes with both QA and QO',
  'dimension':38,'conclusion':'Every member conserves N_m11; input 11 remains orthogonal to target for all times.',
  'universal_two_local_impossibility':False},
 'deadline':{'state':'EXACT NECESSARY BOUND','theorem':2,'exact':'T>=pi','error_2_minus_16':'T>=pi-1/21845',
  'scope':'Static Hermitian two-local on stated source/target, full centered norm<=1; complex couplings allowed.',
  'joint_six_qubit_attainment':'OPEN'},
 'odd_parity_comparator':{'state':'EXACT DIFFERENT CONTRACT','physical_qubits':5,'pairs':6,'planar':True,
  'maximum_degree':4,'deadline':'2*pi','full_norm':1,'width':2,'outputs':['100','010','001','111'],
  'required_single_excitation_interface':False,'coupling_rounding_debit':0},
 'numerical_search':{'state':'FINITE EXPLORATION, NO ENCODER','runs':4,'parameters':62,'planar_pairs':10,
  'best_frozen_fit_all_time_error_floor':exact['frozen_search_candidate']['all_time_error_floor'],
  'all_fits_or_all_hamiltonians_excluded':False},
 'moment_filter':{'state':'EXACT NECESSARY FILTER','planar_real_rank':7,'kernel_dimension':55,
  'sufficiency':False,'constrained_optimization_run':False},
 'verification':{'exact_checks':exact['exact_count'],'numerical_propagation_checks':exact['numerical_count'],
  'optimization_runs_reported_separately':4,'physical_promotion':0},
 'six_qubit_single_excitation_admission':'OPEN',
 'complete_autonomous_episode':'OPEN','irreversible_latch':'OPEN','thermodynamic_refresh':'OPEN'})
write('COMPARISON_CONTRACT.json',{
 'same_operational_task':'Unknown one-native-qubit admission from seed |10> to two modes, with arbitrary spectators.',
 'common_budget':'Full physical centered operator norm <=1; three qubits, same three interaction pairs, planar degree two.',
 'parent':{'deadline':'3*pi/2','g':'1/3','full_spectrum':[-1,'-1/3','1/3',1]},
 'improved':{'deadline':'pi','g':'1/2','full_spectrum':[-1,0,1]},
 'gain':'Deadline ratio 2/3; one-third reduction; exact lower bound attained for stated static contract.',
 'charged_tradeoff':'Higher per-term coefficients. At fixed g=1/3 the norm reduces from one to 2/3 but the endpoint deadline stays 3*pi/2.',
 'alternative_not_matched':'Five-qubit odd-parity admission changes the carrier and cannot directly feed the sixteen-mode single-excitation SWAP core.',
 'hardware_and_external_control_comparison':'Not established; model time has no calibrated physical units.'})
write('WBS_NEXT.json',{
 'closed_scoped':['Optimal isolated single-native admission at pi under full-norm budget','Charge-preserving six-qubit family excluded','Static direct-coupling lower bound','Frozen numerical fit excluded at every time'],
 'next_target':'The original six-qubit four-mode single-excitation all-input isometry.',
 'next_search':['Use exact 55-dimensional first-moment kernel from MOMENT_FILTER.json.','Add higher spectral moment admission checks before expm optimization.','Permit charge breaking; broaden complex Pauli couplings if needed while explicitly specifying a planar graph.','Normalize full spectrum and audit coefficients, degree, input seed, common endpoint phase, arbitrary spectators, and deadline window.'],
 'promotion_gate':'Explicit Hermitian two-local physical generator; exact or enclosed all-input isometry with common phase; full-register spectrum/norm and planar graph; complete-domain deadline error <= 2^-16; independent replay.',
 'deferred':['Mode-to-core extraction','Thirteen-step static concatenation','Irreversible retention','Reservoir thermodynamics and clock refresh','Hardware realization'],
 'negative_result_policy':'A failed finite fit is not a global impossibility proof.'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'pymupdf':fitz.VersionBind})
(R/'README.txt').write_text('''Optimal Static Native-Qubit Admission and Limits of Joint-Mode Encoding
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM development note v0.1

Main result: the existing planar three-qubit admission triangle reaches the same
endpoint at pi instead of 3*pi/2 under a full centered norm-one budget. A scoped
static two-local lower bound proves this one-qubit deadline optimal. The change
adds a diagonal density interaction on an existing pair and raises individual
coefficients; it is not a speed gain at a fixed per-coupling ceiling.

The requested six-qubit joint single-excitation encoder remains OPEN. A natural
charge-preserving family is excluded exactly. Four finite planar real searches
do not find an encoder. The best frozen candidate is excluded at all times by
an exact energy-moment witness. A five-qubit odd-parity endpoint encoder at 2*pi
is a separate carrier, not a replacement for the single-excitation interface.

Status: scoped derivation and constructor replay, not independent peer review.
Theorem-level novelty comparison remains pending. Physical evidence promotion 0.
Time is model time, hbar=1. No thermodynamic refresh or permanent hold is claimed.

Contents and replay (run from this extracted directory):
  python3 certify_constraints.py
    Replays 78 exact checks and 4 numerical propagation checks using frozen fit.
  python3 search_candidates.py
    OPTIONAL EXPENSIVE exploration: reruns four seeded fits and overwrites its
    numerical receipt/basis. No global convergence guarantee. Re-run certification
    afterward; a new optimizer/library version may produce different fits.
  python3 build_ieee_note.py
    Builds actual IEEEtran A4 10pt two-column PDF (three pdflatex passes), verifies
    page dimensions, overflow and references, and renders pages for visual QA.
    Requires pdflatex, numpy, scipy, sympy, and PyMuPDF. Bundled IEEEtran and LPPL.
    Build resets visual_review to pending; inspect rendered pages before release.
  python3 prepare_release.py --visual-review-confirmed
    Release preparation after explicit page inspection; freezes metadata/hashes.

Primary deliverable: manuscript/MQM_SIX_QUBIT_ADMISSION_IEEE_A4_v0.1.pdf
Exact algebra and rational receipts: results/EXACT_RECEIPT.json
Finite search diagnostics: results/SEARCH_RECEIPT.json and SEARCH_BASIS.npz
Next-search necessary kernel: MOMENT_FILTER.json (55-dimensional, not sufficient).
Claim scope, matched comparison and next gates are separate JSON records.
Publication policy: all future paper builds actual IEEEtran A4 two columns.
Parent releases are source anchors and have not been modified.
''')
exclusions={'.aux','.log','.out'}
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in exclusions and '__pycache__' not in p.parts and p.name!='SHA256SUMS.txt')
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'exact':exact['exact_count'],'numerical':exact['numerical_count'],'pdf_pages':qa['pages']}))
