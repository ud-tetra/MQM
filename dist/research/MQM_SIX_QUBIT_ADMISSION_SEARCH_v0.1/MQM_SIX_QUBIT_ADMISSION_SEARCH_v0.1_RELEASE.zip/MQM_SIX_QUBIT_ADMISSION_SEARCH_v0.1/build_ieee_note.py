"""Actual IEEEtran A4 development note; all pages rendered for inspection."""
from pathlib import Path
import json,shutil,subprocess
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript';M.mkdir(exist_ok=True)
parent=R.parent/'MQM_AUTONOMOUS_NATIVE_ADMISSION_v0.1'
for f in ['IEEEtran.cls','LPPL-1.3c.txt']:
    source=parent/'manuscript'/f
    if source.exists():shutil.copy2(source,M/f)
    else:assert (M/f).exists(),f'Missing bundled {f}'
policy=parent/'PUBLICATION_FORMAT_POLICY_v1.0.json'
if policy.exists():shutil.copy2(policy,R/'PUBLICATION_FORMAT_POLICY_v1.0.json')
else:assert (R/'PUBLICATION_FORMAT_POLICY_v1.0.json').exists()
c=json.loads((R/'results/EXACT_RECEIPT.json').read_text());search=json.loads((R/'results/SEARCH_RECEIPT.json').read_text())
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\begin{document}
\title{Optimal Static Native-Qubit Admission\\and Limits of Joint-Mode Encoding}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 5, 2026. ORCID: 0009-0002-5813-0724. Scoped exact results and finite numerical search. Independent review and theorem-level novelty comparison pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We improve a previously certified static native-qubit encoder by correcting the spectrum on an unused excitation sector. With the same three qubits and interaction pairs, it reaches the same endpoint at $\pi$ instead of $3\pi/2$ under a matched full centered norm-one budget. A forbidden direct-coupling bound proves this deadline optimal for the stated native input and seed. We then examine two-native-qubit admission into four single-excitation modes. An exact charge argument excludes its natural jointly charge-conserving six-qubit family. Any static two-local solution with full centered norm at most one requires time at least $\pi$ for exact admission, or $\pi-1/21845$ at complete-state error $2^{-16}$. Four seeded planar numerical fits do not supply an encoder; exact rational interpretation of the best frozen fit gives an all-time error floor exceeding $0.018$. A separate five-qubit odd-parity encoder reaches its different endpoint at $2\pi$. An exact first-moment filter supplies a smaller necessary search space for the unclosed single-excitation interface.
\end{abstract}
\begin{IEEEkeywords}
Autonomous quantum control, two-local Hamiltonian, coherent admission, state transfer, spectral moment, quantum carrier.
\end{IEEEkeywords}

\section{Operational target and source boundary}
The preceding MQM primitive encodes one native qubit into two modes using a static planar triangle \cite{parent}. Two independent copies produce two mode excitations and do not admit a two-qubit body into the one-excitation joint carrier used by the 16-mode SWAP core. The target considered here is
\begin{equation}\label{eq:target}
E\ket{ab}=\ket{ab}_{AO}\ket{\mathbf1_{00}}_M
\longmapsto e^{i\phi}W\ket{ab}
=e^{i\phi}\ket{00}_{AO}\ket{\mathbf1_{ab}}_M,
\end{equation}
where $M=(u,v,w,z)=(m_{00},m_{01},m_{10},m_{11})$. Inputs are arbitrary, including entanglement with spectators; the common phase cannot depend on $ab$. The six-qubit register is fully retained. We require an explicit two-local Hermitian generator, planar physical support graph, full physical norm budget, and a finite deadline window. No successful generator for this exact contract is claimed in this note.

Static gate synthesis already has spectral and numerical frameworks \cite{innocenti}. Transfer speed limits also have substantial prior art \cite{yung}. We derive the present scoped conditions directly rather than infer novelty from a numerical search. The norm budget concerns the full register and an explicitly chosen energy origin, not only an admitted subspace. Time is uncalibrated model time with $\hbar=1$.

\section{The natural charge-preserving family is excluded}
Define the bookkeeping charges
\begin{equation}
Q_A=N_A+N_w+N_z,\qquad Q_O=N_O+N_v+N_z.
\end{equation}
They equal the two native bits at both endpoints of (\ref{eq:target}). They are candidate conserved quantities, not axioms of MQM or physical-energy assertions.

\begin{theorem}[Six-qubit charge obstruction]
Every Hermitian two-local qubit Hamiltonian on $(A,O,u,v,w,z)$ satisfying $[H,Q_A]=[H,Q_O]=0$ also satisfies $[H,N_z]=0$. Consequently input $11$ has complete trace error one relative to its required output for every time, regardless of coupling magnitudes or geometry.
\end{theorem}
\begin{proof}
The per-qubit charge vectors are $(1,0)$ for $A,w$, $(0,1)$ for $O,v$, $(0,0)$ for $u$, and $(1,1)$ for $z$. A nonzero computational-basis matrix element must preserve both total charges. A two-local term changes at most two bit occupations. Flipping $z$ changes both charges by the same sign; no single other qubit has a matching vector to cancel that change. Thus no charge-preserving two-local matrix element can change $z$, even after cancellation between Pauli terms. Initially $N_z=0$; the target for input $11$ has $N_z=1$. Their supports remain orthogonal.
\end{proof}
The replay also exhausts the complete 154-dimensional Hermitian Pauli space of support weight at most two, including imaginary matrix entries. An integer commutator Gram matrix has a 38-dimensional charge-preserving kernel. All 38 exact kernel vectors commute with $N_z$. This is a family exclusion, not a universal impossibility theorem for two-local admission. Breaking at least one stated charge, changing the carrier, admitting higher-body support, or adding counted resources changes the premises.

\section{A deadline bound without conserved-charge assumptions}
For nonzero native inputs, source and target bit strings in (\ref{eq:target}) differ in three occupations ($01,10$) or four ($11$). Thus every two-local generator has zero direct source--target matrix element. The following lemma applies to arbitrary Hermitian matrices, including complex ones.

\begin{theorem}[Forbidden direct-coupling deadline]
Let normalized states $e,f$ obey $\langle e,f\rangle=0$ and $\langle e,Hf\rangle=0$, and let $\|H\|\le1$. If the pure-state trace distance from $e^{-itH}e$ to $f$ is at most $0\le\epsilon<1$, then
\begin{equation}\label{eq:bound}
t\ge L(\epsilon):=\pi-2\arctan\!\left(
\frac{r_\epsilon}{1-\epsilon}\right),
\end{equation}
where $r_\epsilon=\sqrt{2-2\sqrt{1-\epsilon^2}}$. In particular, exact transfer requires $t\ge\pi$.
\end{theorem}
\begin{proof}
For $t\ge\pi$ the bound is immediate. Assume $0<t<\pi$ and write $a=e^{-itH}e$. Choose a phase $\zeta$ with $\|a-\zeta f\|\le r_\epsilon$. Orthogonality gives $|\langle e,a\rangle|\le\epsilon$, and the zero direct matrix element gives
\begin{equation}
|\langle e,Ha\rangle|\le \|He\|r_\epsilon\le r_\epsilon.
\end{equation}
For $\lambda\in[-1,1]$, scalar monotonicity yields
\begin{equation}
\lambda\sin(t\lambda)\ge
\cot(t/2)\,[1-\cos(t\lambda)].
\end{equation}
Indeed $y\cot(ty/2)$ decreases for $0<y\le1$; its derivative sign follows from $x-\sin x\cos x\ge0$, whose derivative is $2\sin^2x$. By spectral calculus,
\begin{align}
r_\epsilon &\ge \langle e,H\sin(tH)e\rangle\nonumber\\
&\ge\cot(t/2)[1-\operatorname{Re}\langle e,a\rangle]
\ge(1-\epsilon)\cot(t/2).
\end{align}
Rearranging gives (\ref{eq:bound}). At $\epsilon=0$, the positive spectral function would force $He=0$ for $t<\pi$, contradicting orthogonal transfer.
\end{proof}
An arbitrary energy shift leaves both zero matrix elements and the channel unchanged. Hence the result applies whenever $\|H-xI\|\le1$ for a declared origin $x$. It uses neither graph planarity nor the charges of Section II.

The full admission half-diamond error dominates its trace error on input $11$. Consequently any static two-local solution to (\ref{eq:target}) obeys the same lower bound. At $\epsilon=2^{-16}$, $r_\epsilon\le\sqrt2\epsilon<3\epsilon/2$ and $\arctan y\le y$ give the exact conservative form
\begin{equation}
T\ge\pi-\frac{3\epsilon}{1-\epsilon}
=\pi-\frac1{21845},\qquad21845=5\cdot17\cdot257.
\end{equation}
This is a necessary bound, not a achieved six-qubit optimum. The scalar lemma's exact $\pi$ limit is sharp: a three-level path with edge weights $1/\sqrt2$ has norm one, no direct endpoint coupling, and transfers endpoints at $\pi$. Its sharpness does not establish saturation of the complete four-input admission contract. The proof assumes a single time-independent generator; it does not certify time-dependent schedules or dissipative models.

\section{A matched optimal improvement of one-qubit admission}
The deadline bound applies to the preceding one-qubit task as well: its source $\ket{110}_{Auv}$ and target $\ket{001}_{Auv}$ differ on three qubits. No two-local generator has a direct matrix element between them. Thus exact static admission under the full centered norm-one budget cannot finish before $\pi$.

Retain the parent interaction triangle \cite{parent}. With $S=N_A+N_v$, its uncentered generator is $K_g=gX_uS+(g/2)(X_AX_v+Y_AY_v)+2gS$. Add a diagonal correction on an existing pair:
\begin{equation}
H_g^\star=K_g-2gN_AN_v-2gI.
\end{equation}
The added density term vanishes throughout the admitted $N_A+N_v\le1$ sectors. Their uncentered evolution is unchanged. It shifts the unused double-occupation sector down by $2g$, reducing the full spectral width from $6g$ to $4g$ without adding qubits or pairs.

\begin{theorem}[Optimal isolated native-qubit admission]
At $g=1/2$, $H_g^\star$ is a planar three-qubit two-local generator with full norm one and spectrum $(-1,0,1)$ of multiplicities $(4,2,2)$. At $T=\pi$,
\begin{equation}
e^{-i\pi H_g^\star}\ket\psi_A\ket{10}_{uv}
=-\ket0_A(\alpha\ket{10}+\beta\ket{01})_{uv}.
\end{equation}
The same duration decodes. The deadline is optimal among static Hermitian two-local generators for this specified input/seed contract with full centered norm at most one.
\end{theorem}
\begin{proof}
In the admitted zero-charge sector the centered generator is $-2gI$. In its one-charge sector it is $g(X_u+X_{Av})$. At $gT=\pi/2$, both cases produce the stated common minus sign. The double-charge sector is $2gX_u$, also bounded by $2g$. The full characteristic polynomial of $H_g^\star/g$ is $(z+2)^4z^2(z-2)^2$, proving the claimed spectrum. The earlier deadline theorem supplies $T\ge\pi$, and this construction attains it. The same isometry argument includes arbitrary spectators.
\end{proof}
All Pauli coefficients at $g=1/2$ are dyadic, so exact binary64 coefficient implementation introduces no rounding debit. The readout interval $|t-\pi|\le2^{-18}$ has complete error at most $2^{-18}<2^{-16}$ under ideal admission and implementation. Recurrence and readout timing remain; no permanent latch is supplied.

The latency ratio is exactly $\pi/(3\pi/2)=2/3$, a reduction by one third under the matched global norm budget. The graph stays three vertices, three pairs, degree two; the Pauli count increases from eight to nine. The largest Pauli coefficient increases from $1/3$ to $1/2$ (largest two-body coefficient from $1/6$ to $1/4$). At fixed underlying $g=1/3$, the correction instead lowers full norm from one to $2/3$ with the original deadline unchanged. Therefore this is not a speed improvement under a separately fixed per-term ceiling. It is a model-level resource certificate, with independent novelty comparison and physical realization pending.

\section{Spectral moments and a finite planar search}
If $e^{-iTH}E=e^{i\phi}W$, then for every nonnegative integer $k$,
\begin{equation}\label{eq:moment}
E^\dagger H^kE=W^\dagger H^kW.
\end{equation}
This follows because the propagator commutes with $H$. The first moment is a linear constraint on Pauli coefficients. Its exact rank is 15 in the full 154-dimensional two-local space, leaving dimension 139. Higher moments and eigenphase alignment remain necessary; first-moment matching is not sufficient.

Our exploratory fit uses 62 real Pauli coefficients: X and Z fields and XX, YY, ZZ, XZ, ZX on a fixed planar ten-pair graph. In order $(A,O,u,v,w,z)$ its pairs are
\begin{equation}
\{Au,Aw,Az,Ou,Ov,Ow,Oz,uw,uv,wz\}.
\end{equation}
Its maximum degree is four. This ansatz permits charge breaking but omits other allowed complex couplings. We minimize the full four-column isometry residual with one common target phase. Four starts use seed 20261005, coefficient coordinates in $[-4\pi,4\pi]$, and a cap of 1000 function evaluations per start. An analytic exponential derivative is checked against finite differences. The coordinate box is not a physical norm budget; fitted generators are normalized separately.

\begin{table}[t]\centering
\caption{Finite numerical search diagnostics; no exact encoder}
\begin{tabular}{rrr}\hline
Start & Evaluations & Isometry norm residual\\\hline
ROWS
\hline\end{tabular}
\end{table}
The best fitted endpoint residual is BESTERROR. These local fits do not exhaust the parameter box, all planar graphs, or all two-local generators. Three stopped under the loss tolerance; one reached the evaluation cap. None certifies the requested $2^{-16}$ target.

\subsection{Exact all-time rejection of the frozen best fit}
We interpret its binary64 coefficients $c_P$ as exact binary rationals and set $B=\sum_P|c_P|$, so $\|H\|\le B$. For input $11$, let $\Delta=\langle e,He\rangle-\langle f,Hf\rangle$. Static evolution conserves the first expectation. Trace duality therefore gives, for every time,
\begin{equation}
D(e^{-itH}e,f)\ge\frac{|\Delta|}{2B}>
\frac{18}{1000}>2^{-16}.
\end{equation}
The exact fraction is in the receipt; its decimal value is ERRORFLOOR. This rejects that one frozen generator at all deadlines, including after uniform norm rescaling. It is not a lower bound for other coefficients in the search ansatz.

For the next attempt we supply an exact kernel of the first-moment constraints inside the same 62-parameter ansatz. Its rank is seven, leaving a 55-dimensional parametrization. This prevents the next fit from spending effort on generators already excluded by first moments, while leaving higher moments and endpoint phases to be solved.

\section{An exact alternative carrier, not the requested encoder}
Changing the output carrier avoids the charge confluence. Use five qubits $(A,O,u,v,w)$, define $S_A=N_A+N_w$, $S_O=N_O+N_v$, and set
\begin{align}
\widetilde H_g={}&gX_u(S_A+S_O)+2g(S_A+S_O)\nonumber\\
&+\frac g2(X_AX_w+Y_AY_w+X_OX_v+Y_OY_v)\nonumber\\
&-2g(N_AN_w+N_ON_v)-4gI.
\end{align}
The two native transport pairs and the shared seed terms commute as grouped operators. Its physical graph is two triangles sharing $u$: five qubits, six pairs, maximum degree four, planar. All terms are at most two-local.

\begin{proposition}[Odd-parity endpoint admission]
At $g=1/4$ this full-register generator has norm one and width two. At $T=2\pi$ it maps
\begin{equation}
\ket{ab}_{AO}\ket{100}_{uvw}
\longmapsto\ket{00}_{AO}
\ket{1\mathbin\oplus a\mathbin\oplus b,\ b,\ a}_{uvw}.
\end{equation}
The same duration decodes, uniformly over spectators.
\end{proposition}
\begin{proof}
For admitted source bits, $S_A=a,S_O=b$ and the density correction vanishes. At $gT=\pi/2$, transport moves the native occupations into $w,v$, while the seed flips by the parity of $a+b$. The $2g(S_A+S_O)$ phases cancel the transport and seed phases, and the origin shift supplies phase one. Thus the output mode words are $100,010,001,111$. Direct full characteristic-polynomial verification gives eigenvalues of $\widetilde H_g/g$ equal to
\begin{equation}
(-4,-2,0,2,4)
\end{equation}
with multiplicities $(10,8,6,4,4)$. Their full norm and width at $g=1/4$ are one and two. All endpoint eigenphases are $\pm1$, giving a full return at $2T$ and the same-generator decoder.
\end{proof}
All Pauli coefficients at $g=1/4$ are dyadic. The nominal window $|t-2\pi|\le2^{-18}$ has complete error at most $2^{-18}<2^{-16}$ under ideal admission and implementation.

This odd-parity carrier has one or three excitations at the endpoint. Its parity is not asserted invariant during admission. It cannot be connected directly to the existing single-excitation SWAP core, and no static admission--execution--extraction episode is established. A comparison with that core must include the conversion and any new computation encoding. Bare-energy realization, coherent supply, irreversible retention, and clock refresh remain open.

\section{Verification and next gate}
The replay records EXACTCOUNT exact checks and NUMCOUNT numerical propagation diagnostics, separately from the four exploratory fits. Exact checks cover the entire two-local charge kernel, support-weight zero couplings, scalar proof identities, sharpness example, full parity spectrum, spectator isometry, rounding, moment-filter kernel, and frozen energy witness. Independent review and theorem-level novelty comparison are pending.

The next target remains the six-qubit single-excitation map (\ref{eq:target}). Use the exact moment filter, test higher moments and coherent endpoint phases, and broaden the physical ansatz only with its graph and norm ledger explicit. A failed numerical fit is not an impossibility result. The five-qubit alternative is a separate exact comparator, not a promotion of the six-qubit contract or a demonstrated computational advantage.

\begin{thebibliography}{3}
\bibitem{parent} B. W. Mayes, ``Exact static admission of a native qubit into two quantum modes,'' MQM development addendum v0.1, Oct. 5, 2026, unpublished. Source release digest in INPUT\_ANCHORS.json.
\bibitem{innocenti} L. Innocenti, L. Banchi, A. Ferraro, S. Bose, and M. Paternostro, ``Supervised learning of time-independent Hamiltonians for gate design,'' arXiv:1803.07119, 2018, doi: 10.1088/1367-2630/ab8aaf.
\bibitem{yung} M.-H. Yung, ``Quantum speed limit for perfect state transfer in one dimension,'' \emph{Phys. Rev. A}, vol. 74, 030303(R), 2006, doi: 10.1103/PhysRevA.74.030303.
\end{thebibliography}
\end{document}
'''
tex=tex.replace('ROWS','\n'.join(f"{row['run']} & {row['nfev']} & {row['isometry_operator_error']:.6f}\\\\" for row in search['runs']))
tex=tex.replace('BESTERROR',f"{search['best']['isometry_operator_error']:.6f}").replace('ERRORFLOOR',f"{c['frozen_search_candidate']['all_time_error_floor_float']:.9f}")
tex=tex.replace('EXACTCOUNT',str(c['exact_count'])).replace('NUMCOUNT',str(c['numerical_count']))
tex=tex.replace('not a achieved','not an achieved')
name='MQM_SIX_QUBIT_ADMISSION_IEEE_A4_v0.1';(M/(name+'.tex')).write_text(tex)
for k in range(3):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,text=True,capture_output=True)
    (R/'results'/f'PDF_BUILD_{k+1}.txt').write_text(p.stdout+p.stderr)
    assert p.returncode==0,p.stdout[-2500:]
log=(M/(name+'.log')).read_text();assert 'Overfull' not in log
doc=fitz.open(M/(name+'.pdf'));sizes=[]
for k,page in enumerate(doc):
    sizes.append([page.rect.width,page.rect.height]);assert abs(page.rect.width-595.276)<.05 and abs(page.rect.height-841.89)<.05
    page.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/f'PAGE_{k+1}.png')
assert '??' not in '\n'.join(page.get_text() for page in doc)
(R/'results/PDF_QA.json').write_text(json.dumps(dict(pages=len(doc),sizes_points=sizes,format='actual IEEEtran v1.8b journal,a4paper,10pt, two columns',
    no_overfull=True,no_unresolved_references=True,visual_review='pending'),indent=2)+'\n')
print(json.dumps(dict(pdf=str(M/(name+'.pdf')),pages=len(doc))))
