"""Exact family exclusion, locality assumptions, parity comparator, and frozen fit audit."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
import json,math
import sympy as s
import numpy as np
from scipy.linalg import expm
R=Path(__file__).resolve().parent;(R/'results').mkdir(exist_ok=True)
checks=[];numeric=[]
def check(n,p):
    assert bool(p),n
    checks.append(n)
def ncheck(n,x,tol=2e-11):
    assert x<tol,(n,x)
    numeric.append(dict(label=n,residual=float(x),ceiling=tol))
labels=['I'*6]
for q in range(6):
    for p in 'XYZ':
        a=['I']*6;a[q]=p;labels.append(''.join(a))
for q,r in combinations(range(6),2):
    for p,t in product('XYZ',repeat=2):
        a=['I']*6;a[q]=p;a[r]=t;labels.append(''.join(a))
check('complete Hermitian two-local Pauli space dimension 154',len(labels)==154)
QA=[1,0,0,0,1,1];QB=[0,1,0,1,0,1];NZ=[0,0,0,0,0,1]
def comm(label,charge):
    out={}
    for q,c in enumerate(charge):
        if c and label[q] in 'XY':
            a=list(label);a[q]='Y' if label[q]=='X' else 'X'
            out[''.join(a)]=c*(1 if label[q]=='X' else -1)
    return out # exact coefficients of [P,Q]/i
C=[(comm(l,QA),comm(l,QB)) for l in labels]
G=s.zeros(len(labels))
for a in range(len(labels)):
    for b in range(a,len(labels)):
        value=sum(sum(v*C[b][k].get(l,0) for l,v in C[a][k].items()) for k in range(2))
        G[a,b]=G[b,a]=value
kernel=G.nullspace();check('joint charge-conserving space dimension 38',len(kernel)==38)
for j,col in enumerate(kernel):
    accum={}
    for a,c in enumerate(col):
        if c:
            for l,v in comm(labels[a],NZ).items():accum[l]=accum.get(l,0)+c*v
    check('charge kernel basis conserves m11 occupation '+str(j),all(v==0 for v in accum.values()))
sources=[8,24,40,56];targets=[8,4,2,1]
for a in (1,2,3):
    check('nonzero native input Hamming distance '+str(a),(sources[a]^targets[a]).bit_count()==(3 if a<3 else 4))
    check('all two-local Pauli direct target matrix elements vanish '+str(a),
       all(sum(1<<(5-k) for k,p in enumerate(l) if p in 'XY')!=(sources[a]^targets[a]) for l in labels))
check('m11 charge witness starts empty and ends occupied',(sources[3]&1)==0 and (targets[3]&1)==1)
# Scalar proof used in the uniform norm-time bound.
x=s.symbols('x',positive=True)
check('monotonicity derivative certificate',s.simplify(s.diff(x-s.sin(x)*s.cos(x),x)-2*s.sin(x)**2)==0)
eps=F(1,1<<16);gap=3*eps/(1-eps)
check('exact finite-error latency loss simplifies to 1/21845',gap==F(1,21845))
check('prime decomposition of latency denominator',21845==5*17*257)
check('radical upper-bound constant',s.Rational(3,2)**2>2)
# Sharpness of the zero-direct-coupling lemma on a general three-level path.
A=s.Matrix([[0,1/s.sqrt(2),0],[1/s.sqrt(2),0,1/s.sqrt(2)],[0,1/s.sqrt(2),0]])
check('sharpness path first coupling zero',A[2,0]==0)
check('sharpness path full norm one',A.charpoly().all_coeffs()==[1,0,-1,0])
check('sharpness path transfers at pi',(s.eye(3)-2*A*A)[:,0]==s.Matrix([0,0,-1]))
# Matched improvement of the prior one-native-qubit contract, on the same pairs.
I=s.eye(2);X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-s.I],[s.I,0]]);N=s.diag(0,1)
def lift3(P,q):return s.kronecker_product(*[P if k==q else I for k in range(3)])
nA,nu,nv=[lift3(N,k) for k in range(3)];xa,xu,xv=[lift3(X,k) for k in range(3)]
ya,yv=lift3(Y,0),lift3(Y,2)
H01=xu*(nA+nv)+(xa*xv+ya*yv)/2+2*(nA+nv)-2*nA*nv-2*s.eye(8)
z=s.symbols('z')
check('corrected one-bit full characteristic polynomial',s.expand(H01.charpoly(z).as_expr()-(z+2)**4*z**2*(z-2)**2)==0)
E1=s.zeros(8,2);E1[2,0]=1;E1[6,1]=1
W1=s.zeros(8,2);W1[2,0]=1;W1[1,1]=1
U1=s.eye(8)-H01*H01/2
check('corrected one-bit exact encoder at pi',U1*E1==-W1)
check('corrected one-bit same-generator decoder',U1*W1==-E1)
check('corrected one-bit full return',U1*U1==s.eye(8))
check('corrected one-bit norm one and width two at g=1/2',max(abs(k) for k in [-2,0,2])/2==1)
check('one-bit locality lower bound applies',(6^1).bit_count()==3)
check('matched norm-budget latency ratio',s.Rational(2,3)*s.Rational(3,2)==1)
check('one-bit correction vanishes on admitted sectors',nA*nv*E1==s.zeros(8,2))
ncheck('optimal one-bit endpoint diagnostic',np.linalg.norm(expm(-1j*np.pi*np.array(H01/2).astype(complex))@np.array(E1).astype(complex)+np.array(W1).astype(complex),2))
# Alternative native two-qubit admission into three-mode odd parity.
I=s.eye(2);X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-s.I],[s.I,0]]);N=s.diag(0,1)
def lift(P,q):return s.kronecker_product(*[P if k==q else I for k in range(5)])
Ns=[lift(N,k) for k in range(5)];Xs=[lift(X,k) for k in range(5)];Ys=[lift(Y,k) for k in range(5)]
SA=Ns[0]+Ns[4];SO=Ns[1]+Ns[3]
K=Xs[2]*(SA+SO)+(Xs[0]*Xs[4]+Ys[0]*Ys[4]+Xs[1]*Xs[3]+Ys[1]*Ys[3])/2+2*(SA+SO)
H0=K-2*(Ns[0]*Ns[4]+Ns[1]*Ns[3])-4*s.eye(32);H=H0/4
levels={-4:10,-2:8,0:6,2:4,4:4}
z=s.symbols('z')
check('alternative full 32-dimensional characteristic polynomial',s.expand(H0.charpoly(z).as_expr()-s.prod((z-e)**m for e,m in levels.items()))==0)
check('alternative full norm one and width two',max(abs(e) for e in levels)/4==1 and (max(levels)-min(levels))/4==2)
poly=s.Poly(s.interpolate([(e,(-1)**(abs(e)//2)) for e in levels],x),x)
U=s.zeros(32)
for coeff in poly.all_coeffs():U=U*H0+coeff*s.eye(32)
E=s.zeros(32,4);P=s.zeros(32,4)
for a in range(4):
    E[8*a+4,a]=1
    b,c=a>>1,a&1
    P[((1^b^c)<<2)|(c<<1)|b,a]=1
check('alternative exact all-input parity admission',U*E==P)
check('alternative same-generator decoding',U*P==E)
check('alternative full projective return',U*U==s.eye(32))
check('alternative native outputs both zero',(Ns[0]+Ns[1])*P==s.zeros(32,4))
check('alternative spectator identity',s.kronecker_product(U,s.eye(4))*s.kronecker_product(E,s.eye(4))==s.kronecker_product(P,s.eye(4)))
gr=F.from_float(float(F(1,4)));d=4*(F(1,4)-gr);window=F(1,1<<18)
check('alternative binary64 full norm exactly one',4*gr==1)
check('alternative exact dyadic implementation',d==0)
check('alternative full readout interval error below 2^-16',window<F(1,1<<16))
Hn=np.array(H).astype(complex);En=np.array(E).astype(complex);Pn=np.array(P).astype(complex)
ncheck('alternative full-input endpoint',np.linalg.norm(expm(-2j*np.pi*Hn)@En-Pn,2))
ncheck('alternative full-spectrum replay',np.max(abs(np.linalg.eigvalsh(Hn)-np.sort([e/4 for e,m in levels.items() for _ in range(m)]))))
ncheck('alternative complete return',np.linalg.norm(expm(-4j*np.pi*Hn)-np.eye(32),2))
# Freeze the fitted model as exact binary rationals, then reject it by a first moment.
search=json.loads((R/'results/SEARCH_RECEIPT.json').read_text());coeff={l:F.from_float(c) for l,c in search['best']['coefficients'].items()}
def element(label,left,right):
    flip=sum(1<<(5-k) for k,p in enumerate(label) if p in 'XY')
    if right^flip!=left:return s.Integer(0)
    phase=s.I**label.count('Y')
    return phase*(-1)**sum((right>>(5-k))&1 for k,p in enumerate(label) if p in 'YZ')
M=s.zeros(32,len(labels))
for k,l in enumerate(labels):
    for a in range(4):
        for b in range(4):
            delta=element(l,sources[a],sources[b])-element(l,targets[a],targets[b])
            M[4*a+b,k]=s.re(delta);M[16+4*a+b,k]=s.im(delta)
rank=M.rank();selected=[labels.index(l) for l in coeff];Ms=M[:,selected];reduced=Ms.nullspace()
check('first-moment constraint has at most 15 independent real equations',rank<=15)
check('planar-family first-moment kernel exactly annihilated',all(Ms*v==s.zeros(32,1) for v in reduced))
check('planar-family first-moment dimension accounts for rank',len(reduced)+Ms.rank()==len(selected))
(R/'MOMENT_FILTER.json').write_text(json.dumps(dict(
    necessary_condition='E^dagger H E = W^dagger H W; higher moments remain necessary',
    full_two_local_dimension=154,full_first_moment_rank=rank,full_first_moment_kernel_dimension=154-rank,
    planar_real_dimension=len(selected),planar_first_moment_rank=Ms.rank(),planar_kernel_dimension=len(reduced),
    exact_planar_kernel=[{labels[selected[k]]:str(c) for k,c in enumerate(v) if c!=0} for v in reduced],
    scope='linear endpoint necessity, not sufficient reachability'),indent=2)+'\n')
L=sum(abs(c) for c in coeff.values())
def diagonal(label,b):
    if any(p in 'XY' for p in label):return 0
    return (-1)**sum(((b>>(5-k))&1) for k,p in enumerate(label) if p=='Z')
moments=[sum(c*(diagonal(l,e)-diagonal(l,f)) for l,c in coeff.items()) for e,f in zip(sources,targets)]
idx=max(range(4),key=lambda a:abs(moments[a]));floor=abs(moments[idx])/(2*L)
check('frozen numerical candidate Pauli norm ledger is positive',L>0)
check('frozen candidate exact first-moment error floor above 2^-16',floor>eps)
check('frozen candidate exact first-moment error floor above 18/1000',floor>F(18,1000))
receipt=dict(exact_count=len(checks),exact_checks=checks,numerical_count=len(numeric),numerical_checks=numeric,
    charge_family=dict(pauli_dimension=154,conserved_dimension=38,charges=dict(QA=QA,QO=QB),
       consequence='all members conserve N_m11; input 11 complete trace error is one for every time',
       scope='six qubits, Hermitian two-local, both stated conserved charges; not all two-local Hamiltonians'),
    latency=dict(exact='T >= pi',finite_error='T >= 2*atan((1-epsilon)/sqrt(2-2*sqrt(1-epsilon^2)))',
       epsilon_2_minus_16='T >= pi - 1/21845',basis='any static Hermitian two-local with full centered norm <=1 and this computational-basis launch/target; planar restriction not needed',
       scalar_lemma_sharp=True,six_qubit_joint_bound_saturation='OPEN'),
    optimal_one_bit=dict(physical_qubits=3,pairs=3,maximum_degree=2,planar=True,g='1/2',deadline='pi',full_norm=1,width=2,
       correction='-2*g*N_A*N_v on existing pair; center at -2*g*I',source_contract='same native-qubit to two-mode isometry as parent',
       full_spectrum={'-1':4,'0':2,'1':2},optimality='static Hermitian two-local, specified computational-basis native input and seed, full centered norm <=1',
       previous_deadline='3*pi/2',ratio='2/3',maximum_Pauli_coefficient='1/2',previous_maximum_Pauli_coefficient='1/3',
       scope='speed improvement at matched full-norm budget; not at a matched per-term ceiling',dyadic=True,window_halfwidth='1/262144',window_error_bound='1/262144'),
    alternative=dict(physical_qubits=5,pairs=6,maximum_degree=4,planar=True,g='1/4',deadline='2*pi',full_norm=1,width=2,
       carrier='three-mode odd parity; one or three excitations',outputs=['100','010','001','111'],
       rounded_g=str(gr),rounding_bound=str(d),window_bound=str(window),full_spectrum_multiplicities=levels,
       exact_single_excitation_contract=False),
    frozen_search_candidate=dict(run=search['best']['run'],basis_witness=idx,diagonal_moments=[str(x) for x in moments],
       sufficient_norm_budget=str(L),all_time_error_floor=str(floor),all_time_error_floor_float=float(floor),
       conclusion='This frozen fit fails at all times by exact energy-moment mismatch; no exclusion of other fitted coefficients.',
       exact_binary_coefficients={l:str(c) for l,c in coeff.items()}),
    moment_filter=dict(full_rank=rank,full_dimension=154-rank,planar_real_rank=Ms.rank(),planar_real_dimension=len(reduced)),
    physical_promotion=0,independent_review='pending',novelty_comparison='partial source check; theorem-level priority unresolved')
(R/'results/EXACT_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(exact=len(checks),numerical=len(numeric),charge_family_dimension=len(kernel),
    frozen_error_floor=float(floor),optimal_one_bit_deadline='pi',alternative_deadline='2*pi',joint_single_excitation_admission='OPEN'),indent=2))
