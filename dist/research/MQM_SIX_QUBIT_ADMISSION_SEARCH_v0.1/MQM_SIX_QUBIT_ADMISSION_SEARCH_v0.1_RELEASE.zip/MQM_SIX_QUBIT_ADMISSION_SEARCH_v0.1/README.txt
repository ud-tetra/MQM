Optimal Static Native-Qubit Admission and Limits of Joint-Mode Encoding
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM development note v0.1

Main result: the existing planar three-qubit admission triangle reaches the same
endpoint at pi instead of 3*pi/2 under a full centered norm-one budget. A scoped
static two-local lower bound proves this one-qubit deadline optimal. The change
adds a diagonal density interaction on an existing pair and raises individual
coefficients; it is not a speed gain at a fixed per-coupling ceiling.

The requested six-qubit joint single-excitation encoder remains OPEN. A natural
charge-preserving family is excluded exactly. Four finite planar real searches
do not find an encoder. The best frozen candidate is excluded at all times by
an exact energy-moment witness. A five-qubit odd-parity endpoint encoder at 2*pi
is a separate carrier, not a replacement for the single-excitation interface.

Status: scoped derivation and constructor replay, not independent peer review.
Theorem-level novelty comparison remains pending. Physical evidence promotion 0.
Time is model time, hbar=1. No thermodynamic refresh or permanent hold is claimed.

Contents and replay (run from this extracted directory):
  python3 certify_constraints.py
    Replays 78 exact checks and 4 numerical propagation checks using frozen fit.
  python3 search_candidates.py
    OPTIONAL EXPENSIVE exploration: reruns four seeded fits and overwrites its
    numerical receipt/basis. No global convergence guarantee. Re-run certification
    afterward; a new optimizer/library version may produce different fits.
  python3 build_ieee_note.py
    Builds actual IEEEtran A4 10pt two-column PDF (three pdflatex passes), verifies
    page dimensions, overflow and references, and renders pages for visual QA.
    Requires pdflatex, numpy, scipy, sympy, and PyMuPDF. Bundled IEEEtran and LPPL.
    Build resets visual_review to pending; inspect rendered pages before release.
  python3 prepare_release.py --visual-review-confirmed
    Release preparation after explicit page inspection; freezes metadata/hashes.

Primary deliverable: manuscript/MQM_SIX_QUBIT_ADMISSION_IEEE_A4_v0.1.pdf
Exact algebra and rational receipts: results/EXACT_RECEIPT.json
Finite search diagnostics: results/SEARCH_RECEIPT.json and SEARCH_BASIS.npz
Next-search necessary kernel: MOMENT_FILTER.json (55-dimensional, not sufficient).
Claim scope, matched comparison and next gates are separate JSON records.
Publication policy: all future paper builds actual IEEEtran A4 two columns.
Parent releases are source anchors and have not been modified.
