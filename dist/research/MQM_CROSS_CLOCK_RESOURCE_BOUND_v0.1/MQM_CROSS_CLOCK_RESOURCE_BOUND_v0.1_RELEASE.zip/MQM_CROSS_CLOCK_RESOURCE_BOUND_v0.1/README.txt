MQM CROSS-CLOCK RESOURCE BOUND | development v0.1 | 5 October 2026

Read manuscript/MQM_CROSS_CLOCK_RESOURCE_BOUND_v0.1.pdf. The report assesses the supplied review and derives cross-design bounds CC1-CC6 with proofs. It is a single-column reading draft, not an IEEE submission or priority certificate.

Replay: OPENBLAS_NUM_THREADS=1 python3 replay_cross_clock.py
Report and figures: python3 build_report.py
See DEPENDENCIES.txt. No authenticated services are needed to run either script.

Main result: ideal clock ADDRESS DIMENSION has matching order m+log(1/epsilon) across arbitrary weighted history paths and diagonal potentials under the stated primitive, retained-domain, pure-bank, readout-window and resource contract. A window of fixed elapsed-time fraction is essential. This does not optimize total physical qubits, gate synthesis, preparation cost or noisy performance.

Finite result: for m13, epsilon1/1024, known common observation window and resource ceilings, 14<=D*<=64. The lower bound is necessary and conservative; no 14-address construction is asserted. Sixty-four is minimal only inside the original spin family. The six clocks are a fixed fixture panel, not an optimization search. Numerical admission and samples are not rigorously interval-enclosed. The spin window has an exact rational certificate.

The new channel fixtures use a small three-step body. The clock panel relies on the proved formula for its thirteen-step scoring. The parent full-body replay is identified in INPUT_ANCHORS.json, not rerun or modified here.

General proofs are in the manuscript. Constructor checks are not independent proof review. Physical promotion remains zero. SHA256_MANIFEST.json covers packaged payloads. Regeneration can change timings and floating receipts; compare values and declared tolerances rather than byte identity.
