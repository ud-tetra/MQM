"""Cross-design clock lower-bound fixtures, not independent proof review.

Run OPENBLAS_NUM_THREADS=1 python3 replay_cross_clock.py.
All results are written beside this file. Requires NumPy and SciPy.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb, sqrt, pi, log, ceil, acos
import csv, json, time
import numpy as np
from scipy.linalg import eigh_tridiagonal
from scipy.sparse import diags
from scipy.sparse.linalg import expm_multiply

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'
OUT.mkdir(exist_ok=True)
TOL = 2e-10
checks = []
residuals = []
started = time.perf_counter()

def exact(name, ok):
    if not ok:
        raise AssertionError(name)
    checks.append({'name': name, 'kind': 'exact'})

def numeric(name, error):
    error = float(error)
    if not np.isfinite(error) or error > TOL:
        raise AssertionError((name, error))
    residuals.append(error)
    checks.append({'name': name, 'kind': 'numerical', 'residual': error})

# Gaussian rational arithmetic: z = (real, imaginary), both Fraction.
Z0 = (F(0), F(0))
Z1 = (F(1), F(0))
def add(a, b): return (a[0] + b[0], a[1] + b[1])
def neg(a): return (-a[0], -a[1])
def mul(a, b): return (a[0]*b[0] - a[1]*b[1], a[0]*b[1] + a[1]*b[0])
def power(z, n):
    if n < 0:
        z = (z[0], -z[1])  # Every admitted root has unit modulus.
        n = -n
    w = Z1
    while n:
        if n & 1: w = mul(w, z)
        z = mul(z, z)
        n //= 2
    return w
def sumz(xs):
    a = Z0
    for x in xs: a = add(a, x)
    return a
def abs2(z): return z[0]*z[0] + z[1]*z[1]

def explicit_factor(r, ratio=F(1, 2)):
    if r == 1: return 1, 1
    L = ceil(ratio*r)
    return L, r * 2**r * comb(L + 2*r - 2, r - 1)

# Exact recurrence controls: survival sums with rational unit-circle roots.
# These test the algebra used by CC2; finite instances do not prove CC2.
for r in range(1, 11):
    roots = []
    for k in range(r):
        u = F(k, r+1)
        roots.append(((1-u*u)/(1+u*u), 2*u/(1+u*u)))
    exact(f'r{r} all roots exactly unit modulus', all(abs2(z) == 1 for z in roots))
    for ratio in [F(1, 2), F(1), F(3, 2)]:
        L = ceil(ratio*r)
        nstar = L + r - 1
        # w_n=f_{nstar-n}; f_0=1, with r positive spectral weights.
        w = [sumz([mul((F(1, r), F(0)), power(z, nstar-n)) for z in roots])
             for n in range(nstar+1)]
        invroots = [(z[0], -z[1]) for z in roots]
        Q = [Z1]
        for z in invroots:
            nxt = [Z0]*(len(Q)+1)
            for j, q in enumerate(Q):
                nxt[j] = add(nxt[j], q)
                nxt[j+1] = add(nxt[j+1], neg(mul(z, q)))
            Q = nxt
        exact(f'r{r} ratio{ratio} elementary coefficients',
              all(abs2(q) <= comb(r, j)**2 for j, q in enumerate(Q)))
        B = [sumz([mul(Q[k], w[j-k]) for k in range(j+1)]) for j in range(r)]
        reciprocal = [Z1]
        for n in range(1, nstar+1):
            reciprocal.append(neg(sumz([mul(Q[k], reciprocal[n-k]) for k in range(1, min(n, r)+1)])))
        exact(f'r{r} ratio{ratio} homogeneous coefficient bound',
              all(abs2(h) <= comb(r+n-1, n)**2 for n, h in enumerate(reciprocal)))
        reconstructed = sumz([mul(B[j], reciprocal[nstar-j]) for j in range(r)])
        exact(f'r{r} ratio{ratio} reconstruction is normalized return', reconstructed == w[nstar] == Z1)
        sample_max2 = max(abs2(w[j]) for j in range(r))
        factor = r*2**r*comb(L+2*r-2, r-1)
        exact(f'r{r} ratio{ratio} explicit window amplitude bound', factor*factor*sample_max2 >= 1)

# Conservative finite lower bound from CC2, distinct from exact spin minimality.
frontier = []
for den in [2, 4, 8, 16, 32, 64, 128, 1024, 2**20, 2**40, 2**80]:
    eps = F(1, den)
    r = 1
    while True:
        L, B = explicit_factor(r)
        error2_floor = F(2*B*B-1, B**4)
        if error2_floor <= eps*eps: break
        r += 1
    exact(f'eps1/{den} first nonexcluded spectral count', error2_floor <= eps*eps)
    if r > 1:
        _, old = explicit_factor(r-1)
        exact(f'eps1/{den} previous spectral count excluded', F(2*old*old-1, old**4) > eps*eps)
    frontier.append({'epsilon_denominator': den, 'spectral_count_lower_bound': r,
                     'm13_clock_dimension_lower_bound': max(14, r),
                     'meaning': 'Necessary conservative bound, not a realizable optimum'})
with (OUT/'CONSERVATIVE_DIMENSION_LOWER_BOUND.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(frontier[0])); writer.writeheader(); writer.writerows(frontier)

# Matching upper construction over several m/epsilon cases, all exact.
upper_rows = []
eta = 3*log(3)/4-log(2)
for m in [1, 4, 13, 32, 64]:
    for den in [2, 16, 1024, 2**20]:
        N = max(m, 4*(m-1), ceil(log(2*den*den)/eta))
        p = F(sum(comb(N,j) for j in range(m)), 2**N)
        exact(f'm{m} eps1/{den} matching-order upper construction', 2*p-p*p <= F(1, den*den))
        upper_rows.append({'m':m,'epsilon_denominator':den,'N_sufficient':N,'clock_dimension':N+1,
                           'g1_window_start':pi*N/4,'g1_window_end':3*pi*N/4})
with (OUT/'MATCHING_ORDER_UPPER_CONSTRUCTIONS.csv').open('w', newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(upper_rows[0]));writer.writeheader();writer.writerows(upper_rows)

# Six fixed designs at the original common episode/window/resource ceilings.
# No optimizer or global dimension search is used.
m=13; N=63; D=N+1
start=pi*N/4; stop=3*pi*N/4
ts=np.linspace(start,stop,8193)
J_LIMIT=F(32,63); V_LIMIT=F(1,63)
spin=np.sqrt(np.arange(1,N+1)*np.arange(N,0,-1))/N
designs=[]
def admit(label, edge, diagonal, preserve=False):
    ev=eigh_tridiagonal(diagonal,edge,eigvals_only=True)
    scale=min(1/max(abs(ev)),float(J_LIMIT)/max(abs(edge)),sqrt(float(V_LIMIT))/abs(edge[0]))
    if preserve: scale=1.0
    designs.append((label,np.array(edge)*scale,np.array(diagonal)*scale,scale))
admit('engineered_spin',spin,np.zeros(D),preserve=True)
admit('uniform_path_norm_only',np.ones(N)/(2*np.cos(pi/(N+2))),np.zeros(D),preserve=True)
edge=np.full(N,.5);edge[0]=.125
admit('weak_launch_uniform',edge,np.zeros(D))
for gamma in [.75,1.0]:
    edge=(np.arange(1,N+1)*np.arange(N,0,-1))**gamma
    edge/=2*max(edge)
    admit(f'power_profile_{gamma}',edge,np.zeros(D))
admit('spin_with_diagonal_bias',spin,.25*np.linspace(-1,1,D))
rows=[];summary=[]
constructed=[]
states_for_witness={}
for label,edge,diagonal,scale in designs:
    ev,V=eigh_tridiagonal(diagonal,edge)
    amp=V @ (V[0,:,None]*np.exp(-1j*ev[:,None]*ts[None,:]))
    norm=max(abs(ev)); variance=edge[0]**2
    constructed.append({'clock':label,'edges':edge.tolist(),'diagonal':diagonal.tolist(),
                        'matrix_convention':'K[j+1,j]=K[j,j+1]=edges[j]; K[j,j]=diagonal[j]'})
    p=np.sum(abs(amp[:m])**2,axis=0)
    dist=np.sqrt(np.maximum(0,2*p-p*p))
    k=int(np.argmax(p)); gap=ts[1]-ts[0]
    # Continuous interpolation inequality for the exact evolution.
    # Floating grid/eigensystem errors are not rigorously enclosed by this replay.
    amp_bound=sqrt(float(p[k]))+norm**2*gap**2/8
    tail_bound=min(1.,amp_bound**2)
    cont_error=sqrt(2*tail_bound-tail_bound**2)
    initial=np.zeros(D);initial[0]=1
    K=diags([edge,diagonal,edge],[-1,0,1],format='csr')
    sparse=expm_multiply(-1j*ts[k]*K,initial,traceA=-1j*ts[k]*sum(diagonal))
    numeric(label+' independent sparse propagation',np.linalg.norm(sparse-amp[:,k]))
    numeric(label+' normalization',np.max(abs(np.sum(abs(amp)**2,axis=0)-1)))
    short_ts=np.linspace(0,pi/(2*sqrt(variance)),25)
    short_return=np.abs((V[0]**2)@np.exp(-1j*ev[:,None]*short_ts[None,:]))
    numeric(label+' variance speed bound',max(0,float(np.max(np.cos(sqrt(variance)*short_ts)-short_return))))
    numeric(label+' return population contained in incomplete sector',max(0,float(np.max(abs(amp[0])**2-p))))
    cut_comm=K.toarray()@np.diag([1]*m+[0]*(D-m))-np.diag([1]*m+[0]*(D-m))@K.toarray()
    numeric(label+' cut commutator norm',abs(np.linalg.norm(cut_comm,2)-edge[m-1]))
    if label=='engineered_spin':
        pexact=F(sum(comb(N,j) for j in range(m)),2**N)
        numeric('spin endpoint against exact rational tail',abs(p[0]-float(pexact)))
        exact('spin exact whole-window target',2*pexact-pexact*pexact<F(1,1024**2))
    admitted=(norm<=1+TOL and max(edge)<=float(J_LIMIT)+TOL and variance<=float(V_LIMIT)+TOL)
    summary.append({'clock':label,'clock_dimension':D,'admitted_norm':float(norm),
                    'max_edge':float(max(edge)),'initial_variance':float(variance),
                    'initial_mean_energy':float(diagonal[0]),
                    'resource_admitted':bool(admitted),'scale_factor':float(scale),
                    'resource_admission_method':'Numerical norm/edge/variance checks within 2e-10; spin also has the analytic reference contract',
                    'grid_worst_p':float(p[k]),'grid_worst_joint_error':float(dist[k]),'grid_worst_time':float(ts[k]),
                    'analytic_interpolation_upper_using_float_samples':cont_error,
                    'target_pass_at_all_grid_points':bool(max(dist)<1/1024),
                    'continuous_certificate_status':'Exact rational binomial certificate' if label=='engineered_spin' else 'No rigorous numerical enclosure; sampled diagnostics only'})
    for i in range(0,len(ts),16):
        rows.append({'clock':label,'time':float(ts[i]),'p':float(p[i]),'joint_error':float(dist[i])})
    states_for_witness[label]=amp[:,k]
with (OUT/'SIX_CLOCK_PANEL.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
(OUT/'SIX_CLOCK_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'CONSTRUCTED_CLOCKS.json').write_text(json.dumps(constructed,indent=2)+'\n')

# General prefix-history channel witness including mixed states.
# Minimal three-step body word with final E flip; all prefixes preserve E0 before it.
X=np.array([[0,1],[1,0]],complex); H=np.array([[1,1],[1,-1]],complex)/sqrt(2)
I2=np.eye(2); T=np.diag([1,np.exp(1j*pi/4)])
G=[np.kron(H,I2),np.kron(T,I2),np.kron(I2,X)]
prefix=[np.eye(4,dtype=complex)]
for U in G: prefix.append(U@prefix[-1])
embed=np.zeros((4,2),complex);embed[0,0]=1;embed[2,1]=1
for label,edge,diagonal,scale in designs:
    # A separate 7-address chain, carrying the same profile's first six edges.
    dd=diagonal[:7]; ee=edge[:6]
    K=diags([ee,dd,ee],[-1,0,1]).toarray()
    ev,V=np.linalg.eigh(K);t=7.3
    c=V@(V[0]*np.exp(-1j*ev*t))
    A=np.vstack([c[j]*prefix[min(j,3)]@embed for j in range(7)])
    B=np.kron(c[:,None],prefix[-1]@embed)
    p=float(sum(abs(c[:3])**2));s=sqrt(2*p-p*p)
    numeric(label+' isometry cross overlap',(np.linalg.norm(A.conj().T@B-(1-p)*I2)))
    for name,rho in [('pure',np.array([[1,0],[0,0]])),('mixed',np.array([[.6,.1j],[-.1j,.4]]))]:
        delta=A@rho@A.conj().T-B@rho@B.conj().T
        actual=sum(abs(np.linalg.eigvalsh(delta)))/2
        numeric(label+' '+name+' complete error formula',abs(actual-s))
        rd=sum((abs(c[j])**2)*(prefix[min(j,3)]@embed@rho@embed.conj().T@prefix[min(j,3)].conj().T) for j in range(7))
        rd-=prefix[-1]@embed@rho@embed.conj().T@prefix[-1].conj().T
        numeric(label+' '+name+' reduced error formula',abs(sum(abs(np.linalg.eigvalsh(rd)))/2-p))

# Narrow-window negative control: fixed 2-address clock can hit arbitrarily small
# error if the window width shrinks. This rejects an unconditional log-size law.
for den in [16,1024,2**20]:
    halfwidth=1/(2*den)
    p=np.sin(halfwidth)**2
    numeric(f'2-address shrinking-window eps1/{den}',max(0,sqrt(2*p-p*p)-1/den))

receipt={'status':'PASS','date':'2026-10-05','exact_checks':sum(x['kind']=='exact' for x in checks),
         'numerical_checks':sum(x['kind']=='numerical' for x in checks),
         'numerical_tolerance':TOL,'max_numerical_residual':max(residuals),
         'checks':checks,'elapsed_seconds':time.perf_counter()-started,
         'claims_status':'Self-contained derivations plus constructor checks; independent review pending',
         'grid_note':'6 x 8193 grid points evaluated; counts above exclude individual grid points',
         'not_established':['Smallest cross-design dimension for m13/epsilon1/1024',
                            'Rigorous floating-point enclosure of every panel sample','Theorem priority','Physical realization']}
(OUT/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='checks'},indent=2))
print(json.dumps(summary,indent=2))
