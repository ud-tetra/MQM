"""Build scientific figures and reading PDF. Run after replay_cross_clock.py.
Requires Matplotlib, NumPy, Pandoc and XeLaTeX. Paths are package-relative.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb, sqrt, ceil
import csv,json,hashlib,subprocess
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R=Path(__file__).resolve().parent
(R/'figures').mkdir(exist_ok=True)
(R/'manuscript').mkdir(exist_ok=True)
receipt=json.loads((R/'results/REPLAY_RECEIPT.json').read_text())
panel=json.loads((R/'results/SIX_CLOCK_SUMMARY.json').read_text())
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})

ks=list(range(1,81));lower=[];upper=[]
for k in ks:
    e2=F(1,2**(2*k));r=1
    while True:
        L=(r+1)//2;B=1 if r==1 else r*2**r*comb(L+2*r-2,r-1)
        if F(2*B*B-1,B**4)<=e2:break
        r+=1
    lower.append(max(14,r))
    N=13
    while True:
        p=F(sum(comb(N,j) for j in range(13)),2**N)
        if 2*p-p*p<=e2:break
        N+=1
    upper.append(N+1)
with (R/'results/FINITE_GAP_SWEEP.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['precision_bits_k','epsilon','conservative_cross_design_lower_D','spin_upper_D'])
    w.writerows([(k,f'2^-{k}',l,u) for k,l,u in zip(ks,lower,upper)])
fig,ax=plt.subplots(figsize=(7.2,4))
ax.plot(ks,upper,color='#174c70',lw=2,label='Spin construction: sufficient across the class')
ax.step(ks,lower,where='mid',color='#a95a2a',lw=2,label='Conservative necessary cross-design bound')
ax.axvline(10,color='#6b7780',ls=':',lw=1)
ax.annotate('Target 2^-10: 14 ≤ D* ≤ 64',xy=(10,64),xytext=(20,85),fontsize=9,
            arrowprops={'arrowstyle':'->','color':'#6b7780'})
ax.set(xlabel='Precision bits k in ε = 2^-k',ylabel='Clock address dimension D',
       title='Matching asymptotic order leaves a wide finite gap (m = 13)')
ax.grid(alpha=.15);ax.legend(fontsize=8,loc='upper left');fig.tight_layout()
fig.savefig(R/'figures/FINITE_RESOURCE_GAP.png');plt.close(fig)

samples=list(csv.DictReader((R/'results/SIX_CLOCK_PANEL.csv').open()))
labels={'engineered_spin':'Engineered spin','uniform_path_norm_only':'Uniform (variance excluded)',
        'weak_launch_uniform':'Weak-launch uniform','power_profile_0.75':'Power profile 0.75',
        'power_profile_1.0':'Power profile 1.0','spin_with_diagonal_bias':'Biased spin'}
colors=['#174c70','#6f7780','#9e5527','#6c6f2c','#7c5375','#28766d']
fig,ax=plt.subplots(figsize=(7.2,4.3))
for item,color in zip(panel,colors):
    key=item['clock'];data=[x for x in samples if x['clock']==key]
    if key=='engineered_spin':
        times=np.array([float(x['time']) for x in data]);z=np.sin(times/63)**2
        p=sum(comb(63,j)*z**j*(1-z)**(63-j) for j in range(13))
        vals=np.sqrt(np.maximum(0,2*p-p*p))
    else: vals=np.array([float(x['joint_error']) for x in data])
    ax.semilogy([float(x['time']) for x in data],np.maximum(vals,1e-15),
                color=color,lw=1.5,ls='--' if not item['resource_admitted'] else '-',label=labels[key])
ax.axhline(1/1024,color='#6b7780',ls=':',label='Target 1/1024')
ax.set(xlabel='Model time; common window [63π/4, 189π/4]',ylabel='Complete channel error',
       title='Five admitted designs plus one resource-excluded diagnostic')
ax.grid(which='both',alpha=.14);ax.legend(fontsize=7.8,ncol=2,loc='lower center')
fig.tight_layout();fig.savefig(R/'figures/SIX_CLOCK_COMPARISON.png');plt.close(fig)

text=r'''---
title: "Cross-Design Clock-Size Bounds for Finite Autonomous Quantum Episodes"
subtitle: "MQM Paper A research continuation - development v0.1"
author: "Benjamin Walker Mayes"
date: "5 October 2026"
---

**Independent researcher**  
ORCID: [0009-0002-5813-0724](https://orcid.org/0009-0002-5813-0724)

**Status.** Self-contained conditional derivations and constructor checks. The supplied narrative review is assessed below; independent theorem review, priority and physical realization remain open. This document is a separate continuation of the autonomous addendum, not an IEEE submission or an automatic public theorem promotion.

## Abstract

We extend a finite autonomous quantum episode's clock-size analysis beyond its engineered spin-clock family. For any prefix-dressed finite Hermitian clock launched at an incomplete address, complete-channel accuracy forces its return amplitude to stay small on the readout interval. An elementary recurrence argument bounds this suppression in terms of the number of supported frequencies and the interval geometry, without a spectral-gap or frequency-spacing assumption. For a fixed ratio of elapsed time to readout duration, the result implies a logarithmic dimension cost in inverse error. Combined with an explicit m-step history path and the earlier spin-clock construction, it gives matching order m + log(1/epsilon) for clock address dimension across arbitrary weighted path clocks with diagonal potentials under a common ideal resource contract. The constants are conservative: for the thirteen-step, epsilon = 1/1024 example, the established finite bracket is 14 necessary to 64 sufficient addresses, not cross-design minimality of 64. We also extend the exact joint error formula to mixed inputs, retain preparation variance in comparisons, and derive a continuous-time sampling allowance. Six fixed clock fixtures support the comparison but do not establish global optimization, physical advantage or independently reviewed novelty.

**Index Terms:** Autonomous quantum control, history clocks, exponential sums, finite readout windows, resource lower bounds, quantum information.

# 1. Analysis of the supplied review

The review correctly identifies the compiled static episode, the role of the final exhaustion bit, the exact complete-versus-clock-traced error distinction, and the unrenewed supervisor. It is a useful explanatory review. It does not present line-by-line proof checking, an independent replay or a theorem-level prior-art comparison. Its source and review method have not been verified. Accordingly, it does not close those evidence tasks.

| Review statement | Assessment and corrected statement |
|:--|:--|
| All phases use one fixed Hamiltonian | Correct for the declared compiled episode after one prepared launch. |
| The machine then sits idle | The identity suffix yields a finite interval of approximate completion. The clock evolves throughout, and later reversal undoes the episode. |
| Single-Hamiltonian computation is genuinely new | Unsupported. History-Hamiltonian computation and idling have established prior art [1]. Priority of the specific combined contract remains open. |
| Optimal clock scaling | The original result was optimal only within the spin-padding family. Section 5 below gives a broader, conditional order result. |
| N = 63 addresses | N = 63 edges/clock steps gives D = 64 addresses, labelled 0 through 63. Identity gates occupy steps 14 through 63. |
| Total 17 qubits plus 64 addresses | Binary encoding has 6 clock + 9 body = 15 encoded qubits; the replay spectator adds one, for 16. Unary encoding has 64 clock sites + 9 body, with the spectator separate. |
| The supervisor is the one external resource | Preparation, donors, outputs and compiled couplings are also supplied resources. The supervisor is internal to the closed comparison domain and is not renewed. |
| Autonomous machines must have an external timekeeper | Not proved. The construction establishes no impossibility theorem for supervisor renewal or for other autonomous architectures. |
| Coupling harder cannot make execution faster | The latency bound fixes a maximum coupling. Increasing that allowed scale can shorten times; linear dependence on program length is conditional on the fixed scale. |
| Real imperfections are all accounted for | Only errors admitted to the stated domain and supply/perturbation contracts are covered. Leakage and additional noise mechanisms require explicit admission. |
| Linear clock-size growth means not scalable | Linear/logarithmic address growth is a mathematical resource law. Practical scalability is unresolved; the law alone does not imply failure. |
| Degenerate logical registers are unrealistic | Zero bare body Hamiltonians are a declared logical benchmark. The benchmark supplies no nondegenerate energy/fuel implementation; impossibility is not established. |
| A complete theoretical foundation | Too broad. Finite supervisor renewal, physical resource preparation, geometry, coupling synthesis and independent validation remain open. |

The development target is therefore a fair cross-design resource statement, with the complete retained domain and observation interval held fixed. Strong adjectives in the review do not promote evidence.

# 2. Comparison class and notation

Let a supplied primitive word have m gates. Its first m - 1 preserve a fresh exhaustion bit E = 0; its last flips E. Define P0 = I, Pj = Gj...G1 for j <= m, and Pj = Pm for j >= m. The pure prepared bank, output slots and donor registers are the same as in the parent addendum. The computational input may be mixed or entangled with any spectator.

Use hbar = 1 throughout. Times and energies are model units with no physical calibration implied.

A path clock has D addresses 0,...,D - 1 with D >= m + 1. Its Hermitian generator K may have arbitrary real diagonal potentials and arbitrary complex nearest-neighbor edges. It starts at address 0. With V = sum_j |j><j| tensor Pj, the full static generator is V(K tensor I)V dagger. Writing c(t) = exp(-iKt)|0>, the actual episode retains all clock, body, donor, output and spectator degrees of freedom. The target is the completed body with its freely evolved comparison clock c(t). No postselection or record deletion is allowed to obtain a smaller error.

The incomplete population and return amplitude are

\[
p(t)=\sum_{j<m}|c_j(t)|^2,\qquad
f(t)=\langle0|e^{-iKt}|0\rangle.
\]

By the spectral theorem,

\[
f(t)=\sum_{\ell=1}^{r}w_\ell e^{-i\lambda_\ell t},
\quad w_\ell>0,\quad\sum_\ell w_\ell=1,\quad r\le D.
\]

Here r counts distinct eigenvalues supported by the launch state, not body dimension or physical qubits. The argument does not require a nonzero spacing between frequencies. If clock eigenvalues or discrete sampling phases coincide, combining frequencies or retaining repeated factors in the recurrence does not invalidate the bounds.

For an interval I = [a,b], a > 0, set length h = b - a and R = b/h = 1 + a/h. A fixed R means that the readout duration is a fixed fraction of elapsed time. A point observation or a width shrinking with error is a different task.

# 3. The exact error extends to mixed inputs

**Proposition CC1 (general-clock complete error).** For this prefix/flag target, every admitted input state, including mixed states and spectator extensions, has complete state distance

\[
\delta(t)=\sqrt{2p(t)-p(t)^2}.
\]

The normalized diamond distance is the same. Tracing the clock gives state and channel distance p(t).

*Proof.* Let A and B be the actual and target isometries from the computational input with its fixed pure bank. Orthogonal clock addresses and the final exhaustion bit give

\[
A^\dagger B=(1-p)I.
\]

Put c = 1 - p and s = sqrt(1 - c squared). For 0 < s, define C = (A - cB)/s. Then B dagger C = 0 and C dagger C = I. Thus A = cB + sC. Under the orthogonal isometric identification by B and C, the difference on any density matrix rho has block form

\[
\begin{pmatrix}c^2-1&cs\\cs&s^2\end{pmatrix}\otimes\rho.
\]

The two-by-two factor has eigenvalues +s and -s. Since rho is positive with trace one, half the trace norm is s, even for mixed input. The s = 0 case follows directly, and spectator extension repeats the same argument. The clock-traced difference has two orthogonal E blocks of trace norm p each. These state statements also give the channel distances. \(\square\)

For an accuracy requirement delta <= epsilon < 1, define

\[
q_\epsilon=\sqrt{1-\sqrt{1-\epsilon^2}}
=\frac{\epsilon}{\sqrt{1+\sqrt{1-\epsilon^2}}}.
\]

Because address 0 is incomplete, |f(t)| squared <= p(t). Consequently complete accuracy throughout I forces

\[
\sup_{t\in I}|f(t)|\le q_\epsilon.
\]

This is the link from an unconditional quantum information task to finite-frequency suppression.

# 4. An explicit finite-frequency window bound

**Lemma CC2 (self-contained recurrence bound).** Suppose f is a sum of r pure frequencies and f(0) = 1. For r >= 2 let

\[
L=\left\lceil\frac{ar}{h}\right\rceil,\qquad
B_{r,L}=r2^r\binom{L+2r-2}{r-1}.
\]

Then

\[
\sup_{t\in[a,b]}|f(t)|\ge\frac1{B_{r,L}}
\ge 2^{-(R+3)r}.
\]

For r = 1 the supremum is exactly one.

*Proof.* Set sampling step tau = a/L. The r times (L + k)tau, 0 <= k < r, lie in I because (r - 1)tau <= h. Let nstar = L + r - 1 and w_n = f((nstar - n)tau). Then w_0,...,w_(r-1) are the admitted samples, while w_nstar = f(0) = 1.

Write z_l = exp(i lambda_l tau). Each has unit modulus. The generating function for the backward sequence is

\[
\sum_{n\ge0}w_n z^n=\frac{A(z)}{Q(z)},\qquad
Q(z)=\prod_{\ell=1}^r(1-z_\ell z),\quad\deg A\le r-1.
\]

If Q(z) = sum_j q_j z^j, its elementary symmetric coefficients satisfy |q_j| <= binomial(r,j). Let M be the largest of the r sample magnitudes. The coefficient A_j = sum_(k=0)^j q_k w_(j-k), j < r, therefore satisfies |A_j| <= 2 to the power r times M. The reciprocal Q has complete homogeneous coefficients H_n satisfying

\[
\frac1{Q(z)}=\sum_{n\ge0}H_nz^n,
\qquad |H_n|\le\binom{r+n-1}{n}.
\]

This follows by expanding r geometric series: there are binomial(r+n-1,n) monomials of degree n, each of unit magnitude. Comparing the nstar coefficient gives

\[
1=|w_{n_*}|\le r2^r
\binom{L+2r-2}{r-1}M=B_{r,L}M.
\]

For the simpler exponential estimate use binomial(n,k) <= 2 to the power n, r <= 2 to the power (r - 1), and L <= ar/h + 1. Hence B <= 2 to the power (L + 4r - 3) <= 2 to the power ((R + 3)r - 2), and the stated looser bound follows. A single frequency with f(0) = 1 has constant unit magnitude. \(\square\)

The constants are intentionally conservative. No frequency spacing, norm ceiling or positive spectral weights beyond the normalization were needed. This is a finite-sum recurrence argument of the established Turan/Remez type, not a claim that exponential-sum theory is new.

For comparison, the classical Turan-Nazarov inequality [2, Theorem 1.1] bounds an r-term pure-frequency sum on [0,b] by (C R) to the power (r - 1) times its supremum on I, for an absolute C. Enlarging C to be at least two gives the alternative consequence r >= 1 + log(1/q_epsilon)/log(CR). We do not assign a numerical value to this unspecified constant or use it to claim a finite optimum. CC2 supplies an explicit elementary version for this development.

# 5. The cross-design size law

**Theorem CC3 (necessary size across static clocks).** Every clock in the comparison class with complete accuracy epsilon on I satisfies

\[
r\ge\frac{\log_2(1/q_\epsilon)}{R+3},\qquad
D\ge\max\left\{m+1,
\left\lceil\frac{\log_2(1/q_\epsilon)}{R+3}\right\rceil\right\}.
\]

For a specific r >= 2, the stronger explicit necessary test is

\[
\epsilon^2\ge\frac{2}{B_{r,L}^2}-\frac1{B_{r,L}^4}.
\]

*Proof.* CC1 forces sup_I |f| <= q_epsilon. Apply CC2 and r <= D. The explicit bound guarantees some t in I with p(t) >= 1/B squared, and delta squared = 2p - p squared is increasing on [0,1]. The path's explicit primitive-address layout separately requires D >= m + 1. \(\square\)

The frequency part applies more generally to finite Hermitian prefix clocks whose launch address is incomplete. The m + 1 part uses the stated path layout and forbids shortening the gate word by a shortcut edge carrying a whole gate product.

For any fixed upper bound on R, and m >= 1, 0 < epsilon < 1/2, CC3 gives

\[
D=\Omega\big(m+\log(1/\epsilon)\big).
\]

This is a necessary bound across arbitrary path weights and diagonal potentials, rather than across one engineered family. Combining two lower bounds by their maximum loses only a constant factor.

## 5.1 Matching order under a common resource contract

The parent construction uses D = N + 1 addresses and edges kappa sqrt((j+1)(N-j)). At beta = pi/4 its endpoint tail is

\[
p_{N,m}=2^{-N}\sum_{j<m}\binom Nj.
\]

Markov's inequality gives p <= 3 to the power (m - 1) times (2/3) to the power N. For eta = (3/4) ln 3 - ln 2 > 0, a sufficient choice is

\[
N\ge\max\left\{m,4(m-1),
\left\lceil\frac{\ln(2/\epsilon^2)}{\eta}\right\rceil\right\}.
\]

It has order m + log(1/epsilon). Let N_ref be either this predetermined sufficient integer or the exact least spin-family integer satisfying the tail criterion. Choose a fixed norm ceiling g > 0 before comparing candidates, and freeze

\[
I_{\rm ref}=\left[\frac{\pi N_{\rm ref}}{4g},
\frac{3\pi N_{\rm ref}}{4g}\right],\quad
\|K\|\le g,\quad J_{\max}\le g,\quad
\sigma_0^2\le\frac{g^2}{N_{\rm ref}}.
\]

All candidates use that same interval, bank, primitive word and error target. The spin construction at kappa = g/N_ref meets these ceilings: its norm is g, its first-edge variance is g squared/N_ref, and all edges have magnitude at most g. The comparison does not rescale each candidate's observation time to its own preferred period.

**Corollary CC4 (cross-design order optimality).** The least clock address dimension D_star in this ideal path-clock task satisfies

\[
D_\star=\Theta\big(m+\log(1/\epsilon)\big).
\]

*Proof.* R = 3/2 in the frozen interval, so CC3 gives the lower bound for every admitted candidate. The admitted spin construction gives the matching-order upper bound. The interval and resource ceilings were fixed using an explicit known construction before the competition, not the unknown cross-design optimum. \(\square\)

The result concerns ideal legal-sector address dimension. Binary encoding has ceiling(log_2 D) clock qubits; unary encoding has D sites. No theorem about general physical qubit optimality, minimum coupling precision, gate synthesis, arbitrary graph shortcuts or whole many-excitation energy norm follows. The statement also does not establish a logarithmic latency lower bound. At fixed nonzero preparation or generator errors, the earlier sufficient perturbation budget may obstruct taking epsilon to zero; CC4 is not a noisy asymptotic fault-tolerance theorem.

## 5.2 A shrinking-window control

Take the two-address clock K = X with one final flag-flip step. Its incomplete population is cos squared t. Near t = pi/2 a symmetric window of half-width epsilon/2 has delta <= sqrt(2) sin(epsilon/2) < epsilon. Thus fixed dimension two achieves arbitrarily small errors if the width shrinks with epsilon. R then diverges. This explicitly rejects an unconditional logarithmic dimension law with no window-geometry premise.

CC2 also rules out zero error on any positive-length interval after this admitted launch: a finite B cannot satisfy a zero return-amplitude supremum. Exact completion at an isolated time remains possible.

# 6. Latency and preparation resources

**Proposition CC5 (combined necessary latency).** With launch energy standard deviation sigma_0 and maximum path edge J_max, complete accuracy at time t requires

\[
t\ge\max\left\{\frac{m\sqrt{1-\epsilon^2}}{2J_{\max}},
\frac{\arccos(q_\epsilon)}{\sigma_0}\right\}.
\]

*Proof.* The first term is the position-commutator bound already established in parent AQ7. For the second, subtract the launch mean energy. The clock state's tangent has constant norm sigma_0 and is orthogonal to its instantaneous state. Cauchy-Schwarz gives |d|f|/dt| <= sigma_0 sqrt(1 - |f| squared). Integrating the corresponding angle bound from f(0) = 1 gives arccos |f(t)| <= sigma_0 t. CC1 requires |f(t)| <= q_epsilon. A zero-variance launch is stationary and cannot meet epsilon < 1. \(\square\)

The variance term is the established Mandelstam-Tamm geometric speed bound applied to this completion contract [3], not a new universal speed limit. For a path launch, sigma_0 squared equals the first edge magnitude squared; a diagonal launch potential changes the mean, not that variance. Both the diagonal norm contribution and mean convention still remain in the declared resource record.

# 7. Original finite contract and six-clock panel

For m = 13, epsilon = 1/1024 use N_ref = 63, g = 1 and the original interval [63 pi/4, 189 pi/4]. For this fixture panel tighten the common edge ceiling to 32/63 and preparation variance ceiling to 1/63, both attained by the spin reference. All clocks have 64 addresses, the same address-0 launch and the same body word. Their clocks evolve with their own comparison state, as CC1 requires.

The five numerically admitted fixed designs are engineered spin, weak-launch uniform, power profiles with exponents 3/4 and 1, and spin with diagonal bias. The sixth is the original norm-one uniform clock, retained as a resource-excluded diagnostic because its preparation variance is too large. Candidate rates are scaled up or down to the minimum of the norm, edge and variance limits. Admission of numerical candidates uses the replay tolerance and is not an interval-enclosed resource certificate; the spin reference has an analytic resource contract. This is a fixed fixture panel, not an optimization over all couplings or dimensions.

| Clock | Norm | Largest edge | Launch variance | Admitted | Worst sampled joint error |
|:--|--:|--:|--:|:--|--:|
__PANEL_TABLE__

The spin clock has its exact rational whole-window certificate. Each other admitted design fails the target at a sampled time. These failures are far above numerical tolerance; a separate sparse propagator checks the eigen-based state at each reported worst time. Their finite failures do not exclude untested designs or smaller clocks.

![Six specified clock designs scored on one observation interval. The spin curve uses the analytic binomial law; other curves are numerical. Values below 1e-15 are drawn at that floor. The dashed uniform curve is excluded by the common variance ceiling.](../figures/SIX_CLOCK_COMPARISON.png){width=95%}

For R = 3/2, L = ceiling(r/2). Exact rational evaluation of CC3 excludes r = 1,2,3 for epsilon = 1/1024. It does not exclude r = 4. The primitive path already requires at least 14 addresses. Thus the presently established bracket is

\[
14\le D_\star\le64.
\]

The upper value is attained by the known spin construction; the lower value is necessary, not an exhibited design. Cross-design minimality of 64 has not been proved. The scalar return-amplitude bound discards all other incomplete addresses and has conservative recurrence constants, which explains some of the finite gap.

![Conservative lower dimension and the known spin upper construction for m = 13. The comparison establishes order, not a close finite optimum. Each precision has the prescribed common window from its spin reference.](../figures/FINITE_RESOURCE_GAP.png){width=95%}

# 8. Continuous-time numerical assurance

**Lemma CC6 (amplitude interpolation allowance).** Let F(t) = P_inc exp(-iKt)|0>, norm K <= g. For neighboring sample times separated by Delta t,

\[
\|F(t)\|\le\max\{\|F(t_k)\|,\|F(t_{k+1})\|\}
+\frac{g^2(\Delta t)^2}{8}.
\]

*Proof.* The twice-differentiable vector F has second derivative norm at most g squared. Linear interpolation's integral remainder has norm at most g squared times (t - t_k)(t_(k+1) - t)/2, bounded by g squared Delta t squared/8. The interpolating vector is a convex combination of the two endpoints, so its norm is at most the larger endpoint norm. \(\square\)

With certified endpoint norm errors at most zeta, add zeta to the right side. Squaring the amplitude bound and applying sqrt(2p - p squared) then bounds continuous complete error. The current panel uses floating eigensystems with no rigorous error enclosure, so its interpolation numbers are diagnostics, not independent numerical certificates. Exact rational binomial analysis already certifies the spin clock. Future candidate certification can use interval enclosures or a rigorously bounded propagator plus this allowance.

The replay passes **__EXACT__ exact rational checks and __NUM__ numerical checks**, tolerance 2e-10, maximum numerical residual __RESID__. It also evaluates 8,193 grid points per design; those points are not counted individually as separate checks. Exact controls test rational unit-circle recurrences, coefficient bounds, conservative dimension exclusions and known upper constructions. Numerical controls check clock normalization, return-population containment, mixed-state channel formulas, cut norms, sparse propagation, variance speed limits and the shrinking-window example. The mixed-state joint fixtures use a separate three-step, two-qubit body to check arbitrary-clock algebra. The parent package retains the full thirteen-step body replay. The six-clock panel propagates the clock subsystem and applies the proved complete-channel relation; it does not independently simulate each new clock on the full thirteen-step body. Finite fixture checks support implementation; the general claims rely on the written proofs.

# 9. Publication implications and next development

This continuation closes the earlier missing cross-design order argument within a clearly defined ideal history-path class. A defensible central statement is: finite autonomous execution with a broad unconditional readout window has an asymptotically tight address-dimension cost across arbitrary weighted path clocks under the declared target and resources. It does not establish unrestricted controller optimality or a superior physical implementation.

The underlying history construction is established [1]. Exponential-sum window bounds have classical sources [2], and the variance speed bound is standard [3]. Our proof is self-contained, but priority of this completion-contract application and its substantive contribution still require a theorem-level literature comparison and independent review. A search failing to locate an identical statement is not a priority certificate.

The next concrete target is the finite bracket. Freeze the original thirteen-step contract, then either construct an admitted clock with fewer than 64 addresses and rigorous continuous-window accuracy, or prove stronger exclusions below 64. A useful route is an interval-certified coupling search with the full incomplete projector rather than only return amplitude. Any candidate must retain norm, edge, variance, launch latency, readout duration, bank and complete-domain requirements. Resource savings should survive the earlier preparation/mismatch ledger.

Supervisor renewal is a separate programme. This size result does not refresh the supervisor or replenish donors. Physical promotion remains zero.

# Reproduction and provenance

Run OPENBLAS_NUM_THREADS=1 python3 replay_cross_clock.py. Run python3 build_report.py to regenerate figures and the reading PDF when Matplotlib, Pandoc and XeLaTeX are available. The editable source, TeX, numerical panel, rational receipts, comparison contract, claim register, parent hashes and package manifest are included. Parent releases are unchanged. The PDF uses a single-column reading format and requires venue-specific preparation before submission.

# References

[1] L. Caha, Z. Landau and D. Nagaj, "The Feynman-Kitaev computer's clock: bias, gaps, idling and pulse tuning," preprint [arXiv:1712.07395](https://arxiv.org/abs/1712.07395). Published as "Clocks in Feynman's computer and Kitaev's local Hamiltonian: Bias, gaps, idling, and pulse tuning," Physical Review A 97, 062306 (2018). doi:10.1103/PhysRevA.97.062306.

[2] O. Friedland and Y. Yomdin, "An observation on Turan-Nazarov inequality," [arXiv:1107.0039v3](https://arxiv.org/abs/1107.0039v3) (2013), Theorem 1.1, restating the classical inequality. Original: F. L. Nazarov, "Local estimates for exponential polynomials and their applications to inequalities of the uncertainty principle type," Algebra i Analiz 5(4), 3-66 (1993); English translation, St. Petersburg Mathematical Journal 5(4), 663-717 (1994).

[3] S. Deffner and S. Campbell, "Quantum speed limits: from Heisenberg's uncertainty principle to optimal quantum control," Journal of Physics A: Mathematical and Theoretical 50, 453001 (2017). doi:10.1088/1751-8121/aa86c6. [arXiv:1705.08023v2](https://arxiv.org/abs/1705.08023v2).
'''
table=[]
for p in panel:
    table.append(f"| {labels[p['clock']]} | {p['admitted_norm']:.6f} | {p['max_edge']:.6f} | {p['initial_variance']:.7f} | {'Yes' if p['resource_admitted'] else 'No'} | {p['grid_worst_joint_error']:.7g} |")
text=text.replace('__PANEL_TABLE__','\n'.join(table)).replace('__EXACT__',str(receipt['exact_checks'])).replace('__NUM__',str(receipt['numerical_checks'])).replace('__RESID__',f"{receipt['max_numerical_residual']:.6g}")
source=R/'manuscript/MQM_CROSS_CLOCK_RESOURCE_BOUND_v0.1.source.txt'
source.write_text(text)
header=R/'manuscript/pdf-header.tex'
header.write_text(r'''\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\footnotesize MQM Paper A / cross-design resource continuation}
\fancyhead[R]{\footnotesize Development 0.1}
\fancyfoot[C]{\thepage}
\setlength{\headheight}{14pt}
\usepackage{float}
\floatplacement{figure}{H}
''')
common=['pandoc',str(source),'-f','markdown+tex_math_single_backslash','--standalone','--resource-path',str(R/'manuscript')+':'+str(R),
        '-V','geometry:margin=22mm','-V','papersize:letter','-V','fontsize:11pt','--include-in-header',str(header)]
for ext in ['tex','pdf']:
    target=R/f'manuscript/MQM_CROSS_CLOCK_RESOURCE_BOUND_v0.1.{ext}'
    args=common+['-o',str(target)]
    if ext=='pdf':args+=['--pdf-engine=xelatex']
    proc=subprocess.run(args,capture_output=True,text=True)
    (R/f'results/BUILD_{ext.upper()}.txt').write_text(proc.stdout+proc.stderr)
    if proc.returncode:raise RuntimeError(proc.stderr)
print('Built report:',len(text.split()),'words')
