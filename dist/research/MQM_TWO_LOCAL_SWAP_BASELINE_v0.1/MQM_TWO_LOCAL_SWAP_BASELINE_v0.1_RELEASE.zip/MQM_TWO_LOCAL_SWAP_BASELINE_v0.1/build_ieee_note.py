"""Build the IEEEtran/A4 note and its static scientific figures from replay results."""
from pathlib import Path
import json, subprocess
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fitz
R=Path(__file__).resolve().parent
M=R/'manuscript';F=R/'figures'
receipt=json.loads((R/'results/REPLAY_RECEIPT.json').read_text())
plt.rcParams.update({'font.size':8,'axes.labelsize':8,'axes.titlesize':8,'font.family':'DejaVu Sans'})
data=np.genfromtxt(R/'results/FINAL_PORT_PROBABILITY.csv',delimiter=',',names=True)
fig,ax=plt.subplots(figsize=(3.45,1.9),layout='constrained')
ax.plot(data['time'],data['probability'],lw=.7,color='#174f80')
ax.scatter([receipt['final_port_best_grid_time']],[receipt['final_port_best_grid_probability']],s=12,color='#b44a27',zorder=4)
ax.set(xlim=(0,1024),ylim=(0,1),xlabel='Time (g = 1/8, arbitrary units)',ylabel='Final-port probability')
ax.grid(alpha=.2);fig.savefig(F/'FINAL_PORT.pdf');fig.savefig(F/'FINAL_PORT.png',dpi=200);plt.close(fig)
minor=receipt['K33_minor'];parts=minor['parts']
labels={'A':'A','O1':r'$O_1$','s2_u2':'u2','s2_u4':'u4','s2_u3_p':'u3:p','s2_u3_q':'u3:q'}
pos={n:(k,i) for k,part in enumerate(parts) for i,n in enumerate(part)}
fig,ax=plt.subplots(figsize=(3.45,1.9),layout='constrained')
for a,b in minor['edges']:
 x,y=zip(pos[a],pos[b]);ax.plot(x,y,color='#8296a7',lw=.9)
for n,(x,y) in pos.items():
 ax.scatter([x],[y],s=190,color='#174f80',zorder=3)
 ax.text(x+(-.09 if x==0 else .09),y,labels[n],ha='right' if x==0 else 'left',va='center',fontsize=8)
ax.set(xlim=(-.35,1.35),ylim=(-.25,2.25));ax.axis('off')
fig.savefig(F/'NONPLANAR_MINOR.pdf');fig.savefig(F/'NONPLANAR_MINOR.png',dpi=200);plt.close(fig)
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,graphicx,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{proposition}{Proposition}
\newtheorem{theorem}{Theorem}
\newcommand{\SW}{\operatorname{SWAP}}
\newcommand{\tr}{\operatorname{tr}}
\newcommand{\ket}[1]{|#1\rangle}
\newcommand{\bra}[1]{\langle#1|}
\begin{document}
\title{An Exact Two-Body SWAP Compilation:\\Invariant Dynamics and a Nonplanar Resource Baseline}
\author{Benjamin Walker Mayes\thanks{Development note v0.1, October 5, 2026. ORCID: 0009-0002-5813-0724. Independent review pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We audit a clock-controlled output-transfer primitive for finite quantum controllers. Its unencoded three-qubit history generator contains weight-three Pauli terms and cannot equal a two-local Hamiltonian on the same unrestricted Hilbert space. Adapting an established direct two-local construction, we instead compile SWAP as three encoded CNOT transitions. Integer identities over $\mathbb Q(\sqrt2)$ certify an invariant computational sector and exact real-time simulation of an expanded history graph, including arbitrary spectator correlations. The explicit qubit realization costs 52 clock qubits and two data qubits, with 204 Pauli terms on 102 interaction pairs. A $K_{3,3}$ subdivision proves that this particular physical graph is nonplanar. A rational coefficient enclosure bounds rounding error below $2^{-40}$ through time 1024 at scale $g=1/8$. These results establish a reproducible baseline, not minimality, hardware realizability, or a certified deterministic completion deadline. The immediate research target is a smaller geometrically admissible implementation under a matched operational contract.
\end{abstract}
\begin{IEEEkeywords}
Hamiltonian quantum computation, two-local interactions, clock encoding, invariant subspace, quantum control, resource certification.
\end{IEEEkeywords}

\section{Task and comparison boundary}
The MQM development task is to implement output capture within a finite execute--capture--renew episode. Here we isolate the transfer $\SW_{A,O_1}$, retaining both qubits and every external spectator. A valid primitive must specify its launch encoding, fixed Hamiltonian, computational sector, completion criterion, and physical resources. The phrase ``two-local'' means that each physical interaction term acts on at most two physical qubits; it does not assert geometric locality or experimental feasibility.

Universal time-independent two-local computation and direct entangled-clock routing are prior art \cite{nagaj}. Our contribution is the explicit, replayable audit of one adapted SWAP instance, with sector identities, a physical Pauli ledger, and a nonplanarity countercertificate. Perturbative square-lattice reductions are another established route \cite{oliveira}; no finite-resource comparison with such a reduction is made here. A spectral or ground-space comparison by itself would not certify the non-equilibrium dynamics required for this task.

Set $\hbar=1$ throughout the algebra. Let $c$ denote a two-address clock qubit, with launch state $\ket0$, and let $S=\SW_{A,O_1}$. The bare history edge is
\begin{equation}
 \begin{aligned}
 H_{\rm edge}&=gX_c\otimes S\\
 &=\frac g2 X_c\bigl(I+X_AX_{O_1}+Y_AY_{O_1}+Z_AZ_{O_1}\bigr).
 \end{aligned}
\label{bare}
\end{equation}
\begin{proposition}[Unencoded generator obstruction]
For $g\ne0$, no sum of one- and two-qubit terms on these same three unrestricted qubits equals $H_{\rm edge}$.
\end{proposition}
\begin{proof}
The tensor-product Pauli operators form an orthogonal basis under the Hilbert--Schmidt inner product. Every two-local sum has zero coefficients on weight-three basis elements. Equation~\eqref{bare} has three such coefficients equal to $g/2$.
\end{proof}
This is a generator-equality obstruction, not a prohibition on a timed SWAP or encoded simulation. For example,
\begin{equation}
 H_{\rm timed}=g(X_c\otimes I+I_c\otimes S),\qquad T=\frac{\pi}{2g}
\end{equation}
is two-local, and $e^{-iTH_{\rm timed}}\ket0\ket\psi=-\ket1S\ket\psi$. Its intermediate clock--body dynamics differs from that of~\eqref{bare}. It is an endpoint benchmark with a chosen readout time, not the autonomous multi-phase history task.

\section{Explicit direct encoding}
We use the exact circuit identity
\begin{equation}
\begin{aligned}
S&=G_2G_1G_0,\\
G_0=G_2&=\mathrm{CNOT}_{A,O_1},\quad G_1=\mathrm{CNOT}_{O_1,A}.
\end{aligned}
\end{equation}
The following rail construction adapts the direct encoding in \cite{nagaj}. Gate $s\in\{0,1,2\}$ has shared ports $c_s,c_{s+1}$ and two rails $r=u,l$. Stations 1, 3, and 5 on each rail are qutrits; stations 2 and 4 and the four ports are qubits. A qutrit station is represented by two physical clock qubits $p,q$:
\begin{equation}
 \ket O=\ket{00},\quad
 \ket A=\frac{\ket{10}+\ket{01}}{\sqrt2},\quad
 \ket B=\frac{\ket{01}-\ket{10}}{\sqrt2}.
\label{encoding}
\end{equation}
All other stations are in $\ket O$ when one station is occupied. The physical launch is the product state with a single excitation at $c_0$, and all remaining clock qubits in $\ket0$. It requires no initial Bell-pair preparation.

Each rail has the ordered transitions
\begin{equation}
 c_s,\ 1A,\ 1B,\ 2,\ 3A,\ 3B,\ 4,\ 5A,\ 5B,\ c_{s+1}.
\label{rail}
\end{equation}
All edge amplitudes in the encoded station description are $g$. For control qubit $a_s$ and target $b_s$, the internal $1A\leftrightarrow1B$ and $5A\leftrightarrow5B$ transitions are multiplied by $P_{a_s,1}$ on the upper rail and $P_{a_s,0}$ on the lower rail. The upper $3A\leftrightarrow3B$ transition applies $X_{b_s}$; the lower one applies identity. All other transitions in~\eqref{rail} are unconditional. Here $P_{a,z}=\ket z\bra z$ on control $a$.

These encoded transitions have physical two-body realizations. An unconditional hop from a single clock qubit $x$ to state $A$ or $B$ of a pair has components
\begin{equation}
 \frac{\sigma g}{2\sqrt2}(X_yX_x+Y_yY_x),\qquad y\in\{p,q\},
\label{hop}
\end{equation}
with $(\sigma_p,\sigma_q)=(+1,+1)$ for $A$ and $(-1,+1)$ for $B$. The pair operator
\begin{equation}
 D_{pq}=\frac{Z_p-Z_q}{2}
\end{equation}
exchanges $A$ and $B$ and annihilates $O$. The control transitions are $gD_{pq}P_{a,z}$; expanding $P_{a,z}$ gives only $Z_p,Z_q,Z_pZ_a,Z_qZ_a$. The upper middle transition $gD_{pq}X_b$ gives two $ZX$ terms; the lower one gives two one-body $Z$ terms. Thus every listed physical term has support at most two. Matched $XX+YY$ terms and diagonal clock $Z$ factors preserve total clock excitation number.

\section{Exact invariant dynamics}
The one-clock-excitation sector has 52 clock basis states and a four-dimensional data system. Let $H_q$ be the encoded-station generator on this 208-dimensional sector, and let $T$ change the physical excitation basis into~\eqref{encoding}. Integer matrices supplied by the replay give
\begin{equation}
 T=(T_a+\sqrt2T_b)/2,\qquad
 H_{\rm phys}/g=(H_a+\sqrt2H_b)/2.
\end{equation}
Equality of the rational and radical coefficients separately certifies $T^\dagger T=I$ and
\begin{equation}
 H_{\rm phys}(T\otimes I_4)=(T\otimes I_4)H_q.
\label{first}
\end{equation}
The Pauli ledger is independently reconstructed to verify its restriction equals the displayed sector generator. Paired exchange terms also certify that this sector is invariant in the full physical Hilbert space; no $2^{54}$-dimensional simulation is assumed.

The computational history is not just the 27-edge backbone. Each gate has a wrong-rail entry leaf and a wrong-rail exit leaf, both attached to a port by unconditional hopping. Including these six reachable blind leaves gives a tree with 34 vertices and 33 edges. Omitting them would give an incorrect propagation model.

For completeness, its isometry $W$ is defined on every four-dimensional input. Let $P_s=G_{s-1}\cdots G_0$, with $P_0=I$. At a backbone station before the middle flip, map data by $P_{a_s,0}P_s$ onto the lower rail and $P_{a_s,1}P_s$ onto the upper rail. After that flip replace $P_s$ by $P_{s+1}$. The ``before'' stations are $1A,1B,2,3A$; the ``after'' stations are $3B,4,5A,5B$. At a port map by $P_s$. The entry leaf interchanges upper/lower projectors at station $1A$, using $P_s$; the exit leaf does so at $5B$, using $P_{s+1}$. These definitions cover all vertices and determine $W$.

Let $K$ denote the integer adjacency matrix of this 34-vertex graph. The replay verifies exactly
\begin{equation}
 W^\dagger W=I_{136},\qquad H_qW=W(gK\otimes I_4).
\end{equation}
Write $\Omega=(T\otimes I_4)W$.
\begin{theorem}[Exact encoded simulation]
On the admitted computational sector,
\begin{equation}
 e^{-itH_{\rm phys}}\Omega=\Omega(e^{-igtK}\otimes I_4)
\label{dynamics}
\end{equation}
for all real $t$. Compiler leakage and normalized diamond distance to this expanded-graph reference are zero, including arbitrary input correlations with an untouched spectator.
\end{theorem}
\begin{proof}
Combine~\eqref{first} with the second intertwining identity, then exponentiate the power series. Tensoring the operator equality with spectator identity and applying it to a purification proves the channel statement for every mixed input.
\end{proof}
This theorem certifies exact simulation of the \emph{new} 34-vertex reference. It does not equate that reference with the original two-address history generator.

\section{Completion differs from compilation fidelity}
Let $v_0,v_f$ be the first and last port vertices of $K$ and let $\mathcal E_0$ launch the clock at $c_0$. Equation~\eqref{dynamics} implies
\begin{equation}
 (\bra{c_3}\otimes I)e^{-itH_{\rm phys}}\mathcal E_0
 =\alpha(t)S,\quad
 \alpha(t)=\bra{v_f}e^{-igtK}\ket{v_0}.
\end{equation}
Consequently a final-port measurement, when successful, gives the exact SWAP, independently of data and spectator input. Its success probability is $q(t)=|\alpha(t)|^2$. This conditional statement is not a deterministic capture guarantee.

For the full-domain target $\mathcal B\ket\psi=\ket{c_3}S\ket\psi$, the overlap of the actual and target isometries is $\alpha(t)^*I_4$. It follows that the exact unconditional distance is
\begin{equation}
 \frac12\|\mathcal A_t-\mathcal B\|_\diamond
 =\sqrt{1-q(t)},
\label{arrivalerror}
\end{equation}
where $\mathcal A_t$ and $\mathcal B$ here denote the channels induced by those isometries. To see this, decompose the actual isometry into its $\alpha\mathcal B$ component and an orthogonal isometry scaled by $\sqrt{1-q}$. The channel difference becomes a two-dimensional matrix tensored with the input density operator. Its two nonzero eigenvalues are $\pm\sqrt{1-q}$, so every input, including a purification, attains~\eqref{arrivalerror}. No clock or donor marginal is silently substituted for this full-domain task.

At $g=1/8$, a 4097-point numerical grid over $[0,1024]$ gives a largest sampled $q=0.4739700233$ at $t=687.75$ (Fig.~\ref{arrival}). This is a diagnostic, not an interval certificate or a global optimum. In particular it does not prove impossibility of better arrival at other times. We claim no high-fidelity completion deadline for this candidate.
\begin{figure}[t]
\centering\includegraphics[width=\columnwidth]{../figures/FINAL_PORT.pdf}
\caption{Sampled final-port probability on a uniform time grid. The marked point is the largest sampled value only. Exact compiler fidelity does not imply efficient arrival.}\label{arrival}
\end{figure}

\section{Physical resources and geometry}
\begin{table}[t]
\caption{Resources for this SWAP primitive only}\label{resources}
\centering\begin{tabular}{lr}\hline
Quantity & Count\\\hline
Paired clock stations &18\\
Single clock stations (including ports)&16\\
Physical clock qubits&52\\
Data qubits&2\\
Total physical qubits&54\\
One-train joint sector dimension&208\\
Computational graph vertices&34\\
Computational joint dimension&136\\
One-/two-body Pauli terms&204\\
Distinct two-body interaction pairs&102\\
Maximum interaction degree&18\\\hline
\end{tabular}
\end{table}
The counts in Table~\ref{resources} charge both qubits of every encoded qutrit. A native-qudit alternative uses 18 qutrit stations, 16 qubit stations, and two data qubits, or 36 sites. That is a different hardware model, not a 36-qubit realization. The single train is delocalized over many physical qubits; it cannot be counted as one physical qubit. The largest degree belongs to data qubit $A$; no bounded-degree claim for an extended episode follows from this instance.

The physical graph has a Kuratowski subdivision with 11 vertices and 14 edges. Suppressing its degree-two vertices produces $K_{3,3}$ with parts
\begin{equation}
 \{A,u3{:}p,u3{:}q\},\qquad\{O_1,u2,u4\},
\end{equation}
where the stations are on the upper rail of the third CNOT. Figure~\ref{minor} displays the resulting minor. Its apparent $A$--$O_1$ edge is a contracted path through other stations, not a physical direct interaction. The original witness, all physical edges, and its replay are included.
\begin{figure}[t]
\centering\includegraphics[width=\columnwidth]{../figures/NONPLANAR_MINOR.pdf}
\caption{A $K_{3,3}$ minor of the physical interaction graph. Labels u2, u4, and u3 refer to the third gate's upper rail. Edges represent paths after contraction.}\label{minor}
\end{figure}
Thus this graph cannot be placed in a strictly planar interaction layout without changing the implementation or charging extra routing resources. This is a countercertificate for the displayed candidate, not a no-go theorem for every planar two-local SWAP. Neither minimum ancilla count nor geometric realizability is established.

\section{Finite arithmetic and perturbation ledger}
The only irrational physical coefficients at $g=1/8$ are 144 signed instances of $\sqrt2/32$. The remaining 60 coefficients are exactly dyadic. Put
\begin{equation}
 b=\lfloor\sqrt{2\,2^{160}}\rfloor,\quad
 \ell=b/2^{80},\quad u=(b+1)/2^{80}.
\end{equation}
The integer square-root computation verifies $\ell^2<2<u^2$. If $r$ is the exact rational value of the binary64 number used to represent $\sqrt2/32$, the whole physical operator mismatch has the certified bound
\begin{equation}
 d\le144\max\{|r-\ell/32|,|r-u/32|\}.
\end{equation}
This follows from the triangle inequality and unit norm of every physical Pauli string, without restricting the perturbation to the legal sector. Duhamel's identity then bounds normalized diamond distance between rounded and ideal unitary channels by $\min\{1,|t|d\}$. For $|t|\le1024$, the exact rational certificate is
\begin{equation}
 |t|d\le\frac{1051833645}{2361183241434822606848}
 \approx4.455\,10^{-13}<2^{-40}.
\end{equation}
This is a representation-error certificate, not a hardware calibration tolerance or the completion error~\eqref{arrivalerror}. With launch error $\epsilon_B$ and a separately bounded physical generator mismatch $d_{\rm hw}$, an unconditional ledger may use
\begin{equation}
 \delta_{\rm task}(t)\le
 \min\{1,\epsilon_B+|t|(d+d_{\rm hw})+\sqrt{1-q(t)}\}.
\end{equation}
Each debit must refer to the same admitted joint domain. Excitation-loss and extra-train errors, nonunitary noise, and spectator coupling require their own explicit admission bounds.

The legal computational generator has $\|gK\|\le4g=1/2$. In contrast, the full 54-qubit physical Hamiltonian has a Pauli-triangle norm upper bound of approximately 8.614. The latter is an upper bound, not an exact norm or a lower bound; it cannot alone prove violation of a hardware norm ceiling. A matched comparison must choose whether it constrains term strengths, incident interaction strengths, a sector norm, or the full operator norm.

\section{Replay, claim boundary, and next experiment}
The package replay passes 24 exact algebra/arithmetic checks and 16 numerical checks. The largest numerical residual is $1.015\,10^{-14}$ against tolerance $10^{-10}$. Checks cover all four input basis dimensions, exact launch and final-port maps, clock-number conservation, the physical ledger, and an entangled spectator. Exact identities provide the all-input/all-time guarantee; the finite numerical samples are consistency tests and do not replace the proofs.

The first development gate is achieved: an explicit two-body baseline with an exact dynamical certificate. The desired breakthrough gate remains open. It requires a smaller geometrically admissible candidate and a certified operational deadline under a common coupling budget. The next comparison should (i) minimize direct encoding and routing resources, (ii) develop a planar alternative or charge nonplanar connectivity explicitly, and (iii) compare against both a timed-control implementation and a perturbative compiler at the same full-domain error and completion task. Padding or engineered couplings must be charged if used to improve arrival. Only after that gate should the complete thirteen-step episode and a dissipative latch be integrated.

This result does not establish closed-loop clock renewal, thermodynamic refreshment, fault tolerance, independence from all external preparation/readout, or a physical UD--GR/QFT correspondence. Geometry can motivate an MQM design hypothesis without supplying those missing proofs. The generic existence of autonomous two-local computation is not the novelty claim. Physical evidence remains 0; independent theorem-level review is pending.

\begin{thebibliography}{2}
\bibitem{nagaj} D. Nagaj, ``Universal 2-local Hamiltonian quantum computing,'' \emph{Phys. Rev. A}, vol. 85, p. 032330, 2012, doi: 10.1103/PhysRevA.85.032330. arXiv:1002.0420v2.
\bibitem{oliveira} R. Oliveira and B. M. Terhal, ``The complexity of quantum spin systems on a two-dimensional square lattice,'' \emph{Quantum Inf. Comput.}, vol. 8, no. 10, pp. 900--924, 2008. arXiv:quant-ph/0504050v6.
\end{thebibliography}
\end{document}
'''
name='MQM_TWO_LOCAL_SWAP_IEEE_A4_v0.1'
(M/(name+'.tex')).write_text(tex)
for i in range(3):
 p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,capture_output=True,text=True)
 (R/'results'/f'LATEX_PASS_{i+1}.txt').write_text(p.stdout)
 if p.returncode:raise RuntimeError(p.stdout[-5000:])
log=(M/(name+'.log')).read_text()
assert 'Overfull' not in log, 'Fix overfull boxes before release'
doc=fitz.open(M/(name+'.pdf'));qa=[]
Q=R/'results'/'visual_qa';Q.mkdir(exist_ok=True)
for i,page in enumerate(doc):
 assert abs(page.rect.width-595.276)<.6 and abs(page.rect.height-841.89)<.6
 page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(Q/f'page_{i+1}.png')
 qa.append({'page':i+1,'width_pt':page.rect.width,'height_pt':page.rect.height,'text_characters':len(page.get_text())})
assert '??' not in ''.join(p.get_text() for p in doc)
(R/'results'/'PDF_FORMAT_RECEIPT.json').write_text(json.dumps({'format':'IEEEtran journal, A4, 10pt, two columns','pages':qa,'overfull_boxes':False,'unresolved_references':False,'visual_review':'PENDING'},indent=2)+'\n')
print(json.dumps({'pdf':str(M/(name+'.pdf')),'page_count':len(doc),'format':'IEEEtran A4','replay_exact_checks':receipt['exact_check_count']},indent=2))
