"""Exact encoded two-local SWAP baseline; no simulation of the entire 54-qubit space.
Run OPENBLAS_NUM_THREADS=1 python3 replay_swap.py. Finite-time samples are diagnostics.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt,sqrt
from itertools import product
import json,csv
import numpy as np
from scipy.linalg import eigh,expm
import networkx as nx
R=Path(__file__).resolve().parent;O=R/'results';O.mkdir(exist_ok=True)
exact=[];nums=[]
def ck(name,c):
 if not c:raise AssertionError(name)
 exact.append(name)
def nm(name,x,tol=1e-10):
 x=float(x)
 if not np.isfinite(x) or x>tol:raise AssertionError((name,x))
 nums.append({'name':name,'residual':x,'tolerance':tol})
I=np.eye(4,dtype=np.int64);X=np.array([[0,1],[1,0]],dtype=np.int64)
bodyX=[np.kron(X,np.eye(2,dtype=int)),np.kron(np.eye(2,dtype=int),X)]
def proj(q,b):
 z=np.diag([1,0]) if b==0 else np.diag([0,1])
 return np.kron(z,np.eye(2,dtype=int)) if q==0 else np.kron(np.eye(2,dtype=int),z)
def cnot(c,t):return proj(c,0)+bodyX[t]@proj(c,1)
Gs=[cnot(0,1),cnot(1,0),cnot(0,1)];P=[I]
for gg in Gs:P.append(gg@P[-1])
SW=np.array([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]],dtype=np.int64)
ck('three CNOT word exactly SWAP',np.array_equal(P[-1],SW))
# Active Bell states: A=(|10>+|01>)/sqrt2, B=(|01>-|10>)/sqrt2.
phys=['c0','c1','c2','c3'];enc=phys.copy();pairs={};singles={x:x for x in phys}
for s in range(3):
 for rail in ['u','l']:
  for j in [1,2,3,4,5]:
   label=f's{s}_{rail}{j}'
   if j in [1,3,5]:
    pairs[label]=(label+'_p',label+'_q');phys.extend(pairs[label]);enc.extend([label+'A',label+'B'])
   else:singles[label]=label;phys.append(label);enc.append(label)
D=len(phys);ck('physical clock count 52',D==52)
pi={x:i for i,x in enumerate(phys)};ei={x:i for i,x in enumerate(enc)}
Ta=np.zeros((D,D),dtype=np.int64);Tb=np.zeros_like(Ta)
for x in singles:Ta[pi[x],ei[x]]=2
for l,(p,q) in pairs.items():
 Tb[pi[p],ei[l+'A']]=Tb[pi[q],ei[l+'A']]=1
 Tb[pi[p],ei[l+'B']]=-1;Tb[pi[q],ei[l+'B']]=1
ck('exact clock encoding isometry rational part',np.array_equal(Ta.T@Ta+2*Tb.T@Tb,4*np.eye(D,dtype=int)))
ck('exact clock encoding isometry radical part',not np.any(Ta.T@Tb+Tb.T@Ta))
Hq=np.zeros((4*D,4*D),dtype=np.int64);Ha=np.zeros_like(Hq);Hb=np.zeros_like(Hq);terms=[]
def term(support,pauli,a,b=F(0)):
 terms.append({'support':support,'pauli':pauli,'coefficient_over_g':{'a':str(a),'b':str(b),'field':'a+b*sqrt2'}})
def block(M,j,k,U):M[4*j:4*j+4,4*k:4*k+4]+=U
def hop(pair,state,single):
 j=ei[pair+state];k=ei[single];block(Hq,j,k,I);block(Hq,k,j,I)
 p,q=pairs[pair]
 for site,sg in [(p,1 if state=='A' else -1),(q,1)]:
  block(Hb,pi[site],pi[single],sg*I);block(Hb,pi[single],pi[site],sg*I)
  for pauli in ['XX','YY']:term([site,single],pauli,F(0),F(sg,4))
def internal(pair,U,kind,q=None,b=None):
 j=ei[pair+'A'];k=ei[pair+'B'];block(Hq,j,k,U);block(Hq,k,j,U)
 p,r=pairs[pair]
 for site,sg in [(p,-1),(r,1)]:block(Ha,pi[site],pi[site],2*sg*U)
 for site,sg in [(p,1),(r,-1)]:
  if kind=='control':
   term([site],'Z',F(sg,4));term([site,['A','O1'][q]],'ZZ',F(sg*(1 if b==0 else -1),4))
  elif kind=='flip':term([site,['A','O1'][q]],'ZX',F(sg,2))
  else:term([site],'Z',F(sg,2))
for s,(control,target) in enumerate([(0,1),(1,0),(0,1)]):
 for rail,b in [('u',1),('l',0)]:
  l=lambda j:f's{s}_{rail}{j}'
  hop(l(1),'A',f'c{s}');internal(l(1),proj(control,b),'control',q=control,b=b)
  hop(l(1),'B',l(2));hop(l(3),'A',l(2))
  internal(l(3),bodyX[target] if rail=='u' else I,'flip' if rail=='u' else 'identity',q=target)
  hop(l(3),'B',l(4));hop(l(5),'A',l(4));internal(l(5),proj(control,b),'control',q=control,b=b)
  hop(l(5),'B',f'c{s+1}')
ck('every physical term has support at most two',all(1<=len(x['support'])<=2 for x in terms))
Ntwo=np.diag([0,1,1,2]);XX=np.kron(X,X)
Y=np.array([[0,-1j],[1j,0]]);XYexchange=XX+np.kron(Y,Y)
ck('matched XX+YY exchange conserves train number',not np.any(XYexchange@Ntwo-Ntwo@XYexchange))
ck('all nonexchange clock factors diagonal Z',all(t['pauli'] in ['XX','YY','Z','ZZ','ZX'] for t in terms))
ck('physical Pauli terms 204',len(terms)==204)
ck('rational Hamiltonian Hermitian',np.array_equal(Ha,Ha.T));ck('radical Hamiltonian Hermitian',np.array_equal(Hb,Hb.T))
# Independently reconstruct the one-train restriction from the serialized Pauli ledger.
La=np.zeros_like(Ha);Lb=np.zeros_like(Hb)
for term0 in terms:
 support=term0['support'];pauli0=term0['pauli']
 Q=np.zeros_like(Ha)
 if pauli0 in ['XX','YY']:
  j,k=[pi[x] for x in support];block(Q,j,k,I);block(Q,k,j,I)
 else:
  site=pi[support[0]]
  B=I if len(support)==1 else (bodyX[['A','O1'].index(support[1])] if pauli0=='ZX' else 2*proj(['A','O1'].index(support[1]),0)-I)
  for j in range(D):block(Q,j,j,(-1 if j==site else 1)*B)
 for M,key in [(La,'a'),(Lb,'b')]:
  c=4*F(term0['coefficient_over_g'][key]);assert c.denominator==1
  M+=c.numerator*Q
ck('serialized Pauli ledger reproduces rational sector generator',np.array_equal(La,2*Ha))
ck('serialized Pauli ledger reproduces radical sector generator',np.array_equal(Lb,2*Hb))
Taa=np.kron(Ta,I);Tbb=np.kron(Tb,I)
ck('exact physical/encoded intertwining rational part',np.array_equal(Ha@Taa+2*Hb@Tbb,2*Taa@Hq))
ck('exact physical/encoded intertwining radical part',np.array_equal(Ha@Tbb+Hb@Taa,2*Tbb@Hq))
vertices=['port0'];neighbors=[];maps=[]
def vec(spec):
 M=np.zeros((4*D,4),dtype=np.int64)
 for label,U in spec:M[4*ei[label]:4*ei[label]+4]+=U
 return M
maps.append(vec([('c0',I)]));ports=[0];leaves=[];paths=[]
for s,(control,target) in enumerate([(0,1),(1,0),(0,1)]):
 old=ports[-1];ids=[]
 for stage in ['1A','1B','2','3A','3B','4','5A','5B']:
  prefix=P[s] if stage in ['1A','1B','2','3A'] else P[s+1]
  ids.append(len(vertices));vertices.append(f's{s}_{stage}')
  maps.append(vec([(f's{s}_l{stage}',proj(control,0)@prefix),(f's{s}_u{stage}',proj(control,1)@prefix)]))
 end=len(vertices);vertices.append(f'port{s+1}');maps.append(vec([(f'c{s+1}',P[s+1])]));ports.append(end)
 path=[old]+ids+[end];neighbors.extend(zip(path[:-1],path[1:]));paths.append(path)
 for label,stage,port,U in [('entry','1A',old,P[s]),('exit','5B',end,P[s+1])]:
  j=len(vertices);vertices.append(f's{s}_wrong_{label}')
  maps.append(vec([(f's{s}_u{stage}',proj(control,0)@U),(f's{s}_l{stage}',proj(control,1)@U)]))
  neighbors.append((port,j));leaves.append((port,j))
W=np.column_stack(maps);C=len(vertices);K=np.zeros((C,C),dtype=np.int64)
for j,k in neighbors:K[j,k]=K[k,j]=1
ck('computational graph count 34',C==34)
ck('exact full-input computational isometry',np.array_equal(W.T@W,np.eye(4*C,dtype=int)))
ck('exact computational subspace invariance',np.array_equal(Hq@W,W@np.kron(K,I)))
ck('exact launch port map',np.array_equal(W[:,4*ports[0]:4*ports[0]+4],vec([('c0',I)])))
ck('exact final port SWAP map',np.array_equal(W[:,4*ports[-1]:4*ports[-1]+4],vec([('c3',SW)])))
pa={'I':np.eye(2),'X':np.array([[0,1],[1,0]]),'Y':np.array([[0,-1j],[1j,0]]),'Z':np.diag([1,-1])}
Hbare=np.kron(pa['X'],SW);coeffs={}
for z in product(pa,repeat=3):
 Q=np.kron(np.kron(pa[z[0]],pa[z[1]]),pa[z[2]]);c=np.trace(Q.conj().T@Hbare)/8
 if abs(c)>1e-12:coeffs[''.join(z)]=str(F(float(c.real)))
ck('bare target has three weight-three terms',coeffs=={'XII':'1/2','XXX':'1/2','XYY':'1/2','XZZ':'1/2'})
# Exact interval for the only irrational physical coefficient, ±sqrt2/32 at g=1/8.
g=F(1,8);root=isqrt(2*(2**80)**2);lo=F(root,2**80);hi=F(root+1,2**80)
ck('sqrt2 rational enclosure',lo*lo<2<hi*hi)
rounded=F.from_float(float(np.sqrt(2)/32));one=max(abs(rounded-lo/32),abs(rounded-hi/32));d=144*one;bound=1024*d
ck('coefficient-rounding channel bound below 2^-40 on [0,1024]',bound<F(1,2**40))
full_bound=sum((g*(abs(F(t['coefficient_over_g']['a']))+abs(F(t['coefficient_over_g']['b']))*hi) for t in terms),F(0))
sector_bound=g*int(max(np.sum(K,axis=1)))
Hphys=(Ha+sqrt(2)*Hb)*float(g)/2;Tf=(Ta+sqrt(2)*Tb)/2;Wphys=np.kron(Tf,np.eye(4))@W;Kf=K*float(g)
Blaunch=Wphys[:,4*ports[0]:4*ports[0]+4]
for t in [0.,1.,17.,80.,256.]:
 actual=expm(-1j*t*Hphys)@Blaunch;clock=expm(-1j*t*Kf)[:,ports[0]]
 predicted=Wphys@np.kron(clock[:,None],np.eye(4))
 nm(f'full input operator dynamics t={t}',np.linalg.norm(actual-predicted))
 nm(f'final-port SWAP block t={t}',np.linalg.norm(actual[4*pi['c3']:4*pi['c3']+4]-clock[ports[-1]]*SW))
 psi=np.zeros((4,2),complex);psi[0,0]=psi[3,1]=1/sqrt(2)
 nm(f'entangled spectator dynamics t={t}',np.linalg.norm(actual@psi-predicted@psi))
Gphys=nx.Graph();Gphys.add_nodes_from(phys+['A','O1'])
for term0 in terms:
 if len(term0['support'])==2:Gphys.add_edge(*term0['support'])
planar,cert=nx.check_planarity(Gphys,counterexample=True)
witness=None if planar else {'nodes':list(cert.nodes),'edges':[list(e) for e in cert.edges]}
minor=None
if not planar:
 ck('nonplanar witness replay',not nx.check_planarity(cert)[0])
 reduced=cert.copy()
 while any(deg==2 for node,deg in reduced.degree()):
  node=next(node for node,deg in reduced.degree() if deg==2)
  a,b=list(reduced.neighbors(node));reduced.remove_node(node);reduced.add_edge(a,b)
 ck('K3,3 subdivision certificate',len(reduced)==6 and reduced.number_of_edges()==9 and nx.is_bipartite(reduced) and all(d==3 for n,d in reduced.degree()))
 colors=nx.bipartite.color(reduced)
 minor={'vertices':list(reduced.nodes),'edges':[list(z) for z in reduced.edges],
        'parts':[[n for n in reduced if colors[n]==c] for c in [0,1]],
        'method':'Suppress degree-two vertices of the included Kuratowski subdivision.'}
# Ordinary timed swap has an endpoint implementation but does not equal the history generator.
Htimed=float(g)*(np.kron(pa['X'],np.eye(4))+np.kron(np.eye(2),SW))
tb=np.pi/(2*float(g));start=np.vstack([np.eye(4),np.zeros((4,4))]);target=np.vstack([np.zeros((4,4)),-SW])
nm('timed unconditioned two-local benchmark endpoint',np.linalg.norm(expm(-1j*tb*Htimed)@start-target))
ev,U=eigh(Kf);ts=np.linspace(0,1024,4097);a=(np.exp(-1j*np.outer(ts,ev))*U[ports[0]])@U[ports[-1]];pr=abs(a)**2;best=int(np.argmax(pr))
with (O/'FINAL_PORT_PROBABILITY.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['time','probability']);w.writeheader();w.writerows({'time':float(t),'probability':float(p)} for t,p in zip(ts,pr))
def frac(z):return {'numerator':str(z.numerator),'denominator':str(z.denominator),'decimal':float(z)}
receipt={'status':'PASS','exact_check_count':len(exact),'numerical_check_count':len(nums),'largest_numerical_residual':max(t['residual'] for t in nums),'primitive':'SWAP(A,O1) via three CNOTs','physical_clock_qubits':D,'data_qubits':2,'total_primitive_qubits':D+2,'qudit_station_version':{'qubit_stations':16,'qutrit_stations':18,'sites_including_data':36},'one_train_sector_dimension':4*D,'computational_graph_vertices':C,'computational_joint_dimension':4*C,'physical_Pauli_terms':len(terms),'physical_two_body_edges':Gphys.number_of_edges(),'physical_max_degree':max(dict(Gphys.degree()).values()),'physical_planar':planar,'nonplanar_witness':witness,'K33_minor':minor,'g':'1/8','legal_computational_norm_upper':frac(sector_bound),'full_physical_norm_triangle_upper':frac(full_bound),'rounded_coefficient_generator_norm_upper':frac(d),'time_horizon':'1024','rounding_channel_error_upper':frac(bound),'final_port_best_grid_probability':float(pr[best]),'final_port_best_grid_time':float(ts[best]),'grid_is_global_optimum':False,'bare_Pauli_expansion':coeffs,'exact_checks':exact,'numerical_checks':nums,'status_boundary':'Exact algebraic compilation under single-excitation clock preparation; independent review pending; physical promotion 0','not_claimed':['Minimum mediator graph or ancilla count','Planar physical interactions','Resource improvement on the thirteen-step episode','Deterministic final-port SWAP at a certified deadline','Equivalence to the original two-address history generator','Fault tolerance or supervisor renewal']}
(O/'REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
(R/'PHYSICAL_TERMS.json').write_text(json.dumps({'g':'1/8','qubits':phys+['A','O1'],'terms':terms},indent=2)+'\n')
(R/'COMPUTATIONAL_GRAPH.json').write_text(json.dumps({'vertices':vertices,'edges':[list(z) for z in neighbors],'ports':ports,'paths':paths,'leaves':[list(z) for z in leaves]},indent=2)+'\n')
(O/'PHYSICAL_GRAPH.json').write_text(json.dumps({'vertices':list(Gphys.nodes),'edges':[list(z) for z in Gphys.edges],'planar':planar,'witness':witness},indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','exact_check_count','numerical_check_count','largest_numerical_residual','total_primitive_qubits','physical_Pauli_terms','physical_two_body_edges','physical_max_degree','physical_planar','rounding_channel_error_upper','final_port_best_grid_probability','final_port_best_grid_time']},indent=2))
