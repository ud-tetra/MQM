MQM TWO-LOCAL SWAP BASELINE v0.1
Date: 2026-10-05. Independent review pending. Physical promotion 0.

This release begins the clock-controlled SWAP(A,O1) compilation. It gives an
explicit direct two-local encoded baseline adapted from Nagaj (2012). It is
not a minimal mediator graph and is not a demonstrated resource improvement.

Main findings
- Original unrestricted three-qubit history generator has weight-three terms.
- Timed ordinary SWAP admits a two-local endpoint benchmark; that is a
  different dynamical task from a clock-coupled autonomous history edge.
- This encoded candidate uses 52 clock qubits plus 2 data qubits, 204 Pauli
  terms, 102 two-body interaction pairs and maximum physical degree 18.
- All-time encoded simulation and invariance are exact on the admitted sector.
- The physical graph is nonplanar, certified by a K3,3 subdivision.
- The expanded computational graph has 34 vertices, including six blind leaves.
- No high-fidelity deterministic completion deadline is certified.
- Coefficient representation debit < 2^-40 through time 1024 at g=1/8.
  This does not bound hardware noise or replace the final-port arrival debit.

Reproduce from the release root:
  OPENBLAS_NUM_THREADS=1 python3 replay_swap.py
  OPENBLAS_NUM_THREADS=1 python3 build_ieee_note.py
The replay requires numpy, scipy, networkx. The PDF build also requires
matplotlib, PyMuPDF, pdfLaTeX and the packages in DEPENDENCIES.json.
No network access is needed. The IEEEtran class and LPPL license are included.
Expected replay: 24 exact checks, 16 numerical checks, PASS.
Expected paper: actual IEEEtran journal style, A4, 10pt, two columns, 4 pages.

Key files
  PHYSICAL_TERMS.json: every physical Pauli support and exact field coefficient.
  COMPUTATIONAL_GRAPH.json: full backbone, ports and blind-leaf graph.
  results/REPLAY_RECEIPT.json: scopes, counts and exact fraction certificates.
  results/PHYSICAL_GRAPH.json: all interactions and nonplanar witness.
  results/FINAL_PORT_PROBABILITY.csv: sampled arrival diagnostic, not a proof.
  manuscript/MQM_TWO_LOCAL_SWAP_IEEE_A4_v0.1.pdf and .tex: development note.
  CLAIM_REGISTER_v0.1.json: precise claim and nonclaim boundaries.
  COMPARISON_CONTRACT_v0.1.json: matched comparison conditions.
  WBS_PROGRESS_v0.1.json: concrete next research gate.

Arithmetic certificates are reproducible; PDF bytes and plotting metadata may
vary across platforms. A full 2^54 matrix is neither formed nor simulated.
Conservation and exact sector identities justify the reduced computation.
The construction preserves spectators by an operator identity, not by assuming
that external correlations vanish. Preparation outside the admitted clock
sector, calibration, excitation loss and reservoir effects need new ledgers.

Next gate: smaller geometrically admissible encoding plus a certified useful
arrival deadline at a matched coupling budget. Extend the complete thirteen-
step episode only after this gate; integrate the dissipative latch afterward.

All future MQM paper PDFs: IEEE formatting and A4, per the user's instruction.
This development template does not imply IEEE submission or acceptance.
