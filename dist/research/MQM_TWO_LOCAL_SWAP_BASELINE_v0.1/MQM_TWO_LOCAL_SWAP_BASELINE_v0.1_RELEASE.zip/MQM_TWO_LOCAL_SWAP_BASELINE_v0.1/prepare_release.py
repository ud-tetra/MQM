"""Write claim scope, comparison contract, provenance and a checked archive.
Run after replay_swap.py, build_ieee_note.py and recorded visual QA.
"""
from pathlib import Path
import hashlib,json,platform,zipfile
import numpy,scipy,matplotlib,networkx,fitz
R=Path(__file__).resolve().parent
def dump(name,obj):(R/name).write_text(json.dumps(obj,indent=2)+'\n')
receipt=json.loads((R/'results/REPLAY_RECEIPT.json').read_text())
qa=json.loads((R/'results/PDF_FORMAT_RECEIPT.json').read_text())
assert receipt['status']=='PASS' and qa['visual_review']=='PASS'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
template=json.loads((R/'TEMPLATE_PROVENANCE.json').read_text())
assert sha(R/'manuscript/IEEEtran.cls')==template['class_sha256']
assert sha(R/'manuscript/LPPL-1.3c.txt')==template['license_sha256']
dump('CLAIM_REGISTER_v0.1.json',{
 'version':'0.1','date':'2026-10-05','independent_review':'pending','physical_promotion':0,
 'claims':[
 {'id':'S1','status':'EXACT DERIVATION','claim':'The bare three-qubit generator g Xc tensor SWAP has three nonzero weight-three coefficients and cannot equal a two-local sum on the same unrestricted space.','boundary':'Not a no-go for timed unitaries, encoding, or ancillary simulation.'},
 {'id':'S2','status':'EXACT CONSTRUCTION REPLAY','claim':'The 54-qubit Pauli ledger is two-local and admits an invariant 136-dimensional computational sector within the 208-dimensional one-train joint sector.','boundary':'This is an adaptation of Nagaj direct encoding, not a generic two-local universality novelty claim.'},
 {'id':'S3','status':'EXACT DYNAMICAL CERTIFICATE','claim':'Hphys Omega = Omega (g K tensor I4), including the six wrong-rail leaves, certifies zero compiler leakage and normalized diamond error at all times.','boundary':'Relative to the expanded 34-vertex graph, not the original two-address generator.'},
 {'id':'S4','status':'EXACT DERIVATION','claim':'Final-port branch is alpha(t) SWAP, and complete-domain distance to the fixed final-port SWAP target is sqrt(1-|alpha(t)|^2).','boundary':'Success may be less than one; conditional correctness is not deterministic capture.'},
 {'id':'S5','status':'EXACT GRAPH COUNTERCERTIFICATE','claim':'The displayed 102-edge physical interaction graph contains a K3,3 subdivision and is nonplanar.','boundary':'No universal planar-compilation obstruction is claimed.'},
 {'id':'S6','status':'EXACT RATIONAL CERTIFICATE','claim':'Binary64 representation of 144 irrational coefficients gives a full-operator/channel rounding debit below 2^-40 on [0,1024], at g=1/8.','boundary':'Representation error only; not calibration, preparation, decoherence, or arrival accuracy.'},
 {'id':'S7','status':'NUMERICAL DIAGNOSTIC','claim':'Largest sampled final-port probability 0.4739700232738219 at time 687.75, on a 4097-point grid.','boundary':'No interval enclosure or global optimum; no impossibility theorem about other times.'},
 {'id':'S8','status':'OPEN','claim':'Minimum physical mediator count, planar implementation, certified useful deadline, and matched resource improvement.'},
 {'id':'S9','status':'NOT ESTABLISHED','claim':'Physical realization, fault tolerance, thermodynamic refreshment, supervising clock renewal, UD-GR/QFT correspondence, or complete thirteen-step local implementation.'}
 ]})
dump('COMPARISON_CONTRACT_v0.1.json',{
 'task':'Arbitrary-input SWAP(A,O1) embedded in a fixed quantum history, preserving complete-domain and spectator correlations.',
 'required_common_conditions':['Launch encoding and its preparation costs','Completion target and deadline/readout window','Normalized diamond or complete joint trace distance','Physical qubit/qudit inventory including clock, routing and mediators','Per-term and per-site coupling budgets with units','Specified geometric graph and permitted crossings/nonlocal links','Retained output/donor/spectator registers and export accounting'],
 'candidate':{'model':'Direct encoded two-local fixed Hamiltonian','qubits':54,'two_body_pairs':102,'max_degree':18,'planar':False,'compiler_error':'0 exactly in admitted ideal sector','completion_deadline':'not certified'},
 'benchmarks':[
 {'model':'Original unencoded two-address history edge','qubits':3,'status':'Generator has weight-three terms; not in two-local physical class.'},
 {'model':'Timed SWAP plus independent clock flip','qubits':3,'status':'Two-local endpoint benchmark at pi/(2g); differs in intermediate dynamics and does not embed autonomous phase control.'},
 {'model':'Perturbative mediator compiler','status':'Candidate construction, penalty budget and real-time dynamical comparison pending.'}
 ],
 'norms_at_g_1_over_8':{'computational_sector_upper':'1/2','full_physical_Pauli_triangle_upper':receipt['full_physical_norm_triangle_upper'],'warning':'An upper bound alone does not prove violation of a norm ceiling.'},
 'binary_address_warning':'34 abstract vertices could be labelled in 6 bits, but that is not this 52-clock-qubit interaction encoding. D <= 32 is necessary for a 5-bit logical address; compiler and routing costs remain additional.',
 'improvement_claim':'none'})
dump('WBS_PROGRESS_v0.1.json',{
 'finished':['Bare generator Pauli obstruction','Explicit direct physical Pauli ledger','Independent sector reconstruction of ledger','Exact computational invariance with blind leaves','Spectator-inclusive dynamics','Physical interaction audit and K3,3 witness','Coefficient rounding enclosure','IEEEtran A4 development note'],
 'next_gate':'Useful planar or geometrically specified primitive with a certified operational deadline under a matched physical coupling budget.',
 'next_actions':[
 {'priority':1,'action':'Search smaller direct encodings and either planarize or explicitly cost nonplanar routing.','acceptance':'Explicit interactions, full invariant-sector proof or certified leakage, and an honest physical resource count.'},
 {'priority':2,'action':'Certify final-port arrival over a defined deadline window; compare engineered couplings, padding and readout.','acceptance':'Unconditional complete-domain error enclosure, with every added clock site and coupling charged.'},
 {'priority':3,'action':'Construct a perturbative planar baseline and compare to direct encoding and timed control.','acceptance':'Same input, target, noise/domain, physical coupling ceiling and operational deadline; include penalties and mediators.'},
 {'priority':4,'action':'Extend to the thirteen-step episode only after the primitive passes the resource/deadline gate.','acceptance':'Whole-bank encoding, real-time error/leakage certificate and physical graph audit.'},
 {'priority':5,'action':'Integrate dissipative terminal latch and clock refresh separately.','acceptance':'Explicit open-system reservoir, reverse thermal channels, correlation export and replenishment ledger.'}
 ],
 'future_paper_PDF_format':'IEEEtran, A4, two columns; exact venue template to be selected later.',
 'physical_promotion':0})
dump('SOURCE_PROVENANCE.json',{
 'method':[{'author':'Daniel Nagaj','title':'Universal 2-local Hamiltonian Quantum Computing','journal':'Physical Review A 85, 032330 (2012)','doi':'10.1103/PhysRevA.85.032330','url':'https://arxiv.org/abs/1002.0420v2','role':'Direct entangled-clock routing and qutrit-to-qubit encoding; prior art.'},
 {'authors':'Roberto Oliveira and Barbara M. Terhal','title':'The complexity of quantum spin systems on a two-dimensional square lattice','journal':'Quantum Information & Computation 8(10), 900-924 (2008)','url':'https://arxiv.org/abs/quant-ph/0504050v6','role':'Perturbative square-lattice comparison route; not replayed here.'}],
 'new_instance':'Three-CNOT SWAP compilation; executable physical ledger, admitted-sector identities, blind-leaf graph, K3,3 witness, finite arithmetic certificate.',
 'user_inputs':'Pasted independent-review and priority drafts in this conversation; citation numbers lacked a supplied bibliography and were not treated as verified references.',
 'verification_date':'2026-10-05'})
anchors=[]
for f in ['MQM_FINITE_CLOCK_CERTIFICATION_v0.1_RELEASE.zip','MQM_DISSIPATIVE_LATCH_AUDIT_v0.1_RELEASE.zip']:
 p=R.parent/f
 if p.exists():anchors.append({'file':f,'sha256':sha(p),'relationship':'Prior immutable release; not changed by this branch.'})
dump('INPUT_ANCHORS.json',{'prior_release_anchors':anchors,'current_source':'User-directed local SWAP development following clock certification and dissipative audit.'})
dump('DEPENDENCIES.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__,'networkx':networkx.__version__,'pymupdf':fitz.VersionBind,'latex':'pdfLaTeX, supplied IEEEtran.cls; packages amsmath, amssymb, amsthm, graphicx, url, hyperref','runtime_note':'Exact field identities use bounded integer arrays; floats are confined to diagnostic evolution and rendered figures.'})
(R/'README.txt').write_text('''MQM TWO-LOCAL SWAP BASELINE v0.1
Date: 2026-10-05. Independent review pending. Physical promotion 0.

This release begins the clock-controlled SWAP(A,O1) compilation. It gives an
explicit direct two-local encoded baseline adapted from Nagaj (2012). It is
not a minimal mediator graph and is not a demonstrated resource improvement.

Main findings
- Original unrestricted three-qubit history generator has weight-three terms.
- Timed ordinary SWAP admits a two-local endpoint benchmark; that is a
  different dynamical task from a clock-coupled autonomous history edge.
- This encoded candidate uses 52 clock qubits plus 2 data qubits, 204 Pauli
  terms, 102 two-body interaction pairs and maximum physical degree 18.
- All-time encoded simulation and invariance are exact on the admitted sector.
- The physical graph is nonplanar, certified by a K3,3 subdivision.
- The expanded computational graph has 34 vertices, including six blind leaves.
- No high-fidelity deterministic completion deadline is certified.
- Coefficient representation debit < 2^-40 through time 1024 at g=1/8.
  This does not bound hardware noise or replace the final-port arrival debit.

Reproduce from the release root:
  OPENBLAS_NUM_THREADS=1 python3 replay_swap.py
  OPENBLAS_NUM_THREADS=1 python3 build_ieee_note.py
The replay requires numpy, scipy, networkx. The PDF build also requires
matplotlib, PyMuPDF, pdfLaTeX and the packages in DEPENDENCIES.json.
No network access is needed. The IEEEtran class and LPPL license are included.
Expected replay: 24 exact checks, 16 numerical checks, PASS.
Expected paper: actual IEEEtran journal style, A4, 10pt, two columns, 4 pages.

Key files
  PHYSICAL_TERMS.json: every physical Pauli support and exact field coefficient.
  COMPUTATIONAL_GRAPH.json: full backbone, ports and blind-leaf graph.
  results/REPLAY_RECEIPT.json: scopes, counts and exact fraction certificates.
  results/PHYSICAL_GRAPH.json: all interactions and nonplanar witness.
  results/FINAL_PORT_PROBABILITY.csv: sampled arrival diagnostic, not a proof.
  manuscript/MQM_TWO_LOCAL_SWAP_IEEE_A4_v0.1.pdf and .tex: development note.
  CLAIM_REGISTER_v0.1.json: precise claim and nonclaim boundaries.
  COMPARISON_CONTRACT_v0.1.json: matched comparison conditions.
  WBS_PROGRESS_v0.1.json: concrete next research gate.

Arithmetic certificates are reproducible; PDF bytes and plotting metadata may
vary across platforms. A full 2^54 matrix is neither formed nor simulated.
Conservation and exact sector identities justify the reduced computation.
The construction preserves spectators by an operator identity, not by assuming
that external correlations vanish. Preparation outside the admitted clock
sector, calibration, excitation loss and reservoir effects need new ledgers.

Next gate: smaller geometrically admissible encoding plus a certified useful
arrival deadline at a matched coupling budget. Extend the complete thirteen-
step episode only after this gate; integrate the dissipative latch afterward.

All future MQM paper PDFs: IEEE formatting and A4, per the user's instruction.
This development template does not imply IEEE submission or acceptance.
''')
(R/'REVIEW_RESPONSE.txt').write_text('''Review analysis and corrections

The primary direction of two-local compilation is accepted as an MQM research
priority. Its selection is not itself evidence of hardware feasibility or
superiority. The first primitive is now concrete and reviewable.

1. Physical realizability: corrected to explicit mathematical interaction
   construction. Native term access, graph placement, control calibration,
   preparation and readout must still be specified for hardware.
2. UD alignment: geometric design motivation is allowed; no proven spin-network,
   GR or QFT correspondence is imported into this quantum-computing certificate.
3. Direct versus perturbative: Nagaj supplies a prior-art exact route without
   penalty gadgets. This instance does not prove a better finite cost than a
   planar mediator construction. Its 54-qubit count and nonplanarity matter.
4. Minimal mediator claim: withheld. The construction uses no perturbative
   mediator penalties but many encoded clock qubits; these are fully charged.
5. Dynamics: exact intertwining addresses all-time motion and leakage rather
   than relying only on spectral matching. The reference is the expanded graph.
6. Autonomous capture: a correct postselected final-port branch does not certify
   deterministic arrival. The explicit arrival debit is sqrt(1-|alpha|^2).
7. Physical locality: two-body support and planar geometry are separate. This
   actual graph fails planarity via a K3,3 countercertificate.
8. Clock compression: abstract vertex labels do not compress this physical
   interaction encoding. Charge clock pairs, routing and compiler resources.
9. Fault tolerance: existing correlated-noise threshold theory is not replaced
   by a joint ledger. No threshold theorem is claimed in this primitive note.
10. Breakthrough gate: prove a matched physical resource saving, or a useful
    cross-architecture lower bound, at the same complete operational task.
    Generic autonomous two-local computation was established in prior work.

The next deliverable should attack geometry and deadline together; extending an
uncompetitive primitive to thirteen gates would not resolve the decisive gap.
''')
exclude={'.aux','.log','.out'}
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in exclude and p.name!='SHA256_MANIFEST.json' and '__pycache__' not in p.parts)
manifest={str(p.relative_to(R)):sha(p) for p in files}
dump('SHA256_MANIFEST.json',manifest)
zpath=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[R/'SHA256_MANIFEST.json']:z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for name,digest in manifest.items():assert hashlib.sha256(z.read(R.name+'/'+name)).hexdigest()==digest
print(json.dumps({'status':'PASS','file_count':len(files)+1,'zip_path':str(zpath),'zip_bytes':zpath.stat().st_size,'zip_sha256':sha(zpath)},indent=2))
