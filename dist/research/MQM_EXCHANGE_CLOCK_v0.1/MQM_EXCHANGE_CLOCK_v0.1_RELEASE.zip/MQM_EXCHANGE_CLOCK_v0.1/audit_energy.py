from pathlib import Path
import json
import numpy as np
R=Path(__file__).resolve().parent
sm=np.array([[0,1],[0,0]],dtype=int);sp=sm.T;N=np.diag([0,1]);I=np.eye(2,dtype=int)
J=np.kron(sm,sp)+np.kron(sp,sm);charge=np.kron(N,I)+np.kron(I,N)
assert np.array_equal(charge@J,J@charge)
Hres=64*charge;assert np.array_equal(Hres@J,J@Hres)
Hdet=64*np.kron(N,I)+65*np.kron(I,N)
assert not np.array_equal(Hdet@J,J@Hdet)
res={'status':'EXACT finite resonant-exchange commutators; DERIVED dressed resonance condition','exact_checks':['total excitation commutator zero','frequency64 resonant free-energy commutator zero','frequency65 detuned free-energy commutator nonzero'],'equations':['[Hlab,A_nu]=-nu A_nu','[Hlab+HB,A_nu b_omega^dagger]=(omega-nu)A_nu b_omega^dagger','[N_R+N_B,sigma_R^- b^dagger+h.c.]=0'],'scope':'Energy-conserving resonant dilation exists algebraically. Finite-band bath coupling and finite-filter GKSL are not thereby exact energy-conserving or certified microscopic realizations.','physical_promotion':0}
(R/'results/ENERGY_AUDIT.json').write_text(json.dumps(res,indent=2))
