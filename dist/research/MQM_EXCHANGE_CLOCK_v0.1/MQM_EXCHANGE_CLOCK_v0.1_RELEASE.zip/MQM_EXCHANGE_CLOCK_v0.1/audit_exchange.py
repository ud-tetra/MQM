"""Positive centered filter-Gram coarse graining of frozen Ohmic spectrum."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction
import math,json
import numpy as np
from scipy.linalg import expm
from numpy.polynomial.legendre import leggauss
R=Path(__file__).resolve().parent
P={'status':'FROZEN before successor evaluation','parent_model':'Omega64,cutoff640,betaOmega20; eight-dimensional admitted port sector','reference_kappa':8,'coarse_graining_times':['1/64','1/16','1/4','1','4'],'kernel':'K_ab=tau/(2pi) integral gamma(omega) sinc((omega-nu_a)tau/2)sinc((omega-nu_b)tau/2)domega, centered window','signed_frequencies':'exchange hypothesis: separate lowering/raising reservoirs; no cross-sign coefficients','spectral_cutoff_multiplier':48,'positive_quadrature':'composite Gauss-Legendre order16 and32, panelwidth<=min(4/tau,1), chunked Gram products; fixed numerical refinement after initial convergence failure','quadrature_comparison_tolerance':1e-9,'eigen_rounding_tolerance':1e-9,'Lamb_shift':'omitted/assumed compensated, separate unknown debit','lab_H_used':True,'time_eval':16,'target':'retained port preparation error <=1/65536; numerical diagnostic only','comparison_bound':'half-diamond <=min(1,t sum_ab |DeltaK_ab| ||A_a||||A_b||); comparison of specified generators, not microscopic bath','Born_and_memory_error':'OPEN, not bounded by PSD or coefficient convergence','physical_promotion':0}
(R/'BATH_PROTOCOL.json').write_text(json.dumps(P,indent=2))
lam=math.sqrt(4*math.sqrt(2));k=8.;Omega=64.;cut=640.;beta=20/64;alpha=k*(-math.expm1(-20))*math.exp(.1)/Omega
X=np.array([[0,1],[1,0]]);sm=np.array([[0,1],[0,0]]);sp=sm.T
C=np.zeros((4,4));C[0,1]=C[1,0]=C[1,2]=C[2,1]=1;S=np.zeros((4,4));S[3,2]=1
h=np.kron(C,np.eye(2))+lam*(np.kron(S,sp)+np.kron(S.T,sm));N=np.kron(np.diag([1,1,1,0]),np.eye(2))+np.kron(np.eye(4),np.diag([0,1]));lab=h+64*N;down=np.kron(np.eye(4),sm);A=down+down.T
E,Q=np.linalg.eigh(lab);ae=Q.T@A@Q;groups=[]
for nu,i,j,v in sorted((E[j]-E[i],i,j,ae[i,j]) for i in range(8) for j in range(8) if E[j]>E[i]+1e-9 and abs(ae[i,j])>1e-11):
 if not groups or abs(groups[-1][0]-nu)>1e-9:groups.append([nu,np.zeros((8,8))])
 groups[-1][1][i,j]=v
freq=np.array([g[0] for g in groups]+[-g[0] for g in groups]);ops=[Q@m@Q.T for nu,m in groups]+[Q@m.T@Q.T for nu,m in groups];on=np.array([np.linalg.norm(a,2) for a in ops]);n=len(freq)
klocal=np.zeros((n,n));klocal[:12,:12]=8

def gram(tau,order):
 width=min(4/tau,1.);count=math.ceil(48*cut/width);width=48*cut/count
 xs,ws=leggauss(order);K=np.zeros((n,n))
 for start in range(0,count,256):
  centers=(np.arange(start,min(start+256,count))+.5)*width
  om=(centers[:,None]+xs[None,:]*width/2).ravel();wt=np.tile(ws*width/2,len(centers))
  gd=alpha*om*np.exp(-om/cut)/(-np.expm1(-beta*om));gu=gd*np.exp(-beta*om)
  f=np.sinc((om[None,:]-freq[:12,None])*tau/(2*math.pi))
  vp=f*np.sqrt(wt*gd*tau/(2*math.pi));vm=f*np.sqrt(wt*gu*tau/(2*math.pi))
  K[:12,:12]+=vp@vp.T;K[12:,12:]+=vm@vm.T
 return K

def gen_from_jumps(H,jumps):
 I=np.eye(8);L=-1j*(np.kron(I,H)-np.kron(H.T,I))
 for j in jumps:
  c=j.conj().T@j;L+=np.kron(j.conj(),j)-.5*(np.kron(I,c)+np.kron(c.T,I))
 return L

def evolve(L):return (expm(16*L)@np.diag([1.,0,0,0,0,0,0,0]).reshape(-1,order='F')).reshape(8,8,order='F')
def td(a,b):return float(sum(abs(np.linalg.eigvalsh((a-b+(a-b).conj().T)/2)))/2)
localgen=gen_from_jumps(lab,[math.sqrt(8)*down]);local=evolve(localgen);target=np.diag([0.,0,0,0,0,0,1.,0]);rows=[];checks=[]
for st in P['coarse_graining_times']:
 tau=float(Fraction(st));a16=gram(tau,16);a32=gram(tau,32);diff=float(np.max(abs(a16-a32)));assert diff<1e-9
 vals,vec=np.linalg.eigh(a32);assert min(vals)>-1e-9
 js=[math.sqrt(max(v,0))*sum((vec[i,j]*op for i,op in enumerate(ops)),np.zeros((8,8))) for j,v in enumerate(vals) if v>0]
 rho=evolve(gen_from_jumps(lab,js));assert abs(np.trace(rho)-1)<1e-10 and min(np.linalg.eigvalsh(rho))>-1e-10
 debit=float(16*np.sum(abs(a32-klocal)*on[:,None]*on[None,:]))
 rows.append({'tau_exact':st,'coefficient_min_eigenvalue':float(min(vals)),'quadrature_max_difference':diff,'full_retained_error_at16':td(rho,target),'distance_from_local_at16':td(rho,local),'generator_comparison_bound_raw':debit,'generator_comparison_bound_capped':min(1.,debit),'numerical_target_pass':bool(td(rho,target)<1/65536),'lowest_up_block_diagonal':float(min(np.diag(a32)[12:])),'largest_up_block_diagonal':float(max(np.diag(a32)[12:])),'K_order32':a32.tolist()})
 checks.extend(['positive coefficient matrix '+st,'quadrature convergence '+st,'trace '+st,'state positivity '+st])
# Exact rational analytic tail envelope; NOT a quadrature or Born-error bound.
# alpha<5/36 using exp(1/10)<10/9; pi>3; exp(-48)<2^-69 by positive Taylor lower sum.
exp_lower=sum((Fraction(48)**j/Fraction(math.factorial(j)) for j in range(101)),Fraction(0));assert exp_lower>2**69
# |A_nu|<=1 for these nondegenerate transition matrices, checked independently.
assert max(on)<1+1e-12
exact_tail=Fraction(17*4*56**2,6)*Fraction(5,36)*640**2*49*2*Fraction(1,2**69)
res={'status':'DERIVED PSD filter Gram and analytic tail envelope; SIMULATED coarse-grained port dynamics','numerical_count':len(checks)+1,'numerical_checks':checks+['resolved operator norm bound diagnostic'],'analytic_tail_bound_exact':str(exact_tail),'analytic_tail_scope':'omitted |omega|>48cutoff contribution to retained half-diamond comparison, tau<=4 and t<=17; at most56 signed frequencies for8 nondegenerate levels; separate from quadrature/Born/memory/Lamb shift errors','gram_PSD_proof':'For any z, z^*K z=tau/(2pi) integral gamma(omega)|sum z_a sinc((omega-nu_a)tau/2)|^2 d omega >=0. Positive quadrature preserves Gram form.','generator_bound_proof':'Each bilinear Lindblad term has diamond norm <=2||A_a||||A_b||; CPTP Duhamel gives stated half-diamond bound for the two specified GKSL semigroups. Computed coefficient diagnostics are not interval-enclosed.','rows':rows,'physical_promotion':0,'microscopic_error_bound':'OPEN; no finite-time bath reference supplied','energy_proof':'For A_nu lowering dressed energy nu, [Hlab,A_nu]=-nu A_nu. A_nu b_nu^dagger commutes with Hlab+HB for resonant bath energy nu. Broadband R-lowering exchange conserves excitation, but free-energy commutator has (omega-Omega) detuning terms. Finite windows retain cross-Bohr terms, so are not exact on-shell energy conservation certificates.','model_debts':['numerical quadrature enclosure','Born approximation','bath-memory truncation','Lamb shift','time-homogeneous coarse-graining choice']}
(R/'results/EXCHANGE_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({'rows':[{k:v for k,v in r.items() if k!='K_order32'} for r in rows],'tail_exact':str(exact_tail),'numerical_checks':res['numerical_count']},indent=2))
