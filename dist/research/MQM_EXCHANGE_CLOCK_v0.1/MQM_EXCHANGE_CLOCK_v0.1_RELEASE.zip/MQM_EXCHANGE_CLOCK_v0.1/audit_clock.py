import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction
import json,math
import numpy as np
from scipy.linalg import expm
from scipy.optimize import brentq
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text());lam=math.sqrt(4*math.sqrt(2))
def weights(name):
 w=np.ones(16)
 if name=='PST16': w[:15]=[math.sqrt((j+1)*(15-j))/8 for j in range(15)]
 if name=='PST14': w[:13]=[math.sqrt((j+1)*(13-j))/7 for j in range(13)]
 w[15]=lam;return w

def mat(name):
 w=weights(name);a=np.diag(-w,1)+np.diag(w,-1);a[16,16]=-4;return a

def q(name,t):
 a=expm(t*mat(name))[:,0];return float(a@a)
# Exact common full-spectrum bound: full scalar graph is a forest; longest component
# is the 17-site live path; other components have norm<=2 or lambda.
# Perron entrywise comparison reduces all profiles to uniform. Sylvester
# recurrence certifies 8/3 I-H_uniform positive definite using lambda^2<198/35.
x=Fraction(8,3);ds=[Fraction(1),x]
for j in range(1,17):ds.append(x*ds[-1]-(Fraction(198,35) if j==16 else 1)*ds[-2])
assert all(d>0 for d in ds);assert Fraction(99,70)**2>2;assert Fraction(198,35)<x*x
rows=[]
for name in P['clock']['profiles']:
 w=weights(name);assert max(w[:15])<=1+1e-15
 samples=[{'time':t,'q':q(name,t),'pass':q(name,t)<1/65536} for t in P['clock']['samples']]
 root=brentq(lambda t:q(name,t)-1/65536,0,16384,xtol=1e-9) if q(name,16384)<1/65536 else None
 # Full 68-state scalar Hamiltonian, not restricted path norm.
 c=np.zeros((17,17));m=c.copy();e=c.copy();s=c.copy()
 for j in range(13):c[j,j+1]=c[j+1,j]=w[j]
 m[13,14]=m[14,13]=w[13];e[14,15]=e[15,14]=w[14];s[16,15]=1
 X=np.array([[0,1],[1,0]]);sm=np.array([[0,1],[0,0]]);f=np.diag([0,1])
 H=np.kron(c,np.eye(4))+np.kron(np.kron(m,X),np.eye(2))+np.kron(np.kron(e,f),np.eye(2))+lam*(np.kron(np.kron(s,np.eye(2)),sm.T)+np.kron(np.kron(s.T,np.eye(2)),sm))
 assert np.linalg.norm(H,2)<8/3
 adjacency=[set(np.flatnonzero(H[i])) for i in range(68)];seen=set();components=[]
 for v in range(68):
  if v in seen:continue
  todo=[v];seen.add(v);comp=[]
  while todo:
   u=todo.pop();comp.append(u)
   for z in adjacency[u]-seen:seen.add(z);todo.append(z)
  assert sum(len(adjacency[u]) for u in comp)//2==len(comp)-1
  assert max(len(adjacency[u]) for u in comp)<=2
  big=any(H[u,z]>1 for u in comp for z in adjacency[u])
  assert not big or len(comp) in [2,17]
  components.append(len(comp))
 assert max(components)==17
 rows.append({'profile':name,'weights':w.tolist(),'samples':samples,'numeric_crossing':root,'q_at_frozen_bracket_endpoint16384':q(name,16384),'first_passing_sample':next((r['time'] for r in samples if r['pass']),None),'full68_norm_numeric':float(np.linalg.norm(H,2)),'full_graph_component_sizes':sorted(components)})
res={'status':'DERIVED common full-spectrum ceiling; SIMULATED matched arrival','norm_ceiling_exact':'8/3','exact_positive_principal_minor_lower_bounds':[str(d) for d in ds],'proof':'All full68 graphs are nonnegative bipartite forests. Longest coupled component is live17 path; remaining program components have max degree2 and weights<=1, isolated exchange edges have lambda<8/3. Entrywise Perron domination bounds engineered graphs by uniform. Sylvester recurrence with lambda^2<198/35 makes every leading minor positive at x=8/3.','rows':rows,'cold_channel_identity':'history gauge preserves arbitrary bank/reference; live and captured supports orthogonal, retained half-diamond=q','bath_scope':'local cold Markov generator; no transfer of port exchange-bath evidence to whole word','physical_promotion':0}
(R/'results/CLOCK_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
