"""Independent directed interval left-edge certificate plus monotone survival."""
from pathlib import Path
from fractions import Fraction
import json,math
from mpmath import iv
iv.dps=80
R=Path(__file__).resolve().parent

def rat(v):f=Fraction(v);return iv.mpf(f.numerator)/f.denominator
def certify(name,center):
 n=17;lam=iv.sqrt(4*iv.sqrt(rat(2)));A=[[rat(0) for _ in range(n)] for _ in range(n)]
 for i in range(n-1):
  w=lam if i==15 else rat(1)
  if name=='PST16' and i<15:w=iv.sqrt(rat((i+1)*(15-i)))/8
  if name=='PST14' and i<13:w=iv.sqrt(rat((i+1)*(13-i)))/7
  A[i][i+1]=-w;A[i+1][i]=w
 A[16][16]=rat(-4)
 t=rat(Fraction(center)-Fraction(1,1024));scale=20;B=[[a*t/2**scale for a in row] for row in A]
 def eye():return [[rat(int(i==j)) for j in range(n)] for i in range(n)]
 def mul(V,W):return [[sum(V[i][k]*W[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
 V=eye();term=eye()
 # Taylor multiplication by tridiagonal B only.
 for order in range(1,25):
  term=[[sum(term[i][k]*B[k][j] for k in range(max(0,j-1),min(n,j+2)))/order for j in range(n)] for i in range(n)]
  V=[[V[i][j]+term[i][j] for j in range(n)] for i in range(n)]
 b=(2+lam+4)*t/2**scale;remainder=iv.exp(b)*b**25/math.factorial(25);rad=iv.mpf([-remainder.b,remainder.b]);V=[[v+rad for v in row] for row in V]
 for _ in range(scale):V=mul(V,V)
 q=sum(V[i][0]*V[i][0] for i in range(n))
 passed=q.b<rat(Fraction(1,65536)).a
 rejected=q.a>rat(Fraction(1,65536)).b
 assert passed or rejected
 return {'profile':name,'time_exact':str(Fraction(center)-Fraction(1,1024)),'q_interval':str(q),'target_pass':bool(passed),'target_reject_at_left':bool(rejected)}
rows=[certify(name,1024) for name in ['uniform','PST16','PST14']]
assert rows[0]['target_pass'] and all(r['target_reject_at_left'] for r in rows[1:])
# Right edges independently reject the whole engineered window by monotonicity.
# Retain protocol-selected uniform certificate; diagnostic engineered endpoint enclosure
# is a disclosed additional rejection check, without changing weights or threshold.
rows.extend([certify(name,Fraction(1024)+Fraction(1,512)) for name in ['PST16','PST14']])
assert all(r['target_reject_at_left'] for r in rows[3:])
res={'status':'INTERVAL VERIFIED uniform pass and two scoped engineered failures at common window','rows':rows,'window':'1024 +/-1/1024','method':'80-digit directed intervals, Taylor24, scale2^20, analytic infinity-norm remainder, interval squaring','monotonicity':'A+A^T=-8P_last implies qprime<=0. Uniform left edge bounds whole window; engineered right edge rejects whole window.','scope':'Fixed cold local generator and prescribed profiles only; no universal engineered-clock no-go','physical_promotion':0}
(R/'results/INTERVAL_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
