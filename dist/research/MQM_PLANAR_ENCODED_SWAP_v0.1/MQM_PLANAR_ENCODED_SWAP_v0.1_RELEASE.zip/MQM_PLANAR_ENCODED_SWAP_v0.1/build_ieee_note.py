"""Build actual IEEEtran/A4 manuscript, figure, and page renders."""
from pathlib import Path
import json, shutil, subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fitz
R=Path(__file__).resolve().parent
M=R/'manuscript';M.mkdir(exist_ok=True)
F=R/'figures';F.mkdir(exist_ok=True)
parent=R.parent/'MQM_TWO_LOCAL_SWAP_BASELINE_v0.1'
for name in ['IEEEtran.cls','LPPL-1.3c.txt']:
    shutil.copy2(parent/'manuscript'/name,M/name)
shutil.copy2(parent/'PUBLICATION_FORMAT_POLICY_v1.0.json',R/'PUBLICATION_FORMAT_POLICY_v1.0.json')
core=json.loads((R/'PHYSICAL_CORE.json').read_text())
receipt=json.loads((R/'results/REPLAY_RECEIPT.json').read_text())
route=json.loads((R/'PLANAR_ROUTED_INTERFACE.json').read_text())
fig,ax=plt.subplots(figsize=(3.45,1.9),layout='constrained')
for e in core['edges']:
    x,y=core['coordinates'][str(e['x'])],core['coordinates'][str(e['y'])]
    ax.plot([x[0],y[0]],[x[1],y[1]],color='#2c6589',lw=1.3)
for j in range(4):
    for a in range(4):
        ax.scatter(j,a,s=95,color='#2c6589',zorder=3)
        basis=core['prefixes'][j][a]
        ax.text(j,a+.13,f'{basis:02b}',ha='center',va='bottom',fontsize=7)
ax.set_xticks(range(4),['Input','CNOT A→O','CNOT O→A','CNOT A→O'])
ax.tick_params(axis='x',labelsize=6.5,length=0)
ax.set_yticks([]);ax.set_xlim(-.3,3.3);ax.set_ylim(-.3,3.65)
for spine in ax.spines.values():spine.set_visible(False)
fig.savefig(F/'CORE_PATHS.png',dpi=220);plt.close(fig)
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,graphicx,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\newcommand{\bra}[1]{\langle#1|}
\newcommand{\SW}{\operatorname{SWAP}}
\begin{document}
\title{A Planar Penalty-Free Two-Local SWAP Core:\\Exact Arrival and the Cost of Native Interfaces}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 5, 2026. ORCID: 0009-0002-5813-0724. Conditional mathematical certificate; independent review pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
A prior native-data clock compilation obtains finite arrival by large detuning, but its full physical spectrum makes the normalized deadline exceed one billion model units. We change the encoding: a single excitation jointly represents a four-address clock and a two-qubit computational basis. The ordered three-CNOT SWAP word becomes four disjoint four-site XY chains, requiring 16 mode qubits and 12 interaction pairs. Engineered couplings give exact arrival at $8\pi$ with full physical operator norm one, without leaf detunings or perturbative penalties. Exact rational radical enclosures certify a complete encoded-domain error below $2^{-16}$ throughout a specified readout interval, including spectators and conservative rounding rescaling. This is a core certificate rather than an end-to-end resource advantage. An explicit coherent native encoder and decoder require 110 scheduled gates; both audited port layouts are nonplanar. Joint mode encoding also scales exponentially in the number of body qubits. We identify interface topology and autonomous admission as the next unresolved development targets.
\end{abstract}
\begin{IEEEkeywords}
Hamiltonian quantum computation, perfect state transfer, two-local interactions, planar graphs, quantum encoding, resource accounting.
\end{IEEEkeywords}

\section{Problem, prior art, and scope}
Static Hamiltonian computation and engineered perfect-transfer chains are established constructions \cite{christandl,nagaj}. In particular, direct two-local computation without large perturbative penalties is already prior art \cite{nagaj}. This note does not claim those principles as new. Its contribution is a finite, reproducible certificate for an MQM SWAP instance and an explicit accounting of the interface that the encoding requires.

The previous 54-qubit native-data instance uses wrong-rail barriers of strength $\Delta=2^{20}$. Its full spectral width is at least $12\Delta$, even though the admitted computational sector has low-energy arrival. Consequently any uniform normalization to a centered full operator-norm budget of one obeys $\eta\le(6\Delta)^{-1}$. The sufficient choice $(6\Delta+9)^{-1}$ is not a necessary bound. That construction and its proof remain immutable \cite{mayes}. Merely improving arrival in a restricted sector does not remove its physical spectral penalty.

We now replace the independent physical clock and data registers by joint mode occupation. The task is the ordered logical word
\begin{equation}
G_0=\mathrm{CNOT}_{A\to O},\quad
G_1=\mathrm{CNOT}_{O\to A},\quad G_2=G_0.
\end{equation}
Its product is SWAP. The four-address history differs from the old expanded routing graph. Comparisons must distinguish logical-word fidelity, physical encoding, and launch/readout obligations. Units below set $\hbar=1$ and refer to model time, not laboratory seconds.

\section{Why deleting leaves is insufficient in the old encoding}
\begin{proposition}[Fixed-port generator obstruction]
For two distinct single-excitation sites $u,v$, any physical two-local qubit Hamiltonian has clock block $\bra{u}H\ket{v}=h_{uv}I_B$. Thus, with a fixed product launch port and two distinct outgoing rails, it cannot exactly realize the data-selected column
\begin{equation}
C=\gamma(\ket{u}\otimes P_1+\ket{v}\otimes P_0),
\end{equation}
where $P_0,P_1$ are complementary nonzero data projectors. Its minimum operator-norm column mismatch is $\gamma/\sqrt2$.
\end{proposition}
\begin{proof}
Changing $\ket{v}$ into $\ket{u}$ changes occupations on two physical clock qubits. A term contributing to that block must act on both, exhausting its two-qubit support and leaving the body untouched. The candidate column is therefore $f\otimes I_B$. On the two data sectors its errors are the distances from $f$ to the orthogonal vectors $\gamma\ket{u}$ and $\gamma\ket{v}$. Half their separation is a lower bound on the larger distance; their midpoint attains it.
\end{proof}
This is a generator statement for the specified port encoding, not an endpoint impossibility theorem for arbitrary two-local computers. Changing the encoding, adding interfaces, or relaxing locality changes its assumptions. The construction below changes the encoding explicitly.

\section{Joint single-excitation encoding}
Let $a\in\{00,01,10,11\}$ and $j\in\{0,1,2,3\}$. Assign a physical mode qubit to each pair $(j,a)$ and define the isometry
\begin{equation}
\mathcal E\ket{j,a}=\ket{\mathbf1_{(j,a)}}.
\end{equation}
The right side has one excitation in a 16-qubit register. Its admitted sector has dimension 16, equal to the logical clock--body dimension. It does not contain two independent native data qubits. Encoding arbitrary unknown input coherently is an admission obligation.

Write $G_ja$ for the basis permutation effected by gate $G_j$. Define the physical generator
\begin{equation}\label{eq:H}
H=\sum_{j=0}^{2}\sum_a\frac{J_j}{2}
\left(X_{j,a}X_{j+1,G_ja}+Y_{j,a}Y_{j+1,G_ja}\right),
\end{equation}
with $J_0=J_2=\sqrt3/16$ and $J_1=1/8$. Every term is two-local. Equal XX and YY coefficients conserve excitation exactly. Restricted to the admitted sector,
\begin{equation}
\mathcal E^\dagger H\mathcal E=
\sum_jJ_j(\ket{j+1}\bra{j}\otimes G_j+\mathrm{h.c.}).
\end{equation}
The restriction is an exact invariant simulation, not a low-energy approximation. It holds for all inputs and all times, and tensoring an external spectator preserves the identity.

Set $P_0=I$, $P_{j+1}=G_jP_j$. Because all gates are permutations, the physical graph consists of four disjoint paths $\{(j,P_ja):j=0,1,2,3\}$, one per initial basis label. It has 16 vertices, 12 pairs, 24 Pauli terms, and maximum degree two. Placing $(j,P_ja)$ at coordinate $(j,a)$ is an explicit crossing-free embedding. There are no blind leaves, detuning terms, or mediator penalties.
\begin{figure}[t]
\centering\includegraphics[width=\columnwidth]{../figures/CORE_PATHS.png}
\caption{Physical mode paths. Labels are the body basis at each logical stage. Each horizontal line is a disjoint physical chain; the encoded logical data are jointly represented by mode occupation.}
\end{figure}

\section{Exact arrival and the full physical spectrum}
\begin{theorem}[Planar core certificate]
The physical Hamiltonian in (\ref{eq:H}) has full operator norm one and spectral width two. At $T=8\pi$, for every body input $\ket\psi$,
\begin{equation}
e^{-iHT}\mathcal E\ket{0,\psi}
=i\mathcal E\ket{3,\SW\psi}.
\end{equation}
The same channel identity holds with any entangled spectator.
\end{theorem}
\begin{proof}
The prefix gauge sends the one-excitation restriction to $A\otimes I_4$, where $A$ is the four-site adjacency matrix with edges $J_j$. Its characteristic polynomial is
\begin{equation}
\det(zI-A)=(z^2-9/256)(z^2-1/256).
\end{equation}
Spectral interpolation at $T=8\pi$ gives $e^{-iAT}=iR$, with $R$ reversing the chain. Equivalently, its amplitudes from the first site are
\begin{equation}
c_j(t)=(-i)^j\sqrt{\binom3j}
\sin^j(t/16)\cos^{3-j}(t/16).
\end{equation}
Since $P_3=\SW$, this proves the endpoint identity.

The full physical register has dimension $2^{16}$, so the one-excitation eigenvalues alone do not certify its budget. For one four-qubit XY chain, the full 16-dimensional spectrum is
\begin{equation}
\{-4,-3,-2,-1,0,1,2,3,4\}/16
\end{equation}
with multiplicities $(1,2,1,2,4,2,1,2,1)$. Direct characteristic-polynomial verification is supplied. Four disjoint chains are tensor factors whose spectra add. Their extremal eigenvalues are $\pm1$, attained by tensor products of chain extremal states. Thus $\|H\|=1$ and its centered spectral width is two on the entire physical Hilbert space.
\end{proof}
The maximum physical Pauli coefficient is $1/16$. Arrival is not irreversible retention: the coherent finite core continues evolving after $T$. A dissipative latch, renewal of its supervisor, and thermodynamic supply remain outside this theorem.

\section{Rounding, channel metric, and deadline window}
Let $D(\rho,\sigma)=\tfrac12\|\rho-\sigma\|_1$; channel distances use half the diamond norm. If input--output isometries differ in operator norm by $b$, both metrics are bounded by $b$, uniformly over spectators. This follows from the pure-state trace-distance bound and purification, and avoids certifying only the body marginal.

Only 16 Pauli coefficients in (\ref{eq:H}) are irrational, each $\sqrt3/32$; the remaining eight are dyadic. With $r=\lfloor\sqrt{3\,2^{200}}\rfloor$, integer arithmetic encloses each irrational coefficient between $r/(32\,2^{100})$ and $(r+1)/(32\,2^{100})$. For its implemented binary64 rational $c$, define
\begin{equation}
d=16\max\{|c-r/(32\,2^{100})|,
|c-(r+1)/(32\,2^{100})|\}.
\end{equation}
Then $\|\widetilde H-H\|\le d$. The rational receipt certifies $(176/7)d<1.262\times10^{-15}<2^{-40}$, using $8\pi<176/7$.

To retain a strict full physical budget after rounding, use $\widetilde H/(1+d)$ and deadline $T'=8\pi(1+d)$. This conservative correction is charged, rather than assuming rounded norm equals one. The accumulated rounding debit at $T'$ is still $8\pi d$.

For $|t-T'|\le\tau=2^{-16}$, the ideal invariant-sector norm $3/16$ and Duhamel's bound give
\begin{equation}
D_{\rm complete}(t)\le \frac3{16}\tau+
\left(\frac{176}{7}+\tau\right)d
<2.862\times10^{-6}<2^{-16}.
\end{equation}
This bounds the entire interval, not a sampled maximum. It applies to the admitted encoded input, final clock, body, and spectator. Imperfect state admission contributes an additional debit $\epsilon_{\rm adm}$; additional Hamiltonian error $d_{\rm hw}$ contributes at most $t\,d_{\rm hw}$. No lab timing or noise model is inferred from the arithmetic.

\section{Native interface: explicit circuit and geometry}
An explicit native encoder uses two data qubits $A,O$ and the four input-stage modes $h_{00},h_{01},h_{10},h_{11}$. Initialize only $h_{00}$ excited. Apply
\begin{align}
&\mathrm{Fredkin}(A;h_{00},h_{10}),\nonumber\\
&\mathrm{Fredkin}(O;h_{00},h_{01}),\nonumber\\
&\mathrm{Fredkin}(O;h_{10},h_{11}),\nonumber\\
&\mathrm{CNOT}_{h_{10}\to A},\ 
\mathrm{CNOT}_{h_{11}\to A},\nonumber\\
&\mathrm{CNOT}_{h_{01}\to O},\ 
\mathrm{CNOT}_{h_{11}\to O}.
\end{align}
On each basis input this maps $\ket{a}_{AO}\ket{\mathbf1_{00}}$ to $\ket{00}_{AO}\ket{\mathbf1_a}$. By linearity it preserves arbitrary coherences and spectator correlations. It moves information rather than erasing it. After core arrival, the inverse circuit at the terminal four modes transfers the SWAP output back to native ports and restores a known terminal excitation.

Each Fredkin is two CNOTs and one Toffoli. The replay exactly verifies a Toffoli decomposition using six CNOTs, seven T/T-dagger gates, and two H gates, consistent with elementary gate synthesis \cite{barenco}. Each interface therefore uses 28 CNOTs, 21 T/T-dagger gates, and six H gates: 55 gates per interface, or 110 total. These are upper-bound constructions, not minimal gate counts. Native CNOT is counted as an elementary scheduled two-qubit gate; its pulse realization is an additional hardware obligation.

The union of interaction pairs used by the core and interfaces is audited, rather than declaring the entire system planar from the core diagram:
\begin{table}[t]\centering
\caption{Core and native-interface resource audit}
\begin{tabular}{lrrrr}
\hline
Layout & Qubits & Pairs & Degree & Planar\\\hline
Encoded core &16&12&2&Yes\\
Reused native ports &18&32&8&No\\
Separate native ports &20&32&5&No\\\hline
Routed reused ports &18&17&2&Yes\\\hline
\end{tabular}
\end{table}
The supplied nonplanar witness subgraphs are independently replayable. Each isolated six-qubit interface is planar, but joining them through the SWAP paths is not planar for either tested unrouted layout. Separating ports reduces the maximum degree without resolving that geometry.

\subsection{A planar scheduled comparator}
Place the reused ports at sites 0 and 1 of a line, followed by the four core paths in contiguous four-site blocks. All 12 core pairs remain nearest neighbors. Five additional available pairs make an 18-site path with 17 pairs and maximum degree two; bridge couplings are off during the static core interval. For each interface CNOT, move its control adjacent to the target with nearest-neighbor SWAPs, apply the CNOT, and reverse the moves. Every gate restores the physical register mapping. Exact binary linear algebra verifies each routed CNOT on all 18-qubit basis states.

This explicit schedule adds ROUTESWAPS SWAPs to the 110 interface gates: ROUTEGATES scheduled gates in total. If SWAP is decomposed into three CNOTs, the interfaces use ROUTECNOTS CNOTs plus the same 54 single-qubit gates. No extra qubits are assumed, and no minimality is claimed.

An ideal piecewise norm-one latency is explicit. For an involutory gate $U$ (CNOT, SWAP, or H), the generator $(I-U)/2$ has norm one and implements $U$ in time $\pi$. T/T-dagger use $\mp\ket1\bra1$ for $\pi/4$. Sequential interfaces and the static core therefore take
\begin{equation}
T_{\rm hybrid}=\pi\left(ROUTETIME+8d\right).
\end{equation}
This model charges the gate intervals under the full norm budget, but excludes switching slew, pulse imperfections, and the physical classical controller. It is a scheduled hybrid comparator, not a single fixed Hamiltonian for the entire episode. Arrival error survives an ideal decoder by unitary invariance; imperfect interfaces require their own joint error debits. No autonomous admission--execution--extraction episode has been established.

\section{Scaling, verification, and next development gate}
For $n$ body qubits and $m$ gates, this joint mode construction requires $(m+1)2^n$ physical mode qubits. A 13-gate word on nine body qubits would require 7168 modes before interfaces. Permutation-only words retain disjoint paths; generic quantum gates mix paths, so this planar proof cannot be carried over automatically. Logical address compression is not a reduction of the physical mode count.

The executable certificate records EXACTCOUNT exact algebraic, arithmetic, and graph checks and NUMCOUNT numerical diagnostics. Exact checks cover generator intertwining, full-chain characteristic polynomials, endpoint spectral interpolation, integer radical enclosures, encoder/decoder basis identities, and gate synthesis. Numerical checks cover all-input endpoint isometries, several full encoded-time propagators, and an entangled spectator. They supplement rather than replace the proofs. There are no experimental data or independently audited novelty claims.

The next gate is to replace the scheduled native admission and extraction interfaces by a proved fixed-generator process while preserving arbitrary unknown inputs and correlations. Its complete pair graph, ancillas, and full spectrum must be charged. The planar routed schedule gives a concrete upper-bound comparator for that effort. Resource comparisons must include state preparation, readout timing, interface latency, and the same logical operational task. An endpoint-only timed SWAP remains a required comparator; the present encoded history does not establish advantage over it.

Large spectral width does not itself prove high-frequency dephasing: that requires system--bath couplings and a spectral-density model. The UD-inspired finite interaction graph here denotes nonzero two-body support pairs. No correspondence with GR spin networks, QFT continuum limits, or a thermal refresh mechanism is established by this compilation.

\begin{thebibliography}{4}
\bibitem{christandl} M. Christandl, N. Datta, A. Ekert, and A. J. Landahl, ``Perfect state transfer in quantum spin networks,'' \emph{Phys. Rev. Lett.}, vol. 92, 187902, 2004, doi: 10.1103/PhysRevLett.92.187902.
\bibitem{nagaj} D. Nagaj, ``Universal 2-local Hamiltonian quantum computing,'' \emph{Phys. Rev. A}, vol. 85, 032330, 2012, doi: 10.1103/PhysRevA.85.032330.
\bibitem{barenco} A. Barenco \emph{et al.}, ``Elementary gates for quantum computation,'' \emph{Phys. Rev. A}, vol. 52, pp. 3457--3467, 1995, doi: 10.1103/PhysRevA.52.3457.
\bibitem{mayes} B. W. Mayes, ``MQM weighted-arrival resource audit,'' IEEE-focused development note v0.1, Oct. 5, 2026, unpublished. Immutable release SHA-256 recorded in INPUT\_ANCHORS.json.
\end{thebibliography}
\end{document}
'''
tex=tex.replace('EXACTCOUNT',str(receipt['exact_count'])).replace('NUMCOUNT',str(receipt['numerical_count']))
tex=tex.replace('An explicit coherent native encoder and decoder require 110 scheduled gates; both audited port layouts are nonplanar.',
    'An explicit native encoder and decoder require 110 scheduled gates; their unrouted layouts are nonplanar. Nearest-neighbor routing gives a planar 18-qubit line at the cost of ROUTESWAPS additional SWAPs.')
tex=tex.replace('We identify interface topology and autonomous admission as the next unresolved development targets.',
    'Autonomous admission is the next unresolved development target.')
tex=tex.replace('ROUTESWAPS',str(route['interface_counts']['SWAP'])).replace('ROUTEGATES',str(route['scheduled_interface_gates']))
tex=tex.replace('ROUTECNOTS',str(route['CNOT_count_if_SWAP_decomposed'])).replace('ROUTETIME',route['norm_one_model_latency_in_pi_units'])
name='MQM_PLANAR_ENCODED_SWAP_IEEE_A4_v0.1'
(M/(name+'.tex')).write_text(tex)
for k in range(3):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,text=True,capture_output=True)
    (R/'results'/f'PDF_BUILD_{k+1}.txt').write_text(p.stdout+p.stderr)
    assert p.returncode==0,p.stdout[-3000:]
log=(M/(name+'.log')).read_text()
assert 'Overfull' not in log, 'Fix overfull layout before release'
doc=fitz.open(M/(name+'.pdf'))
sizes=[]
for k,page in enumerate(doc):
    sizes.append([page.rect.width,page.rect.height])
    assert abs(page.rect.width-595.276)<.05 and abs(page.rect.height-841.89)<.05
    page.get_pixmap(matrix=fitz.Matrix(1.35,1.35)).save(R/'results'/f'PAGE_{k+1}.png')
text='\n'.join(page.get_text() for page in doc)
assert '??' not in text
(R/'results'/'PDF_QA.json').write_text(json.dumps(dict(pages=len(doc),sizes_points=sizes,
    format='actual IEEEtran v1.8b, journal, a4paper, 10pt, two columns',
    no_overfull=True,no_unresolved_references=True,visual_review='pending'),indent=2)+'\n')
print(json.dumps(dict(pdf=str(M/(name+'.pdf')),pages=len(doc),exact=receipt['exact_count'],numerical=receipt['numerical_count'])))
