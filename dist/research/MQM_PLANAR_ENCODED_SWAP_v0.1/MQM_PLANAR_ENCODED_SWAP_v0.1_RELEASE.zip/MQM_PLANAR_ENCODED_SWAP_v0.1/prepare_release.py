"""Generate scope records and an immutable replay bundle after visual PDF QA."""
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parent
def dump(n,v):(R/n).write_text(json.dumps(v,indent=2)+'\n')
receipt=json.loads((R/'results/REPLAY_RECEIPT.json').read_text())
route=json.loads((R/'PLANAR_ROUTED_INTERFACE.json').read_text())
qa=json.loads((R/'results/PDF_QA.json').read_text())
assert qa['visual_review']=='passed', 'Visual inspection is required before freezing'
parent=R.parent/'MQM_WEIGHTED_ARRIVAL_RESOURCE_AUDIT_v0.1_RELEASE.zip'
dump('INPUT_ANCHORS.json',dict(parent_release=parent.name,parent_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
    operation='new branch; parent releases remain immutable',user_target='Remove blind leaves and detuning; explore planar two-local topologies',
    source_urls=['https://arxiv.org/abs/quant-ph/0309131','https://arxiv.org/abs/1002.0420','https://arxiv.org/abs/quant-ph/9503016']))
dump('CLAIM_REGISTER_v0.1.json',dict(status='conditional mathematical development; independent review pending',physical_promotion=0,
    certified=['Exact four-address three-CNOT logical SWAP history under joint mode encoding',
       '16 physical mode qubits; 12 core pairs; degree 2; planar; no blind leaves or detuning',
       'Exact full physical core norm 1 and width 2; ideal deadline 8*pi',
       'Rounded core budget conservatively rescaled; interval error <2^-16',
       'Spectator-uniform isometry and half-diamond guarantees conditional on admitted encoded input',
       'Explicit coherent native interfaces and exact nearest-neighbor routing; 18-qubit planar hybrid'],
    open=['Autonomous native input and output interfaces','Permanent retention or clock refresh',
       'Hardware supply, preparation, pulse switching and noise certificate','Minimality or advantage over direct timed SWAP',
       'Polynomial scaling in body qubits','Thirteen-gate non-permutation word planarity','Independent theorem-level novelty comparison']))
dump('COMPARISON_CONTRACT_v0.1.json',dict(
    required_metrics=['same unknown-input channel with spectators','physical qubits including admission and readout',
       'full physical norm and energy origin','total interaction graph and maximal degree',
       'static versus scheduled controls','admission, execution and extraction latency','certified interval error and omitted hardware terms'],
    rows=[dict(name='prior detuned native-data implementation',qubits=54,pairs=102,maximum_degree=18,planar=False,
          declared_deadline_lower_bound='336*pi*2^20 after norm-one uniform scaling',interface='native clock-data input'),
       dict(name='new encoded static core',qubits=16,pairs=12,maximum_degree=2,planar=True,
          ideal_deadline='8*pi',interface='encoded admission assumed; no native ports'),
       dict(name='new planar scheduled hybrid',qubits=18,pairs=17,maximum_degree=2,planar=True,
          model_deadline='pi*(830.5+8*d)',interface_gates=854,additional_routing_SWAPS=744,
          interface='scheduled; switching slew and controller resources unmodeled'),
       dict(name='direct native endpoint-only SWAP',qubits=2,pairs=1,maximum_degree=1,planar=True,
          model_deadline='pi with norm-one generator (I-SWAP)/2',interface='timed pulse; no serial logical clock history')],
    verdict='No matched end-to-end advantage established. The encoded-core speed comparison changes the encoding and interface contract.'))
dump('WBS_NEXT_v0.1.json',dict(next_target='Autonomous native admission and extraction under a planar full-spectrum budget',
    acceptance=['Explicit native unknown-input to mode-occupation isometry, including spectators',
       'Time-independent two-local physical generator and fixed launch; no hidden per-gate switching',
       'Planar complete physical graph with all ancillas counted',
       'Full physical norm <=1, certified finite arrival window, and preparation/implementation error debit',
       'Compare total resources against the 18-qubit routed hybrid and direct timed endpoint'],
    intermediate=['Search alternate native encodings before expanding the 13-step word',
       'Improve 744-SWAP routed upper bound without claiming minimum',
       'Check conservation constraints and nonstationary supply if native interfaces conserve excitation',
       'Independent proof and prior-art audit before theorem promotion']))
(R/'REVIEW_RESPONSE.txt').write_text('''The review correctly identifies full-spectrum detuning cost as a decisive blocker for the previous encoding.
Corrections: eta <= 1/(6 Delta) is the necessary norm-one scaling bound. eta=1/(6 Delta+9) is sufficient, not necessary. A wide spectrum alone establishes neither high-frequency dephasing nor dissipated heat. Those require physical bath and supply models. The interaction graph records nonzero two-body support pairs, not basis-state adjacency; no GR/QFT correspondence is established.

New development: change to a joint clock-body mode encoding. Four disjoint four-site XY paths are an exact two-local planar core for the ordered three-CNOT SWAP word. They use 16 physical qubits, have full physical norm one, and arrive at 8 pi without detuning. This is not the old expanded clock channel on fewer native clock qubits. The admission interface has changed.

Interface audit: native encoder/decoder take 110 scheduled elementary gates in an explicit construction. Their two unrouted physical layouts are nonplanar. Routing on an 18-site line adds 744 SWAPs, making 854 interface gates; every routed CNOT is exactly verified. The line has 17 pairs, degree two, and no additional qubits. The ideal piecewise norm-one latency including the core is pi*(830.5+8d), excluding switching slew and controller realization. This is a hybrid upper-bound comparator, not an autonomous full-cycle solution or a minimum.

Evidence boundary: arithmetic certifies core coefficient rounding and a readout interval, conditional on encoded admission. State preparation, interface pulse errors, realistic spectra, battery supply, irreversible latching, and supervising-clock refresh are open. Generic joint mode compilation costs (m+1)*2^n physical mode qubits, and generic non-permutation gates do not inherit the four-path planar proof.

Next gate: eliminate scheduled native admission/extraction without reintroducing uncharged graph, spectrum, energy, timing, or correlation debt. Benchmark the full construction against both the routed hybrid and direct timed SWAP. Do not extend the 13-step non-permutation episode before resolving this boundary.
''')
(R/'README.txt').write_text(f'''MQM PLANAR ENCODED SWAP v0.1
Benjamin Walker Mayes; ORCID 0009-0002-5813-0724
Conditional theoretical development. Independent review pending. Physical promotion 0.

Result: 16-qubit planar static encoded core, 12 pairs, degree 2, full physical norm 1, deadline 8*pi. Rounded full-norm scaling and complete-domain interval certificate are recorded in results/REPLAY_RECEIPT.json. 18-qubit planar scheduled native interface comparator: 17 pairs, 744 routing SWAPs, 854 interface gates.
Scope: joint mode encoding; native inputs require coherent admission. Static autonomy holds only during the core. No permanent latch, closed-loop refresh, scalability, minimality, or end-to-end advantage is certified.

Replay: python3 certify_core.py
Build: python3 build_ieee_note.py (requires pdflatex; actual IEEEtran class bundled under LPPL)
Verified: {receipt['exact_count']} exact checks (including gate-by-gate routed action and locality) and {receipt['numerical_count']} numerical diagnostics.
Dependencies: numpy, scipy, sympy, networkx; matplotlib and PyMuPDF for manuscript build/render.
Format: IEEEtran journal,a4paper,10pt; two columns. PUBLICATION_FORMAT_POLICY_v1.0.json applies to future paper builds.
Each exact resource claim states its encoding and interface boundary. The model time unit has no physical calibration.
''')
dump('SOURCE_PROVENANCE.json',dict(sources=[dict(arxiv='quant-ph/0309131',role='prior art: static engineered perfect transfer'),
    dict(arxiv='1002.0420',role='prior art: direct two-local autonomous computation without penalties'),
    dict(arxiv='quant-ph/9503016',role='prior art: elementary gate synthesis; the particular decomposition is verified in replay')],
    novelty='instance certificate; neither perfect transfer nor static two-local computation claimed novel'))
files=[p for p in sorted(R.rglob('*')) if p.is_file() and p.suffix not in ['.aux','.log','.out'] and p.name!='SHA256_MANIFEST.json']
dump('SHA256_MANIFEST.json',{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
archive=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'SHA256_MANIFEST.json']:z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=len(files)+1)))
