MQM PLANAR ENCODED SWAP v0.1
Benjamin Walker Mayes; ORCID 0009-0002-5813-0724
Conditional theoretical development. Independent review pending. Physical promotion 0.

Result: 16-qubit planar static encoded core, 12 pairs, degree 2, full physical norm 1, deadline 8*pi. Rounded full-norm scaling and complete-domain interval certificate are recorded in results/REPLAY_RECEIPT.json. 18-qubit planar scheduled native interface comparator: 17 pairs, 744 routing SWAPs, 854 interface gates.
Scope: joint mode encoding; native inputs require coherent admission. Static autonomy holds only during the core. No permanent latch, closed-loop refresh, scalability, minimality, or end-to-end advantage is certified.

Replay: python3 certify_core.py
Build: python3 build_ieee_note.py (requires pdflatex; actual IEEEtran class bundled under LPPL)
Verified: 164 exact checks (including gate-by-gate routed action and locality) and 24 numerical diagnostics.
Dependencies: numpy, scipy, sympy, networkx; matplotlib and PyMuPDF for manuscript build/render.
Format: IEEEtran journal,a4paper,10pt; two columns. PUBLICATION_FORMAT_POLICY_v1.0.json applies to future paper builds.
Each exact resource claim states its encoding and interface boundary. The model time unit has no physical calibration.
