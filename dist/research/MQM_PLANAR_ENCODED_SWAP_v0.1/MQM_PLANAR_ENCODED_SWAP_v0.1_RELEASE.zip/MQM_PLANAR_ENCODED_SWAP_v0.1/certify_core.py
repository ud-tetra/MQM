#!/usr/bin/env python3
"""Exact and numerical replay. Run from any directory; receipts stay beside script."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json, platform
import numpy as np
import sympy as s
import networkx as nx
from scipy.linalg import expm

ROOT=Path(__file__).resolve().parent
(ROOT/'results').mkdir(exist_ok=True)
exact=[]; numeric=[]
def check(label, condition):
    assert bool(condition), label
    exact.append(label)
def ncheck(label, value, ceiling=2e-12):
    assert value < ceiling, (label,value,ceiling)
    numeric.append(dict(label=label,residual=float(value),ceiling=ceiling))
def dump(name,obj):
    (ROOT/name).write_text(json.dumps(obj,indent=2)+'\n')
def cx(a,c,t):
    return a ^ (1<<(1-t)) if a & (1<<(1-c)) else a
word=[(0,1),(1,0),(0,1)]
prefix=[[a for a in range(4)]]
for c,t in word: prefix.append([cx(a,c,t) for a in prefix[-1]])
check('ordered CNOT word is SWAP',prefix[-1]==[0,2,1,3])
weights=[s.sqrt(3)/16,s.Rational(1,8),s.sqrt(3)/16]
H=s.zeros(16); graph=nx.Graph(); graph.add_nodes_from(range(16))
edges=[]
for j,(c,t) in enumerate(word):
    for a in range(4):
        x,y=4*j+a,4*(j+1)+cx(a,c,t)
        H[x,y]=H[y,x]=weights[j]
        graph.add_edge(x,y)
        edges.append(dict(x=x,y=y,j=j,input_basis=a,weight=str(weights[j]),pauli_coefficient=str(weights[j]/2)))
Q=s.zeros(16)
for j in range(4):
    for a in range(4):Q[4*j+prefix[j][a],4*j+a]=1
A=s.zeros(4)
for j,w in enumerate(weights):A[j,j+1]=A[j+1,j]=w
check('all-input, all-time generator intertwining',Q.T*H*Q==s.kronecker_product(A,s.eye(4)))
check('unitary prefix permutation',Q.T*Q==s.eye(16))
check('core has 16 vertices and 12 pairs',(len(graph),graph.number_of_edges())==(16,12))
check('four disconnected paths',sorted(len(c) for c in nx.connected_components(graph))==[4]*4)
check('core maximum degree two',max(dict(graph.degree()).values())==2)
planar,embedding=nx.check_planarity(graph)
check('exact combinatorial core planarity',planar)
X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-s.I],[s.I,0]]);N=s.diag(0,1)
xy=(s.kronecker_product(X,X)+s.kronecker_product(Y,Y))/2
number=s.kronecker_product(N,s.eye(2))+s.kronecker_product(s.eye(2),N)
check('exact two-site excitation commutator',xy*number-number*xy==s.zeros(4))
check('XY restricted hopping matrix element',xy[1,2]==1 and xy[2,1]==1)
z=s.symbols('z')
check('chain characteristic polynomial',s.expand(A.charpoly(z).as_expr()-(z*z-s.Rational(9,256))*(z*z-s.Rational(1,256)))==0)
roots=[-s.Rational(3,16),-s.Rational(1,16),s.Rational(1,16),s.Rational(3,16)]
Uexact=s.zeros(4)
for e,phase_value in zip(roots,[-s.I,s.I,-s.I,s.I]):
    projector=s.eye(4)
    for other in roots:
        if e!=other:projector=projector*(A-other*s.eye(4))/(e-other)
    Uexact+=phase_value*projector
check('exact endpoint spectral interpolation',s.simplify(Uexact)==s.I*s.eye(4)[:,::-1])

# Audit the full four-qubit chain, not merely its one-excitation restriction.
chain=s.zeros(16)
for b in range(16):
    for j,w in enumerate(weights):
        mask=(1<<j)|(1<<(j+1))
        if bool(b&(1<<j)) != bool(b&(1<<(j+1))):chain[b^mask,b]+=w
levels={-s.Rational(1,4):1,-s.Rational(3,16):2,-s.Rational(1,8):1,
        -s.Rational(1,16):2,s.Rational(0):4,s.Rational(1,16):2,
        s.Rational(1,8):1,s.Rational(3,16):2,s.Rational(1,4):1}
expected=s.prod((z-e)**m for e,m in levels.items())
check('full 16-dimensional chain characteristic polynomial',s.expand(chain.charpoly(z).as_expr()-expected)==0)
check('four tensor factors give exact full physical norm one',4*max(levels)==1 and 4*min(levels)==-1)
check('full physical spectral width two',4*(max(levels)-min(levels))==2)
check('maximum Pauli coefficient is 1/16',max(weights)/2==s.Rational(1,16))

# Binary64 is admitted only through exact rational square-root enclosures.
bits=100; den=1<<bits; lo=isqrt(3*den*den)
check('integer lower radical enclosure',lo*lo<=3*den*den)
check('integer upper radical enclosure',(lo+1)**2>3*den*den)
low,high=F(lo,den*32),F(lo+1,den*32)
implemented=F.from_float(float(np.sqrt(3)/32))
coefficient_debit=max(abs(implemented-low),abs(implemented-high))
d=16*coefficient_debit
tau=F(1,65536); t_upper=F(176,7) # 8*pi < 176/7
endpoint=t_upper*d
window=F(3,16)*tau+(t_upper+tau)*d
check('binary64 physical generator error enclosure',d>0)
check('rounded endpoint error below 2^-40',endpoint<F(1,1<<40))
check('complete encoded-domain window error below 2^-16',window<F(1,1<<16))
check('strict capture window uses a bound on the whole interval',tau==F(1,65536))
eta=1/(1+d)
check('rounded full-norm budget scaling',eta*(1+d)==1)
gamma=s.Rational(1,8)
desired=s.Matrix([[0,0],[0,gamma],[gamma,0],[0,0]])
candidate=s.kronecker_product(s.Matrix([gamma/2,gamma/2]),s.eye(2))
check('fixed-encoding minimax residual is gamma/sqrt(2)',
    (candidate-desired).T*(candidate-desired)==s.eye(2)*gamma**2/2)

# Explicit coherent native encoder. Modes 0,1,2,3 denote 00,01,10,11.
native=[('F',0,2,4),('F',1,2,3),('F',1,4,5),
        ('C',4,0),('C',5,0),('C',3,1),('C',5,1)]
def perm_apply(b,g):
    b=list(b)
    if g[0]=='C': b[g[2]]^=b[g[1]]
    elif g[0]=='F' and b[g[1]]:b[g[2]],b[g[3]]=b[g[3]],b[g[2]]
    return b
for a in range(4):
    b=[a>>1,a&1,1,0,0,0]
    for gate in native:b=perm_apply(b,gate)
    check('encoder exact basis isometry '+str(a),b==[0,0]+[int(k==a) for k in range(4)])
    for gate in reversed(native):b=perm_apply(b,gate)
    check('decoder reverses encoder '+str(a),b==[a>>1,a&1,1,0,0,0])

# Exact Clifford+T verification of the Toffoli used to expand each Fredkin.
toff=[('H',2),('C',1,2),('Td',2),('C',0,2),('T',2),('C',1,2),('Td',2),
      ('C',0,2),('T',1),('T',2),('H',2),('C',0,1),('T',0),('Td',1),('C',0,1)]
phase=(1+s.I)/s.sqrt(2)
def gate_matrix(g,n=3):
    M=s.zeros(1<<n)
    for b in range(1<<n):
        bits=[(b>>(n-1-k))&1 for k in range(n)]
        idx=lambda v:sum(x<<(n-1-k) for k,x in enumerate(v))
        if g[0]=='C':
            bits[g[2]]^=bits[g[1]];M[idx(bits),b]=1
        elif g[0]=='H':
            k=g[1];old=bits[k]
            for new in (0,1):
                bits[k]=new;M[idx(bits),b]=(-1)**(old*new)/s.sqrt(2)
        else:M[b,b]=phase**(bits[g[1]]*(1 if g[0]=='T' else -1))
    return M
M=s.eye(8)
for gate in toff:M=gate_matrix(gate)*M
goal=s.eye(8);goal[6,6]=goal[7,7]=0;goal[6,7]=goal[7,6]=1
check('exact Toffoli Clifford+T decomposition',all(s.simplify(v)==0 for v in M-goal))
for b in range(8):
    a=[b>>2,(b>>1)&1,b&1]
    out=a.copy();out[2]^=out[1];out[1]^=out[0]*out[2];out[2]^=out[1]
    expect=a.copy()
    if a[0]:expect[1],expect[2]=expect[2],expect[1]
    check('Fredkin decomposition basis '+str(b),out==expect)
check('both interfaces exact expanded gate count',2*(10+3*6+3*7+3*2)==110)

def add_interface(G,j,Aport,Oport):
    h=lambda a:4*j+a
    G.add_edges_from([(Aport,h(0)),(Aport,h(2)),(Aport,h(3)),
       (Oport,h(0)),(Oport,h(1)),(Oport,h(2)),(Oport,h(3)),
       (h(0),h(2)),(h(0),h(1)),(h(2),h(3))])
audits={}
for kind in ['reused_ports','separate_ports']:
    G=graph.copy()
    add_interface(G,0,'A_in','O_in')
    add_interface(G,3,'A_in' if kind=='reused_ports' else 'A_out',
                  'O_in' if kind=='reused_ports' else 'O_out')
    p,w=nx.check_planarity(G,counterexample=True)
    audits[kind]=dict(vertices=len(G),pairs=G.number_of_edges(),maximum_degree=max(dict(G.degree()).values()),
       planar=p,edges=[list(e) for e in G.edges],nonplanar_witness=[] if p else [list(e) for e in w.edges])
    check(kind+' footprint correctly charged',len(G)==(18 if kind=='reused_ports' else 20))
    check(kind+' core and interface pairs charged',G.number_of_edges()==32)
check('reused native-port device is nonplanar',not audits['reused_ports']['planar'])

# Charge scheduled routing instead of claiming that native interfaces are free.
line_order=['A','O']+[4*j+prefix[j][a] for a in range(4) for j in range(4)]
position={label:k for k,label in enumerate(line_order)}
line=nx.path_graph(18)
check('physical line contains every core pair',all(abs(position[e['x']]-position[e['y']])==1 for e in edges))
check('routed device is planar and degree two',nx.check_planarity(line)[0] and max(dict(line.degree()).values())==2)
expanded=[]
for gate in native:
    if gate[0]=='C':expanded.append(gate)
    else:
        _,c,x,y=gate
        expanded.append(('C',x,y));mapping=[c,y,x]
        expanded += [(g[0],)+tuple(mapping[k] for k in g[1:]) for g in toff]
        expanded.append(('C',x,y))
check('expanded interface exact length',len(expanded)==55)
route_schedule=[];routing_swaps=0;stage_counts={}
for stage,sequence in [(0,expanded),(3,list(reversed(expanded)))]:
    mapping=['A','O']+[4*stage+a for a in range(4)]
    begin=len(route_schedule);swaps_before=routing_swaps
    for gate_index,g in enumerate(sequence):
        name=g[0]
        if stage==3:name={'T':'Td','Td':'T'}.get(name,name)
        sites=[position[mapping[k]] for k in g[1:]]
        if name!='C':route_schedule.append([name,sites[0]]);continue
        c,t=sites
        hops=list(range(c,t-1)) if c<t else list(range(c-1,t,-1))
        pairs=[(k,k+1) for k in hops]
        routed_control=t-1 if c<t else t+1
        local=[('S',x,y) for x,y in pairs]+[('C',routed_control,t)]+[('S',x,y) for x,y in reversed(pairs)]
        L=np.eye(18,dtype=np.uint8)
        for kind,x,y in local:
            if kind=='S':L[[x,y]]=L[[y,x]]
            else:L[y]^=L[x]
        expected=np.eye(18,dtype=np.uint8);expected[t]^=expected[c]
        check('routed gate action stage %d gate %d'%(stage,gate_index),np.array_equal(L,expected))
        check('routed gate locality stage %d gate %d'%(stage,gate_index),all(abs(x-y)==1 for _,x,y in local))
        route_schedule += [list(gate) for gate in local]
        routing_swaps+=2*len(pairs)
    stage_counts[str(stage)]=dict(scheduled_gates=len(route_schedule)-begin,routing_swaps=routing_swaps-swaps_before)
check('routed count charges every SWAP',len(route_schedule)==110+routing_swaps)
check('routing adds no physical ancillas',len(line_order)==18)
check('all routing uses line edges',all(abs(g[1]-g[2])==1 for g in route_schedule if g[0] in ['C','S']))
dump('PLANAR_ROUTED_INTERFACE.json',dict(line_order=line_order,physical_qubits=18,pairs=17,maximum_degree=2,
    planar=True,core_active_pairs=12,bridges_off_during_core=True,autonomous_interface=False,
    route_schedule=route_schedule,interface_counts=dict(CNOT=56,SWAP=routing_swaps,H=12,T_or_Tdg=42),
    stage_counts=stage_counts,scheduled_interface_gates=len(route_schedule),
    CNOT_count_if_SWAP_decomposed=56+3*routing_swaps,
    norm_one_model_latency_in_pi_units=str(F(routing_swaps)+F(173,2)),
    latency_assumptions='One gate active at a time; CNOT, SWAP and H use (I-U)/2 for duration pi; T/Tdg use +/-|1><1| for pi/4. Core duration 8*pi*(1+d). Switching and hardware slew are excluded.'))

Hn=np.array(H).astype(complex);An=np.array(A).astype(complex)
Qn=np.array(Q).astype(complex);cn=np.array(chain).astype(complex)
T=8*np.pi
endpoint_target=1j*Qn[:,12:16]
U=expm(-1j*T*Hn)
ncheck('all-input endpoint isometry',np.linalg.norm(U[:,:4]-endpoint_target,2))
ncheck('full chain spectrum diagnostic',np.max(np.abs(np.linalg.eigvalsh(cn)-np.sort([float(e) for e,m in levels.items() for _ in range(m)]))))
for k,t in enumerate([0,T/7,T/3,T/2,T,T+float(tau)]):
    physical=expm(-1j*t*Hn)
    logical=Qn@np.kron(expm(-1j*t*An),np.eye(4))@Qn.T
    ncheck('whole encoded generator replay time '+str(k),np.linalg.norm(physical-logical,2))
    amps=np.array([(-1j)**j*np.sqrt([1,3,3,1][j])*np.sin(t/16)**j*np.cos(t/16)**(3-j) for j in range(4)])
    ncheck('binomial amplitude replay time '+str(k),np.linalg.norm(expm(-1j*t*An)[:,0]-amps))
# Maximally entangled four-dimensional external spectator.
phi=np.eye(4).reshape(-1)/2
final=np.kron(U[:,:4],np.eye(4))@phi
desired=np.kron(endpoint_target,np.eye(4))@phi
ncheck('entangled spectator endpoint',np.linalg.norm(final-desired))
Hr=Hn.copy()
for e in edges:
    if e['j']!=1:Hr[e['x'],e['y']]=Hr[e['y'],e['x']]=2*float(implemented)
ncheck('rounded all-input endpoint diagnostic',np.linalg.norm(expm(-1j*T*Hr)[:,:4]-endpoint_target,2))
def sparse_apply(state,g):
    out={};kind=g[0]
    def add(b,v):out[b]=out.get(b,0)+v
    for b,v in state.items():
        x=g[1];bx=(b>>x)&1
        if kind=='C':add(b^((1<<g[2]) if bx else 0),v)
        elif kind=='S':add(b^(((1<<x)|(1<<g[2])) if bx!=((b>>g[2])&1) else 0),v)
        elif kind=='H':
            for new in (0,1):add((b&~(1<<x))|(new<<x),v*(-1)**(bx*new)/np.sqrt(2))
        else:add(b,v*np.exp(1j*np.pi/4*bx*(1 if kind=='T' else -1)))
    return out
enc_len=stage_counts['0']['scheduled_gates']
for a in range(4):
    initial=(a>>1)|((a&1)<<1)|(1<<position[0])
    state={initial:1}
    for gate in route_schedule[:enc_len]:state=sparse_apply(state,gate)
    target=1<<position[a]
    ncheck('routed native encoder basis '+str(a),np.sqrt(sum(abs(v-(1 if b==target else 0))**2 for b,v in state.items())))
    body=prefix[-1][a];state={1<<position[12+body]:1}
    for gate in route_schedule[enc_len:]:state=sparse_apply(state,gate)
    target=(body>>1)|((body&1)<<1)|(1<<position[12])
    ncheck('routed native decoder basis '+str(a),np.sqrt(sum(abs(v-(1 if b==target else 0))**2 for b,v in state.items())))

dump('PHYSICAL_CORE.json',dict(encoding='one excitation jointly encodes clock and body',
    physical_qubits=16,sector_dimension=16,logical_clock_addresses=4,logical_body_dimension=4,
    pairs=12,pauli_terms=24,maximum_degree=2,planar=True,full_norm=1,full_spectral_width=2,
    deadline='8*pi',prefixes=prefix,edges=edges,
    coordinates={str(4*j+prefix[j][a]):[j,a] for j in range(4) for a in range(4)}))
dump('INTERFACE_AUDIT.json',dict(encoder=native,toffoli_decomposition=toff,
    each_interface=dict(CNOT=28,T_or_Tdg=21,H=6),total_interface_gates=110,graphs=audits,
    scheduled_interfaces=True,autonomous_end_to_end=False))
dump('results/REPLAY_RECEIPT.json',dict(exact_count=len(exact),exact_checks=exact,
    numerical_count=len(numeric),numerical_checks=numeric,
    rounding=dict(radical_bits=bits,coefficient_lower=str(low),coefficient_upper=str(high),
       implemented=str(implemented),generator_bound=str(d),endpoint_bound=str(endpoint),
       window_bound=str(window),window_bound_float=float(window)),
    rounded_unit_norm=dict(scale=str(eta),deadline='8*pi*(1+d)',physical_window_halfwidth=str(tau)),
    environment=dict(python=platform.python_version(),sympy=s.__version__,networkx=nx.__version__,numpy=np.__version__),
    physical_promotion=0,independent_review='pending'))
print(json.dumps(dict(exact=len(exact),numerical=len(numeric),endpoint_bound=float(endpoint),
    window_bound=float(window),routing_swaps=routing_swaps,routed_interface_gates=len(route_schedule),
    interfaces={k:{p:v for p,v in a.items() if p in ('vertices','pairs','planar','maximum_degree')} for k,a in audits.items()}),indent=2))
