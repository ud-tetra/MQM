"""Build IEEEtran A4 admission addendum and render every page."""
from pathlib import Path
import shutil,json,subprocess
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript';M.mkdir(exist_ok=True)
parent=R.parent/'MQM_PLANAR_ENCODED_SWAP_v0.1'
for n in ['IEEEtran.cls','LPPL-1.3c.txt']:shutil.copy2(parent/'manuscript'/n,M/n)
shutil.copy2(parent/'PUBLICATION_FORMAT_POLICY_v1.0.json',R/'PUBLICATION_FORMAT_POLICY_v1.0.json')
receipt=json.loads((R/'results/REPLAY_RECEIPT.json').read_text())
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newcommand{\ket}[1]{|#1\rangle}
\begin{document}
\title{Exact Static Admission of a Native Qubit\\into Two Quantum Modes}
\author{Benjamin Walker Mayes\thanks{MQM development addendum v0.1, October 5, 2026. ORCID: 0009-0002-5813-0724. Exact scoped operator result; independent review and theorem-level novelty comparison pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We give an exact three-qubit, two-local, time-independent Hamiltonian that coherently encodes an arbitrary native qubit into two single-excitation modes. Its physical interaction graph is a planar triangle. After an explicit energy-origin shift, its full operator norm is one, its spectral width is two, and its endpoint time is $3\pi/2$. The same positive generator implements decoding at the same duration; no intermediate pulse scheduling or large spectral penalty is required for either isolated operation. Integer and rational certificates cover the full spectrum, both input--output isometries, spectator extension, and common binary64 coefficient rounding. This closes a one-qubit admission subproblem, not the two-qubit joint admission required by the preceding 16-mode SWAP core. We also correct overstatements in an external review, including the exclusion of diagonal phase gates from planar path encodings.
\end{abstract}
\begin{IEEEkeywords}
Autonomous quantum control, native admission, two-local Hamiltonian, coherent encoding, finite resource certificate.
\end{IEEEkeywords}

\section{Admission task and accounting boundary}
Let $A$ be an unknown native qubit and $u,v$ be mode qubits. The admitted initial state is
\begin{equation}
\ket\psi_A\ket{10}_{uv}
=(\alpha\ket0+\beta\ket1)_A\ket{10}_{uv}.
\end{equation}
The desired final state is $\ket0_A(\alpha\ket{10}+\beta\ket{01})_{uv}$ up to a common phase. The state of the native qubit is transferred coherently; it is not measured, discarded, or erased. Any external spectator is included in the operational guarantee.

Static two-local computation and engineered transfer are established prior art \cite{nagaj,christandl}. This note claims a finite certified admission primitive, not novelty of those general principles, a minimal architecture, or an experimental realization. In particular, it does not replace the two-native-qubit encoder of the preceding MQM SWAP construction \cite{parent}.

\section{A bounded-spectrum static generator}
Write $N_q=(I-Z_q)/2$, $S=N_A+N_v$, and
\begin{align}
K_g&=gX_uS+\frac g2(X_AX_v+Y_AY_v)+2gS,\nonumber\\
H_g&=K_g-3gI.\label{eq:H}
\end{align}
The energy origin $-3gI$ is explicit. It affects only the common phase and is charged when stating the full norm. Every nontrivial term acts on at most two qubits: the pairs are $(A,u),(u,v),(A,v)$. They form a planar triangle of degree two. There is no mediator, detuning scale, or low-energy approximation.

Equivalently, the centered generator has the Pauli expansion
\begin{align}
H_g=g\big[&-I-Z_A-Z_v+X_u\nonumber\\
&-\tfrac12(X_uZ_A+X_uZ_v)
+\tfrac12(X_AX_v+Y_AY_v)\big].\label{eq:pauli}
\end{align}
Thus the complete physical ledger has three qubits, three pairs, four one-body terms or identities, and four two-body Pauli terms. Identities are included in the eight-term representation.

\begin{theorem}[Static native admission]
For $g=1/3$, $\|H_g\|=1$ on the full eight-dimensional register and its spectral width is two. At $T=\pi/(2g)=3\pi/2$,
\begin{equation}
e^{-iH_gT}\ket\psi_A\ket{10}_{uv}
=-i\ket0_A(\alpha\ket{10}+\beta\ket{01})_{uv}.
\end{equation}
The same generator acting for another duration $T$ decodes the admitted modes into the native qubit, with the same common phase. These identities hold with arbitrary spectators.
\end{theorem}
\begin{proof}
The three parts of $K_g$ commute because XY transport between $A,v$ conserves $S$. In the $S=0$ sector, $K_g=0$, so the zero-input state $\ket{010}_{Auv}$ acquires only $e^{i3gT}=-i$.

In the $S=1$ sector, regard $\ket{10}_{Av},\ket{01}_{Av}$ as a logical two-state system with flip $X_{Av}$. Here
\begin{equation}
H_g=gX_u+gX_{Av}-gI.
\end{equation}
Both flips act on independent factors. At $gT=\pi/2$, their product evolution is $-iX_uX_{Av}$. It maps $\ket{110}$ to $-i\ket{001}$ and vice versa. Along with the zero-input state, this proves the encoder and decoder by linearity. Tensoring the isometry identity with an identity operator proves spectator uniformity.

The full $S=0$ spectrum is $-3g$ with multiplicity two. The $S=1$ eigenvalues are $-3g,-g,-g,g$. In the $S=2$ sector, $H_g=gI+2gX_u$, with eigenvalues $-g,3g$. Overall, $H_g/g$ has eigenvalues $(-3,-1,1,3)$ with multiplicities $(3,3,1,1)$, and characteristic polynomial
\begin{equation}
(z+3)^3(z+1)^3(z-1)(z-3).
\end{equation}
Hence the full norm is $3g$ and the spectral width is $6g$. At $g=1/3$ these are one and two. All endpoint eigenphases are $\pm i$, so $e^{-2iH_gT}=-I$ on the entire physical register.
\end{proof}

\section{Exact rounding and readout interval}
Distances mean half the trace norm or half the diamond norm. The all-input isometry bound therefore includes entangled spectators and the full three-qubit output, not only a reduced mode state.

Implement all coefficients using the same rational binary64 value
\begin{equation}
g_r=\frac{6004799503160661}{18014398509481984}.
\end{equation}
Exact halving retains the coefficient ratios in (\ref{eq:pauli}). The full implemented norm is
\begin{equation}
3g_r=1-2^{-54}<1,
\end{equation}
and the generator mismatch is exactly $d=3|g_r-1/3|=2^{-54}$. At the nominal deadline $T=3\pi/2<5$, Duhamel's bound gives endpoint error below $5d<2^{-40}$. Calibrating instead to $T_r=\pi/(2g_r)$ restores exact ideal arrival in this common-scale model.

For the nominal window $|t-T|\le2^{-18}$, the implemented full norm is at most one, so
\begin{equation}
D_{\rm complete}(t)\le2^{-18}+5\,2^{-54}<2^{-16}.
\end{equation}
This is an interval certificate, not a sampled trajectory. It assumes exact coefficient ratios and correct initial seed. A preparation debit $\epsilon_{\rm prep}$ and additional independent generator mismatch $d_{\rm phys}$ add at most $\epsilon_{\rm prep}+t\,d_{\rm phys}$. Timing is in model units without physical calibration.

\section{Review corrections and the phase-path extension}
The accompanying review correctly identifies unresolved native admission, interface scheduling, and exponential joint-mode cost. Its stronger conclusions require narrowing.

First, the fixed-port obstruction in \cite{parent} concerns a specified generator column with a product launch encoding. It does not prove that joint mode encoding is necessary for all penalty-free two-local transport. Second, 110 interface gates and 744 routing SWAPs are counts of an explicit upper-bound construction, not lower bounds. Third, the rounding-scaled parent deadline is $8\pi(1+d)$, and its channel convention is half the diamond norm. Removing the old detuning cost in a changed encoding is not a matched end-to-end speed advantage. Autonomy also does not, by itself, establish resource advantage.

The review incorrectly groups T with basis-mixing gates. T is diagonal. More generally a monomial unitary obeys
\begin{equation}
U_j\ket a=e^{i\theta_{j,a}}\ket{\pi_j(a)}.
\end{equation}
It still routes each basis state along one physical path. A complex edge amplitude $h$ has the two-local realization
\begin{align}
H_{xy}={}&\frac{\operatorname{Re}h}{2}(X_xX_y+Y_xY_y)\nonumber\\
&+\frac{\operatorname{Im}h}{2}(X_xY_y-Y_xX_y).
\end{align}
On disjoint paths, vertex phase rotations remove all edge phases. This is a unitary equivalence on the full physical register, so the full spectrum is unchanged when edge magnitudes are fixed. T therefore preserves the path topology under this extension. H mixes basis states, invalidating the disjoint-path proof, but that alone does not prove nonplanarity.

The UD-inspired graph here denotes physical two-body support pairs. No GR spin-network, QFT continuum, or thermodynamic correspondence follows from it.

\section{Unclosed two-qubit interface and physical assumptions}
Two copies of this primitive encode two native qubits into a product of two dual-mode registers. That product has two mode excitations, whereas the 16-mode SWAP core requires one excitation jointly encoding its two-qubit body. Copying the primitive therefore does not solve that core's admission contract. Nor does an isolated encoding endpoint compile the admission, execution, and extraction sequence into one fixed generator.

The next task is the explicit six-qubit isometry
\begin{equation}
\ket{ab}_{AO}\ket{\mathbf1_{00}}_{M}
\longmapsto\ket{00}_{AO}\ket{\mathbf1_{ab}}_{M},
\end{equation}
for four mode qubits $M$, uniformly over unknown inputs and spectators. A candidate must supply a planar two-local fixed generator, a full-spectrum norm certificate, and a finite arrival window. Additional mediators, fresh registers, or controller terms must be counted. The present one-qubit theorem does not certify that extension.

Although $S$ is conserved, neither $N_u+N_v$ nor $N_A+N_u+N_v$ is conserved. During admission the mode state can leave the single-excitation sector; the guarantee is an endpoint isometry on the full three-qubit domain. The old invariant clock-sector assumption is not retained for this interface. The model cannot be promoted to energy-conserving exchanges of nondegenerate bare qubits without a further realization or coherent-supply construction. Conservation of the fixed total generator is not an energy ledger for separately specified bare Hamiltonians. The primitive also recurs; it provides no permanent latch or reservoir refresh.

The replay records EXACTCOUNT exact checks and NUMCOUNT numerical diagnostics, including full characteristic-polynomial, encoder/decoder, spectator, and complex-phase identities. Numerical propagation supports rather than replaces the algebra. Independent review, novelty comparison, physical realization, and matched resource advantage remain open.

\begin{thebibliography}{3}
\bibitem{nagaj} D. Nagaj, ``Universal 2-local Hamiltonian quantum computing,'' \emph{Phys. Rev. A}, vol. 85, 032330, 2012, doi: 10.1103/PhysRevA.85.032330.
\bibitem{christandl} M. Christandl, N. Datta, A. Ekert, and A. J. Landahl, ``Perfect state transfer in quantum spin networks,'' \emph{Phys. Rev. Lett.}, vol. 92, 187902, 2004, doi: 10.1103/PhysRevLett.92.187902.
\bibitem{parent} B. W. Mayes, ``A planar penalty-free two-local SWAP core: Exact arrival and the cost of native interfaces,'' MQM IEEE-focused development note v0.1, Oct. 5, 2026, unpublished. Release digest in INPUT\_ANCHORS.json.
\end{thebibliography}
\end{document}
'''
tex=tex.replace('EXACTCOUNT',str(receipt['exact_count'])).replace('NUMCOUNT',str(receipt['numerical_count']))
name='MQM_AUTONOMOUS_NATIVE_ADMISSION_IEEE_A4_v0.1'
(M/(name+'.tex')).write_text(tex)
for k in range(3):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,text=True,capture_output=True)
    (R/'results'/f'PDF_BUILD_{k+1}.txt').write_text(p.stdout+p.stderr)
    assert p.returncode==0,p.stdout[-2500:]
log=(M/(name+'.log')).read_text();assert 'Overfull' not in log
doc=fitz.open(M/(name+'.pdf'));sizes=[]
for k,p in enumerate(doc):
    sizes.append([p.rect.width,p.rect.height])
    assert abs(p.rect.width-595.276)<.05 and abs(p.rect.height-841.89)<.05
    p.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/f'PAGE_{k+1}.png')
assert '??' not in '\n'.join(p.get_text() for p in doc)
(R/'results/PDF_QA.json').write_text(json.dumps(dict(pages=len(doc),sizes_points=sizes,
    format='IEEEtran v1.8b journal,a4paper,10pt; two columns',no_overfull=True,no_unresolved_references=True,visual_review='pending'),indent=2)+'\n')
print(json.dumps(dict(pdf=str(M/(name+'.pdf')),pages=len(doc))))
