"""Freeze the model certificate, review audit and next-interface contract."""
from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parent
def dump(n,v):(R/n).write_text(json.dumps(v,indent=2)+'\n')
q=json.loads((R/'results/PDF_QA.json').read_text());assert q['visual_review']=='passed'
p=R.parent/'MQM_PLANAR_ENCODED_SWAP_v0.1_RELEASE.zip'
attachment=R.parent.parent/'upload/Pasted text(2).txt'
dump('INPUT_ANCHORS.json',dict(parent_release=p.name,parent_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    review_source=attachment.name,review_sha256=hashlib.sha256(attachment.read_bytes()).hexdigest(),
    parent_immutable=True,operation='new scoped addendum; no parent claims promoted',
    mathematical_source='Explicit operator construction and direct replay; novelty comparison pending'))
dump('CLAIM_REGISTER_v0.1.json',dict(locked_scoped_exact=['Three-qubit static encoder and decoder at 3*pi/2',
    'Physical two-local triangle; full centered norm 1 and width 2',
    'All-input and spectator-uniform isometry identities',
    'Common binary64 scale has full norm 1-2^-54 and exact generator mismatch 2^-54',
    'Nominal readout interval 2^-18 has complete-domain half-diamond error below 2^-16',
    'T phase monomial extension preserves disjoint-path pair topology and full spectrum at fixed edge magnitudes'],
    open=['Two-native-qubit joint single-excitation encoder','Autonomous integration with the SWAP core',
    'Minimality, novelty and independent review','Bare-Hamiltonian and coherent-supply realization',
    'Irreversible latch and clock refresh','Matched end-to-end resource advantage'],physical_promotion=0))
dump('TWO_QUBIT_ADMISSION_CONTRACT_v0.1.json',dict(status='OPEN',
    input='|ab>_AO tensor |1_00>_four_modes, unknown and spectator entangled',
    output='common_phase |00>_AO tensor |1_ab>_four_modes',
    initial_physical_qubits=6,extra_ancillas='must be declared and charged',
    required=['Time-independent explicit qubit Hamiltonian with support weight <=2',
       'Planar complete physical support-pair graph','Full physical norm <=1 with origin recorded',
       'Finite deadline and complete input-isometry window bound',
       'No hidden scheduled phase change, energy penalty or discarded correlation',
       'Same input and output contract for comparison against 110-gate and routed 854-gate constructions'],
    non_solution='Two independent one-qubit encoders produce two mode excitations, not the required one joint excitation.'))
(R/'REVIEW_RESPONSE.txt').write_text('''Review disposition: broad direction useful; strong claims narrowed.

1. Old billion-unit bound remains valid for its native-data encoding. The 16-mode core changes the encoding and interface contract; its deadline is not a matched native end-to-end speedup.
2. Parent core arithmetic uses half the diamond norm and, after conservative norm rescaling, a window centered on 8*pi*(1+d). State admission, native control and physical errors are separate debits.
3. The fixed-port proposition forbids one specified generator column. It does not prove joint mode encoding universally necessary, nor rule out all penalty-free two-local native encoders.
4. 110 interface gates and 744 additional routing SWAPs are explicit upper bounds, not minimum requirements. T and T-dagger both occur in the schedule.
5. T is diagonal, hence monomial. Its phases can be placed on two-local complex hoppings without changing disjoint paths. Vertex phase gauges preserve the full physical spectrum at fixed magnitudes. H mixes basis modes; this breaks the disjoint-path argument but does not by itself establish nonplanarity.
6. Autonomous admission is required for the fully autonomous target. Its absence alone proves neither the absence nor presence of resource advantage. A matched comparator remains necessary.
7. The finite physical graph does not establish GR or QFT correspondence. 7168 mode qubits is the exact cost of the naive n=9,m=13 joint construction, not an impossibility or a universal lower bound.

Next action completed: isolated one-native-qubit admission has an exact static three-qubit planar two-local generator, centered full norm one, finite deadline 3*pi/2, and the same-generator decoder. This does not replace the full two-native-qubit interface. The next contract is captured separately. Novelty, realization and physical promotion remain open/0.
''')
(R/'README.txt').write_text('''MQM AUTONOMOUS NATIVE ADMISSION v0.1
Benjamin Walker Mayes; ORCID 0009-0002-5813-0724
EXACT scoped mathematical primitive; independent review and novelty comparison pending. Physical promotion 0.

Result: one native qubit coherently maps into two mode qubits using a fixed two-local Hamiltonian on a three-qubit triangle. Full centered norm 1, width 2, ideal endpoint 3*pi/2. Same generator decodes at that duration. No detuning, perturbative approximation, or intermediate pulse schedule is used in this isolated operation.
Scope: fixed mode seed and unknown input; arbitrary spectators admitted. Does not solve two-native-qubit joint admission into the prior core, and does not compile an entire execute/capture/renew cycle.
Mode occupation can leave the one-excitation sector during admission; the endpoint isometry is certified on the full three-qubit domain. Bare excitation count is not conserved. The full energy origin is explicit. Physical supply and bare-Hamiltonian realization remain open.

Replay: python3 certify_admission.py
Build: python3 build_ieee_note.py (requires pdflatex)
Dependencies: numpy, scipy, sympy, networkx; PyMuPDF for rendering.
Verified: 28 exact checks and 12 numerical diagnostics.
Paper format: actual IEEEtran, journal,a4paper,10pt, two columns. All future MQM paper PDFs retain IEEE A4 policy.
''')
files=[f for f in sorted(R.rglob('*')) if f.is_file() and f.suffix not in ['.aux','.log','.out'] and f.name!='SHA256_MANIFEST.json']
dump('SHA256_MANIFEST.json',{str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files})
archive=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files+[R/'SHA256_MANIFEST.json']:z.write(f,str(Path(R.name)/f.relative_to(R)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps(dict(zip=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=len(files)+1)))
