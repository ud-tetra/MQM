MQM AUTONOMOUS NATIVE ADMISSION v0.1
Benjamin Walker Mayes; ORCID 0009-0002-5813-0724
EXACT scoped mathematical primitive; independent review and novelty comparison pending. Physical promotion 0.

Result: one native qubit coherently maps into two mode qubits using a fixed two-local Hamiltonian on a three-qubit triangle. Full centered norm 1, width 2, ideal endpoint 3*pi/2. Same generator decodes at that duration. No detuning, perturbative approximation, or intermediate pulse schedule is used in this isolated operation.
Scope: fixed mode seed and unknown input; arbitrary spectators admitted. Does not solve two-native-qubit joint admission into the prior core, and does not compile an entire execute/capture/renew cycle.
Mode occupation can leave the one-excitation sector during admission; the endpoint isometry is certified on the full three-qubit domain. Bare excitation count is not conserved. The full energy origin is explicit. Physical supply and bare-Hamiltonian realization remain open.

Replay: python3 certify_admission.py
Build: python3 build_ieee_note.py (requires pdflatex)
Dependencies: numpy, scipy, sympy, networkx; PyMuPDF for rendering.
Verified: 28 exact checks and 12 numerical diagnostics.
Paper format: actual IEEEtran, journal,a4paper,10pt, two columns. All future MQM paper PDFs retain IEEE A4 policy.
