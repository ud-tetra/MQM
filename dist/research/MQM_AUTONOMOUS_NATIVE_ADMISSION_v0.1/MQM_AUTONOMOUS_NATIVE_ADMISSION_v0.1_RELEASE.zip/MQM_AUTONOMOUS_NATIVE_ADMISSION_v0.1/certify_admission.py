"""Exact static native-qubit to dual-mode admission certificate; no optimization."""
from pathlib import Path
from fractions import Fraction as F
import json,platform
import sympy as s
import numpy as np
import networkx as nx
from scipy.linalg import expm
R=Path(__file__).resolve().parent
(R/'results').mkdir(exist_ok=True)
exact=[];numeric=[]
def check(n,p):
    assert bool(p),n
    exact.append(n)
def ncheck(n,v,tol=2e-12):
    assert v<tol,(n,v)
    numeric.append(dict(label=n,residual=float(v),ceiling=tol))
I=s.eye(2);X=s.Matrix([[0,1],[1,0]]);Y=s.Matrix([[0,-s.I],[s.I,0]]);Z=s.diag(1,-1);N=s.diag(0,1)
def lift(op,j):return s.kronecker_product(*[op if k==j else I for k in range(3)])
NA,Nu,Nv=[lift(N,j) for j in range(3)]
XA,Xu,Xv=[lift(X,j) for j in range(3)]
YA,Yv=lift(Y,0),lift(Y,2)
ZA,Zv=lift(Z,0),lift(Z,2)
total=NA+Nv
H0=Xu*total+(XA*Xv+YA*Yv)/2+2*total-3*s.eye(8)
g=s.Rational(1,3);H=g*H0
pauli=-s.eye(8)-ZA-Zv+Xu-(Xu*ZA+Xu*Zv)/2+(XA*Xv+YA*Yv)/2
check('explicit weight-at-most-two Pauli generator',H0==pauli)
check('Hermiticity',H==H.conjugate().T)
check('transport commutes with total source-target excitation',H0*total==total*H0)
check('conditional mode flip commutes with transport',Xu*total*(XA*Xv+YA*Yv)==(XA*Xv+YA*Yv)*Xu*total)
check('bare total excitation is not conserved',H*(total+Nu)!=(total+Nu)*H)
check('mode-sector invariance is not assumed during admission',H*(Nu+Nv)!=(Nu+Nv)*H)
z=s.symbols('z');expected=(z+3)**3*(z+1)**3*(z-1)*(z-3)
check('full eight-dimensional characteristic polynomial',s.expand(H0.charpoly(z).as_expr()-expected)==0)
check('full norm one',max(abs(e*g) for e in [-3,-1,1,3])==1)
check('full spectral width two',6*g==2)
E=s.zeros(8,2);E[2,0]=1;E[6,1]=1
W=s.zeros(8,2);W[2,0]=1;W[1,1]=1
check('native admission isometry',E.T*E==s.eye(2))
check('encoded output isometry',W.T*W==s.eye(2))
U=s.zeros(8)
for lam,phase in [(-3,-s.I),(-1,s.I),(1,-s.I),(3,s.I)]:
    P=s.eye(8)
    for other in [-3,-1,1,3]:
        if other!=lam:P=P*(H0-other*s.eye(8))/(lam-other)
    U+=phase*P
check('exact endpoint encoder at T=3*pi/2',U*E==-s.I*W)
check('same positive generator implements decoder',U*W==-s.I*E)
check('full return at twice the deadline',U*U==-s.eye(8))
check('output native qubit fixed at zero',(NA*W)==s.zeros(8,2))
check('output mode register has one excitation',(Nu+Nv)*W==W)
check('native zero-input and seed stay on an eigenspace',H*E[:,0]==-E[:,0])
graph=nx.Graph([('A','u'),('u','v'),('A','v')])
check('physical graph planar',nx.check_planarity(graph)[0])
check('three physical qubits, three pairs, degree two',len(graph)==3 and graph.number_of_edges()==3 and max(dict(graph.degree()).values())==2)
# Review correction: a T phase is monomial and preserves physical path adjacency.
phase=(1+s.I)/s.sqrt(2);TP=s.diag(1,phase)
check('T is monomial with identity basis permutation',TP[0,1]==0 and TP[1,0]==0)
xy=(s.kronecker_product(X,X)+s.kronecker_product(Y,Y))/2
phased=(s.kronecker_product(X,X)+s.kronecker_product(Y,Y)+s.kronecker_product(X,Y)-s.kronecker_product(Y,X))/(2*s.sqrt(2))
gauge=s.kronecker_product(I,TP)
check('two-local complex hopping phase',s.simplify(phased[1,2]-phase)==0)
check('full physical phase-edge gauge equivalence',s.simplify(gauge*xy*gauge.conjugate().T-phased)==s.zeros(4))
# Common rounded rational g and exact halving retain all coefficient ratios.
gr=F.from_float(float(F(1,3)));dg=abs(gr-F(1,3));d=3*dg
check('rounded scale below exact scale',gr<F(1,3))
check('exact binary64 full norm 1-2^-54',3*gr==1-F(1,1<<54))
check('exact rounded generator debit 2^-54',d==F(1,1<<54))
tau=F(1,1<<18);bound=tau+5*d
check('nominal deadline rounded endpoint below 2^-40',5*d<F(1,1<<40))
check('whole interval error below 2^-16',bound<F(1,1<<16))
# Spectator extension is an operator identity, not a product-input assumption.
check('spectator-uniform endpoint identity',s.kronecker_product(U,s.eye(2))*s.kronecker_product(E,s.eye(2))==-s.I*s.kronecker_product(W,s.eye(2)))
Hn=np.array(H).astype(complex);En=np.array(E).astype(complex);Wn=np.array(W).astype(complex)
T=3*np.pi/2
ncheck('all native-input endpoint channel',np.linalg.norm(expm(-1j*T*Hn)@En+1j*Wn,2))
ncheck('whole physical spectrum diagnostic',np.max(abs(np.linalg.eigvalsh(Hn)-np.array([-1]*3+[-1/3]*3+[1/3,1]))))
ncheck('same-generator native decoder',np.linalg.norm(expm(-1j*T*Hn)@Wn+1j*En,2))
ncheck('full physical projective return',np.linalg.norm(expm(-2j*T*Hn)+np.eye(8),2))
for k,t in enumerate([T/7,T/3,T/2,T,T+float(tau)]):
    # Independent factorization of the three commuting pieces.
    factor=np.exp(3j*t/3)*expm(-1j*t*np.array(Xu*total).astype(complex)/3)@expm(-1j*t*np.array((XA*Xv+YA*Yv)/2).astype(complex)/3)@expm(-2j*t*np.array(total).astype(complex)/3)
    ncheck('commuting factorization '+str(k),np.linalg.norm(expm(-1j*t*Hn)-factor,2))
bell=np.eye(2).reshape(-1)/np.sqrt(2)
ncheck('entangled external spectator',np.linalg.norm(np.kron(expm(-1j*T*Hn)@En,np.eye(2))@bell+1j*np.kron(Wn,np.eye(2))@bell))
Hr=float(gr)*np.array(H0).astype(complex)
ncheck('rounded native encoder diagnostic',np.linalg.norm(expm(-1j*T*Hr)@En+1j*Wn,2))
ncheck('rounded scale calibrated endpoint',np.linalg.norm(expm(-1j*np.pi/(2*float(gr))*Hr)@En+1j*Wn,2))
receipt=dict(exact_count=len(exact),exact_checks=exact,numerical_count=len(numeric),numerical_checks=numeric,
    parameters=dict(g='1/3',physical_qubits=3,pairs=3,maximum_degree=2,planar=True,full_norm=1,width=2,
      deadline='3*pi/2',window_halfwidth=str(tau),window_bound=str(bound),window_bound_float=float(bound),
      rounded_g=str(gr),rounded_full_norm=str(3*gr),generator_rounding_bound=str(d)),
    scope='One native qubit and two mode qubits; does not encode two native qubits into four jointly single-excited modes.',
    promotion='conditional exact mathematical primitive; physical promotion 0; novelty and independent review pending',
    environment=dict(python=platform.python_version(),sympy=s.__version__,numpy=np.__version__,networkx=nx.__version__))
(R/'results/REPLAY_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['exact_count','numerical_count','parameters']},indent=2))
