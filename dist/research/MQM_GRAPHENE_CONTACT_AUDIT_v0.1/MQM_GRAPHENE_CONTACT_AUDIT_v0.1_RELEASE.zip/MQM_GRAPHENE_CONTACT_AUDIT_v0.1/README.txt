Finite-Contact Audit of a Selected Graphene Transmission Target
Benjamin Walker Mayes | ORCID0009-0002-5813-0724 | MQM v0.1

MODEL
Infinite-mass boundaries,q_n=(n+1/2)pi/W. Neutral strip,L30nm,hbar*vF
0.6582119eVnm. Identical uniform-width finite-doping leads,abrupt interfaces,
zero temperature,no disorder/interactions/magnetic field. PROTOCOL.json frozen
before successor evaluation; selected target was exposed earlier.
T_n=1/[cosh(qL)^2+(q/kx)^2sinh(qL)^2],kx=sqrt(kF^2-q^2),only q<kF.
Six exact checks include symbolic amplitude/current identities and bookkeeping;
27 numerical checks verify mode matching,flux conservation and a fitted root.

RESULT
Ideal-contact width15.502297nm requires lowest transverse energy66.694429meV.
Uniform-width50meV lead has no incoming mode.200meV lead reducesT0 by11.03%.
Refitting gives15.795235nm,T0=7/768 within binary64 root tolerance,2 open modes.
Total mode transmission differs from per-mode target. Width+/-1% changesT0
approximately-6.05%/+6.31%. This is sensitivity,not empirical uncertainty.
No gate voltage or material scattering law is derived. Physical promotion0.
Occupancy-to-transmission and transmission-to-latch-rate bridges remainOPEN.
No hardware result,quantum advantage or certified fabrication width.

REPLAY
  python3 audit_transport.py
numpy,scipy,sympy. No random seeds/shots/device records. Parameter fitting is
declared engineering tuning,not independent prediction. Mathematical contact
checks do not establish that hBN/lithography implements these boundary conditions.

PDF
  python3 build_pdf.py
Requires pdflatex,IEEEtran,balance,PyMuPDF. Inspect both PAGE_*.png then:
  python3 prepare_release.py --visual-review-confirmed
IEEEtran journal,A4,10pt,two columns;class license included.
SOURCE_ANCHORS and CLAIM_REGISTER preserve source/evidence boundaries.
SHA256SUMS.txt covers distributed files; earlier releases remain immutable.
