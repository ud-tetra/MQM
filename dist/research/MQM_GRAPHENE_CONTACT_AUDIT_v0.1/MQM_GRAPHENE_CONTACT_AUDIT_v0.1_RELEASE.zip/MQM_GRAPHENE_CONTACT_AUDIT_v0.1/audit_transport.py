"""Frozen ideal Dirac-strip contact and mode audit; no device validation."""
from pathlib import Path
from fractions import Fraction
import json,math
import numpy as np
import sympy as s
from scipy.optimize import brentq
R=Path(__file__).resolve().parent
protocol={'status':'FROZEN before successor evaluation; exploratory model comparison','boundary':'Infinite-mass hard confinement: q_n=(n+1/2)pi/W','contact':'Identical uniform-width ideal leads; chemical-potential energy mu_lead relative to lead Dirac point','interior':'Uniform strip at neutrality, mu_strip=0; abrupt mode-preserving interfaces','temperature':0,'disorder':False,'interactions':False,'L_nm':30,'hbar_vF_eV_nm':0.6582119,'target':'7/768 per lowest mode; NOT total transmission or occupancy','lead_energy_scan_eV':[0.05,0.10,0.20,0.50,1.0],'nominal_finite_lead_eV':0.20,'width_sensitivity_fraction':0.01,'physical_promotion':0,'gate_voltage':'Not inferred; no capacitance or lever-arm calibration','unit_convention':'Transmission modes counted without spin/valley multiplicities; conductance conversion requires separate degeneracy contract','acceptance':'Compare exact algebraic mode matching to analytic formula, determine open modes and finite-contact/total-mode corrections; not certify material feasibility.'}
(R/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2))
checks=[]
def check(name,val):assert bool(val),name;checks.append(name)
# Symbolic matching: P u_in + r P u_ref = t u_in, with q/kx=z.
z,c=s.symbols('z c',real=True);ss=s.symbols('ss',positive=True);den=1+z*z
# Let longitudinal kx=1, Fermi radius sqrt(1+z^2); spinor ratio(1+i z)/sqrt(...).
k=s.sqrt(den);ui=s.Matrix([1,(1+s.I*z)/k]);ur=s.Matrix([1,(-1+s.I*z)/k]);P=s.diag(c+ss,c-ss)
mat=s.Matrix.hstack(P*ur,-ui);sol=s.simplify(mat.inv()*(-P*ui));t=sol[1]
check('matched amplitude',s.simplify(t-(c*c-ss*ss)/(c+s.I*z*ss))==0)
check('current-normalized transmitted probability',s.simplify(t*s.conjugate(t)-(c*c-ss*ss)**2/(c*c+z*z*ss*ss))==0)
check('same lead incoming and outgoing flux',s.simplify((ui.conjugate().T*s.Matrix([[0,1],[1,0]])*ui)[0]-2/k)==0)
check('target fraction',Fraction(7,768)==Fraction(7,4*192))
check('threshold denominator factorization',768==2**8*3)
check('finite-contact propagation-threshold limit',s.limit(1/(c*c+z*z*ss*ss),z,s.oo)==0)
L=30.;hv=.6582119;target=float(Fraction(7,768));x=math.acosh(math.sqrt(1/target));W0=math.pi*L/(2*x)
def mode(W,mu,n):
 q=(n+.5)*math.pi/W;kF=mu/hv
 if q>=kF:return 0.
 kx=math.sqrt(kF*kF-q*q)
 return 1/(math.cosh(q*L)**2+(q/kx)**2*math.sinh(q*L)**2)
def count(W,mu):return sum((n+.5)*math.pi/W<mu/hv for n in range(200))
def total(W,mu):return sum(mode(W,mu,n) for n in range(count(W,mu)))
numeric=[];rows=[]
for mu in protocol['lead_energy_scan_eV']:
 N=count(W0,mu);Ts=[mode(W0,mu,n) for n in range(N)]
 rows.append({'lead_eV':mu,'open_modes':N,'T0':Ts[0] if N else None,'sum_modes':sum(Ts),'relative_T0_change':Ts[0]/target-1 if N else None})
 for n in range(N):
  q=(n+.5)*math.pi/W0;kF=mu/hv;kx=math.sqrt(kF*kF-q*q)
  u=np.array([1,(kx+1j*q)/kF]);rvec=np.array([1,(-kx+1j*q)/kF]);prop=np.diag([math.exp(q*L),math.exp(-q*L)])
  rr,tt=np.linalg.solve(np.column_stack([prop@rvec,-u]),-prop@u)
  assert abs(abs(tt)**2-mode(W0,mu,n))<1e-12
  assert abs(abs(rr)**2+abs(tt)**2-1)<1e-12
  numeric.extend(['mode matching '+str((mu,n)),'flux conservation '+str((mu,n))])
Wfit=brentq(lambda W:mode(W,.2,0)-target,hv*math.pi/(2*.2)*(1+1e-9),100.,xtol=1e-12)
assert abs(mode(Wfit,.2,0)-target)<1e-12;numeric.append('finite-contact inverse-design numerical root')
sensitivity=[]
for frac in [-.01,0,.01]:
 W=Wfit*(1+frac);sensitivity.append({'width_nm':W,'fractional_width_change':frac,'T0':mode(W,.2,0),'relative_target_change':mode(W,.2,0)/target-1,'open_modes':count(W,.2),'sum_modes':total(W,.2)})
negative={'lead50meV_open_modes_at_W0':count(W0,.05),'transmission_is_occupancy_trigger':False}
result={'status':'EXACT symbolic contact matching; binary64 exploratory parameter evaluation','exact_count':len(checks),'exact_checks':checks,'numerical_count':len(numeric),'numerical_checks':numeric,'matching_tolerance':1e-12,'target':str(Fraction(7,768)),'W_infinite_contact_nm':W0,'lowest_mode_energy_eV':hv*math.pi/(2*W0),'finite_contact_formula':'T_n=1/[cosh(q_n L)^2+(q_n/kx_n)^2 sinh(q_n L)^2],kx_n=sqrt((mu_lead/hbar_vF)^2-q_n^2); only q_n<mu_lead/hbar_vF','lead_scan':rows,'W_recalibrated_for_200meV_nm':Wfit,'recalibrated_open_modes':count(Wfit,.2),'recalibrated_T0':mode(Wfit,.2,0),'recalibrated_sum_modes':total(Wfit,.2),'width_sensitivity':sensitivity,'negative_controls':negative,'scope':'Model equations, not interval-certified dimensional design or measured hardware; fitting after target choice is disclosed engineering','physical_promotion':0}
(R/'results/TRANSPORT_AUDIT.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:result[k] for k in ['exact_count','numerical_count','W_infinite_contact_nm','lowest_mode_energy_eV','W_recalibrated_for_200meV_nm','recalibrated_open_modes','recalibrated_sum_modes','lead_scan','width_sensitivity']},indent=2))
