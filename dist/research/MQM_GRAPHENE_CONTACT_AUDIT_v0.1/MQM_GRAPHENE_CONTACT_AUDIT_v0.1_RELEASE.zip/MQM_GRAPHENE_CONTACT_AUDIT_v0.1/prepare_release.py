from pathlib import Path
import argparse,json,hashlib,zipfile,platform
import numpy,scipy,sympy,fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args();assert args.visual_review_confirmed
def read(n):return json.loads((R/n).read_text())
def write(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
d=read('results/TRANSPORT_AUDIT.json');q=read('results/PDF_QA.json')
assert d['exact_count']==6 and d['numerical_count']==27 and d['lead_scan'][0]['open_modes']==0
assert q['pages']==2 and q['A4'] and q['no_overfull'] and q['no_unresolved_references']
q['visual_review']='PASSED: both final IEEE A4 pages inspected; tables and equations readable, no overlap or clipping.';write('results/PDF_QA.json',q)
write('SOURCE_ANCHORS.json',{'primary_source':'J.Tworzydlo etal.,Sub-Poissonian Shot Noise in Graphene,PRL96,246802(2006)','author_preprint':'https://arxiv.org/pdf/cond-mat/0603315','version':'v3,10April2006','verified':'2026-10-06','scope':'Infinite-mass boundary and mode-matching background. This release defines finite-lead wavevectors explicitly and verifies its own matching formula. No source device demonstrates this target.','capacity_latch_release_library_id':'libfile_b0abc6cb80788191ba420ad1d012d6fd','capacity_latch_zip_sha256':hashlib.sha256((R.parent/'MQM_CAPACITY_BOUNDARY_LATCH_v0.1_RELEASE.zip').read_bytes()).hexdigest(),'threshold_provenance':'Selected7/768 transmission target inspired by historical capacity parameter; occupancy,transmission and Lindblad rate not equated.'})
write('CLAIM_REGISTER.json',{'model_matching':{'status':'EXACT symbolic identities / AUTO_LOCK scoped','assumptions':'Infinite-mass strip,neutral interior,identical uniform-width finite-doping ideal leads,abrupt mode-preserving interfaces,T=0,no disorder/interactions/B field','exact_checks':6,'scope':'Continuum model only'},'parameter_evaluation':{'status':'SIMULATED binary64 exploratory inverse design','numerical_checks':27,'lead50meV':'No open modes at ideal-contact width','nominal_lead_eV':.2,'nominal_width_nm':d['W_recalibrated_for_200meV_nm'],'fitted_target':'Lowest-mode7/768 within root tolerance1e-12','mode_sum_equals_target':False,'interval_certified_width':False,'independent_prediction':False},'physical_promotion':0,'device_or_advantage_claim':False,'occupancy_transduction':'OPEN','Lindblad_rate_transduction':'OPEN','independent_review':'pending'})
write('NEXT_GATE.json',{'status':'OPEN','recommended':'Finite interior detuning and energy-window transport under frozen boundary/contact model','strengthening_test':'Track phase and all open-mode transmissions; compare zero-temperature and thermal averages under declared temperatures before physically motivated boundary/disorder study','acceptance':'Declare tolerance band and transduction observable; target matching alone is insufficient','priority_score':80,'score_type':'Prioritization judgment for architecture feasibility; not measured closure percentage','main_MQM_gate':'Native admission and physical reservoir compiler remainOPEN; graphene is an adjacent interface study.'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'pymupdf':fitz.VersionBind})
write('ARITHMETIC_COUNTS.json',{'target':'7/768,768=2^8*3','exact_checks':'6=2*3','numerical_checks':'27=3^3','lead_scan_points':5,'width_sensitivity_points':3,'typed_scope':'Mode counts are not physical qubits; these factors imply no material capacity law.'})
(R/'README.txt').write_text('''Finite-Contact Audit of a Selected Graphene Transmission Target
Benjamin Walker Mayes | ORCID0009-0002-5813-0724 | MQM v0.1

MODEL
Infinite-mass boundaries,q_n=(n+1/2)pi/W. Neutral strip,L30nm,hbar*vF
0.6582119eVnm. Identical uniform-width finite-doping leads,abrupt interfaces,
zero temperature,no disorder/interactions/magnetic field. PROTOCOL.json frozen
before successor evaluation; selected target was exposed earlier.
T_n=1/[cosh(qL)^2+(q/kx)^2sinh(qL)^2],kx=sqrt(kF^2-q^2),only q<kF.
Six exact checks include symbolic amplitude/current identities and bookkeeping;
27 numerical checks verify mode matching,flux conservation and a fitted root.

RESULT
Ideal-contact width15.502297nm requires lowest transverse energy66.694429meV.
Uniform-width50meV lead has no incoming mode.200meV lead reducesT0 by11.03%.
Refitting gives15.795235nm,T0=7/768 within binary64 root tolerance,2 open modes.
Total mode transmission differs from per-mode target. Width+/-1% changesT0
approximately-6.05%/+6.31%. This is sensitivity,not empirical uncertainty.
No gate voltage or material scattering law is derived. Physical promotion0.
Occupancy-to-transmission and transmission-to-latch-rate bridges remainOPEN.
No hardware result,quantum advantage or certified fabrication width.

REPLAY
  python3 audit_transport.py
numpy,scipy,sympy. No random seeds/shots/device records. Parameter fitting is
declared engineering tuning,not independent prediction. Mathematical contact
checks do not establish that hBN/lithography implements these boundary conditions.

PDF
  python3 build_pdf.py
Requires pdflatex,IEEEtran,balance,PyMuPDF. Inspect both PAGE_*.png then:
  python3 prepare_release.py --visual-review-confirmed
IEEEtran journal,A4,10pt,two columns;class license included.
SOURCE_ANCHORS and CLAIM_REGISTER preserve source/evidence boundaries.
SHA256SUMS.txt covers distributed files; earlier releases remain immutable.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'exact_checks':6,'numerical_checks':27}))
