"""Render the scoped research update with the locked IEEEtran A4 format."""
from pathlib import Path
import json,shutil,subprocess
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript';M.mkdir(exist_ok=True)
parent=R.parent/'MQM_SIX_QUBIT_ADMISSION_SEARCH_v0.1'
for name in ['IEEEtran.cls','LPPL-1.3c.txt']:
    source=parent/'manuscript'/name
    if source.exists():shutil.copy2(source,M/name)
    else:assert (M/name).exists()
k=json.loads((R/'results/KERNEL_RECEIPT.json').read_text())
a=json.loads((R/'results/HIGHER_MOMENT_AUDIT.json').read_text())
b=json.loads((R/'results/SECOND_MOMENT_AUDIT.json').read_text())
x=json.loads((R/'results/EXPANDED_PLANAR_FILTER.json').read_text())
s0=json.loads((R/'results/FILTERED_SEARCH_RECEIPT.json').read_text())
s1=json.loads((R/'results/SECOND_MOMENT_SEARCH_RECEIPT.json').read_text())
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\begin{document}
\title{Moment-Constrained Symmetry Breaking\\for Autonomous Joint Qubit Admission}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 5, 2026. ORCID: 0009-0002-5813-0724. Scoped derivations and finite numerical exploration. Independent review and theorem-level novelty comparison pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We formalize symmetry-breaking directions for an unclosed six-qubit static admission isometry. In a fixed 62-parameter real planar two-local ansatz, the exact first-moment kernel has dimension 55. Its intersection with the two bookkeeping-charge commutants has dimension 20, leaving a 35-dimensional charge-breaking complement. Terminal-mode occupation has a different decomposition: 45 conserving directions and ten independent changing directions. We exhibit all ten changing directions, then run four moment-filtered endpoint fits and four fits with a second-moment soft penalty. None supplies the required encoder. Exact binary-rational second-moment witnesses exclude the two frozen best candidates at every deadline at error $2^{-16}$. Allowing all Hermitian two-local terms on the same graph produces a 97-dimensional first-moment kernel after removing scalar identity, without increasing qubits or allowed pairs. This larger search remains unrun. No global impossibility, physical realization, or resource advantage is asserted.
\end{abstract}
\begin{IEEEkeywords}
Autonomous quantum control, two-local Hamiltonian, joint admission, symmetry breaking, spectral moment, planar interaction graph.
\end{IEEEkeywords}

\section{Task and scope correction}
The target retains six physical qubits in order $(A,O,u,v,w,z)$, with the last four modes labeled $00,01,10,11$:
\begin{equation}
E\ket{ab}=\ket{ab}_{AO}\ket{\mathbf1_{00}}_M
\longmapsto e^{i\phi}W\ket{ab}
=e^{i\phi}\ket{00}_{AO}\ket{\mathbf1_{ab}}_M.
\end{equation}
The phase must be common to all four inputs; arbitrary spectators are admitted. Full-register norms, not only low-energy or single-excitation restrictions, determine the budget. The endpoint carrier contains one mode excitation; conservation of that count during transit is not required. No generator for this exact endpoint contract is provided here.

The preceding note \cite{parent} proves a family obstruction for charges $Q_A=N_A+N_w+N_z$ and $Q_O=N_O+N_v+N_z$. These are specified bookkeeping operators. A correspondence with ADM charges or Noether currents is not established. That note also improves isolated one-qubit admission to optimal deadline $\pi$ under a full centered norm-one budget; the larger per-coupling coefficients remain charged. This does not close the two-qubit interface.

An all-time witness for one frozen numerical fit does not terminate numerical optimization generally. Failure in one real ansatz does not force a nonplanar graph or a different carrier. Spectral/inverse-eigenvalue methods for static gate synthesis already exist \cite{innocenti}; the present contribution is the explicit scoped filtering and replay.

\section{Exact decomposition of the real planar kernel}
The allowed graph has pairs
\begin{equation}
\{Au,Aw,Az,Ou,Ov,Ow,Oz,uw,uv,wz\}.
\end{equation}
It is planar, with six vertices, ten edges, and maximum degree four. The real ansatz uses $X,Z$ fields and $XX,YY,ZZ,XZ,ZX$ on each pair: 62 Hermitian Pauli coefficients, omitting identity. It is a subset of all Hermitian terms on this graph.

Let $c$ be the Pauli coefficient vector. The real linear map $Mc=E^\dagger HE-W^\dagger HW$ has rank seven. An exact integer basis $B$ supplies $c=B\theta$, $\theta\in\mathbb R^{55}$. Let $D$ stack the Pauli coefficient maps of $[H,Q_A]/i$ and $[H,Q_O]/i$ after restriction to $B$; let $Z_c$ similarly represent $[H,N_z]/i$.
\begin{proposition}[Two distinct symmetry decompositions]
On this specified first-moment kernel, $\operatorname{rank}D=35$ and $\dim\ker D=20$, while $\operatorname{rank}Z_c=10$ and $\dim\ker Z_c=45$. A choice of 35 pivot columns complements the 20 charge-preserving directions to a full 55-coordinate basis.
\end{proposition}
\begin{proof}
The receipt gives exact integer commutator matrices. Nullspaces and pivot columns are computed over $\mathbb Q$; their concatenation has rank 55. The charge-preserving columns are annihilated by both $D$ and $Z_c$. The stated ranks and identities are replayed exactly, not inferred from floating singular values.
\end{proof}
The full all-pairs complex Hermitian charge family has dimension 38 in the preceding note. The dimension 20 here belongs to its intersection with this smaller real planar moment kernel. These are distinct spaces.

Every successful generator must have $[H,N_z]\ne0$: input $11$ begins with $N_z=0$ and ends with $N_z=1$. Thus merely breaking $Q_A$ or $Q_O$ is insufficient. The following ten first-moment-compatible directions are independent modulo the $N_z$ commutant:
\begin{align}
&X_z,\ X_AX_z,\ Y_AY_z,\ Z_AX_z,\notag\\
&X_OX_z,\ Y_OY_z,\ Z_OX_z,\ Z_wX_z,\notag\\
&X_O+X_uX_v+X_wX_z,\notag\\
&X_O+X_uX_v+Y_wY_z.\label{eq:directions}
\end{align}
They lie on the declared graph and have support weight at most two. Activation is necessary, not sufficient for the full coherent isometry.

\section{Finite search and higher-moment rejection}
Both batches minimize all four endpoint columns with a common target phase. Batch A uses the exact integer moment basis with 55 real coordinates and up to 500 evaluations per start. Its four seeds are a projected preceding fit, a projected transport construction with terminal-mode routes, and two seeded random vectors. Batch B uses up to 1000 evaluations per start and adds
\begin{equation}
2\frac{E^\dagger H^2E-W^\dagger H^2W}{1+\sum_P c_P^2}
\end{equation}
to the least-squares residual. This is a soft penalty, not an exact second-moment constraint. Analytic exponential and penalty derivatives are checked against finite differences. A coordinate box $[-4\pi,4\pi]$ is not a physical norm ceiling.
\begin{table}[t]
\caption{Finite diagnostics; decimals are not certified channel bounds}
\centering\begin{tabular}{lrr}
\hline Batch & Best endpoint residual & Unit-norm deadline\\\hline
First moment only & @RES0@ & @TIME0@\\
Second-moment penalty & @RES1@ & @TIME1@\\\hline
\end{tabular}
\end{table}
The endpoint residual is the operator norm of $e^{-iH}E-e^{i\phi}W$, not an exact diamond distance. The unit-norm deadline is the sampled full spectral radius: centering and dividing $H$ by that radius retains the endpoint channel after that amount of model time. All eight fits fail to produce the required $2^{-16}$ contract. Four stop under loss tolerances; four reach evaluation caps. None is a global minimum certificate.

Freeze binary fractions of the kernel coordinates before assembling coefficients, preserving $Mc=0$ exactly. Separately rounding each assembled coefficient can break the moment identity; that norm debit is recorded. For a frozen generator let $B_1=\sum_P|c_P|$. Since $H^2$ is conserved by its static propagator and $\|H^2\|\le B_1^2$, an expectation mismatch $\Delta_2$ on any chosen input gives
\begin{equation}
D_{\rm tr}(e^{-itH}\ket{e},\ket{f})
\ge \frac{|\Delta_2|}{2B_1^2}\quad\text{for every }t.
\end{equation}
Exact fractions are provided in the audits. For each best frozen fit the basis input $10$ supplies a floor greater than $2^{-16}$: Batch A exceeds $1/512$ and Batch B exceeds $1/1024$. Diagnostic values are @FLOOR0@ and @FLOOR1@. The witness remains valid under uniform norm rescaling and excludes only the named frozen generator. It does not exclude the real family or other coefficients.

\section{A larger planar search remains available}
On the same graph, include $X,Y,Z$ fields and all nine two-qubit Pauli products. There are $1+3\cdot6+9\cdot10=109$ real Hermitian coefficients including identity. Odd numbers of $Y$ allow imaginary computational-basis entries. The full real first-moment constraint has rank eleven; its kernel has dimension 98, or 97 when scalar identity is removed. The exact basis is supplied. No qubits or allowed pairs are added, although more independent coupling components are admitted and must be charged if implemented. Optimization in this broader kernel is unrun.

The next gate is the original six-qubit single-excitation endpoint with an explicit generator, full physical spectrum, and complete channel deadline enclosure. Higher moments and spectral phase matching must be audited jointly. The available 97-coordinate planar option demonstrates why a failed real fit does not force a geometry change. Irreversible retention, native extraction, static concatenation, thermodynamic supply, and supervising-clock refresh remain separate open obligations.

\section{Verification and evidence status}
There are 40 exact checks for the real kernel decomposition, nine for the expanded kernel, and two separate nine-check frozen-candidate audits: 67 exact checks in this release. Eight finite optimization runs and derivative checks are numerical diagnostics. No empirical result or advantage is promoted. Independent review and theorem-level novelty comparison remain pending. The parent is preserved as a separate immutable source; this note does not silently expand its claim registry.
\begin{thebibliography}{2}
\bibitem{parent} B. W. Mayes, ``Optimal static native-qubit admission and limits of joint-mode encoding,'' MQM development note v0.1, Oct. 5, 2026, unpublished. Frozen release identified in INPUT\_ANCHORS.json.
\bibitem{innocenti} L. Innocenti, L. Banchi, A. Ferraro, S. Bose, and M. Paternostro, ``Supervised learning of time-independent Hamiltonians for gate design,'' arXiv:1803.07119, 2018, doi: 10.1088/1367-2630/ab8aaf.
\end{thebibliography}
\end{document}
'''
repl={'RES0':f"{s0['best']['isometry_operator_residual']:.6f}",'RES1':f"{s1['best']['isometry_operator_residual']:.6f}",
 'TIME0':f"{s0['best']['normalized_deadline']:.6f}",'TIME1':f"{s1['best']['normalized_deadline']:.6f}",
 'FLOOR0':f"{a['error_floor_decimal_diagnostic']:.8f}",'FLOOR1':f"{b['error_floor_decimal_diagnostic']:.8f}"}
for key,value in repl.items():tex=tex.replace('@'+key+'@',value)
assert '@' not in tex
stem='MQM_MOMENT_FILTERED_ADMISSION_IEEE_A4_v0.1'
(M/(stem+'.tex')).write_text(tex)
for n in range(3):
    proc=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',stem+'.tex'],cwd=M,capture_output=True,text=True)
    (R/'results'/f'PDF_BUILD_{n+1}.txt').write_text(proc.stdout+proc.stderr)
    assert proc.returncode==0,proc.stdout[-2500:]
log=(M/(stem+'.log')).read_text();assert 'Overfull' not in log
pdf=M/(stem+'.pdf');doc=fitz.open(pdf);sizes=[]
for n,page in enumerate(doc):
    sizes.append([page.rect.width,page.rect.height]);assert abs(page.rect.width-595.276)<.1 and abs(page.rect.height-841.89)<.1
    assert '??' not in page.get_text()
    page.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/f'PAGE_{n+1}.png')
(R/'results/PDF_QA.json').write_text(json.dumps({'pages':len(doc),'sizes_points':sizes,'format':'actual IEEEtran v1.8b journal,a4paper,10pt, two columns','no_overfull':True,'no_unresolved_references':True,'visual_review':'pending'},indent=2)+'\n')
print(json.dumps({'pdf':str(pdf.resolve()),'pages':len(doc)}))
