"""Exact first-moment kernel for every Hermitian two-local term on the same graph."""
from pathlib import Path
from itertools import product
import json
import sympy as s
R=Path(__file__).resolve().parent
old=json.loads((R/'results/KERNEL_RECEIPT.json').read_text())
labels=['IIIIII']
for q in range(6):
    for p in 'XYZ':
        a=['I']*6;a[q]=p;labels.append(''.join(a))
for x,y in old['ansatz']['pairs']:
    for p,q in product('XYZ',repeat=2):
        a=['I']*6;a[x]=p;a[y]=q;labels.append(''.join(a))
def entry(l,row,col):
    mask=sum(1<<(5-k) for k,p in enumerate(l) if p in 'XY')
    if row!=(col^mask):return s.Integer(0)
    out=s.Integer(1)
    for k,p in enumerate(l):
        bit=(col>>(5-k))&1
        if p=='Y':out*=s.I*(-1 if bit else 1)
        elif p=='Z' and bit:out*=-1
    return out
E=[8,24,40,56];W=[8,4,2,1]
M=s.zeros(32,len(labels))
for k,l in enumerate(labels):
    for a in range(4):
        for b in range(4):
            x=entry(l,E[a],E[b])-entry(l,W[a],W[b])
            M[4*a+b,k]=s.re(x);M[16+4*a+b,k]=s.im(x)
K=M[:,1:].nullspace();B=s.Matrix.hstack(*K)
checks=[]
def check(name,p):
    assert p,name
    checks.append(name)
check('all graph-local Hermitian Pauli terms counted',len(labels)==1+3*6+9*10==109)
check('first-moment real constraint rank eleven',M.rank()==11)
check('scalar identity is a free phase direction',M[:,0]==s.zeros(32,1))
check('kernel including identity dimension 98',109-M.rank()==98)
check('kernel with identity removed dimension 97',len(K)==97 and B.rank()==97)
check('all broadened kernel vectors exactly satisfy endpoint first moment',M[:,1:]*B==s.zeros(32,97))
check('contains every prior real ansatz term',set(old['basis_labels']).issubset(set(labels)))
check('new terms include imaginary matrix couplings',any(sum(c=='Y' for c in l)%2 for l in labels))
elementary=[s.eye(2),s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
check('Hermitian elementary Pauli factors on disjoint tensor positions',all(p.H==p for p in elementary) and all(set(l).issubset(set('IXYZ')) for l in labels))
receipt={'status':'EXACT necessary filter; optimization not run in this larger space',
 'graph':old['ansatz'],'all_Hermitian_graph_local_dimension_including_identity':109,
 'identity_phase_removed_dimension':108,'first_moment_real_rank':11,'kernel_including_identity_dimension':98,'kernel_without_identity_dimension':97,
 'coefficients':'Real coefficients of Hermitian Pauli strings; odd number of Y gives imaginary computational-basis matrix entries.',
 'labels_without_identity':labels[1:],
 'exact_kernel_without_identity':[{l:str(c) for l,c in zip(labels[1:],v) if c} for v in K],
 'scope':'Same six qubits, same ten allowed physical pairs, same planar degree-four graph; no added routing resource. Higher moments, spectrum and endpoint remain open.',
 'exact_count':len(checks),'exact_checks':checks,'joint_admission':'OPEN','physical_promotion':0}
(R/'results/EXPANDED_PLANAR_FILTER.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('exact_count','all_Hermitian_graph_local_dimension_including_identity','first_moment_real_rank','kernel_without_identity_dimension')}))
