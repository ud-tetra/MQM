Moment-Constrained Symmetry Breaking for Autonomous Joint Qubit Admission
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM development note v0.1

EXACT SCOPED RESULTS
The 55-dimensional first-moment kernel has a 20-dimensional both-charge-
conserving intersection and a 35-dimensional charge-breaking complement.
Terminal-mode occupation instead has 45 conserving and ten changing directions.
The ten displayed terminal-changing directions are necessary seed resources,
not a sufficient encoder. All Hermitian terms on the SAME planar graph yield
a 97-dimensional first-moment kernel after removing scalar identity.

FINITE SEARCH
Four first-moment-only fits and four second-moment-penalized fits found no
encoder. Exact second-moment witnesses exclude the frozen best of each batch
at every time and uniform norm rescaling: floors exceed 1/512 and 1/1024.
This excludes those candidates only. It does not establish a family no-go.
The larger 97-coordinate planar search is prepared but UNRUN.

Evidence: 40 + 9 + 9 + 9 = 67 exact scoped replay checks, eight finite fits,
and numerical derivative/endpoint diagnostics. Independent review and theorem-
level novelty comparison pending. Physical evidence promotion 0.
Original six-qubit joint single-excitation admission remains OPEN.

REPLAY (numpy, scipy, sympy, networkx, PyMuPDF; pdflatex for PDF)
  python3 formalize_kernel.py
  python3 broaden_planar.py
  python3 audit_filtered.py
  python3 audit_filtered.py --second-moment
These replay exact constraints and the stored binary-rational candidate audits.

OPTIONAL EXPENSIVE RE-OPTIMIZATION (overwrites numerical receipts)
  python3 search_filtered.py --max-nfev 500
  python3 search_filtered.py --max-nfev 1000 --moment-weight 2
The coordinate box is not a physical norm ceiling. First moment is parametrized
exactly; the second moment uses a soft penalty, not a hard constraint. Floating
optimizer versions may change candidates. Re-run audits and update all receipts.

PDF AND RELEASE
  python3 build_ieee_note.py
Inspect BOTH current results/PAGE_*.png before freezing:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran A4, 10pt, two columns; IEEEtran class and LPPL bundled.
The locked publication policy is carried forward. The parent release is intact.

NEXT TARGET
Search the exact 97-coordinate planar Hermitian filter while auditing higher
moments, spectral phases, full-register norm and complete input channel error.
More independent coupling components are admitted; no qubits or pairs are added
by the mathematical filter. No physical advantage is claimed.
