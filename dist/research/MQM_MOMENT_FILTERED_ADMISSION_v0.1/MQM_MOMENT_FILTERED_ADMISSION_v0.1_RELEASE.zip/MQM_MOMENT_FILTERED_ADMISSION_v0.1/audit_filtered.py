"""Exact binary-rational higher-moment audit of the frozen filtered candidate."""
from pathlib import Path
from fractions import Fraction as F
import json,argparse
import numpy as np
R=Path(__file__).resolve().parent
j=json.loads((R/'results/KERNEL_RECEIPT.json').read_text())
ap=argparse.ArgumentParser();ap.add_argument('--second-moment',action='store_true');args=ap.parse_args()
source='SECOND_MOMENT_SEARCH_RECEIPT.json' if args.second_moment else 'FILTERED_SEARCH_RECEIPT.json'
run=json.loads((R/'results'/source).read_text())
best=run['best'];labels=j['basis_labels']
data=np.load(R/'results/FILTERED_BASIS.npz');P=np.rint(data['P']).astype(int)
c=[F(best['Pauli_coefficients_exact'][l]) for l in labels]
theta=[F(x) for x in best['kernel_coordinates_exact']]
checks=[]
def check(label,value):
    assert value,label
    checks.append(label)
check('exact first-moment basis coefficient freeze',all(c[k]==sum((F(v.get(l,'0'))*t for v,t in zip(j['first_moment_basis'],theta)),F(0)) for k,l in enumerate(labels)))
H=[[F(0) for _ in range(64)] for _ in range(64)]
for a,p in zip(c,P):
    for r,col in zip(*np.nonzero(p)):H[int(r)][int(col)]+=int(p[r,col])*a
check('frozen full 64-dimensional matrix Hermitian',all(H[i][k]==H[k][i] for i in range(64) for k in range(64)))
sources=[8,24,40,56];targets=[8,4,2,1]
M1=[[H[sources[a]][sources[b]]-H[targets[a]][targets[b]] for b in range(4)] for a in range(4)]
check('frozen first-moment matrix exactly zero',all(x==0 for row in M1 for x in row))
QA=j['charges']['QA'];QO=j['charges']['QO'];Nz=j['charges']['Nz']
def occupation(index,charge):return sum(q*((index>>(5-k))&1) for k,q in enumerate(charge))
charge_flags={}
for name,q in [('QA',QA),('QO',QO),('Nz',Nz)]:
    active=any(H[a][b] and occupation(a,q)!=occupation(b,q) for a in range(64) for b in range(64))
    charge_flags[name]=active
check('frozen candidate changes terminal mode occupation',charge_flags['Nz'])
check('frozen candidate breaks at least one native bookkeeping charge',charge_flags['QA'] or charge_flags['QO'])
cols={i:[H[a][i] for a in range(64)] for i in set(sources+targets)}
M2=[[sum((cols[sources[a]][k]*cols[sources[b]][k]-cols[targets[a]][k]*cols[targets[b]][k] for k in range(64)),F(0)) for b in range(4)] for a in range(4)]
check('second-moment diagonal entries agree with full columns',all(M2[a][a]==sum((H[k][sources[a]]**2-H[k][targets[a]]**2 for k in range(64)),F(0)) for a in range(4)))
B=sum((abs(x) for x in c),F(0))
check('full Pauli sum norm ledger positive',B>0)
witnesses=[]
for a in range(4):
    witnesses.append({'input':'basis '+str(a),'difference':M2[a][a],'floor':abs(M2[a][a])/(2*B*B)})
for a in range(4):
    for b in range(a+1,4):
        for sign in (-1,1):
            delta=(M2[a][a]+M2[b][b]+2*sign*M2[a][b])/2
            witnesses.append({'input':f'(|{a:02b}> {"+" if sign==1 else "-"} |{b:02b}>)/sqrt(2)','difference':delta,'floor':abs(delta)/(2*B*B)})
selected=max(witnesses,key=lambda x:x['floor']);eps=F(1,1<<16)
floor=selected['floor']
den=1
while floor and F(1,den)>=floor:den*=2
simple=F(1,den) if floor else F(0)
check('selected higher-moment trace lower bound and simple fraction valid arithmetic',floor==abs(selected['difference'])/(2*B*B) and (not floor or floor>simple))
rounding=sum((abs(F(float(q))-q) for q in c),F(0))
check('binary64 coefficient assembly bound nonnegative',rounding>=0)
receipt={
 'status':'Exact first-moment preservation and scoped frozen-candidate second-moment audit',
 'best_run':best['run'],'exact_count':len(checks),'exact_checks':checks,
 'first_moment':'exact zero 4x4 matrix',
 'charge_commutators_nonzero':charge_flags,
 'second_moment_matrix':[[str(x) for x in row] for row in M2],
 'full_Pauli_norm_upper_bound':str(B),
 'witness_input':selected['input'],'second_moment_expectation_difference':str(selected['difference']),
 'all_time_complete_trace_error_floor':str(floor),'error_floor_decimal_diagnostic':float(floor),
 'simple_fraction_strict_lower_bound':str(simple),
 'target_epsilon':'1/65536','frozen_candidate_excluded_at_target_for_all_times':floor>eps,
 'binary64_coefficient_assembly_norm_debit':str(rounding),'coefficient_assembly_debit_decimal':float(rounding),
 'proof':'Static H commutes with H^2. Exact expectation mismatch delta is conserved; trace duality with ||H^2|| <= (sum |c_P|)^2 gives D >= |delta|/(2 B^2). This concerns the frozen candidate only, with arbitrary deadline or uniform rescaling.',
 'numerical_endpoint_status':'Diagnostics only; no certified expm or optimizer global minimum.',
 'joint_admission':'OPEN','physical_promotion':0,'independent_review':'pending'}
name='SECOND_MOMENT_AUDIT.json' if args.second_moment else 'HIGHER_MOMENT_AUDIT.json'
(R/'results'/name).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('exact_count','best_run','witness_input','error_floor_decimal_diagnostic','frozen_candidate_excluded_at_target_for_all_times')}))
