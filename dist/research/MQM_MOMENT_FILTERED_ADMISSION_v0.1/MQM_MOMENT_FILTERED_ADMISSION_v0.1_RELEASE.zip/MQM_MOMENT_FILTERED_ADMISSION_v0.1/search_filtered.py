"""Finite 55-coordinate exploration; exact first-moment parametrization."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as F
import json,time,argparse
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import least_squares
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--max-nfev',type=int,default=500)
ap.add_argument('--moment-weight',type=float,default=0.,help='Weight of normalized second-moment penalty; a penalty is not an exact constraint.')
args=ap.parse_args()
j=json.loads((R/'results/KERNEL_RECEIPT.json').read_text())
old=json.loads((R/'PARENT_SEARCH_RECEIPT.json').read_text())
data=np.load(R/'results/FILTERED_BASIS.npz')
B,P,E,W=[data[k] for k in ('B','P','E','W')]
labels=j['basis_labels'];Fbasis=np.einsum('ka,kij->aij',B,P)
cache={}
def evaluate(x):
    if 'x' in cache and np.array_equal(cache['x'],x):return cache['r'],cache['j']
    H=np.einsum('a,aij->ij',x[:-1],Fbasis)
    val,V=eigh(H,check_finite=False);phase=np.exp(-1j*val);target=np.exp(1j*x[-1])*W
    VE=V.T@E;UE=V@(phase[:,None]*VE);err=UE-target
    divided=-1j*np.exp(-1j*(val[:,None]+val[None,:])/2)*np.sinc((val[:,None]-val[None,:])/(2*np.pi))
    vB=np.einsum('ia,kij,jb->kab',V,Fbasis,V,optimize=True)
    dU=np.einsum('ia,kab,bj->kij',V,vB*divided[None,:,:],VE,optimize=True)
    derivatives=np.concatenate([dU,(-1j*target)[None,:,:]],axis=0).reshape(len(x),-1).T
    residual=np.concatenate([err.real.ravel(),err.imag.ravel()])
    jac=np.concatenate([derivatives.real,derivatives.imag],axis=0)
    if args.moment_weight:
        # First moment is already exact. Second moment has a scaled soft penalty.
        c=B@x[:-1];den=1+np.dot(c,c)
        HE=H@E;HW=H@W
        m=HE.T@HE-HW.T@HW
        BE=Fbasis@E;BW=Fbasis@W
        dm=np.einsum('kia,ib->kab',BE,HE)+np.einsum('ia,kib->kab',HE,BE)-np.einsum('kia,ib->kab',BW,HW)-np.einsum('ia,kib->kab',HW,BW)
        dden=2*B.T@c
        dj=(dm/den-m[None,:,:]*dden[:,None,None]/den**2).reshape(55,-1).T
        dj=np.column_stack([dj,np.zeros(16)])
        residual=np.r_[residual,args.moment_weight*m.ravel()/den]
        jac=np.vstack([jac,args.moment_weight*dj])
    cache.update(x=x.copy(),r=residual,j=jac)
    return residual,jac
rng=np.random.default_rng(2026100517)
probe=np.r_[rng.normal(0,.2,55),.3];J=evaluate(probe)[1];grad=0.
for col in [0,5,18,37,54,55]:
    h=np.zeros(56);h[col]=1e-6
    grad=max(grad,float(np.max(abs((evaluate(probe+h)[0]-evaluate(probe-h)[0])/(2e-6)-J[:,col]))))
assert grad<1e-7,grad
runs=[];best=None
initial=np.array([old['best']['coefficients'][l] for l in labels])
projected=np.linalg.lstsq(B,initial,rcond=None)[0]
seeds=[np.r_[projected,old['best']['phase']]]
if args.moment_weight and (R/'results/FILTERED_SEARCH_RECEIPT.json').exists():
    prior=json.loads((R/'results/FILTERED_SEARCH_RECEIPT.json').read_text())['best']
    seeds[0]=np.r_[[float(F(q)) for q in prior['kernel_coordinates_exact']],prior['phase']]
# A seed constructed from two one-bit transport sectors, then first-moment projected.
c=np.zeros(62)
for native,target in [(0,4),(1,3)]:
    terms=[({native:'Z'},-1),({target:'Z'},-1),({2:'X'},1),({2:'X',native:'Z'},-.5),({2:'X',target:'Z'},-.5),({native:'X',target:'X'},.5),({native:'Y',target:'Y'},.5)]
    for termspec,v in terms:
        l=''.join(termspec.get(k,'I') for k in range(6));c[labels.index(l)]+=v*np.pi/2
transport=np.linalg.lstsq(B,c,rcond=None)[0]
for index in data['nz_pivots']:transport[int(index)]+=.2
seeds.append(np.r_[transport,0.])
for scale in [.6,1.5]:
    theta=rng.normal(0,scale,55)
    theta[int(data['nz_pivots'][0])]+=1
    seeds.append(np.r_[theta,0.])
for run,x0 in enumerate(seeds):
    x0=np.clip(x0,-4*np.pi+1e-8,4*np.pi-1e-8)
    started=time.monotonic()
    result=least_squares(lambda x:evaluate(x)[0],x0,jac=lambda x:evaluate(x)[1],bounds=(-4*np.pi,4*np.pi),max_nfev=args.max_nfev,ftol=1e-10,xtol=1e-10,gtol=1e-10)
    theta=result.x[:-1];H=np.einsum('a,aij->ij',theta,Fbasis)
    val,V=eigh(H);center=(val[0]+val[-1])/2;radius=(val[-1]-val[0])/2
    UE=V@(np.exp(-1j*val)[:,None]*(V.T@E));phi=np.angle(np.trace(W.T@UE))
    op=float(np.linalg.norm(UE-np.exp(1j*phi)*W,2))
    moments={}
    Hc=H-center*np.eye(64)
    for k in [1,2,3,4]:
        power=np.linalg.matrix_power(Hc,k)
        moments[str(k)]=float(np.linalg.norm(E.T@power@E-W.T@power@W,2)/(radius**k))
    # Fractions of theta define the physical model as exact combinations of the integer kernel;
    # do not freeze separately rounded assembled Pauli coefficients.
    fractions=[F(float(x)) for x in theta]
    coeff=[sum((F(int(B[k,a]))*fractions[a] for a in range(55)),F(0)) for k in range(62)]
    rec=dict(run=run,seed_type=[('prior_filtered_best' if args.moment_weight else 'projected_parent_best'),'transport_plus_m11_routes','random_0.6','random_1.5'][run],nfev=result.nfev,status=int(result.status),seconds=time.monotonic()-started,cost=float(result.cost),
       isometry_operator_residual=op,phase=float(phi),centered_norm=float(radius),spectral_center=float(center),normalized_deadline=float(radius),
       basis_trace_errors=[float(np.sqrt(max(0,1-abs(W[:,a]@UE[:,a])**2))) for a in range(4)],
       normalized_moment_mismatches=moments,charge_breaking=True)
    runs.append(rec)
    if best is None or op<best['isometry_operator_residual']:
        best={**rec,'kernel_coordinates_exact':[str(x) for x in fractions],'Pauli_coefficients_exact':{l:str(c) for l,c in zip(labels,coeff)},'coefficients_float':{l:float(c) for l,c in zip(labels,coeff)}}
    receipt={'status':'FINITE NUMERICAL EXPLORATION; no exact encoder or universal impossibility established',
       'parameterization':'H = sum(theta_a B_a), exact integer first-moment basis, 55 real coordinates and common phase',
       'coefficient_freeze':'Exact binary fractions of kernel coordinates, integer basis combination before coefficient assembly',
       'graph':j['ansatz'],'random_seed':2026100517,'starts':4,'max_nfev_per_start':args.max_nfev,'coordinate_box':'[-4*pi,4*pi] in kernel coordinates; not a full norm or Pauli coefficient ceiling',
       'objective':'All four endpoint columns, common phase; second moment soft penalty weight '+str(args.moment_weight)+' on M2/(1+sum(c_P^2)). No exact nonlinear constraint or higher-moment sufficiency claimed.',
       'moment_weight':args.moment_weight,
       'norm_normalization':'theta defines dimensionless TH; a unit centered-norm generator uses deadline equal to the spectral radius.',
       'gradient_finite_difference_error':grad,'runs':runs,'best':best,'physical_promotion':0}
    name='SECOND_MOMENT_SEARCH_RECEIPT.json' if args.moment_weight else 'FILTERED_SEARCH_RECEIPT.json'
    (R/'results'/name).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(rec),flush=True)
