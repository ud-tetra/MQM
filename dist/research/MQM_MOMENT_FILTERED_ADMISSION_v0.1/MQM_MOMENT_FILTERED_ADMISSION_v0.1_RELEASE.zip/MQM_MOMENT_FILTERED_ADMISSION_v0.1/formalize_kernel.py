"""Exact symmetry decomposition of the supplied first-moment kernel."""
from pathlib import Path
from fractions import Fraction
import json
import sympy as s
import numpy as np
import networkx as nx
R=Path(__file__).resolve().parent
(R/'results').mkdir(exist_ok=True)
parent=json.loads((R/'PARENT_SEARCH_RECEIPT.json').read_text())
f=json.loads((R/'PARENT_MOMENT_FILTER.json').read_text())
labels=list(parent['best']['coefficients'])
B=s.Matrix([[s.Rational(v.get(l,'0')) for v in f['exact_planar_kernel']] for l in labels])
data=np.load(R/'PARENT_SEARCH_BASIS.npz');P,E,W=[data[k] for k in ('P','E','W')]
checks=[]
def check(label,value):
    assert bool(value),label
    checks.append(label)
def commutator(charge):
    rows={}
    for i,l in enumerate(labels):
        for q,c in enumerate(charge):
            if c and l[q] in 'XY':
                out=list(l);out[q]='Y' if l[q]=='X' else 'X';out=''.join(out)
                if out not in rows:rows[out]=[0]*len(labels)
                rows[out][i]+=c*(1 if l[q]=='X' else -1)
    return s.Matrix(list(rows.values())) # exact coefficients of [P,Q]/i
QA=[1,0,0,0,1,1];QO=[0,1,0,1,0,1];Nz=[0,0,0,0,0,1]
CA,CO,CZ=[commutator(q) for q in (QA,QO,Nz)]
D=CA.col_join(CO)*B;Z=CZ*B
charge_kernel=D.nullspace();pivots=list(D.rref()[1]);zpivots=list(Z.rref()[1])
C=s.Matrix.hstack(*charge_kernel)
J=s.eye(55)[:,pivots]
T=C.row_join(J)
M=s.Matrix.hstack(*[s.Matrix(np.rint(E.T@p@E-W.T@p@W).astype(int)).reshape(16,1) for p in P])
check('complete real planar ansatz dimension 62',len(labels)==62)
check('exact first-moment rank 7',M.rank()==7)
check('exact first-moment kernel dimension and rank 55',B.shape==(62,55) and B.rank()==55)
check('all supplied basis vectors satisfy first moment exactly',M*B==s.zeros(16,55))
check('paired charge commutator rank 35',D.rank()==35)
check('both-charge-preserving intersection dimension 20',len(charge_kernel)==20)
check('charge-preserving columns exactly annihilated',D*C==s.zeros(D.rows,20))
check('charge-breaking quotient has 35 independent directions',D[:,pivots].rank()==35)
check('charge splitting coordinates invertible',T.rank()==55)
check('m11 changing quotient rank 10',Z.rank()==10)
check('m11 conserving intersection dimension 45',len(Z.nullspace())==45)
check('charge-preserving intersection freezes m11',Z*C==s.zeros(Z.rows,20))
graph=nx.Graph(parent['pair_graph'])
check('fixed graph planar',nx.check_planarity(graph)[0])
check('fixed graph six vertices and ten pairs',len(graph)==6 and graph.number_of_edges()==10)
check('fixed graph maximum degree four',max(dict(graph.degree()).values())==4)
check('every basis direction has support weight <=2',all(sum(c!='I' for c in l)<=2 for l in labels))
check('launch source has m11 occupation zero',(56&1)==0)
check('input11 target has m11 occupation one',(1&1)==1)
def sparse(col):return {l:str(c) for l,c in zip(labels,col) if c}
examples=[
 ('X_z',{'IIIIIX':1}),
 ('X_A_X_z',{'XIIIIX':1}),
 ('Y_A_Y_z',{'YIIIIY':1}),
 ('Z_A_X_z',{'ZIIIIX':1}),
 ('X_O_X_z',{'IXIIIX':1}),
 ('Y_O_Y_z',{'IYIIIY':1}),
 ('Z_O_X_z',{'IZIIIX':1}),
 ('Z_w_X_z',{'IIIIZX':1}),
 ('coupled_X_w_X_z',{'IXIIII':1,'IIXXII':1,'IIIIXX':1}),
 ('coupled_Y_w_Y_z',{'IXIIII':1,'IIXXII':1,'IIIIYY':1})]
for name,coeff in examples:
    v=s.Matrix([coeff.get(l,0) for l in labels])
    check(name+' first-moment compatible',M*v==s.zeros(16,1))
    check(name+' changes m11 occupation',CZ*v!=s.zeros(CZ.rows,1))
check('ten displayed m11-changing directions independent modulo conserving kernel',
      s.Matrix.hstack(*[CZ*s.Matrix([c.get(l,0) for l in labels]) for _,c in examples]).rank()==10)
check('source and target columns are separate orthonormal isometries',np.array_equal(E.T@E,np.eye(4)) and np.array_equal(W.T@W,np.eye(4)))
receipt={
 'status':'EXACT scoped linear-algebra filter, not an admission construction',
 'order':['A','O','u=m00','v=m01','w=m10','z=m11'],
 'ansatz':{'physical_qubits':6,'real_Pauli_parameters':62,'first_moment_rank':7,'kernel_dimension':55,'pairs':parent['pair_graph'],'planar':True,'maximum_degree':4},
 'charges':{'QA':QA,'QO':QO,'Nz':Nz},
 'charge_preserving_intersection_dimension':20,'charge_breaking_quotient_dimension':35,
 'Nz_preserving_intersection_dimension':45,'Nz_changing_quotient_dimension':10,
 'basis_labels':labels,'first_moment_basis':f['exact_planar_kernel'],
 'charge_preserving_basis':[sparse(B*c) for c in charge_kernel],
 'charge_breaking_complement_basis':[sparse(B[:,j]) for j in pivots],
 'Nz_changing_complement_basis':[sparse(B[:,j]) for j in zpivots],
 'displayed_Nz_changing_examples':[{ 'name':name,'terms':{l:str(c) for l,c in coeff.items()}} for name,coeff in examples],
 'necessary_active_condition':'[H,N_z] != 0 is necessary; merely breaking QA or QO is insufficient if N_z still conserved.',
 'comparison':'38 is the full Hermitian all-pairs charge family; 20 is its intersection with this real planar first-moment kernel. Equal labels do not identify these spaces.',
 'higher_moment_necessity':'E^dagger H^k E = W^dagger H^k W for every nonnegative k; no sufficiency claimed.',
 'review_corrections':['Frozen-candidate witness excludes only that candidate at all times.','Finite search failure does not force nonplanarity or a different carrier.','55 coordinates obey only a linear necessary condition, not all physical constraints.','QA and QO are defined bookkeeping charges; ADM/Noether physical correspondence is not established.','One-qubit latency gain matches full norm, not per-coupling ceilings.'],
 'exact_count':len(checks),'exact_checks':checks,'physical_promotion':0,'independent_review':'pending'}
(R/'results/KERNEL_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
np.savez(R/'results/FILTERED_BASIS.npz',B=np.array(B).astype(float),P=P,E=E,W=W,charge_split=np.array(T).astype(float),nz_pivots=zpivots)
print(json.dumps({k:receipt[k] for k in ('exact_count','charge_preserving_intersection_dimension','charge_breaking_quotient_dimension','Nz_preserving_intersection_dimension','Nz_changing_quotient_dimension')}))
