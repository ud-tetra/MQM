"""Freeze scoped receipts, the IEEE A4 note and the expanded planar next-search basis."""
from pathlib import Path
import json,hashlib,zipfile,argparse,platform
import numpy,scipy,sympy,networkx,fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args()
assert args.visual_review_confirmed,'Inspect all current PDF page renders before release.'
def read(name):return json.loads((R/name).read_text())
def write(name,obj):(R/name).write_text(json.dumps(obj,indent=2)+'\n')
k=read('results/KERNEL_RECEIPT.json');x=read('results/EXPANDED_PLANAR_FILTER.json')
a=read('results/HIGHER_MOMENT_AUDIT.json');b=read('results/SECOND_MOMENT_AUDIT.json')
s0=read('results/FILTERED_SEARCH_RECEIPT.json');s1=read('results/SECOND_MOMENT_SEARCH_RECEIPT.json')
qa=read('results/PDF_QA.json')
assert qa['pages']==2 and qa['no_overfull'] and qa['no_unresolved_references']
assert s0['best']['isometry_operator_residual']>1/65536 and s1['best']['isometry_operator_residual']>1/65536
assert a['frozen_candidate_excluded_at_target_for_all_times'] and b['frozen_candidate_excluded_at_target_for_all_times']
assert a['simple_fraction_strict_lower_bound']=='1/512' and b['simple_fraction_strict_lower_bound']=='1/1024'
qa['visual_review']='passed: both final page renders inspected; equations, table and two-column layout readable; no clipping or overlap'
write('results/PDF_QA.json',qa)
parent=R.parent/'MQM_SIX_QUBIT_ADMISSION_SEARCH_v0.1_RELEASE.zip'
attachment=R.parent.parent/'upload/Pasted text(3).txt'
write('INPUT_ANCHORS.json',{
 'author':'Benjamin Walker Mayes','orcid':'0009-0002-5813-0724',
 'parent_pdf_library_id':'libfile_1a0be5da7bfc8191ab2ab7fb4a6bcd56',
 'parent_zip_library_id':'libfile_3bdb94756538819184e0860c18f626a0',
 'parent_zip_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.exists() else '003c274f918d6c04f294f931a15c3a6247d8d8322e6bf42e323581a8b2caa18c',
 'review_attachment':{'name':'Pasted text(3).txt','library_file_id':'libfile_0cc61b37b044819180556460bc687627','file_id':'file_000000003a7081f69bdcea605f8cb95b','sha256':hashlib.sha256(attachment.read_bytes()).hexdigest() if attachment.exists() else None},
 'source_use':'Supplied review read from its supplied local copy; prior frozen basis and receipts copied into this separate release. Review citation placeholders are not accepted as verified external sources.',
 'prior_release_modified':False})
write('CLAIM_REGISTER.json',{
 'real_kernel_symmetry_decomposition':{'status':'EXACT / AUTO_LOCK SCOPED','first_moment_dimension':55,'both_charge_conserving_intersection':20,'charge_breaking_complement':35,'Nz_conserving_intersection':45,'Nz_changing_complement':10,
  'scope':'62-real-coefficient ansatz, exact first-moment kernel, specified six-qubit planar ten-pair graph; not all Hermitian generators.'},
 'terminal_activation':{'status':'DERIVED NECESSARY','condition':'[H,N_z]!=0','sufficient':False},
 'frozen_candidate_exclusions':{'status':'EXACT / AUTO_LOCK SCOPED','witness':'second-moment expectation conserved by static H','batch_A_strict_floor':'1/512','batch_B_strict_floor':'1/1024','scope':'These two exact binary-rational frozen generators, every time and uniform norm rescaling; not all searched coefficients.'},
 'expanded_planar_filter':{'status':'EXACT / AUTO_LOCK SCOPED','all_Hermitian_dimension_including_identity':109,'first_moment_rank':11,'kernel_without_identity':97,'added_qubits':0,'added_allowed_pairs':0,'new_independent_coupling_components':True,'optimization_run':False,'sufficient':False},
 'search':{'status':'NUMERICAL EXPLORATION','starts':8,'basis_parameters':55,'first_moment':'exact parameterization','second_moment':'soft penalty in second batch only','optimizer_global_certificate':False},
 'six_qubit_single_excitation_admission':'OPEN','static_full_episode':'OPEN','thermodynamic_refresh':'OPEN',
 'physical_promotion':0,'independent_review':'pending','theorem_level_novelty_comparison':'pending',
 'verification':{'exact_kernel_checks':k['exact_count'],'expanded_kernel_checks':x['exact_count'],'candidate_audit_checks':[a['exact_count'],b['exact_count']],'total_exact_checks':sum(v['exact_count'] for v in [k,x,a,b]),'finite_fits':8,'derivative_check_max_errors':[s0['gradient_finite_difference_error'],s1['gradient_finite_difference_error']]}})
write('REVIEW_CORRECTIONS.json',{
 'accepted':['Isolated one-qubit optimum at pi has the stated full centered norm scope.','Joint interface remains open.','First-moment filtering is necessary.','The five-qubit odd-parity comparator changes the carrier.'],
 'corrected':k['review_corrections'],
 'important_new_condition':'Activate terminal-mode-changing directions; native charge breaking alone is insufficient.',
 'source_claim_policy':'Scope corrections are supported by explicit local algebra and frozen receipts; no unverified ADM or Noether identification enters the manuscript.'})
write('NEXT_GATE.json',{
 'target':'Same six-qubit all-input single-excitation admission endpoint with common phase and arbitrary spectators.',
 'recommended_next_search':'Use the exact 97-coordinate full Hermitian planar first-moment kernel; permit imaginary matrix entries via real coefficients of odd-Y Hermitian Pauli strings.',
 'required_diagnostics':['Second and higher moments and endpoint phase conditions','Nonzero terminal-mode commutator','Full 64-dimensional spectrum and centered norm budget','Per-term coupling ceilings, allowed pairs and preparation resources','Uniform complete channel enclosure over deadline window'],
 'resource_policy':'Keep six qubits and the same ten allowed planar pairs initially; charge additional interaction components explicitly.',
 'stop_policy':'A finite unsuccessful optimization is not a no-go theorem; exact energy-moment witnesses may exclude individual frozen generators.',
 'promotion_gate':'Explicit candidate generator, verified graph, full-spectrum normalization and a complete-input channel certificate <=2^-16, then independent replay.',
 'not_closed':['Six-qubit endpoint generator','Native extraction to core','Permanent terminal hold','Clock refresh','Thermodynamic accounting','Physical realization']})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'networkx':networkx.__version__,'pymupdf':fitz.VersionBind})
(R/'README.txt').write_text('''Moment-Constrained Symmetry Breaking for Autonomous Joint Qubit Admission
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM development note v0.1

EXACT SCOPED RESULTS
The 55-dimensional first-moment kernel has a 20-dimensional both-charge-
conserving intersection and a 35-dimensional charge-breaking complement.
Terminal-mode occupation instead has 45 conserving and ten changing directions.
The ten displayed terminal-changing directions are necessary seed resources,
not a sufficient encoder. All Hermitian terms on the SAME planar graph yield
a 97-dimensional first-moment kernel after removing scalar identity.

FINITE SEARCH
Four first-moment-only fits and four second-moment-penalized fits found no
encoder. Exact second-moment witnesses exclude the frozen best of each batch
at every time and uniform norm rescaling: floors exceed 1/512 and 1/1024.
This excludes those candidates only. It does not establish a family no-go.
The larger 97-coordinate planar search is prepared but UNRUN.

Evidence: 40 + 9 + 9 + 9 = 67 exact scoped replay checks, eight finite fits,
and numerical derivative/endpoint diagnostics. Independent review and theorem-
level novelty comparison pending. Physical evidence promotion 0.
Original six-qubit joint single-excitation admission remains OPEN.

REPLAY (numpy, scipy, sympy, networkx, PyMuPDF; pdflatex for PDF)
  python3 formalize_kernel.py
  python3 broaden_planar.py
  python3 audit_filtered.py
  python3 audit_filtered.py --second-moment
These replay exact constraints and the stored binary-rational candidate audits.

OPTIONAL EXPENSIVE RE-OPTIMIZATION (overwrites numerical receipts)
  python3 search_filtered.py --max-nfev 500
  python3 search_filtered.py --max-nfev 1000 --moment-weight 2
The coordinate box is not a physical norm ceiling. First moment is parametrized
exactly; the second moment uses a soft penalty, not a hard constraint. Floating
optimizer versions may change candidates. Re-run audits and update all receipts.

PDF AND RELEASE
  python3 build_ieee_note.py
Inspect BOTH current results/PAGE_*.png before freezing:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran A4, 10pt, two columns; IEEEtran class and LPPL bundled.
The locked publication policy is carried forward. The parent release is intact.

NEXT TARGET
Search the exact 97-coordinate planar Hermitian filter while auditing higher
moments, spectral phases, full-register norm and complete input channel error.
More independent coupling components are admitted; no qubits or pairs are added
by the mathematical filter. No physical advantage is claimed.
''')
excluded={'.aux','.log','.out'}
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in excluded and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'pages':qa['pages'],'total_exact_checks':sum(v['exact_count'] for v in [k,x,a,b])}))
