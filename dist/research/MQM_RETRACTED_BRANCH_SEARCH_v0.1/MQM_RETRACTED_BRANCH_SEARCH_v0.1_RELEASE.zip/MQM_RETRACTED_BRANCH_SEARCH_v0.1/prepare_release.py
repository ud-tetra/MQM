"""Freeze the audited branch-search continuation; parent releases stay immutable."""
from pathlib import Path
import argparse, json, hashlib, zipfile, platform
import numpy, scipy, sympy, networkx, fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args()
assert args.visual_review_confirmed
def read(n):return json.loads((R/n).read_text())
def write(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
receipts=[read('results/'+n) for n in ['MOMENT_GEOMETRY.json','FROZEN_AUDIT.json','ROOT_CERTIFICATE.json','ROOT_CENTER_SPECTRAL_CERTIFICATE.json','ROOT_SPECTRAL_FLOOR.json','SHARED_RETURN_WITNESS.json']]
total=sum(d['exact_count'] for d in receipts);assert total==252
geo,a,root,center,floor,shared=receipts
g=read('results/BRANCH_GRADIENT_RECEIPT.json');s=read('results/BRANCH_SEARCH.json');qa=read('results/PDF_QA.json')
assert g['columns_checked']==166 and g['max_discrepancy']<2e-6
assert floor['strict_dyadic_error_floor']=='1/16' and floor['exact_second_moment_zero']
assert qa['pages']==2 and all(qa[k] for k in ['A4','actual_IEEEtran','two_columns','no_overfull','no_unresolved_references'])
qa['visual_review']='PASSED: both final pages inspected; readable IEEE two-column layout; equations and references fit, no overlap or clipping.'
write('results/PDF_QA.json',qa)
stale=R/'results/PAGE_3.png'
if stale.exists():stale.unlink()
parent=R.parent/'MQM_SECOND_MOMENT_MANIFOLD_v0.1_RELEASE.zip'
write('INPUT_ANCHORS.json',{'parent_library_zip_id':'libfile_e5c2b1b71fcc8191b56c0f12d4b0017f','parent_library_pdf_id':'libfile_5e088c9f0c488191937b5e9de0210c1f','parent_zip_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'parent_immutable':True,'author':'Benjamin Walker Mayes','orcid':'0009-0002-5813-0724','task':'Continue MQM paper development: rank-aware retracted branch search and shared-return criterion'})
write('CLAIM_REGISTER.json',{'search':{'status':'NUMERICAL bounded exploration','attempts':158,'accepted':100,'rejected':58,'declared_attempt_cap':200,'initial_operator_residual':s['initial']['isometry_operator_residual'],'best_operator_residual':s['best']['isometry_operator_residual'],'stationarity_or_global_optimality':False,'resource_improvement':False},'exact_selected_root':{'status':'EXACT / AUTO_LOCK SCOPED','first_and_second_moments_match':True,'fixed_dyadic_coordinates':82,'dependent_coordinates':15,'local_branch_dimension':82,'root_type':'Unique real algebraic root in a fixed rational slice box','radius':root['box_radius_inf'],'full_norm_implementation':'H=G/L_upper; norm<=1 on all64 dimensions','deadline_upper':root['root_Pauli_norm_upper'],'all_time_half_diamond_error':'strictly greater than1/16','scope':'One selected exact root; not the family or continuous optimization path'},'shared_return':{'status':'DERIVED with exact task-data checks; novelty pending','perfect_admission_Krylov_dimension_upper':61,'finite_error_assumption':'Simple spectrum','finite_error_condition':'sum of three smallest shared-launch weights <= (epsilon/(1-epsilon))^2','target_threshold':'1/4294836225','necessary_not_sufficient':True,'root_launch_weights_enclosed':False,'family_no_go':False},'total_scoped_exact_checks':252,'numerical_reduced_Jacobian_columns':166,'certified_encoder':False,'physical_promotion':0,'independent_review':'pending','theorem_level_novelty_comparison':'pending'})
write('NEXT_GATE.json',{'status':'OPEN','target':'Recenter or switch a certified regular chart and continue complete coherent endpoint search','deadline_cap':512,'error_target':'1/65536 on a nonzero readout window','workflow':['Use the selected regular root as a local chart reference; do not infer a globally regular manifold.','Declare new free-coordinate box, trust region and finite exploration budget.','Use shared-return conditions only as necessary candidate screens; certify spectral assumptions before applying a bound.','Retain four coherent endpoint columns, one common phase and arbitrary spectators.','Audit each selected point by rational contraction and full-spectrum error/norm bounds.','Close native admission before composing with the encoded SWAP core.'],'publication_target':'Matched physical resource improvement or informative lower bound across competing clock architectures','failure_scope':'Sampled points and certified roots only; finite unsuccessful searches do not exclude the planar family.'})
write('SOURCE_REFERENCE.json',{'standard_ingredient':'Isometric-channel distance and numerical-range geometry','author':'John Watrous','title':'The Theory of Quantum Information','year':2018,'chapter':3,'theorems':['3.54','3.55'],'official_author_manuscript':'https://cs.uwaterloo.ca/~watrous/TQI/TQI.3.pdf','verified_date':'2026-10-06','scope':'Standard channel ingredient credited; task-specific shared-return derivation and novelty comparison are separate.'})
write('ARITHMETIC_COUNTS.json',{'exact_checks':'252=2^2*3^2*7','numerical_columns':'166=2*83','physical_dimension':'64=2^6','kernel_coordinates':'97 is prime','free_coordinates':'82=2*41','free_plus_phase':'83 is prime','Krylov_dimension_bound':'61 is prime; dimension bound, not a clock count','target_denominator':'65536=2^16','weight_threshold_denominator':'4294836225=65535^2=(3*5*17*257)^2','deadline_cap':'512=2^9','scope':'Typed counts are not interchangeable physical resources.'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'networkx':networkx.__version__,'pymupdf':fitz.VersionBind})
(R/'README.txt').write_text('''Retracted Admission Search and a Shared-Return Spectral Criterion
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM v0.1

RESULT
Guarded branch search: 158 attempts,100 accepted,58 rejected. The sampled
operator residual improves only from0.222891523 to0.222881819. This is not a
resource saving or evidence of stationarity/global optimality. The conservative
deadline increases to approximately358.894545 under a full operator norm<=1.
A rational contraction certifies a selected regular algebraic root, with exact
first/second moment equality and local zero-manifold dimension82. Exact spectral
enclosures still prove complete half-diamond admission error>1/16 at ALL times.
This excludes one root, not the planar family. Admission remains OPEN.

NEW NECESSARY CONDITIONS
Perfect admission requires shared-input Krylov dimension<=61, even with
degeneracies. For simple spectrum and complete error<=epsilon<1, the smallest
three shared-launch eigenmode weights sum to <=(epsilon/(1-epsilon))^2.
At epsilon=1/65536 this threshold is exactly1/4294836225. These conditions are
necessary, not sufficient. Root launch weights are not enclosed; the floating
screen does not overcome the certified all-time error floor. Standard channel
geometry is credited to Watrous; independent review and novelty comparison
remain pending. Physical promotion0. 252 scoped exact checks,166 numerical
reduced-Jacobian checks. No encoder, hardware advantage or autonomous refresh.

CERTIFICATE REPLAY (numpy,scipy,sympy,networkx)
  python3 moment_geometry.py
  python3 verify_frozen.py
  python3 certify_root.py
  python3 spectral_certificate.py --root-center
  python3 certify_root_spectral_floor.py
  python3 shared_return_witness.py
Numerical Newton/eigensolver output proposes data; exact rational contraction
and Gaussian-integer spectral enclosures are the proof. The center differs
from the implicit algebraic root; root-box perturbation is explicitly charged.

OPTIONAL SEARCH (overwrites search receipts; repeat all audits afterward)
  python3 search_branch.py
Declared cap200,guarded free box,83 optimization variables,deadline ledger<=512.
Numerical retraction is not exact path certification. Check the JSON receipts
for the actual termination and precision guards; do not treat the cap as a
number of completed attempts.

PDF (pdflatex and PyMuPDF)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png renders before:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two columns. Class license included.
NEXT_GATE.json records chart recentering and complete admission requirements.
Parent releases remain immutable; SHA256SUMS.txt covers distributed files.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'pages':qa['pages'],'exact_checks':total}))
