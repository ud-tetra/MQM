Retracted Admission Search and a Shared-Return Spectral Criterion
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM v0.1

RESULT
Guarded branch search: 158 attempts,100 accepted,58 rejected. The sampled
operator residual improves only from0.222891523 to0.222881819. This is not a
resource saving or evidence of stationarity/global optimality. The conservative
deadline increases to approximately358.894545 under a full operator norm<=1.
A rational contraction certifies a selected regular algebraic root, with exact
first/second moment equality and local zero-manifold dimension82. Exact spectral
enclosures still prove complete half-diamond admission error>1/16 at ALL times.
This excludes one root, not the planar family. Admission remains OPEN.

NEW NECESSARY CONDITIONS
Perfect admission requires shared-input Krylov dimension<=61, even with
degeneracies. For simple spectrum and complete error<=epsilon<1, the smallest
three shared-launch eigenmode weights sum to <=(epsilon/(1-epsilon))^2.
At epsilon=1/65536 this threshold is exactly1/4294836225. These conditions are
necessary, not sufficient. Root launch weights are not enclosed; the floating
screen does not overcome the certified all-time error floor. Standard channel
geometry is credited to Watrous; independent review and novelty comparison
remain pending. Physical promotion0. 252 scoped exact checks,166 numerical
reduced-Jacobian checks. No encoder, hardware advantage or autonomous refresh.

CERTIFICATE REPLAY (numpy,scipy,sympy,networkx)
  python3 moment_geometry.py
  python3 verify_frozen.py
  python3 certify_root.py
  python3 spectral_certificate.py --root-center
  python3 certify_root_spectral_floor.py
  python3 shared_return_witness.py
Numerical Newton/eigensolver output proposes data; exact rational contraction
and Gaussian-integer spectral enclosures are the proof. The center differs
from the implicit algebraic root; root-box perturbation is explicitly charged.

OPTIONAL SEARCH (overwrites search receipts; repeat all audits afterward)
  python3 search_branch.py
Declared cap200,guarded free box,83 optimization variables,deadline ledger<=512.
Numerical retraction is not exact path certification. Check the JSON receipts
for the actual termination and precision guards; do not treat the cap as a
number of completed attempts.

PDF (pdflatex and PyMuPDF)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png renders before:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two columns. Class license included.
NEXT_GATE.json records chart recentering and complete admission requirements.
Parent releases remain immutable; SHA256SUMS.txt covers distributed files.
