"""Guarded numerical retraction on an 82-coordinate moment chart, plus one phase."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json,time
import numpy as np
from complex_objective import Objective
from moment_geometry import D,B,F,E,W,R,labels
geo=json.loads((R/'results'/'MOMENT_GEOMETRY.json').read_text())
parent=json.loads((R/'PARENT_ROOT_CERTIFICATE.json').read_text())
center=json.loads((R/'PARENT_ROOT_CENTER.json').read_text())['best']
PORTS=np.array(parent['varied_coordinates']);FREE=np.array([j for j in range(97) if j not in PORTS]);DQ=D[geo['independent_components']].astype(float)
INITIAL=np.array([float(Q(v)) for v in center['kernel_coordinates_exact']]);PHASE=center['phase']
endpoint=Objective(B,F,E,W)
def retract(z,reference):
    theta=reference.copy();theta[FREE]=z
    for k in range(20):
        # Extended precision controls cancellation during numerical retraction.
        # This is a proposal calculation, not the later exact root proof.
        extended=np.asarray(theta,dtype=np.longdouble)
        JL=np.einsum('kab,b->ka',DQ.astype(np.longdouble),extended)
        J=np.asarray(JL,dtype=float);q=np.asarray(np.einsum('ka,a->k',JL,extended)/2,dtype=float)
        condition=float(np.linalg.cond(J[:,PORTS]));scale=1+np.linalg.norm(B@theta)**2
        if condition>1e7:raise ValueError('dependent Jacobian condition guard')
        step=np.linalg.solve(J[:,PORTS],q)
        if k>=2 and max(abs(q))/scale<2e-15 and max(abs(step))<2e-13:return theta,J,condition,k
        if max(abs(step))>1.:raise ValueError('dependent Newton step guard')
        theta[PORTS]-=step
    raise ValueError('Newton retraction residual guard')
def evaluate(x,reference):
    theta,J,condition,iterations=retract(x[:-1],reference)
    tangent=np.zeros((97,82));tangent[FREE,:]=np.eye(82)
    tangent[PORTS,:]=-np.linalg.solve(J[:,PORTS],J[:,FREE])
    full=np.r_[theta,x[-1]];r,jac=endpoint.evaluate(full)
    reduced=np.column_stack([jac[:,:97]@tangent,jac[:,97]])
    q=np.einsum('a,kab,b->k',theta,DQ,theta)/2
    return {'theta':theta,'r':r,'jac':reduced,'cost':float(r@r/2),'condition':condition,'Newton_iterations':iterations,'normalized_moment_max':float(max(abs(q))/(1+np.linalg.norm(B@theta)**2)),'tangent_constraint_defect':float(np.max(abs(J@tangent))),'Pauli_norm_diagnostic':float(sum(abs(B@theta)))}
def freeze(state,x,iteration):
    tq=[Q(float(v)) for v in state['theta']]
    c=[sum((int(b)*q for b,q in zip(row,tq)),Q(0)) for row in B]
    er=state['r'][:256].reshape(64,4)+1j*state['r'][256:].reshape(64,4)
    return {'run':iteration,'cost':state['cost'],'isometry_operator_residual':float(np.linalg.norm(er,2)),'normalized_moment_max':state['normalized_moment_max'],'dependent_condition_diagnostic':state['condition'],'kernel_coordinates_exact':[str(q) for q in tq],'phase':float(x[-1]),'Pauli_coefficients_exact':{l:str(v) for l,v in zip(labels,c)},'Pauli_norm_upper_exact':str(sum(abs(v) for v in c)),'strict_deadline_cap_exact':sum(abs(v) for v in c)<=512}
def main():
    x=np.r_[INITIAL[FREE],PHASE];state=evaluate(x,INITIAL);initial=freeze(state,x,-1)
    rng=np.random.default_rng(2026100605);errors=[];tangent_errors=[]
    for probe in [x,x+1e-4*rng.normal(size=83)]:
        ps=evaluate(probe,INITIAL);h=1e-6
        tangent_errors.append(ps['tangent_constraint_defect'])
        for k in range(83):
            e=np.zeros(83);e[k]=h
            dr=(evaluate(probe+e,ps['theta'])['r']-evaluate(probe-e,ps['theta'])['r'])/(2*h)
            errors.append(float(np.max(abs(dr-ps['jac'][:,k]))))
    assert max(errors)<2e-6,max(errors)
    assert max(tangent_errors)<1e-7,max(tangent_errors)
    (R/'results'/'BRANCH_GRADIENT_RECEIPT.json').write_text(json.dumps({'columns_checked':166,'step':1e-6,'max_discrepancy':max(errors),'tangent_constraint_defects':tangent_errors,'max_tangent_defect':max(tangent_errors),'status':'NUMERICAL implementation checks; exact selected root separately certified'},indent=2))
    history=[];best=initial;trust=.05;damping=.001;accepted=0;rejections={};start=time.monotonic()
    for iteration in range(200):
        j=state['jac'];grad=j.T@state['r'];delta=np.linalg.solve(j.T@j+damping*np.eye(83),-grad)
        if max(abs(delta[:-1]))>trust:delta*=trust/max(abs(delta[:-1]))
        trial=x+delta;why=None
        if max(abs(trial[:-1]-INITIAL[FREE]))>1.:why='free coordinate box guard'
        else:
            try:
                proposed=evaluate(trial,state['theta'])
                if proposed['Pauli_norm_diagnostic']>512:why='full Pauli budget guard'
                elif max(abs(proposed['theta'][PORTS]-state['theta'][PORTS]))>1.:why='dependent coordinate trust guard'
                elif proposed['cost']>=state['cost']:why='no cost decrease'
            except ValueError as exc:why=str(exc)
        if why:
            rejections[why]=rejections.get(why,0)+1;damping=min(1e8,damping*4);trust=max(1e-7,trust/2)
            history.append({'iteration':iteration,'accepted':False,'reason':why,'cost':state['cost'],'trust':trust})
        else:
            x=trial;state=proposed;accepted+=1;damping=max(1e-8,damping/2);trust=min(.2,trust*1.2)
            frozen=freeze(state,x,iteration)
            if frozen['strict_deadline_cap_exact'] and frozen['isometry_operator_residual']<best['isometry_operator_residual']:best=frozen
            history.append({'iteration':iteration,'accepted':True,'cost':state['cost'],'operator_residual':frozen['isometry_operator_residual'],'moment_max':state['normalized_moment_max'],'dependent_condition':state['condition'],'trust':trust})
        if iteration%25==0:print({'iteration':iteration,'accepted':accepted,'best_residual':best['isometry_operator_residual'],'cost':state['cost']},flush=True)
        if damping>=1e8:break
    receipt={'status':'FINITE NUMERICAL retracted search only; no encoder, global branch or global optimum inferred','random_seed':2026100605,'free_coordinates':82,'common_phase_coordinates':1,'dependent_coordinates':15,'iteration_cap':200,'iterations_attempted':len(history),'accepted_steps':accepted,'rejected_steps':len(history)-accepted,'rejection_reasons':rejections,'seconds':time.monotonic()-start,'guards':{'free_displacement_inf_from_initial':1.,'dependent_Jacobian_condition':1e7,'Newton_iterations':20,'normalized_moment_tolerance':2e-15,'Newton_step_tolerance':2e-13,'maximum_dependent_step_inf':1.,'full_Pauli_budget':512},'initial':initial,'best':best,'final':freeze(state,x,len(history)-1),'history':history}
    (R/'results'/'BRANCH_SEARCH.json').write_text(json.dumps(receipt,indent=2))
    print({k:receipt[k] for k in ['accepted_steps','rejected_steps','seconds']},flush=True);print({'best_residual':best['isometry_operator_residual'],'exact_L':float(Q(best['Pauli_norm_upper_exact']))},flush=True)
if __name__=='__main__':main()
