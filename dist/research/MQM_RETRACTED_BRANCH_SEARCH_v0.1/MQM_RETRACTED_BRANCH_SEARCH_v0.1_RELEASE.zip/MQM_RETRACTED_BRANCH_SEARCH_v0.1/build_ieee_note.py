"""IEEEtran/A4 continuation note with a scoped shared-return criterion."""
from pathlib import Path
from fractions import Fraction as Q
import json,subprocess
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript'
def read(n):return json.loads((R/'results'/n).read_text())
s=read('BRANCH_SEARCH.json');g=read('BRANCH_GRADIENT_RECEIPT.json');root=read('ROOT_CERTIFICATE.json');floor=read('ROOT_SPECTRAL_FLOOR.json');shared=read('SHARED_RETURN_WITNESS.json')
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\begin{document}
\title{Retracted Admission Search and\\a Shared-Return Spectral Criterion}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 6, 2026. ORCID: 0009-0002-5813-0724. Scoped derivation and constructor replay. Independent review and theorem-level novelty comparison pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
Guarded endpoint optimization on a regular second-moment-zero branch yields 100 accepted steps in 158 attempts for a six-qubit planar admission interface. The selected exact algebraic root remains excluded at every deadline by half-diamond error greater than $1/16$. We derive necessary shared-return conditions: perfect admission requires shared-input Krylov dimension at most 61; for simple spectrum, error at most $\epsilon<1$ requires the three smallest launch weights to sum to at most $(\epsilon/(1-\epsilon))^2$. The release includes 252 scoped exact checks and 166 numerical reduced-Jacobian checks. Admission and physical realization remain open.
\end{abstract}
\begin{IEEEkeywords}
Autonomous control, spectral return, implicit manifold, joint admission, two-local Hamiltonian.
\end{IEEEkeywords}
\section{Complete task and inherited regular branch}
Use register order $(A,O,u,v,w,z)$, with mode labels $(00,01,10,11)$, and define isometries
\begin{align}
E\ket{ab}&=\ket{ab}_{AO}\ket{\mathbf1_{00}}_M,\\
W\ket{ab}&=\ket{00}_{AO}\ket{\mathbf1_{ab}}_M.
\end{align}
The complete task retains four coherent inputs and arbitrary spectator entanglement, with one common phase. The six-qubit full physical dimension is 64. Permitted pairs remain $\{Au,Aw,Az,Ou,Ov,Ow,Oz,uw,uv,wz\}$, planar with maximum degree four. No additional qubits or permitted pairs are introduced.

An integer first-moment kernel parametrizes the accumulated generator
\begin{equation}
G(\theta)=\sum_k(B\theta)_kP_k=\sum_{a=1}^{97}\theta_aF_a.
\end{equation}
All 108 Pauli coefficients are real, with support at most two. Complex matrix entries are allowed. The first compressed moment matches identically. Fifteen independent rational quadratic equations $q(\theta)=0$ express second-moment equality; the nominal sixteenth Hermitian component vanishes because $E\ket{00}=W\ket{00}$. The preceding release \cite{parent} certified a regular zero point and a local 82-dimensional branch. It did not prove global regularity or admission.

Split coordinates into fifteen dependent ports $y$ and 82 free entries $z$. At a regular point,
\begin{equation}
q(y,z)=0,\qquad\frac{dy}{dz}=-J_y^{-1}J_z.
\end{equation}
The phase is a separate variable. These 83 search variables are not physical qubits or clock addresses.

\section{Retraction, reduced derivative and guards}
Keep the residual
\begin{equation}
R=e^{-iG(\theta)}E-e^{i\phi}W,\qquad f=\tfrac12\|R\|_F^2.
\end{equation}
Given a trial free-coordinate vector, Newton iterations solve the dependent equations using the preceding numerical point as a reference. The tangent lift is
\begin{equation}
\mathcal T_z=\begin{bmatrix}I_{82}\\-J_y^{-1}J_z\end{bmatrix},
\end{equation}
with rows restored to their actual coordinate order. The full complex exponential derivative is inherited from \cite{parent}; multiplying its real residual Jacobian by this lift gives the 82 reduced columns. The common phase supplies the 83rd column. Equivalently,
\begin{equation}
\nabla_z f=\nabla_z^{\rm full}f-J_z^\mathsf TJ_y^{-\mathsf T}\nabla_y f.
\end{equation}
A damped Gauss--Newton proposal solves
\begin{equation}
(\mathcal J^\mathsf T\mathcal J+\lambda I)\,\delta
=-\mathcal J^\mathsf Tr.
\end{equation}
The proposal is retracted and admitted only if the cost decreases and all numerical guards pass. Free displacement from the initial chart is bounded by one in infinity norm. The dependent Jacobian condition limit is $10^7$, the Newton cap is 20 iterations, and the dependent-step bound is one. Retraction requires normalized moment residual below $2\cdot10^{-15}$ and Newton step below $2\cdot10^{-13}$, after at least two iterations. Polynomial evaluation uses extended precision to reduce cancellation; this is not the exact certificate.

The complete Pauli ledger is $L=\sum_k|c_k|$. Every admitted trial must have sampled $L\le512$; selected frozen and algebraic points are audited exactly. For $H=G/L$, full norm is at most one on all 64 dimensions and the conservative deadline is $T=L$. This is not an optimal centered norm or a low-energy restriction.

At two probes, all $2\cdot83=166$ reduced-Jacobian columns pass central differences with step $10^{-6}$. The maximum discrepancy is @GRAD@; tangent constraint defect is at most @TANGENT@. These numerical checks do not certify a global chart or an exact continuous path.

\section{Finite search and exact endpoint audit}
The declared cap is 200 attempts. The search stops after 158: 100 steps are accepted and 58 rejected. Thirty-five rejections come from the free-coordinate box and 23 from lack of cost decrease. Damping reaches its stop threshold. This is a guarded finite termination, not evidence of stationarity or global optimality.

The initial sampled operator residual is @INITIAL@ and the selected residual is @BEST@, an absolute change of approximately $9.70\cdot10^{-6}$. This modest change is not a resource saving: the selected conservative deadline is approximately @DEADLINE@, compared with approximately 356.049 for the parent root. Six qubits, ten allowed pairs and 108 possible coupling components remain charged.

Freeze the selected numerical coordinates and refine a fifteen-coordinate rational slice. A dyadic approximate inverse $R_0$ defines $\mathcal B(y)=y-R_0q(y)$. Exact residual and preconditioned-Hessian bounds certify
\begin{equation}
\beta<1,\qquad\eta+\beta r<r,\qquad r=2^{-49}.
\end{equation}
Banach's theorem gives one unique real root in that fixed slice; its selected Jacobian minor stays invertible. Other 82 coordinates are fixed exact dyadics. The root itself has implicitly defined real algebraic coefficients, not claimed binary-rational values. First and second moments match exactly, and full norm at most one is certified with a deadline below 512. This certifies the selected point, not every numerical iterate or their connecting path.

Exact Gaussian-integer spectral residuals enclose the dyadic center's true projectors. The root-box Pauli norm debit is charged through a separated-gap projector bound. With $S=\sum_\lambda|\operatorname{Tr}(W^\dagger\Pi_\lambda E)|$, the maximally entangled logical/reference witness gives
\begin{equation}
\tfrac12\|\mathcal U_t-\mathcal W\|_\diamond
\ge\sqrt{1-(S/4)^2}>1/16
\end{equation}
at every deadline. The enclosed radical diagnostic is @FLOOR@. Scalar shifts and uniform norm scaling do not remove this obstruction. It excludes this algebraic root only, not the planar family.

\section{A shared-return structural criterion}
Let $v=E\ket{00}=W\ket{00}$ and $\Delta=W-E$. Exact task data satisfy
\begin{equation}
\Delta^\dagger\Delta=\operatorname{diag}(0,2,2,2).
\end{equation}
Thus there are three independent target-difference directions with singular value $\sqrt2$.
\begin{proposition}[Perfect-return Krylov restriction]
If a static Hermitian generator perfectly implements this task at a deadline, then
\begin{equation}
\dim\operatorname{span}\{G^kv:k\ge0\}\le61.
\end{equation}
This does not require simple spectrum.
\end{proposition}
\begin{proof}
Perfect admission gives $Uv=e^{i\phi}v$. Since $U$ commutes with $G$, it acts by that same phase on the shared-input Krylov space $\mathcal C$. This space reduces Hermitian $G$ and $U$. Projecting $UE=e^{i\phi}W$ onto $\mathcal C$ gives $P_{\mathcal C}(W-E)=0$. Three independent differences lie in its orthogonal complement, hence $\dim\mathcal C\le64-3$.
\end{proof}
Consequently the class $\dim\mathcal C>61$ is excluded from \emph{perfect} admission. This is a precise class restriction, not an impossibility result for all planar two-local generators.

\begin{proposition}[Finite-error launch-weight condition]
Suppose $G$ has simple spectrum, with normalized eigenvectors $h_n$, and let $w_n=|\langle h_n,v\rangle|^2$. If complete half-diamond admission error is at most $\epsilon<1$ at some deadline, the three smallest weights satisfy
\begin{equation}
w_{(1)}+w_{(2)}+w_{(3)}
\le\left(\frac{\epsilon}{1-\epsilon}\right)^2.
\end{equation}
\end{proposition}
\begin{proof}
Set $X=W^\dagger UE$ and let $\nu$ be the distance from zero to its numerical range. Standard isometric-channel geometry \cite{watrous} gives error $\sqrt{1-\nu^2}$. A supporting phase of the closest numerical-range point yields
\begin{equation}
\eta=\|UE-e^{i\phi}W\|\le\sqrt{2(1-\nu)}
\le\sqrt2\,\epsilon.
\end{equation}
Let $A=U-e^{i\phi}I$. Since $AE=e^{i\phi}\Delta+(UE-e^{i\phi}W)$, singular-value perturbation gives $\sigma_3(AE)\ge\sqrt2-\eta$. Therefore $A$ has at least three eigenmodes with phase displacement at least $\sqrt2-\eta$. The shared column obeys $\|Av\|\le\eta$. In the simple spectral basis,
\begin{equation}
\|Av\|^2=\sum_n|e^{-it\lambda_n}-e^{i\phi}|^2w_n.
\end{equation}
The sum of the weights of those three modes is at most $\eta^2/(\sqrt2-\eta)^2$. The three smallest weights have no larger sum. Substitution of $\eta\le\sqrt2\epsilon$ proves the claim.
\end{proof}
At target $\epsilon=2^{-16}$ the necessary threshold is exactly
\begin{equation}
w_{(1)}+w_{(2)}+w_{(3)}\le\frac1{65535^2}.
\end{equation}
In the perfect simple-spectrum limit, at least three modes must have zero launch weight. For degenerate spectra, individual eigenvector weights depend on the chosen basis; the simple-spectrum condition must not be dropped. The Krylov restriction remains basis independent.

The selected center's floating three-weight sum is approximately @WEIGHT@, below the necessary target threshold. This is not an enclosed root-weight certificate and passing a necessary screen does not supply admission: the separate spectral bound still excludes the root. The standard channel-distance ingredient is credited to \cite{watrous}; theorem-level novelty comparison for this task specialization remains pending.

\section{Next lifecycle gate}
Next, recenter or switch the regular chart and continue the budgeted coherent endpoint search. Each selected point requires an exact root, full-spectrum norm and deadline/window certificate. Admission at error $2^{-16}$ remains OPEN; SWAP-core composition is gated. The publication target remains a matched resource improvement or informative lower bound across competing architectures.
\begin{thebibliography}{2}
\bibitem{parent} B. W. Mayes, ``A Certified Regular Second-Moment Branch for Planar Joint Qubit Admission,'' MQM development note v0.1, Oct. 6, 2026, immutable replay release; independent review pending.
\bibitem{watrous} J. Watrous, \emph{The Theory of Quantum Information}. Cambridge University Press, 2018, ch. 3, Theorems 3.54--3.55. Author manuscript: \url{https://cs.uwaterloo.ca/~watrous/TQI/}.
\end{thebibliography}
\end{document}
'''
values={'BEST':f"{s['best']['isometry_operator_residual']:.9f}",'INITIAL':f"{s['initial']['isometry_operator_residual']:.9f}",'GRAD':f"{g['max_discrepancy']:.3g}",'TANGENT':f"{g['max_tangent_defect']:.3g}",'DEADLINE':f"{float(Q(root['root_Pauli_norm_upper'])):.6f}",'FLOOR':f"{floor['floor_diagnostic']:.6f}",'WEIGHT':f"{shared['numerical_center_three_weight_sum']:.3g}"}
for k,v in values.items():tex=tex.replace('@'+k+'@',v)
name='MQM_RETRACTED_BRANCH_SEARCH_IEEE_A4_v0.1';(M/(name+'.tex')).write_text(tex)
for k in range(2):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,capture_output=True,text=True)
    (R/'results'/('PDF_BUILD_'+str(k)+'.txt')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout[-3000:]
doc=fitz.open(M/(name+'.pdf'));log=(M/(name+'.log')).read_text()
for i,p in enumerate(doc):p.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/('PAGE_'+str(i+1)+'.png'))
qa={'pages':len(doc),'A4':all(abs(p.rect.width-595.276)<1 and abs(p.rect.height-841.89)<1 for p in doc),'actual_IEEEtran':True,'class_options':'journal,a4paper,10pt','two_columns':True,'no_overfull':'Overfull' not in log,'no_unresolved_references':'undefined' not in log,'visual_review':'pending'}
(R/'results'/'PDF_QA.json').write_text(json.dumps(qa,indent=2));print(qa)
