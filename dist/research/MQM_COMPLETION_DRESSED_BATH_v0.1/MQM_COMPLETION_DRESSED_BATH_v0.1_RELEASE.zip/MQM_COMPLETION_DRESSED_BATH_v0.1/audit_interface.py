"""Autonomous terminal marker + spectral thermal-bath audit; conditional frontend."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction
import json,math
import numpy as np
import sympy as s
from scipy.linalg import expm
R=Path(__file__).resolve().parent
P={'status':'FROZEN before evaluation, exploratory conditional compiler/bath audit','port':'native ququart C=p,m,e,d; fresh completion flag F=0; auxiliary R=0; launch p,F0,R0','frontend_contract':'p is the terminal frontend address after its work word. No work-word or native joint admission compiler included. No occupancy-to-completion material trigger.','marker':'h (|m><p|+h.c.) tensor X_F; no pulse or initially true completion flag','latch_entry':'g (|e><m|+h.c.) tensor |1><1|_F','reservoir_exchange':'lambda (|d><e| tensor sigma_R+ +h.c.)','physical_types':'one native ququart, two qubits; native pair graph F-C-R; ququart qubit-dilation not certified two-local','h':1,'g':1,'lambda_squared':'4sqrt2','local_kappa':8,'local_reverse_ratio':'0','readout_center':16,'readout_half_width':'1/1024','bath_model':'bosonic Ohmic exponential cutoff, coupling A=I_CF tensor X_R; fully secular dressed (Davies-type) generator','H_free':'Omega [(P_p+P_m+P_e)tensorI+I tensorN_R]','Omega':64,'cutoff':640,'beta_Omega':20,'reference_downward_kappa':[8,'1/1024'],'spectral_density':'J(nu)=alpha nu exp(-nu/cutoff), alpha chosen gamma_down(Omega)=kappa_ref','rate':'gamma_down(nu)=J(nu)/(1-exp(-beta nu)); gamma_up=exp(-beta nu)gamma_down','Lamb_shift':'not calculated; absorbed/assumed calibrated Hamiltonian, separate open debit','times':[16,256,65536,262144,1048576],'target':'retained preparation channel half-diamond <=1/65536; data identity; bath traced','heuristic_secular_gate':'max resolved jump norm-squared / minimum distinct positive Bohr-frequency separation <1/10; diagnostic only, no microscopic error theorem','grouping_frequency_tolerance':1e-9,'matrix_entry_cutoff':1e-11,'numerical_tolerance':1e-8,'precision':'binary64; symbolic exact; cold interval separate','physical_promotion':0,'comparison':'same Hamiltonian; local and secular generators compared. High-rate secular replay diagnostic only, not falsification of local/singular-coupling model.'}
(R/'PROTOCOL.json').write_text(json.dumps(P,indent=2))
exact=[];num=[]
def ck(n,v,led):assert bool(v),n;led.append(n)
def ketbra(d,a,b):M=s.zeros(d);M[a,b]=1;return M
I4=s.eye(4);I2=s.eye(2);X=s.Matrix([[0,1],[1,0]]);sm=s.Matrix([[0,1],[0,0]]);sp=sm.T
cp=ketbra(4,0,0);cm=ketbra(4,1,1);ce=ketbra(4,2,2);cd=ketbra(4,3,3);f0=s.diag(1,0);f1=s.diag(0,1)
h,g,l=s.symbols('h g l',positive=True)
mark=ketbra(4,1,0)+ketbra(4,0,1);entry=ketbra(4,2,1)+ketbra(4,1,2);S=ketbra(4,3,2)
H=h*s.kronecker_product(mark,X,I2)+g*s.kronecker_product(entry,f1,I2)+l*(s.kronecker_product(S,I2,sp)+s.kronecker_product(S.T,I2,sm))
valid=s.kronecker_product(cp,f0,I2)+s.kronecker_product(cm+ce+cd,f1,I2)
blocked=s.kronecker_product(cp,f1,I2)+s.kronecker_product(cm,f0,I2)
down=s.kronecker_product(I4,I2,sm);up=down.T
ck('native pair Hamiltonian Hermitian',H==H.T,exact)
ck('admitted sector projector rank8',valid*valid==valid and valid.rank()==8,exact)
ck('admitted sector invariant',H*valid-valid*H==s.zeros(16),exact)
ck('bath lowering preserves admitted sector',down*valid-valid*down==s.zeros(16),exact)
ck('bath raising preserves admitted sector',up*valid-valid*up==s.zeros(16),exact)
ck('blocked sector rank4',blocked.rank()==4,exact)
ck('blocked sector invariant Hamiltonian',H*blocked-blocked*H==s.zeros(16),exact)
ck('blocked sector bath-invariant',down*blocked-blocked*down==s.zeros(16) and up*blocked-blocked*up==s.zeros(16),exact)
cap=s.kronecker_product(cd,I2,I2);wrongcap=s.kronecker_product(cd,f0,I2)
ck('blocked sector excludes capture',cap*blocked==s.zeros(16),exact)
ck('admitted capture has flag1',wrongcap*valid==s.zeros(16),exact)
V=s.zeros(16,8)
for c in range(4):
 for r in range(2):V[c*4+(0 if c==0 else 2)+r,c*2+r]=1
ck('admitted-sector isometry',V.T*V==s.eye(8) and V*V.T==valid,exact)
Hr=V.T*H*V
x=s.symbols('x');char=s.factor(H.charpoly(x).as_expr())
ck('spectral reflection symmetry',s.expand(char.subs(x,-x)-char)==0,exact)
N=s.kronecker_product(cp+cm+ce,I2,I2)+s.kronecker_product(I4,I2,s.diag(0,1))
ck('free-energy charge commutes interaction',H*N-N*H==s.zeros(16),exact)
ck('bath lowering charge',N*down-down*N==-down,exact)
ck('cold target dF1R0 annihilated',H[:,14]==s.zeros(16,1) and down[:,14]==s.zeros(16,1),exact)
# Primitive without auxiliary: marker transfers fresh flag0 to flag1 at pi/(2h).
ck('marker involution on p0,m1',H[6,0]==h and H[0,6]==h,exact)
# All jumps built spectrally from H and X_R preserve the proved block projectors.
ck('bath coordinate commutes with valid and blocked',(down+up)*valid-valid*(down+up)==s.zeros(16) and (down+up)*blocked-blocked*(down+up)==s.zeros(16),exact)
Zc=s.diag(1,-1)
ck('displayed binary encoding has weight3 marker coefficient',s.trace(s.kronecker_product(Zc,X,X,I2)*H)/16==h/2,exact)
ck('selected path discriminant exact square',s.simplify((2+4*s.sqrt(2))**2-16*s.sqrt(2))==36,exact)
lam=math.sqrt(4*math.sqrt(2));hs=np.array(Hr.subs({h:1,g:1,l:lam}),float);hf=np.array(H.subs({h:1,g:1,l:lam}),float)
n=np.array(V.T*N*V,float);d=np.array(V.T*down*V,float);a=d+d.T
Omega=64.;cut=640.;beta=20/Omega;lab=Omega*n+hs
E,Q=np.linalg.eigh(lab);ae=Q.T@a@Q
trans=[]
for i in range(8):
 for j in range(8):
  if E[j]>E[i]+1e-9 and abs(ae[i,j])>1e-11:trans.append((E[j]-E[i],i,j,ae[i,j]))
groups=[]
for nu,i,j,v in sorted(trans):
 if not groups or abs(groups[-1][0]-nu)>1e-9:groups.append([nu,np.zeros((8,8))])
 groups[-1][1][i,j]=v
freq=[v[0] for v in groups];sep=min(b-a for a,b in zip(freq,freq[1:]))
ck('spectral decomposition reconstructs bath operator',np.linalg.norm(sum((Q@(m+m.T)@Q.T for nu,m in groups),np.zeros((8,8)))-a)<1e-10,num)
ck('full physical norm equals admitted upper path norm',abs(np.linalg.norm(hf,2)-np.linalg.norm(hs,2))<1e-10,num)

def gen(H,jumps):
 d=len(H);I=np.eye(d);L=-1j*(np.kron(I,H)-np.kron(H.T,I))
 for j in jumps:
  c=j.conj().T@j;L+=np.kron(j.conj(),j)-.5*(np.kron(I,c)+np.kron(c.T,I))
 return L

def evolve(L,rho,t):return (expm(t*L)@rho.reshape(-1,order='F')).reshape(8,8,order='F')
def td(A,B):v=(A-B+(A-B).conj().T)/2;return float(sum(abs(np.linalg.eigvalsh(v)))/2)
init=np.diag([1.,0,0,0,0,0,0,0]);target=np.diag([0.,0,0,0,0,0,1.,0])
local=gen(hs,[math.sqrt(8)*d]);local_rows=[]
for t in [4,16,64,256]:
 rho=evolve(local,init,t)
 ck('local trace '+str(t),abs(np.trace(rho)-1)<1e-10,num)
 local_rows.append({'time':t,'full_retained_error':td(rho,target),'flag1_probability':float(sum(np.diag(rho)[2:]).real)})
gibbs=Q@np.diag(np.exp(-beta*(E-E[0]))/sum(np.exp(-beta*(E-E[0]))))@Q.T
bath=[]
for kval in P['reference_downward_kappa']:
 k=float(Fraction(kval));alpha=k*(1-math.exp(-beta*Omega))*math.exp(Omega/cut)/Omega
 jumps=[];rates=[]
 for nu,mat in groups:
  gd=alpha*nu*math.exp(-nu/cut)/(1-math.exp(-beta*nu));gu=gd*math.exp(-beta*nu)
  op=Q@mat@Q.T;jumps.extend([math.sqrt(gd)*op,math.sqrt(gu)*op.T]);rates.append({'frequency':nu,'down_rate':gd,'up_rate':gu,'ratio':math.exp(-beta*nu),'operator_norm_squared':float(np.linalg.norm(op,2)**2),'linewidth_debit':gd*float(np.linalg.norm(op,2)**2)})
 L=gen(hs,jumps)
 ck('Gibbs stationary '+str(kval),np.linalg.norm(L@gibbs.reshape(-1,order='F'))<1e-10,num)
 for rr in rates:ck('KMS ratio '+str((kval,rr['frequency'])),abs(rr['up_rate']/rr['down_rate']-rr['ratio'])<1e-15,num)
 linewidth=max(x['linewidth_debit'] for x in rates);gate=bool(linewidth/sep<.1)
 rows=[]
 for t in P['times']:
  rho=evolve(L,init,t);loc=evolve(local,init,t)
  ck('global trace '+str((kval,t)),abs(np.trace(rho)-1)<1e-8,num)
  ck('global positivity '+str((kval,t)),min(np.linalg.eigvalsh(rho))>-1e-8,num)
  rows.append({'time':t,'retained_error_to_target':td(rho,target),'difference_from_fast_local_model':td(rho,loc),'distance_to_Gibbs':td(rho,gibbs),'flag1_probability':float(sum(np.diag(rho)[2:]).real),'target_pass_numerical':td(rho,target)<1/65536})
 bath.append({'reference_kappa':str(kval),'alpha':alpha,'frequencies':rates,'minimum_frequency_separation':sep,'max_individual_linewidth':linewidth,'secular_ratio':linewidth/sep,'heuristic_secular_gate_pass':gate,'interpretation':'heuristic separation diagnostic, not rigorous Born-Markov certification; fast case diagnostic only' if not gate else 'passes declared separation diagnostic; weak-coupling approximation error remains OPEN','rows':rows})
res={'status':'EXACT autonomous marker invariants; SIMULATED dressed Ohmic-bath comparison','exact_count':len(exact),'exact_checks':exact,'numerical_count':len(num),'numerical_checks':num,'full_characteristic_polynomial':str(char),'native_full_interaction_norm':float(np.linalg.norm(hf,2)),'lab_full_centered_norm':float((np.linalg.eigvalsh(Omega*np.array(N,float)+hf)[-1]-np.linalg.eigvalsh(Omega*np.array(N,float)+hf)[0])/2),'admitted_energies':E.tolist(),'positive_Bohr_frequencies':freq,'local_cold_rows':local_rows,'dressed_bath':bath,'Gibbs_target_error':td(gibbs,target),'physical_promotion':0,'scope':'Autonomous flag setting from declared terminal frontend port; no compiled work word or joint admission. Native subsystem locality only. Davies-type bath generator conditional on weak-coupling/secular approximation; no continuum replay or hardware.'}
(R/'results/INTERFACE_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k not in ['numerical_checks','exact_checks','dressed_bath']},indent=2));print(json.dumps({'bath_summary':[{'kappa':b['reference_kappa'],'secular_ratio':b['secular_ratio'],'gate':b['heuristic_secular_gate_pass'],'rows':b['rows']} for b in bath]},indent=2))
