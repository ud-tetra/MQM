MQM COMPLETION DRESSED BATH v0.1
Conditional autonomous terminal marker and separate Ohmic-bath comparison. Physical promotion0.

Replay:
 python3 audit_interface.py
 python3 certify_port.py
PDF: python3 build_pdf.py; inspect PAGE_*.png.
Dependencies in requirements.txt; pdflatex and IEEEtran dependencies external.

19 exact checks;52 binary64 checks; directed interval original local-bath window.
Local reverse extension:26625/2147483648 <1/65536 for r<=2^-24.
Native ququart+F+R two pair graph; qubit2local implementation remains OPEN.
Frontend terminal port semantics remain a contract, not an execution compiler.
Bath frequencies grouped; restricted-sector Gibbs, not full ergodic thermal state.
Fast secular bath FAILS separation diagnostic despite passing numerical target.
Weak-rate bath passes heuristic diagnostic, not microscopic validity theorem.
First passing sampled weak deadline2^18; not minimum latency or rigorous time window.
No empirical device result, hardware promotion or quantum advantage.
IEEEtran distributed under LPPL; license retained.
