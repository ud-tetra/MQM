"""Directed interval certificate for marked completion port, local cold bath."""
from pathlib import Path
from fractions import Fraction
import math,json
from mpmath import iv
iv.dps=80
R=Path(__file__).resolve().parent

def rat(x):f=Fraction(x);return iv.mpf(f.numerator)/f.denominator
def mul(A,B):return [[sum(A[i][k]*B[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
def eye():return [[rat(int(i==j)) for j in range(4)] for i in range(4)]
lam=iv.sqrt(4*iv.sqrt(rat(2)));k=8
A=[[rat(0),rat(-1),rat(0),rat(0)],[rat(1),rat(0),rat(-1),rat(0)],[rat(0),rat(1),rat(0),-lam],[rat(0),rat(0),lam,rat(-4)]]
t=iv.mpf([rat(Fraction(16)-Fraction(1,1024)).a,rat(Fraction(16)+Fraction(1,1024)).b]);scale=14
B=[[v*t/2**scale for v in row] for row in A];norm_bound=(2+lam+4)*t/2**scale
V=eye();term=eye()
for j in range(1,33):
 term=mul(term,B);term=[[v/j for v in row] for row in term]
 V=[[V[i][k]+term[i][k] for k in range(4)] for i in range(4)]
rem=iv.exp(norm_bound)*norm_bound**33/math.factorial(33);rad=iv.mpf([-rem.b,rem.b]);V=[[v+rad for v in row] for row in V]
for _ in range(scale):V=mul(V,V)
q=sum(V[i][0]*V[i][0] for i in range(4));ceil=Fraction(5,2**20)
assert q.b<rat(ceil).a
thermal=ceil+8*Fraction(1,2**24)*(16+Fraction(1,1024));assert thermal<Fraction(1,65536)
res={'status':'INTERVAL VERIFIED original-window local cold marker-and-latch error; DERIVED reverse-jump extension','interval_error':str(q),'exact_cold_ceiling':str(ceil),'exact_reverse_ratio_max':'1/16777216','exact_total_reverse_bound':str(thermal),'target':'1/65536','window':'|t-16|<=1/1024','scope':'fixed pF0R0 admitted launch, native ququart marker, spectator identity, local Markov bath traced. Does not apply to the dressed Ohmic generator.','method':'80-digit directed intervals; Taylor order32 scale2^14 infinity-norm remainder, interval squaring','reverse_extension':'CPTP Duhamel bound adds kappa*r*t with kappa8. Selected sufficient rational ceiling/range disclosed; not optimized.','physical_promotion':0}
(R/'results/PORT_INTERVAL_CERTIFICATE.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
