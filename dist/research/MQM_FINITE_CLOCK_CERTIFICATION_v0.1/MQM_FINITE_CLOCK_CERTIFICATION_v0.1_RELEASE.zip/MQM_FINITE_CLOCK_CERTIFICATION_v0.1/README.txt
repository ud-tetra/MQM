MQM FINITE CLOCK CERTIFICATION v 0.1 -- 5 October 2026

Primary paper: manuscript/MQM_CERTIFIED_53_ADDRESS_CLOCK_IEEE_A 4_v 0.1.pdf
Actual IEEEtran journal class, A 4 (210 x 297 mm), two columns, 10pt.
PUBLICATION_FORMAT_POLICY_v 1.0.json records the user's requirement for all future papers.

RESULT
The frozen thirteen-step episode has an admitted static clock with 53 addresses,
versus the previous 64-address engineered-spin reference (11/64=17.1875% reduction).
The fixed common interval is [63*pi/4,189*pi/4]; no timing rescaling is used.
Exact dyadic couplings are in CERTIFIED_CLOCK.json, denominator 2^30.
Complete retained-domain ideal error is uniformly <=0.0008817189423708117.
Including the original preparation 2^-16 and static-generator mismatch 2^-21
allowances, the upper bound is 0.0009677595597805739<1/1024.
A separate Gram-dimension proof requires at least 16 addresses in the ideal task.
The certified finite bracket is 16..53; no global minimum is established.
Six binary clock qubits are still needed. Unary clock sites decrease from 64 to 53.

REPRODUCE
From this directory:
  OPENBLAS_NUM_THREADS=1 python 3 certify_clock.py
  python 3 build_ieee_paper.py
Optional discovery (not needed for the certificate):
  OPENBLAS_NUM_THREADS=1 python 3 search_clock_candidates.py
Certificate output includes exact rational resource checks, a continuous-window
arithmetic error bound, and separate sparse-propagator numerical diagnostics.
The build script runs three pdfLaTeX passes and checks A 4, resolved references
and absence of overfull boxes. It builds figures and the paper from this package.

STATUS
The certificate is conditional on the specified elementary binary 64 arithmetic
model. Independent proof/implementation review and theorem-priority review are
pending. Local search hit its iteration limits; failed 52-address discovery is
not an infeasibility result. No hardware, fault tolerance, coupling-synthesis
saving, universal autonomous processor or self-renewing supervisor is claimed.
The body benchmark is degenerate. Parent full-body constructor evidence is
anchored but not bundled; new-clock replay uses the general complete-domain
proof and explicitly propagates the clock, not every body register.

INPUT_ANCHORS.json links this continuation by SHA 256 to immutable earlier releases.
CLAIM_REGISTER_v 0.1.json records exact scope; COMPARISON_CONTRACT_v 0.1.json freezes
resources. REVIEW_RESPONSE_AND_NEXT_STEPS.txt explains publication implications.
SHA 256_MANIFEST.json covers all release payload files except itself.
Vector figure PDFs are plot assets; IEEE/A 4 applies to the paper PDF.
