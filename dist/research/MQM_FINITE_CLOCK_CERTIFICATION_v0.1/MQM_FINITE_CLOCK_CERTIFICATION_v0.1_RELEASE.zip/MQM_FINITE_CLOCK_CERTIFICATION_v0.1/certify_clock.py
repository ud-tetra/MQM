"""Verified dyadic path-clock propagation with explicit binary64 error budget.
Run OPENBLAS_NUM_THREADS=1 python3 certify_clock.py.
The numerical assurance is conditional on the stated floating arithmetic model.
All algebraic admissions, bounds and final threshold decisions are rational.
"""
from pathlib import Path
from fractions import Fraction as F
from math import factorial, isqrt, comb
import json,csv,time,sys,ctypes
import numpy as np
from scipy.linalg import eigh_tridiagonal
from scipy.sparse import diags
from scipy.sparse.linalg import expm_multiply

R=Path(__file__).resolve().parent;OUT=R/'results';OUT.mkdir(exist_ok=True)
started=time.perf_counter()
assert ctypes.CDLL(None).fegetround()==0, 'Round-to-nearest mode required'
assert np.finfo(np.float64).eps==2**-52 and np.finfo(np.float64).minexp==-1022
candidate=json.loads((R/'CERTIFIED_CLOCK.json').read_text())
den=2**candidate['coupling_denominator_bits']
edge_q=[F(n,den) for n in candidate['edge_numerators']]
edge=np.array([float(e) for e in edge_q],dtype=np.float64)
D=len(edge)+1;m=13
assert D<=64 and m<D
exact=[]
def check(name,ok):
    if not ok:raise AssertionError(name)
    exact.append(name)
def fjson(q):return {'numerator':str(q.numerator),'denominator':str(q.denominator),'decimal':float(q)}
def ceilq(q):return -(-q.numerator//q.denominator)
def upper_sqrt(q,bits=60):
    assert q>=0
    den=2**bits
    num=isqrt(q.numerator*den*den//q.denominator)
    if F(num*num,den*den)<q:num+=1
    ans=F(num,den)
    check('dyadic square-root enclosure',ans*ans>=q)
    return ans
for i,q in enumerate(edge_q):
    check(f'edge {i} exact binary64 representation',F(float(q))==q)
    check(f'edge {i} positive and below local ceiling',0<q<=F(32,63))
check('initial variance below 1/63',edge_q[0]**2<=F(1,63))

# I-K and I+K have the same leading determinants for this zero-diagonal path.
# Strictly positive leading minors certify spectral norm below one (Sylvester).
detprev=F(1);detcurr=F(1)
minors=[detcurr]
for i,e in enumerate(edge_q):
    detnew=detcurr-e*e*detprev
    check(f'positive norm-admission leading minor {i+2}',detnew>0)
    minors.append(detnew);detprev,detcurr=detcurr,detnew

# Machin identity pi=16 atan(1/5)-4 atan(1/239), with alternating-series bounds.
# No rounded pi is used in the certified time endpoints.
def atan_interval(inv,terms=80):
    x=F(1,inv)
    s=sum(((-1)**k)*x**(2*k+1)/F(2*k+1) for k in range(terms))
    nxt=((-1)**terms)*x**(2*terms+1)/F(2*terms+1)
    return min(s,s+nxt),max(s,s+nxt)
a5,b5=atan_interval(5);a239,b239=atan_interval(239)
pi_lo=16*a5-4*b239;pi_hi=16*b5-4*a239
check('Machin bracket contains decimal 3.141592653589793 view',pi_lo<F('3.141592653589794') and pi_hi>F('3.141592653589793'))
h=F(1,128);hf=float(h);P=12
left=F(63,4)*pi_lo;right=F(189,4)*pi_hi
first=(left/h).numerator//(left/h).denominator
last=ceilq(right/h)
check('outward time mesh covers true window',first*h<=left and last*h>=right)
u=F(1,2**53)
gamma72=72*u/(1-72*u)
rounding=gamma72/(1-h)
underflow=F(1,2**1000)
check('simple local roundoff ceiling',rounding<128*u)
trunc=h**(P+1)/(factorial(P+1)*(1-h))
local=rounding+trunc+underflow
check('global rational propagation bound denominator positive',last*local<1)
global_err=last*local/(1-last*local)

# K is real and bipartite: c_j=(-i)^j v_j, v'=Av with A skew real.
# Each Av component uses at most two products and one subtraction.
def advance(v):
    term=v.copy();out=v.copy()
    for k in range(1,P+1):
        tmp=np.empty_like(term)
        tmp[0]=-edge[0]*term[1]
        tmp[-1]=edge[-1]*term[-2]
        tmp[1:-1]=edge[:-1]*term[:-2]-edge[1:]*term[2:]
        term=(hf/k)*tmp
        out+=term
    return out
v=np.zeros(D,dtype=np.float64);v[0]=1
peak=0.;peak_step=first;chart=[];snapshots={}
for n in range(last+1):
    if first<=n<=last:
        pop=float(np.sum(v[:m]*v[:m]))
        if pop>peak:peak=pop;peak_step=n;peak_state=v.copy()
        if (n-first)%16==0 or n==last:
            chart.append({'step':n,'time':n*hf,'p_float':pop,'joint_error_float':np.sqrt(max(0,2*pop-pop*pop))})
        if n in [first,(first+last)//2,last]:snapshots[n]=v.copy()
    if n==last:break
    v=advance(v)
    if not np.all(np.isfinite(v)):raise AssertionError('nonfinite propagation')

# Sum/product rounding for the 13-component squared norm uses a safe gamma32.
gamma32=32*u/(1-32*u)
peak_squared_upper=(F(peak)+underflow)/(1-gamma32)
sample_norm_upper=upper_sqrt(peak_squared_upper)
amplitude_upper=sample_norm_upper+global_err+h*h/8
tail_upper=min(F(1),amplitude_upper**2)
joint_squared_upper=2*tail_upper-tail_upper**2
joint_upper=upper_sqrt(joint_squared_upper)
eps=F(1,1024);bank=F(1,2**16);mismatch=F(1,2**21)
total_upper=joint_upper+bank+right*mismatch
check('ideal full-window joint target',joint_squared_upper<eps*eps)
check('parent supply/mismatch full-window target',total_upper<eps)
check('three-time packing condition q_epsilon<1/3',eps**2<F(17,81))
lower_dimension=m+3

# Independent numerical diagnostic at three mesh times. Not used for admission.
K=diags([edge,np.zeros(D),edge],[-1,0,1],format='csr')
v0=np.zeros(D);v0[0]=1
diagnostics=[]
phases=(-1j)**np.arange(D)
snapshots[peak_step]=peak_state
for step,state in snapshots.items():
    other=expm_multiply(-1j*(step*hf)*K,v0,traceA=0)
    residual=float(np.linalg.norm(other-phases*state))
    if residual>1e-10:raise AssertionError(('sparse diagnostic',residual))
    diagnostics.append({'step':step,'residual':residual})
ev=eigh_tridiagonal(np.zeros(D),edge,eigvals_only=True)
unshaped_p=F(sum(comb(D-1,j) for j in range(m)),2**(D-1))
check('unshaped same-dimension spin clock fails original window target',2*unshaped_p-unshaped_p**2>eps**2)
with (OUT/'CERTIFIED_WINDOW_TRACE.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(chart[0]));w.writeheader();w.writerows(chart)
receipt={
 'status':'PASS','clock_dimension':D,'edges':D-1,'m':m,'date':'2026-10-05',
 'runtime_round_to_nearest_verified':True,
 'arithmetic_model':'IEEE binary64 round-to-nearest for elementary array operations; unit roundoff 2^-53; underflow covered by 2^-1000 allowance',
 'couplings':'Exactly representable positive dyadic rationals; zero diagonal',
 'norm_certificate':'Positive exact rational leading minors of I-K and I+K',
 'diagnostic_clock_norm':float(max(abs(ev))),'max_edge_exact':fjson(max(edge_q)),
 'initial_variance_exact':fjson(edge_q[0]**2),
 'time_mesh_step':fjson(h),'first_included_mesh_step':first,'last_mesh_step':last,
 'window_samples':last-first+1,'propagation_steps_from_zero':last,'taylor_order':P,
 'peak_float_population':peak,'peak_mesh_step':peak_step,
 'local_rounding_bound':fjson(rounding),'local_taylor_bound':fjson(trunc),
 'global_state_vector_error_bound':fjson(global_err),'interpolation_amplitude_allowance':fjson(h*h/8),
 'sample_incomplete_norm_upper':fjson(sample_norm_upper),
 'uniform_incomplete_population_upper':fjson(tail_upper),
 'uniform_joint_error_upper':fjson(joint_upper),
 'bank_allowance':fjson(bank),'generator_mismatch_allowance':fjson(mismatch),
 'uniform_total_error_upper':fjson(total_upper),'target':fjson(eps),
 'unshaped_same_dimension_endpoint_p':fjson(unshaped_p),
 'finite_clock_dimension_lower_bound':lower_dimension,
 'finite_bracket':[lower_dimension,D],
 'exact_checks':len(exact),'exact_check_names':exact,
 'sparse_diagnostics':diagnostics,'elapsed_seconds':time.perf_counter()-started,
 'status_boundary':'Mathematical certificate conditional on floating arithmetic model; independent implementation/proof audit and physical realization pending',
 'not_claimed':['Global smallest clock','Savings in binary clock qubits','Reduction in coupling synthesis cost','Independent theorem priority','Fault tolerance']}
(OUT/'CERTIFICATION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
(OUT/'EXACT_NORM_MINORS.json').write_text(json.dumps([fjson(x) for x in minors],indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','clock_dimension','window_samples','exact_checks','global_state_vector_error_bound','uniform_joint_error_upper','uniform_total_error_upper','elapsed_seconds']},indent=2))
