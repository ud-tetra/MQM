"""Build IEEEtran journal-format A4 paper and figures; run after certificate replay."""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import csv,json,subprocess,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R=Path(__file__).resolve().parent
M=R/'manuscript';OUT=R/'results';FIG=R/'figures';FIG.mkdir(exist_ok=True)
receipt=json.loads((OUT/'CERTIFICATION_RECEIPT.json').read_text())
candidate=json.loads((R/'CERTIFIED_CLOCK.json').read_text())
trace=list(csv.DictReader((OUT/'CERTIFIED_WINDOW_TRACE.csv').open()))
t=np.array([float(x['time']) for x in trace])
joint=np.array([float(x['joint_error_float']) for x in trace])
plt.rcParams.update({'font.size':8,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':240})
fig,ax=plt.subplots(figsize=(3.5,2.6))
for N,name,col in [(63,'Spin reference, D = 64','#194e76'),(52,'Unshaped spin, D = 53','#a25224')]:
    z=np.sin(t/63)**2
    p=sum(comb(N,j)*z**j*(1-z)**(N-j) for j in range(13))
    ax.semilogy(t,np.maximum(np.sqrt(np.maximum(0,2*p-p*p)),1e-15),color=col,lw=1.3,label=name)
ax.semilogy(t,np.maximum(joint,1e-15),color='#237765',lw=1.3,label='Shaped dyadic clock, D = 53')
ax.axhline(1/1024,color='#596774',lw=.9,ls='--',label='Required error: 1/1024')
ax.set(xlabel='Model time',ylabel='Complete channel error')
ax.grid(which='both',alpha=.13);ax.legend(fontsize=6.6,loc='lower center')
fig.tight_layout();fig.savefig(FIG/'CLOCK_ERROR_COMPARISON.pdf');fig.savefig(FIG/'CLOCK_ERROR_COMPARISON.png');plt.close(fig)

fig,ax=plt.subplots(figsize=(3.5,2.3))
for N,name,col in [(63,'Spin reference, D = 64','#194e76'),(52,'Unshaped spin, D = 53','#a25224')]:
    j=np.arange(N);e=np.sqrt((j+1)*(N-j))/63
    ax.plot(j,e,lw=1.2,color=col,label=name)
e=np.array(candidate['edge_numerators'])/2**candidate['coupling_denominator_bits']
ax.plot(np.arange(len(e)),e,color='#237765',lw=1.3,label='Certified shaped clock, D = 53')
ax.axvline(12.5,ls=':',lw=.8,color='#596774')
ax.set(xlabel='Clock edge index j',ylabel='Edge magnitude')
ax.grid(alpha=.13);ax.legend(fontsize=6.4,loc='lower center')
fig.tight_layout();fig.savefig(FIG/'CLOCK_COUPLINGS.pdf');fig.savefig(FIG/'CLOCK_COUPLINGS.png');plt.close(fig)

coupling_rows=[]
nums=candidate['edge_numerators']
for row in range(13):
    items=[]
    for block in range(4):
        j=row+13*block;items.extend([str(j),str(nums[j])])
    coupling_rows.append(' & '.join(items)+r' \\')

tex=r'''\documentclass[a4paper,journal,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm}
\usepackage{graphicx,booktabs,array,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{lemma}{Lemma}
\newtheorem{proposition}{Proposition}
\newtheorem{corollary}{Corollary}
\newcommand{\norm}[1]{\left\lVert #1\right\rVert}
\newcommand{\ket}[1]{\lvert #1\rangle}
\newcommand{\bra}[1]{\langle #1\rvert}
\newcommand{\Dcal}{\mathcal D}
\begin{document}
\title{A Certified 53-Address Clock for Finite Quantum Execution, Capture, and Renewal}
\author{Benjamin Walker Mayes\thanks{Independent researcher. ORCID: 0009-0002-5813-0724. Development manuscript v0.1, October 5, 2026. Independent proof review and theorem-level priority assessment remain pending. No physical realization is claimed.}}
\markboth{MQM Research Development, Version 0.1, October 2026}{Mayes: Certified Finite Quantum Clocks}
\maketitle
\begin{abstract}
We construct a 53-address static history clock for a thirteen-step quantum episode containing two executions, two output captures, two complete work-module exchanges, and a final completion flag. Compared with the previously certified 64-address engineered-spin reference, the new clock reduces address dimension by 11, or 17.1875\%, under the same launch, readout interval, retained-domain error target, and resource ceilings. The positive couplings are exact dyadic rationals. Rational leading-minor tests certify the norm and local-resource admissions. A real skew-generator propagator with explicit binary64 roundoff, Taylor-tail, and interpolation allowances bounds complete error throughout the continuous interval. The ideal bound is below $8.817190\times10^{-4}$; retaining the earlier preparation and static-generator allowances gives a bound below $9.677596\times10^{-4}<1/1024$. A three-time Gram argument independently excludes clocks with only one or two completed addresses, strengthening the finite dimension bracket to $16\le D_\star\le53$ for the ideal task. The certificate is conditional on its declared arithmetic model and remains subject to independent audit. It establishes a reduction against a specified reference, not a global optimum, a binary-qubit saving, or a physical quantum advantage.
\end{abstract}
\begin{IEEEkeywords}
Autonomous quantum control, history Hamiltonians, finite quantum clocks, verified numerical computation, resource bounds, quantum information.
\end{IEEEkeywords}

\section{Introduction}
\IEEEPARstart{A}{utonomous} history-Hamiltonian computation, engineered state transfer, and clock idling are established techniques \cite{caha,christandl}. Their relevance here is a finite information task: execute supplied gates, retain two outputs, exchange used work modules for prepared donors, and compare the complete resulting state while retaining the clock and outgoing correlations.

The preceding MQM developments \cite{episode,cross} compiled such an episode and established its exact complete-channel error. They also gave an address-size law of order $m+\log(1/\epsilon)$ within the spin family and then across a declared weighted-history-path class. The finite example remained between 14 necessary and 64 sufficient addresses. Asymptotic order did not decide that finite optimum.

This paper advances both ends of the finite bracket. We provide an explicit 53-address clock and a continuous-window certificate with the original supply and mismatch allowances. A separate subspace-packing obstruction raises the lower bound to 16. The construction remains a program-specific finite episode. The supervisor is not renewed, the bank is supplied, and logical body Hamiltonians remain degenerate. There is no experimental result or total physical-resource optimality claim.

\section{Complete Episode and Frozen Contract}
\subsection{Registers and compiled word}
The body comprises nine qubits in the order
\begin{equation}
(A,J,D_{1A},D_{1J},D_{2A},D_{2J},O_1,O_2,E).
\end{equation}
The input $A$ can be arbitrarily correlated with a spectator $Y$. All other body qubits start in $\ket0$, except $D_{1A}$, which starts in $\ket+$. The work module is $(A,J)$, each donor has a matched pair, and $O_1,O_2$ are fresh output slots. All declared bare body Hamiltonians vanish; this is a logical benchmark, not a thermodynamic preparation model.

The thirteen primitives are
\begin{align}
(G_1,\ldots,G_{13})={}&(H_A,T_A,\mathrm{CNOT}_{A,J},\nonumber\\
&\mathrm{SWAP}_{A,O_1},\mathrm{SWAP}_{A,D_{1A}},\nonumber\\
&\mathrm{SWAP}_{J,D_{1J}},T_A,H_A,\mathrm{CNOT}_{A,J},\nonumber\\
&\mathrm{SWAP}_{A,O_2},\mathrm{SWAP}_{A,D_{2A}},\nonumber\\
&\mathrm{SWAP}_{J,D_{2J}},X_E).
\end{align}
Here $T=\operatorname{diag}(1,e^{i\pi/4})$. The output captures exchange the computational qubit with its output slot; full work-module exchange exports internal correlations to the outgoing donor. The first twelve primitives preserve $E=0$; the thirteenth flips it. The final flag marks schedule completion, not independent verification of a logical answer or irreversible fuel depletion. The parent package retains the full-body constructor replay \cite{episode}.

\subsection{Static history generator and comparison}
For $D$ addresses $j=0,\ldots,D-1$, define $P_0=I$, $P_j=G_j\cdots G_1$ for $j\le m=13$, and $P_j=P_m$ afterwards. A real clock with zero diagonal and positive edges is
\begin{equation}\label{eq:clock}
K=\sum_{j=0}^{D-2}e_j(\ket{j+1}\bra j+\ket j\bra{j+1}).
\end{equation}
With $V=\sum_j\ket j\bra j\otimes P_j$, the full static generator is
\begin{equation}
H_{\rm hist}=V(K\otimes I)V^\dagger.
\end{equation}
The clock starts at address 0. All compiled interactions are constant after that prepared launch. Body-gate and donor-selection pulses are absent during this ideal episode.

Let $c(t)=e^{-iKt}\ket0$. On a purified input the history state is $\sum_j c_j(t)\ket jP_j\ket\psi$. The complete target is $c(t)\otimes P_m\ket\psi$, retaining the clock, all body registers, outputs, donors, records and spectator. Each design is compared with its own freely evolving clock, as in the preceding fixed contract; no design receives a rescaled observation interval or postselected target.

\begin{proposition}[Exact complete error]\label{prop:channel}
With the fixed pure bank and fresh final-step flag, put $p(t)=\sum_{j<m}|c_j(t)|^2$. Every admitted input, including mixed states and spectators, has complete trace distance and normalized diamond distance
\begin{equation}\label{eq:error}
\delta(t)=\sqrt{2p(t)-p(t)^2}.
\end{equation}
Tracing out the clock gives distance $p(t)$.
\end{proposition}
\begin{proof}
The actual and target isometries $A_t,B_t$ have $A_t^\dagger B_t=(1-p)I$, because all incomplete prefixes are in the opposite flag sector. Set $c=1-p$, $s=\sqrt{1-c^2}$ and $C=(A_t-cB_t)/s$ when $s>0$. Then $B_t^\dagger C=0$ and $C^\dagger C=I$. On an arbitrary density operator the difference, under the orthogonal identification by $B_t,C$, is
\begin{equation}
\begin{pmatrix}c^2-1&cs\\cs&s^2\end{pmatrix}\otimes\rho.
\end{equation}
The two-by-two factor has eigenvalues $\pm s$, so half the trace norm is $s$. The zero case and spectator extension follow directly. After clock reduction the two flag blocks each have trace norm $p$.
\end{proof}

\subsection{Common resources}
Use $\hbar=1$ and model units. The frozen task requires complete error at most $\epsilon=1/1024$ over
\begin{equation}\label{eq:window}
I=[a,b]=[63\pi/4,189\pi/4].
\end{equation}
Its duration is $63\pi/2$ and center is $63\pi/2$. Every candidate starts at address 0 with the same supplied bank and word. On the legal clock sector the resource ceilings are
\begin{equation}\label{eq:resources}
\norm K\le1,\qquad e_j\le32/63,\qquad \sigma_0^2\le1/63.
\end{equation}
For \eqref{eq:clock}, launch mean energy is zero and variance is $e_0^2$. These ceilings do not bound the whole many-excitation physical Hilbert space, geometric synthesis, or coupling-description cost.

The 64-address reference has $e_j=\sqrt{(j+1)(63-j)}/63$. Its worst interval tail is the exact rational
\begin{equation}
p_{\rm ref}=2^{-63}\sum_{j=0}^{12}\binom{63}{j}
=\frac{3440189695001}{9223372036854775808}.
\end{equation}
This reference satisfies the common contract and has ideal joint error approximately $0.000863697$. Its 64 addresses are minimal within that spin-padding family, not across all clocks \cite{cross}.

\section{A Stronger Finite Lower Bound}
\begin{theorem}[Completed-subspace time packing]\label{thm:packing}
Let a static finite Hermitian clock start at an incomplete address, and let its completed projector have rank $k$. Suppose \eqref{eq:error} is at most $\epsilon$ on $[a,b]$, $a>0$. Set
\begin{equation}
q=\sqrt{1-\sqrt{1-\epsilon^2}},\quad n=\lfloor b/a\rfloor.
\end{equation}
If $n\ge2$ and $q<1/n$, then $k\ge n$. For an explicit $m$-step path this implies $D\ge m+n$.
\end{theorem}
\begin{proof}
The return amplitude $f(t)=\bra0e^{-iKt}\ket0$ obeys $|f(t)|\le\sqrt{p(t)}\le q$ on the interval. Consider $n$ clock states $c(ia)$, $1\le i\le n$. Every nonzero time difference between them is in $[a,b]$, so their Gram matrix $G$ has diagonal one and off-diagonal magnitude at most $q$. Gershgorin gives
\begin{equation}
\lambda_{\min}(G)\ge1-(n-1)q.
\end{equation}
Write $G=G_{\rm comp}+G_{\rm inc}$ by projecting these columns. The incomplete Gram matrix is positive with trace at most $nq^2$. If $k<n$, $G_{\rm comp}$ has a unit null vector $z$, yielding
\begin{equation}
1-(n-1)q\le z^\dagger Gz\le\operatorname{tr}G_{\rm inc}\le nq^2.
\end{equation}
This contradicts $1-(n-1)q-nq^2=(1+q)(1-nq)>0$. In the history path $k=D-m$.
\end{proof}
For \eqref{eq:window}, $n=3$. The condition $q<1/3$ is equivalent to $\epsilon^2<17/81$, which is exactly true at $\epsilon=1/1024$. Therefore $D\ge16$, excluding 14 and 15 even with arbitrary path weights and diagonal potentials. This is an elementary Gram-dimension obstruction using the stated completion contract, not a universal computing speed limit. It does not establish the optimal dimension.

\section{Discovery and Exact Candidate}
A local SLSQP search perturbed positive nearest-neighbor couplings while constraining the maximum edge, launch variance, and clock norm. It scored 49 times on the fixed interval, with a dense 4097-time diagnostic afterwards. Warm starts descended from 63 to 52 addresses. The recorded optimizer runs hit their iteration limit. No convergence, global search, or infeasibility claim is inferred from that status.

We selected the 53-address candidate, rounded its couplings to dyadic denominator $2^{30}$, and evaluated the rounded object independently. The certificate depends only on the declared rounded candidate, not on an optimizer success flag or reproducing discovery. Table~\ref{tab:couplings} gives the complete clock: $e_j=n_j/2^{30}$, with every diagonal entry zero. The 52 edges carry the thirteen primitives followed by identity edges; addresses are 0 through 52.

\begin{table}[t]
\caption{Exact candidate edge numerators; $e_j=n_j/2^{30}$.}
\label{tab:couplings}\centering\scriptsize
\begin{tabular}{rrrrrrrr}\toprule
$j$ & $n_j$ & $j$ & $n_j$ & $j$ & $n_j$ & $j$ & $n_j$\\\midrule
__COUPLINGS__
\bottomrule\end{tabular}
\end{table}

\subsection{Rational resource admission}
Every coupling is exactly representable in binary64. Positivity, $e_j\le32/63$, and $e_0^2\le1/63$ are tested using rational arithmetic. To certify the norm, let $d_0=d_1=1$ and form the leading determinants of $I-K$:
\begin{equation}
d_{r+1}=d_r-e_{r-1}^2d_{r-1}.
\end{equation}
All are strictly positive as exact rationals. The same recurrence gives the minors of $I+K$, so Sylvester's criterion proves both matrices positive definite and $\norm K<1$. No floating eigenvalue threshold is used for admission. The diagnostic norm is about $0.823391632$, compared with the ceiling one.

\begin{figure}[t]\centering
\includegraphics[width=\columnwidth]{../figures/CLOCK_COUPLINGS.pdf}
\caption{Clock couplings for the reference, unshaped smaller spin clock, and certified dyadic candidate. The dotted line separates primitive-gate edges from the identity suffix. This is a supplied static generator, not a measured coupling profile.}
\label{fig:couplings}\end{figure}

\section{Continuous-Window Certificate}
\subsection{Real generator and time mesh}
Because \eqref{eq:clock} is bipartite with zero diagonal, write $c_j(t)=(-i)^jv_j(t)$. The real vector satisfies
\begin{equation}
v'_j=e_{j-1}v_{j-1}-e_jv_{j+1},\qquad v(0)=(1,0,\ldots,0).
\end{equation}
Its generator $A$ is skew-symmetric, $\norm A=\norm K<1$, and its entrywise absolute matrix is $K$, also of norm below one. This last fact permits a vector-norm rounding estimate for each two-product, one-subtraction matrix-vector component.

The replay uses $h=1/128$ and the degree-12 Taylor polynomial for $e^{hA}$. Machin's identity
\begin{equation}
\pi=16\arctan(1/5)-4\arctan(1/239)
\end{equation}
and 80-term alternating-series bounds yield rational $\pi_-$ and $\pi_+$. The mesh starts at $\lfloor(63\pi_-/4)/h\rfloor h$ and ends at $\lceil(189\pi_+/4)/h\rceil h$, outwardly enclosing the true window. Propagation starts at time zero. It takes 19001 steps and evaluates 12669 window samples.

\subsection{Roundoff and truncation bounds}
Assume elementary binary64 operations round to nearest with unit roundoff $u=2^{-53}$. The replay checks rounding mode and binary64 parameters. Following standard deterministic rounding analysis \cite{higham}, set $\gamma_r=ru/(1-ru)$. In the Taylor recurrence each term incurs at most five elementary-rounding factors per order: three for the matrix-vector component, one division for $h/k$, and one multiplication. Each term's error is dominated in norm by $\gamma_{5k}h^k\norm v/k!$.

Summing twelve nonconstant terms adds at most $\gamma_{12}$. Combining this with $\gamma_{60}$ bounds local rounding by $\gamma_{72}e^h\norm v$, hence by
\begin{equation}
\rho_{\rm rnd}=\frac{\gamma_{72}}{1-h}<128u.
\end{equation}
An absolute $2^{-1000}$ allowance covers underflow in the stated small vector kernel. No overflow occurs. The Taylor remainder obeys the rational bound
\begin{equation}
\tau=\frac{h^{13}}{13!(1-h)}.
\end{equation}
Put $r_0=\rho_{\rm rnd}+\tau+2^{-1000}$. Unitarity of the exact evolution gives $E_{s+1}\le(1+r_0)E_s+r_0$ for total state-vector error. For $M=19001$ and $Mr_0<1$,
\begin{equation}\label{eq:global}
E_M\le(1+r_0)^M-1\le\frac{Mr_0}{1-Mr_0}
<1.531\times10^{-10}.
\end{equation}
The final inequality uses $\binom Mk\le M^k$ to bound the finite binomial sum by a geometric series. This assurance is conditional on the stated arithmetic model; it is not an interval enclosure of an eigensystem or an external validation.

\subsection{From mesh samples to the whole interval}
The computed peak incomplete population is about $3.79259\times10^{-7}$ on the outward mesh. To enclose its squared norm, the replay divides the exact rational representation of that float, with an underflow allowance, by $1-\gamma_{32}$. The factor safely covers the products and sum over thirteen components. Its square root is rounded upward to a dyadic rational using integer arithmetic.

For $F(t)=P_{\rm inc}e^{-iKt}\ket0$, $\norm{F''(t)}\le1$. Linear interpolation between neighboring samples therefore gives
\begin{equation}\label{eq:interp}
\norm{F(t)}\le\max\{\norm{F(t_s)},\norm{F(t_{s+1})}\}+h^2/8.
\end{equation}
Indeed, the integral remainder has norm at most $(t-t_s)(t_{s+1}-t)/2$. Let $S_+$ be the upward sample-norm bound. Equations~\eqref{eq:global}--\eqref{eq:interp} imply
\begin{equation}
p(t)\le\left(S_++E_M+h^2/8\right)^2=:p_+.
\end{equation}
The complete-channel bound is $\sqrt{2p_+-p_+^2}$, rounded upward by exact integer square-root arithmetic. Every final threshold decision is rational. The recorded uniform ideal bound is below $0.0008817190$.

\subsection{Retaining the existing imperfection budget}
For complete initial supply discrepancy $\epsilon_B$ and a static full-generator perturbation of norm at most $d$ on the same legal domain, unitary contractivity, Duhamel and the triangle inequality give
\begin{equation}\label{eq:total}
\Dcal(\rho_t^{\rm act},\rho_t^{\rm target})
\le\min\{1,\epsilon_B+td+\delta(t)\}.
\end{equation}
Retain the parent's allowances $\epsilon_B=2^{-16}$ and $d=2^{-21}$. Substituting $b\le189\pi_+/4$ and the certified ideal bound gives
\begin{equation}
\epsilon_{\rm total}<0.0009677596<1/1024.
\end{equation}
The replay stores the exact fractions and verifies this strict comparison, without relying on displayed decimals. These are supplied mathematical allowances, not empirically measured errors. A preparation term in a diamond-distance bound requires a uniform completely bounded preparation guarantee; a single supplied-state discrepancy alone does not furnish it. Unadmitted leakage or additional noise is outside \eqref{eq:total}.

\section{Comparison and Reproduction}
\begin{table}[t]\centering
\caption{Same frozen time window and target; model resources.}\label{tab:comparison}
\begin{tabular}{lrr}\toprule
Quantity & Spin reference & Dyadic candidate\\\midrule
Clock addresses & 64 & 53\\
Adjacent edges & 63 & 52\\
Binary clock qubits & 6 & 6\\
Diagnostic clock norm & 1 & 0.823392\\
Largest edge & 0.507937 & 0.420658\\
Launch variance & 0.0158730 & 0.0138799\\
Uniform ideal bound & 0.000863697 & 0.000881719\\
With supplied allowances & 0.000949738 & 0.000967760\\\bottomrule
\end{tabular}\end{table}

The address saving is $11/64=17.1875\%$, while the edge-count saving is $11/63$. Six binary clock qubits are still required; the nine-qubit body remains the same, with spectators separate. A unary implementation uses 53 clock sites instead of 64. Neither encoding's coupling-synthesis or geometric implementation cost is equated to address dimension.

An unshaped 53-address spin clock with rate $1/63$ satisfies the resource ceilings but fails the same window target. Its endpoint tail is $2^{-52}\sum_{j<13}\binom{52}{j}$, and the failure follows by an exact rational squared-error comparison. Fig.~\ref{fig:error} shows that fewer addresses alone are insufficient; the supplied coupling shape matters.

\begin{figure}[t]\centering
\includegraphics[width=\columnwidth]{../figures/CLOCK_ERROR_COMPARISON.pdf}
\caption{Analytic spin curves and numerical dyadic-clock diagnostics on the frozen interval. Values below $10^{-15}$ are drawn at that floor. The dyadic clock's continuous guarantee comes from the separate arithmetic certificate, not from this plot. No curve is experimental data.}
\label{fig:error}\end{figure}

The replay passes __CHECKS__ rational checks covering exact representability, edge and variance limits, norm minors, outward time mesh, roundoff bounds, interval accuracy, the original supply/mismatch budget, the unshaped control and the time-packing threshold. Three sparse-propagator comparisons at early, middle and late mesh times have residuals below $1.14\times10^{-13}$; they are numerical diagnostics, not independent theorem review. The certificate scores the thirteen-step word using Proposition~\ref{prop:channel}. It does not rerun every body register for the new clock; the parent full-body constructor and the general retained-domain proof supply that link.

The release includes the exact couplings, discovery record, certificate kernel, rational resource and error receipts, plotted traces, IEEEtran source and formatting policy. Run \texttt{certify\_clock.py} with Python, NumPy and SciPy. The optional search is version-sensitive and is not required for the certificate. Run \texttt{build\_ieee\_paper.py} with Matplotlib and pdfLaTeX to reproduce the IEEE journal-format A4 manuscript.

\section{Scope and Next Research Target}
Combining Theorem~\ref{thm:packing} and the explicit admitted construction gives the current ideal bracket
\begin{equation}
16\le D_\star\le53.
\end{equation}
The upper construction additionally meets the stated imperfection allowance. The lower bound ranges over ideal static clocks with the same prefix/flag task; it does not exclude arbitrary noisy devices that violate that structure. The local search's 52-address failure is not an infeasibility certificate. No global smallest clock is asserted.

The result is a finite reduction against our specified spin reference and a stronger finite obstruction. Underlying history propagation and idling are prior art \cite{caha,christandl}; deterministic rounding analysis is standard \cite{higham}. The exact candidate, completion-contract packing application and assurance combination remain subject to theorem-level priority comparison and independent mathematical audit. They do not establish a state-of-the-art advantage across different tasks or a physical quantum advantage.

The finite interval is approximate readout, not an absorbing halt. No exact completion time or exact projective period is certified for the shaped clock. The supervisor is not renewed and no replacement donors are created. Bare logical energy degeneracy, supplied preparation, coupling precision, geometric locality and physical calibration remain open implementation questions. Physical promotion remains zero.

The next computational target is an admitted design below 53 addresses with the same continuous certificate and noise ledger, or a stronger exclusion approaching that dimension. Independent review should first check the rounding-operation count, underflow allowance, norm-admission recurrence and three-time packing argument. A named IEEE venue will require its own final template and submission checks; this development paper already uses IEEEtran journal options with A4 paper and two columns.

\IEEEtriggeratref{3}
\begin{thebibliography}{5}
\bibitem{caha} L. Caha, Z. Landau, and D. Nagaj, ``Clocks in Feynman's computer and Kitaev's local Hamiltonian: Bias, gaps, idling, and pulse tuning,'' \emph{Phys. Rev. A}, vol. 97, p. 062306, 2018, doi: 10.1103/PhysRevA.97.062306.
\bibitem{christandl} M. Christandl, N. Datta, A. Ekert, and A. J. Landahl, ``Perfect state transfer in quantum spin networks,'' \emph{Phys. Rev. Lett.}, vol. 92, p. 187902, 2004, doi: 10.1103/PhysRevLett.92.187902.
\bibitem{episode} B. W. Mayes, ``Finite autonomous execution, capture and renewal: Exact joint error and a scoped resource law,'' MQM Paper A research addendum, development v0.1, Oct. 5, 2026, unpublished development record.
\bibitem{cross} B. W. Mayes, ``Cross-design clock-size bounds for finite autonomous quantum episodes,'' MQM Paper A research continuation, development v0.1, Oct. 5, 2026, unpublished development record.
\bibitem{higham} N. J. Higham, \emph{Accuracy and Stability of Numerical Algorithms}, 2nd ed. Philadelphia, PA, USA: SIAM, 2002, doi: 10.1137/1.9780898718027.
\end{thebibliography}
\end{document}
'''
tex=tex.replace('__COUPLINGS__','\n'.join(coupling_rows)).replace('__CHECKS__',str(receipt['exact_checks']))
path=M/'MQM_CERTIFIED_53_ADDRESS_CLOCK_IEEE_A4_v0.1.tex';path.write_text(tex)
for run in range(3):
    proc=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',path.name],cwd=M,capture_output=True,text=True)
    (OUT/f'PDF_BUILD_{run+1}.txt').write_text(proc.stdout+proc.stderr)
    if proc.returncode:raise RuntimeError(proc.stdout[-5000:]+proc.stderr)
import fitz
doc=fitz.open(path.with_suffix('.pdf'))
for page in doc:
    mm=[page.rect.width*25.4/72,page.rect.height*25.4/72]
    assert abs(mm[0]-210)<.1 and abs(mm[1]-297)<.1,'A4 format required'
    assert '??' not in page.get_text(),'Unresolved cross-reference'
assert 'Overfull' not in path.with_suffix('.log').read_text(),'Layout overflow requires review'
print('Built IEEEtran A4 paper; coupling table has',len(nums),'exact entries.')
