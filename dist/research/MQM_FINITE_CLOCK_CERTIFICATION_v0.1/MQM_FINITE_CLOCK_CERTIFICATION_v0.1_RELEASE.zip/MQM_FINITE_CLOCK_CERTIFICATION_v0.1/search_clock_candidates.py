"""Optional discovery replay. Certificates do not depend on convergence or rerunning search.
Requires NumPy/SciPy; finite-difference SLSQP can vary across versions.
Run OPENBLAS_NUM_THREADS=1 python3 search_clock_candidates.py.
"""
from pathlib import Path
import time,json
import numpy as np
from scipy.linalg import eigh_tridiagonal
from scipy.optimize import minimize

ROOT=Path(__file__).resolve().parent/'results';ROOT.mkdir(exist_ok=True)
m=13; firstcap=np.sqrt(1/63); J=32/63
ts=np.linspace(63*np.pi/4,189*np.pi/4,49)
q2=(1/1024)**2/(1+np.sqrt(1-(1/1024)**2))
events=[];started=time.perf_counter()
previous=None
for N in range(62,50,-1):
    initial=np.sqrt(np.arange(1,N+1)*np.arange(N,0,-1))/63
    if previous is not None:
        x=np.linspace(0,1,len(previous));xx=np.linspace(0,1,N)
        oldspin=np.sqrt(np.arange(1,len(previous)+1)*np.arange(len(previous),0,-1))/63
        initial*=np.interp(xx,x,previous/oldspin)
    initial=np.minimum(initial,J);initial[0]=min(initial[0],firstcap)
    last=[None,None]
    def calc(x):
        if last[0] is None or not np.array_equal(x,last[0]):
            e,V=eigh_tridiagonal(np.zeros(N+1),x[:N])
            a=V[:m]@(V[0,:,None]*np.exp(-1j*e[:,None]*ts))
            p=np.sum(abs(a)**2,axis=0)
            last[:]=[x.copy(),(p,e[-1])]
        return last[1]
    count=[0]
    def callback(x):
        count[0]+=1
        if count[0]%20==0:
            print('N',N,'iteration',count[0],'worst p/q2',max(calc(x)[0])/q2,flush=True)
    pp=calc(np.r_[initial,1.])[0]
    x0=np.r_[initial,max(pp)/q2]
    cons=[{'type':'ineq','fun':lambda x:x[-1]-calc(x)[0]/q2},
          {'type':'ineq','fun':lambda x:1-calc(x)[1]}]
    bounds=[(.001,firstcap)]+[(.001,J)]*(N-1)+[(0,100)]
    opt=minimize(lambda x:x[-1],x0,method='SLSQP',bounds=bounds,constraints=cons,
                 callback=callback,options={'ftol':1e-8,'maxiter':100 if N>=60 else 60,'eps':1e-6})
    edge=opt.x[:N]
    e,V=eigh_tridiagonal(np.zeros(N+1),edge)
    dense=np.linspace(ts[0],ts[-1],4097)
    a=V[:m]@(V[0,:,None]*np.exp(-1j*e[:,None]*dense))
    p=np.sum(abs(a)**2,axis=0)
    rec={'N':N,'D':N+1,'success':bool(opt.success),'message':opt.message,
         'iterations':opt.nit,'norm':float(e[-1]),'max_p':float(max(p)),
         'p_ratio':float(max(p)/q2),'edges':edge.tolist(),'elapsed':time.perf_counter()-started}
    events.append(rec);(ROOT/'SEARCH_RESULTS.json').write_text(json.dumps(events,indent=2)+'\n')
    print(json.dumps({k:v for k,v in rec.items() if k!='edges'}),flush=True)
    previous=edge
    if max(p)>q2*.95:break
