import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as F
import json,math
import numpy as np
from numpy.polynomial.legendre import leggauss
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text());B=16;k=8;T=16;lam=math.sqrt(4*math.sqrt(2));A=np.diag([-1.,-1.,-lam],1)+np.diag([1.,1.,lam],-1);proj=np.diag([0.,0.,0.,1.]);C0=k*B/math.pi
ref=json.loads((R/'PARENT_CONTINUUM_CERTIFICATE.json').read_text());center=float(ref['q_chain_interval'].split(',')[0].strip('['))
rows=[]
for st in P['kernel']['step_sizes']:
 h=float(F(st));N=int(T/h);times=np.arange(N+1)*h;C=np.empty(N+1);C[0]=C0;C[1:]=k*np.sin(B*times[1:])/(math.pi*times[1:]);v=np.zeros((N+1,4));v[0,0]=1
 inv=np.linalg.inv(np.eye(4)-h*A/2+h*h*C0*proj/4);right=np.eye(4)+h*A/2;memory_previous=0.
 for n in range(1,N+1):
  past=h*np.dot(C[1:n][::-1],v[1:n,3]) # initial aux amplitude zero, hence no initial endpoint term
  rhs=right@v[n-1];rhs[3]-=h*(memory_previous+past)/2;v[n]=inv@rhs;memory_previous=past+h*C0*v[n,3]/2
 q=float(v[-1]@v[-1]);rows.append({'h_exact':st,'steps':N,'q':q,'difference_from_parent_interval_center':abs(q-center),'live_amplitudes':v[-1].tolist()})
assert abs(rows[-1]['q']-center)<1e-8 and abs(rows[-1]['q']-rows[-2]['q'])<1e-8
# Thermal kernel via explicit Bose geometric series, independently compare frequency quadrature.
beta=float(F('5/16'));kr=[]
for st in ['0','1/16','1','16']:
 s=float(F(st));series=sum((math.exp(-ell*beta*(64-B))*np.exp(1j*B*s)-math.exp(-ell*beta*(64+B))*np.exp(-1j*B*s))/(ell*beta+1j*s) for ell in range(1,5))*k/(2*math.pi)
 qs=[]
 for order in [256,512]:
  x,w=leggauss(order);d=B*x;nbar=1/np.expm1(beta*(64+d));qs.append(np.dot(B*w*k/(2*math.pi)*nbar,np.exp(-1j*d*s)))
 assert abs(qs[0]-qs[1])<1e-12 and abs(series-qs[1])<1e-12
 tail=k*B/math.pi*math.exp(-5*beta*(64-B))/(1-math.exp(-beta*(64-B)))
 kr.append({'time_exact':st,'series_real':float(series.real),'series_imag':float(series.imag),'series_quadrature_difference':float(abs(series-qs[1])),'quadrature_difference':float(abs(qs[0]-qs[1])),'analytic_series_tail_bound_float':tail})
res={'status':'SIMULATED independent vacuum Volterra cross-check; DERIVED thermal geometric-series kernels','vacuum_rows':rows,'vacuum_equation':'vprime=A0 v - e3 integral_0^t C0(t-s)v3(s)ds, C0(s)=8sin(16s)/(pi s)','solver':'Implicit trapezoid ODE plus trapezoid memory integral; no reservoir chain or exponential in this solver','acceptance':P['kernel']['target'],'thermal_kernel_rows':kr,'thermal_kernel_series':'Cn(s)=kappa/(2pi) sum_l>=1 [exp(-l beta(Omega-B)) exp(iBs)-exp(-l beta(Omega+B)) exp(-iBs)]/(l beta+i s); Cdown=C0+Cn; physical upward correlation uses conjugate and opposite carrier phase','scope':'Vacuum cross-check numerical only. Thermal kernels and covariance do not constitute simulated thermal channel.','thermal_quadrature_orders_used':[256,512],'numerical_amendment':'NUMERICAL_AMENDMENT.json','physical_promotion':0}
(R/'results/KERNEL_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
