MQM THERMAL KERNEL v0.1

Replay from this directory:
python freeze.py
python audit_thermal.py
python kernel_initial_diagnostic.py
python audit_kernel.py

Original audit_kernel_initial_recipe.py intentionally fails its original quadrature acceptance at s16. It is preserved as a failure receipt, not a passing replay command. NUMERICAL_AMENDMENT.json changes quadrature resolution only. The original PROTOCOL.json remains frozen.

DERIVED thermal comparison is conditional on the declared Gaussian continuum reference. No finite-temperature channel trajectory was simulated. beta5/16 remains OPEN; beta7/16 is a separately frozen sufficient cooling design. Vacuum kernel audit is numerical, not a second interval theorem. Physical promotion0.

PDF: IEEEtran journal,a4paper,10pt two-column. Compile with pdflatex twice from manuscript directory. IEEEtran class and LPPL license included.
