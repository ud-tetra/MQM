import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as F
import json,math
import numpy as np
from numpy.polynomial.legendre import leggauss,legval
from mpmath import iv
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text());iv.dps=80
B=16;Om=64;k=8;t=16;vac=F(json.loads((R/'PARENT_CONTINUUM_CERTIFICATE.json').read_text())['continuum_ceiling_exact']);assert vac==F(3,2**18)+F(1,2**128)
def rat(v):v=F(v);return iv.mpf(v.numerator)/v.denominator
rows=[]
for st,emin,power in [('5/16',15,21),('3/8',18,25),('7/16',21,30),('1/2',24,34)]:
 beta=F(st);s=sum((F(emin)**j/F(math.factorial(j)) for j in range(81)),F(0));assert s>2**power
 variance=rat(k)/(2*iv.pi*rat(beta))*(iv.ln(1-iv.exp(-rat(beta*(Om+B))))-iv.ln(1-iv.exp(-rat(beta*(Om-B)))))
 debit=t*t*variance
 bound=F(k*t*t,1)/(6*beta*(2**power-1));total=vac+bound
 assert debit.b<rat(bound).a
 rows.append({'beta_exact':st,'beta_min_frequency_exact':str(beta*(Om-B)),'noise_variance_interval':str(variance),'t_squared_variance_interval':str(debit),'exact_conservative_thermal_debit':str(bound),'exact_total_ceiling':str(total),'sufficient_target_pass':total<F(1,65536),'exp_lower_proof_power':power})
beta=float(F('5/16'));covs=[]
for order in [128,256]:
 x,w=leggauss(order);delta=B*x;occ=1/np.expm1(beta*(Om+delta));phi=np.array([math.sqrt((2*n+1)/(2*B))*legval(x,[0]*n+[1]) for n in range(8)])
 cov=(phi*(B*w*occ))@phi.T;covs.append(cov)
assert max(abs(covs[0]-covs[1]).ravel())<1e-12
cov=covs[1];e=np.linalg.eigvalsh(cov);off=cov-np.diag(np.diag(cov));assert min(e)>-1e-14 and max(abs(off).ravel())>1e-10
# Exact integer matrix direction: thermofield up term is system raising AND aux creation.
sm=np.array([[0,1],[0,0]],dtype=int);N=np.diag([0,1]);I=np.eye(2,dtype=int);J=np.kron(sm.T,sm.T)+np.kron(sm,sm)
Q=np.kron(N,I)-np.kron(I,N);assert np.array_equal(Q@J,J@Q)
# A coherent thermal mixture diagonal coefficient integral gives nbar^j/(1+nbar)^(j+1).
# Rational checks at nbar=1/3 support finite-mode Gaussian-mixture implementation.
nbar=F(1,3)
mixture_checks=[]
for j in range(10):
 integral=nbar**j/(1+nbar)**(j+1);thermal=(1/(1+nbar))*(nbar/(1+nbar))**j;assert integral==thermal;mixture_checks.append(j)
res={'status':'DERIVED Gaussian thermal reference and full-channel debit; SIMULATED projected covariance','rows':rows,'primary_beta':'5/16','primary_bound_status':'INCONCLUSIVE for target; not a thermal channel failure','cooling_design':'beta7/16 sufficient; temperature ratio5/7 relative to beta5/16 at fixed energy unit; no kelvin or device assignment','covariance_primary_order256':cov.tolist(),'covariance_eigenvalues':e.tolist(),'largest_offdiagonal':float(max(abs(off).ravel())),'quadrature_max_difference':float(max(abs(covs[0]-covs[1]).ravel())),'coherent_mixture_rational_checks':mixture_checks,'signed_charge_check':'system raising plus thermofield aux creation preserves N_system-N_aux, not total positive excitation','proof':'Finite thermal modes equal circular-Gaussian coherent-state mixtures. After time-dependent displacement, final bath displacement disappears under trace and dynamics is vacuum reference plus D(t)=zeta(t)Sdag+zeta*(t)S. Since S=I_C tensor sigma_R^- exactly, ||D||=|zeta|. In vacuum interaction picture, Liouvillian norm<=2|zeta|, mean first-order term0. Second Duhamel remainder and unitary channel norm1 give half-diamond<=2 integral_(s>u) E|zeta(s)zeta(u)| dsdu <= t^2 V_beta. Apply finite-mode bound to declared Gaussian continuum regularization. No thermal one-excitation approximation used.','thermal_covariance':'N_nm=integral phi_n phi_m n_beta(Omega+delta)d delta; not independent chain-site reset','reference_assumption':P['thermal']['Gaussian_continuum_assumption'],'physical_promotion':0}
(R/'results/THERMAL_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k not in ['covariance_primary_order256']},indent=2))
