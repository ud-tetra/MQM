from pathlib import Path
from fractions import Fraction
import json,math
from mpmath import iv
R=Path(__file__).resolve().parent
P={'status':'FROZEN before interval evaluation; parameters selected after exploratory target exposure','selection':'smallest frozen band and smallest frozen mode count, without changing physical coefficients or deadline','B':16,'M':256,'time':16,'digits':240,'Taylor_degree':1280,'Hermitian_norm_ceiling':24,'target':'1/65536','cold_error_ceiling':'3/262144','scope':'Finite256-mode vacuum bath, point deadline only; not continuum, thermal bath, or complete word'}
p=R/'CERTIFICATE_PROTOCOL.json'
if p.exists():assert json.loads(p.read_text())==P
else:p.write_text(json.dumps(P,indent=2)+'\n')
iv.dps=240

def rat(v):f=Fraction(v);return iv.mpf(f.numerator)/f.denominator
M=P['M'];B=P['B'];t=P['time'];lam=iv.sqrt(4*iv.sqrt(2));c=iv.sqrt(1/(2*iv.pi));delta=[rat(Fraction(2*n+1-M,16)) for n in range(M)]
zero=iv.mpc(0,0);term=[zero for _ in range(4+M)];term[0]=iv.mpc(1,0);v=term.copy()
# Static full H in the one-excitation rotating frame. ||H||<=16+G<23<24,
# since ||H4||<4, G^2=128/pi<128/3<49.
assert Fraction(128,3)<49
for n in range(1,P['Taylor_degree']+1):
 old=term;zsum=sum(old[4:],zero)
 term=[-1j*t*old[1]/n,-1j*t*(old[0]+old[2])/n,-1j*t*(old[1]+lam*old[3])/n,-1j*t*(lam*old[2]+c*zsum)/n]
 term.extend(-1j*t*(c*old[3]+delta[j]*old[4+j])/n for j in range(M))
 v=[a+b for a,b in zip(v,term)]
# Integral Taylor remainder for skew-Hermitian generator uses unitary norm1,
# so R<=||Ht||^(degree+1)/(degree+1)! (no exponential factor).
n=P['Taylor_degree']+1;remainder=rat(24*t)**n/math.factorial(n);rad=iv.mpf([-remainder.b,remainder.b])
q=rat(0)
for z in v[:4]:
 re=z.real+rad;im=z.imag+rad;q+=re*re+im*im
ceil=Fraction(3,2**18);assert q.b<rat(ceil).a and ceil<Fraction(1,2**16)
res={'status':'DIRECTED INTERVAL finite microscopic reference target pass','q_interval':str(q),'exact_error_ceiling':str(ceil),'time':16,'B':16,'M':256,'Taylor_remainder_norm_bound_interval':str(remainder),'method':P,'proof':'Exact one-excitation Hermitian finite reference, norm<24; directed240-digit Taylor1280, unitary integral remainder. Captured photon branches are orthogonal to bath vacuum, so retained half-diamond=q for fixed launch and arbitrary identity spectator.','continuum_promotion':False,'physical_promotion':0}
(R/'results/REFERENCE_INTERVAL.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
