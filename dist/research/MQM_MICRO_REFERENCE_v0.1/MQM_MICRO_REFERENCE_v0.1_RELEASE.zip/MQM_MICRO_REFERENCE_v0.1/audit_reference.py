import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction
import json,math
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import expm_multiply
from scipy.linalg import expm,eigh
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text())['reference'];lam=math.sqrt(4*math.sqrt(2));k=8
H4=np.diag([1.,1.,lam],1)+np.diag([1.,1.,lam],-1);localK=H4.astype(complex);localK[3,3]-=4j
v0=np.zeros(4);v0[0]=1

def reduced(v):
 s=v[:4];q=float(np.vdot(s,s).real);rho=np.zeros((5,5),complex);rho[:4,:4]=np.outer(s,s.conj());rho[4,4]=1-q;return rho,q

def td(a,b):return float(np.sum(abs(np.linalg.eigvalsh(a-b)))/2)
rows=[];checks=[]
for B in P['band_half_widths']:
 for M in P['midpoint_mode_counts']:
  det=B*(2*np.arange(M)+1-M)/M;c=math.sqrt(k*(2*B/M)/(2*math.pi));dim=4+M
  ii=[];jj=[];vv=[]
  for j,w in enumerate([1.,1.,lam]):ii.extend([j,j+1]);jj.extend([j+1,j]);vv.extend([w,w])
  for n,d in enumerate(det):
   a=4+n;ii.extend([a,3,a]);jj.extend([a,a,3]);vv.extend([d,c,c])
  H=coo_matrix((vv,(ii,jj)),shape=(dim,dim)).tocsr();launch=np.zeros(dim,complex);launch[0]=1
  assert (H-H.T).nnz==0
  dense=None
  if M==256:dense=eigh(H.toarray())
  samples=[]
  for t in P['time_samples']:
   v=expm_multiply(-1j*t*H,launch,traceA=0);assert abs(np.vdot(v,v)-1)<1e-9
   rho,q=reduced(v);loc,_=reduced(expm(-1j*t*localK)@v0)
   cross=None
   if dense is not None:
    ee,ev=dense;vd=ev@(np.exp(-1j*t*ee)*ev[0,:]);cross=float(np.linalg.norm(v-vd));assert cross<1e-9
   raw=Fraction(t*B,M);samples.append({'time':t,'retained_error':q,'distance_from_local':td(rho,loc),'target_pass_numerical':q<1/65536,'norm_error':float(abs(np.vdot(v,v)-1)),'dense_independent_vector_difference':cross,'continuum_comparison_bound_exact':str(min(Fraction(1),raw))})
  rows.append({'B':B,'M':M,'one_excitation_dimension':dim,'spacing_exact':str(Fraction(2*B,M)),'recurrence_spacing_time':'pi*M/B (bath-frequency phase alignment, not necessarily full-system recurrence)','samples':samples})
  checks.append('hermitian/norm/cross-solver B'+str(B)+' M'+str(M))
# Exact all-time floor in the strict-resonance bright-mode control family.
resonant=[]
for B,rbound in [(16,Fraction(3,8)),(32,Fraction(17,64)),(48,Fraction(7,32))]:
 G=math.sqrt(k*B/math.pi);h=np.diag([1.,1.,lam,G],1)+np.diag([1.,1.,lam,G],-1)
 # a=lambda^2/G^2=pi*sqrt2/(2B), bounded with pi<22/7,sqrt2<99/70.
 a_upper=Fraction(1089,490*B);assert rbound*rbound>a_upper
 floor=(1-rbound)**2/2;assert floor>Fraction(1,65536)
 ss=[]
 for t in P['time_samples']:
  v=expm(-1j*t*h)[:,0];q=float(sum(abs(v[:4])**2));assert q+1e-12>float(floor);ss.append({'time':t,'q':q})
 resonant.append({'B':B,'a_upper_exact':str(a_upper),'sqrt_a_upper_exact':str(rbound),'all_time_retained_error_floor_exact':str(floor),'samples':ss})
res={'status':'SIMULATED explicit finite vacuum bath; DERIVED continuum comparison and exact scoped resonance obstruction','rows':rows,'resonance_control':resonant,'checks':checks,'continuum_proof':'Embed M normalized constant-bin modes into L2[-B,B]. Flat spectral coupling lies exactly in bin span. Replace continuum multiplication delta by midpoint step multiplication; operator difference<=B/M. Full unitary Duhamel and partial trace give retained fixed-launch channel distance<=min(1,tB/M). Numerical finite evolution and that debit are separate.','resonance_floor_proof':'At delta=0 only one bath bright mode couples, giving a five-site path. Its normalized zero mode z=(1,0,-1,0,lambda/G)/sqrt(2+a), a=lambda^2/G^2. Conservation of <z|psi> and Cauchy imply 1<=sqrt(2q)+sqrt(a), hence q>=(1-sqrt(a))^2/2 for a<1. Rational pi/sqrt2 enclosures give printed all-time floors. Scope: this collapsed family only.','energy_scope':'Static finite full Hamiltonian conserves its total energy and exact excitation charge. Free system+bath energy does not commute with off-resonant exchange. No Born or Markov approximation within this defined finite model.','unclosed':['finite solver directed error enclosure','continuum target certificate','finite-temperature bath','earlier thermal Ohmic comparison','whole13-step microscopic bath','physical realization'],'physical_promotion':0}
(R/'results/REFERENCE_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({'largest_M_rows':[r for r in rows if r['M']==2048],'resonance_control':resonant},indent=2))
