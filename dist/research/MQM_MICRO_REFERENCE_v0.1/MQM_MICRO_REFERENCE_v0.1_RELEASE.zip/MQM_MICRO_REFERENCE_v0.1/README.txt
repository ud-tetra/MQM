MQM MICROSCOPIC REFERENCE v0.1
Replay from this directory:
python3 freeze.py
python3 audit_reference.py
python3 audit_modes.py
python3 certify_reference.py
python3 build_pdf.py
python3 prepare_release.py

Target: fixed cold vacuum port launch, full spectator retained. One finite256-mode B16 case is interval-certified at t16. Finite bath returns are possible; no invariant dark hold. Numerical grid convergence is not a continuum bound. This new flat spectrum does not replace prior thermal Ohmic failures or certify the full13-step word. Norm24 applies only to one-excitation sector, not full Fock space. Physical promotion0.
