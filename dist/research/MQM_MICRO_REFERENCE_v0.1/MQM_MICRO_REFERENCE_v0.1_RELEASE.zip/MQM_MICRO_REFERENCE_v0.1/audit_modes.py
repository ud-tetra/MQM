import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,math
import numpy as np
from scipy.linalg import eig,expm
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text())['modal'];rows=[]
for name in P['profiles']:
 w=np.ones(16);w[15]=math.sqrt(4*math.sqrt(2))
 if name=='PST16':w[:15]=[math.sqrt((j+1)*(15-j))/8 for j in range(15)]
 if name=='PST14':w[:13]=[math.sqrt((j+1)*(13-j))/7 for j in range(13)]
 A=np.diag(-w,1)+np.diag(w,-1);A[16,16]=-4
 assert np.array_equal(A+A.T,np.diag([0]*16+[-8]))
 z,V=eig(A);V=V/np.linalg.norm(V,axis=0);coef=np.linalg.solve(V,np.eye(17)[:,0]);gamma=-2*z.real;port=abs(V[16,:])**2
 identityerr=float(max(abs(gamma-8*port)));residual=float(np.linalg.norm(A@V-V*z));assert identityerr<1e-9 and residual<1e-9
 mode_rows=[]
 for j in np.argsort(gamma):
  mode_rows.append({'real_eigenvalue':float(z[j].real),'imag_eigenvalue':float(z[j].imag),'probability_decay_rate':float(gamma[j]),'terminal_weight':float(port[j]),'biorthogonal_launch_coefficient_abs_squared':float(abs(coef[j])**2),'note':'coefficient squared is not an orthogonal modal probability'})
 samples=[]
 for t in P['times']:
  a=coef*np.exp(z*t);v=V@a;vd=expm(A*t)[:,0];err=float(np.linalg.norm(v-vd));assert err<1e-9
  diagonal=float(np.sum(abs(a)**2));q=float(np.vdot(v,v).real)
  samples.append({'time':t,'q':q,'reconstruction_vector_error':err,'modal_diagonal_sum':diagonal,'cross_term_sum':q-diagonal,'slowest_pair_diagonal':float(sum(abs(a[j])**2 for j in np.argsort(gamma)[:2]))})
 rows.append({'profile':name,'eigen_residual':residual,'decay_identity_error':identityerr,'eigenvector_condition_number':float(np.linalg.cond(V)),'modes':mode_rows,'samples':samples})
res={'status':'DERIVED endpoint-decay identity; SIMULATED modal mechanism','rows':rows,'identity_proof':'For normalized Av=zv, vdag(A+Adag)v=2Re(z)=-8|v_last|^2. Thus small terminal support forces slow probability decay.','scope':'Frozen profiles, current absorber and launch. Biorthogonal coefficients are not probabilities; cross terms retained. No universal reflection/interference theorem; spectral quantities not interval certified.','eventual_capture_proof':'For any path with all positive weights, endpoint-decay identity makes Re(z)<=0. If Re(z)=0, terminal component vanishes; the endpoint eigen-equation and recurrence force every component to vanish, contradiction. All eigenvalues have strictly negative real part; q tends to0. Long-lived modes are not exact dark states.','physical_promotion':0}
(R/'results/MODE_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({'rows':[{'profile':r['profile'],'slow_modes':r['modes'][:2],'samples':r['samples']} for r in rows]},indent=2))
