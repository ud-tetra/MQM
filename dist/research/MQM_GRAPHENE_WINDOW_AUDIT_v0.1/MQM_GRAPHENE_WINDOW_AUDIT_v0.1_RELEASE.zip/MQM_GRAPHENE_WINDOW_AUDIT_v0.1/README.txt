MQM GRAPHENE WINDOW AUDIT v0.1
Fixed-width ideal transport-model successor. Physical promotion 0.

Replay: python3 audit_window.py; python3 certify_window.py
PDF: python3 build_pdf.py; inspect PAGE_*.png.
Requirements: numpy scipy sympy mpmath PyMuPDF; pdflatex and IEEEtran dependencies.
PARENT_TRANSPORT_AUDIT.json preserves the exact parent input and provenance hash.
5 exact symbolic checks; 3285 binary64 checks; 3600 directed interval boxes.
Operating band: relative lowest-mode probability <1/100, phase <1/100 rad.
Sufficient symmetric windows: E alone or U alone <=1/2000 eV; joint <=1/4000 eV each.
Numerical roots are not maximal interval-certified windows.
Thermal conductance average is not a coherent channel average.
No 2^-16 quantum-channel certificate, material capacity law, hardware validation or advantage.
Parent target fitting and successor window selection are disclosed engineering.
IEEEtran redistributed under LPPL; license retained.
