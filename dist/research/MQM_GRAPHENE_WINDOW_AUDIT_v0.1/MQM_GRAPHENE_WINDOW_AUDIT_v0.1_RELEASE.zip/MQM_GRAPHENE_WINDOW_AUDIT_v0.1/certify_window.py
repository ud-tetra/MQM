"""Directed interval sufficient-window certificate for fixed source coefficients."""
from pathlib import Path
from fractions import Fraction
import json
from mpmath import iv
iv.dps=50
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text())
def rat(v):
 f=Fraction(v);return iv.mpf(f.numerator)/f.denominator
def cell(a,b):return iv.mpf([rat(a).a,rat(b).b])
hv=rat('0.6582119');W=rat(float(P['width_nm_fixed']));mu=rat('0.2');L=rat(30);q=iv.pi/(2*W);target=rat(Fraction(7,768))
def D(E,U):
 f=(mu+E)/hv;p=(E-U)/hv
 la=iv.sqrt(q*q-p*p);kx=iv.sqrt(f*f-q*q)
 c=(iv.exp(la*L)+iv.exp(-la*L))/2
 s=(iv.exp(la*L)-iv.exp(-la*L))/(2*la)
 return c,(q*q-f*p)*s/kx
c0,b0=D(rat(0),rat(0));tan=iv.sin(rat('0.01'))/iv.cos(rat('0.01'))
rows=[]
# Sufficient symmetric windows chosen after numerical scan: disclosed engineering refinement.
for name,radius,N in [('energy',Fraction(1,2000),1000),('gate',Fraction(1,2000),1000),('joint',Fraction(1,4000),40)]:
 worst=0.;margin=1.;count=0
 bounds=[-radius+2*radius*k/N for k in range(N+1)]
 for a,b in zip(bounds,bounds[1:]):
  es=cell(a,b) if name!='gate' else rat(0)
  Us=[cell(a,b)] if name=='gate' else ([cell(x,y) for x,y in zip(bounds,bounds[1:])] if name=='joint' else [rat(0)])
  for us in Us:
   c,bb=D(es,us);prob=1/(c*c+bb*bb)
   # Strict comparisons establish each entire interval box passes, not merely its midpoint.
   assert prob.a>target.b*rat('.99').b and prob.b<target.a*rat('1.01').a
   real=c0*c+b0*bb;imag=b0*c-c0*bb
   assert real.a>0 and abs(imag).b<(tan*real).a
   rel=abs(prob/target-1);worst=max(worst,float(rel.b));margin=min(margin,float((tan*real-abs(imag)).a));count+=1
 rows.append({'window':name,'radius_eV_exact':str(radius),'interval_boxes':count,'probability_relative_error_upper_diagnostic_float':worst,'phase_witness_positive_margin_diagnostic_float':margin,'all_strict_interval_comparisons_pass':True})
res={'status':'INTERVAL VERIFIED sufficient ideal-model windows','arithmetic':'mpmath.iv 50 decimal digits, directed interval operations; exact rational source coefficients except pi enclosed by iv.pi','width_provenance':'exact binary64 fitted width treated as fixed coefficient, not fabrication confidence interval','target':'7/768','acceptance':'relative T0 <1/100 and relative phase <1/100 radians','certificate':rows,'tuning_disclosure':'sufficient windows selected after exploratory numerical roots, independently checked by directed interval boxes; no independent prediction','excluded':'No material errors, no channel-distance bound, no temperature channel certificate','physical_promotion':0}
(R/'results/INTERVAL_CERTIFICATE.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
