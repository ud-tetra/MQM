"""Successor transport audit: fixed-width exploratory robustness, no hardware claim."""
from pathlib import Path
import json, math, hashlib
import numpy as np
import sympy as sy
from scipy.linalg import expm
from scipy.integrate import quad
from scipy.optimize import brentq
from numpy.polynomial.legendre import leggauss
R=Path(__file__).resolve().parent
parent=R/'PARENT_TRANSPORT_AUDIT.json'
base=json.loads(parent.read_text()); W=base['W_recalibrated_for_200meV_nm']
P={'status':'FROZEN before evaluation; exploratory robustness','parent_result_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'width_nm_fixed':W,'length_nm':30,'hv_eV_nm':.6582119,'mu_lead_eV':.2,'boundary':'infinite mass, identical width, abrupt mode-preserving contacts','energy_definition':'E relative to global Fermi level; lead energy mu+E; strip energy E-U','U_definition':'uniform interior potential shift; contacts unchanged','scan_E_or_U_eV':[-.02,.02,401],'temperature_K':[.02,.1,1,4],'kB_eV_K':8.617333262145e-5,'thermal_cutoff_kBT':40,'acceptance_exploratory':{'relative_lowest_mode_probability':.01,'relative_lowest_mode_phase_rad':.01},'root_xtol_eV':1e-13,'matching_tolerance':1e-11,'quad_absolute_tolerance':1e-13,'quadrature_comparison_tolerance':1e-11,'readout_error_2^-16':'NOT identified with scalar transport tolerance','no_refit':True,'no_disorder_or_phonons':True,'physical_promotion':0}
(R/'PROTOCOL.json').write_text(json.dumps(P,indent=2))
# All protocol fields written before evaluating successor outcomes.
exact=[]; nums=[]
def ck(name,condition,ledger):
 assert bool(condition),name
 ledger.append(name)
z,p,k,c,s=sy.symbols('q p k c s',real=True);i=sy.I
A=sy.Matrix([[z,i*p],[i*p,-z]])
ck('generator square scalar',A*A==(z*z-p*p)*sy.eye(2),exact)
ck('current conservation generator',A.conjugate().T*sy.Matrix([[0,1],[1,0]])+sy.Matrix([[0,1],[1,0]])*A==sy.zeros(2),exact)
ck('transfer determinant',sy.simplify((c*sy.eye(2)+s*A).det()-c*c+(z*z-p*p)*s*s)==0,exact)
# Let lead longitudinal momentum kx, radial momentum f with f^2=kx^2+q^2.
f=sy.sqrt(k*k+z*z); B=sy.Matrix([[1,1],[(k+i*z)/f,(-k+i*z)/f]])
M=sy.simplify(B.inv()*(c*sy.eye(2)+s*A)*B)
ck('lead-basis denominator',sy.simplify(M[1,1]-c-i*(z*z-f*p)*s/k)==0,exact)
ck('neutrality reduction',sy.simplify(M[1,1].subs(p,0)-(c+i*z*z*s/k))==0,exact)
hv=P['hv_eV_nm']; L=P['length_nm']; mu=P['mu_lead_eV']; target=7/768
sx=np.array([[0,1],[1,0]],complex); sz=np.diag([1,-1])
def modes(E):
 return max(0,int(math.ceil((mu+E)*W/(hv*math.pi)-.5)))
def amp(E,U,n):
 q=(n+.5)*math.pi/W; f=(mu+E)/hv
 if f<=q:return 0j
 kx=math.sqrt(f*f-q*q); p=(E-U)/hv; lam=np.sqrt(complex(q*q-p*p))
 c=np.cosh(lam*L); s=L if abs(lam)<1e-12 else np.sinh(lam*L)/lam
 return 1/(c+1j*(q*q-f*p)*s/kx)
def vals(E,U=0):return [abs(amp(E,U,n))**2 for n in range(modes(E))]
t0=amp(0,0,0)
scan=[]
for kind in ['energy','gate']:
 for v in np.linspace(-.02,.02,401):
  E,U=(float(v),0.) if kind=='energy' else (0.,float(v))
  Ts=vals(E,U); a=amp(E,U,0)
  scan.append({'kind':kind,'offset_eV':float(v),'open_modes':modes(E),'T0':Ts[0],'sum_modes':sum(Ts),'phase_shift_rad':float(np.angle(a/t0)), 'mode_details':[{'mode':n,'T':tv,'phase_rad':float(np.angle(amp(E,U,n)))} for n,tv in enumerate(Ts)]})
  for n in range(modes(E)):
   q=(n+.5)*math.pi/W; f=(mu+E)/hv;kx=math.sqrt(f*f-q*q);p=(E-U)/hv
   u=np.array([1,(kx+1j*q)/f]);ur=np.array([1,(-kx+1j*q)/f]);Prop=expm(L*(q*sz+1j*p*sx))
   rr,tt=np.linalg.solve(np.column_stack([Prop@ur,-u]),-Prop@u)
   ck('amplitude '+str((kind,v,n)),abs(tt-amp(E,U,n))<1e-11,nums)
   ck('flux '+str((kind,v,n)),abs(abs(rr)**2+abs(tt)**2-1)<1e-11,nums)
ck('frozen nominal recovers previous T0',abs(abs(t0)**2-target)<1e-12,nums)
# Numerical nearest crossings; sampled interiors separately verified. Not interval enclosure.
roots={}
for kind in ['energy','gate']:
 def func(v):
  E,U=(v,0) if kind=='energy' else (0,v)
  return max(abs(abs(amp(E,U,0))**2/target-1)/.01,abs(np.angle(amp(E,U,0)/t0))/.01)-1
 out=[]
 for sign in [-1,1]:
  root=brentq(lambda a:func(sign*a),0,.02,xtol=1e-13)
  out.append(sign*root)
  for v in np.linspace(0,sign*root,101)[1:-1]:ck('window sampled '+str((kind,v)),func(v)<0,nums)
 roots[kind]={'lower_eV':out[0],'upper_eV':out[1],'scope':'nearest numerically located joint probability/phase crossings; sampled interior, no rigorous enclosure'}
# Thermal averages use conductance weighting, not coherent amplitude averaging.
therm=[]
for T in P['temperature_K']:
 theta=P['kB_eV_K']*T
 points=[-40.,40.]+[(hv*(n+.5)*math.pi/W-mu)/theta for n in range(20) if -40<(hv*(n+.5)*math.pi/W-mu)/theta<40]
 points=sorted(points)
 def integ(x,total):
  ts=vals(theta*x)
  val=sum(ts) if total else (ts[0] if ts else 0.)
  return val/(4*math.cosh(x/2)**2)
 def gauss(order,total):
  ns,ws=leggauss(order);ans=0
  for a,b in zip(points,points[1:]):ans+=(b-a)/2*sum(w*integ((a+b)/2+(b-a)/2*x,total) for x,w in zip(ns,ws))
  return ans
 row={'temperature_K':T,'threshold_breakpoints_x':points[1:-1]}
 for total in [False,True]:
  qv=qe=0
  for a,b in zip(points,points[1:]):
   val,err=quad(lambda x:integ(x,total),a,b,epsabs=1e-13,epsrel=1e-11,limit=200);qv+=val;qe+=err
  a256=gauss(256,total);a512=gauss(512,total)
  ck('thermal independent quadratures '+str((T,total)),max(abs(qv-a512),abs(a512-a256))<1e-11,nums)
  row['total' if total else 'lowest']={'average':qv,'relative_to_target':qv/target-1,'quad_reported_error':qe,'gauss256':a256,'gauss512':a512,'max_method_difference':max(abs(qv-a512),abs(a512-a256))}
 row['retained_window_max_modes']=modes(40*theta)
 # Tail bound: mode count <= (mu+E)W/(pi hv)+1 for positive energies, negative tail <= fixed ceil bound.
 # f' weight <= exp(-|x|); integrate (C + a theta |x|) at x>=40.
 a=W/(math.pi*hv);C=a*mu+1
 row['omitted_total_tail_bound']=2*math.exp(-40)*(C+a*theta*41)
 therm.append(row)
(R/'results/SCAN.json').write_text(json.dumps(scan,indent=2))
res={'status':'DERIVED transfer formula; NUMERICALLY VERIFIED robustness in frozen ideal model','exact_checks':exact,'exact_count':len(exact),'numerical_checks':nums,'numerical_count':len(nums),'window_roots':roots,'thermal':therm,'nominal_phase_rad':float(np.angle(t0)),'second_mode_threshold_E_eV':hv*1.5*math.pi/W-mu,'nominal_T0':abs(t0)**2,'scan_extrema':{kind:{'min_T0':min(r['T0'] for r in scan if r['kind']==kind),'max_T0':max(r['T0'] for r in scan if r['kind']==kind),'max_abs_phase_shift':max(abs(r['phase_shift_rad']) for r in scan if r['kind']==kind)} for kind in ['energy','gate']},'physical_promotion':0,'precision':'binary64; symbolic SymPy; no interval-certified operating window','amendments':[]}
(R/'results/WINDOW_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k not in ['numerical_checks','exact_checks']},indent=2))
