from pathlib import Path
import json,numpy as np
from scipy.sparse.linalg import expm_multiply
P=Path(__file__).resolve().parent;ns={'__file__':str(P/'response.py')};exec((P/'response.py').read_text().split('rows=[]')[0],ns)
p=P/'results/NUMERICAL_RESPONSE.json';a=json.loads(p.read_text())
for row in a['rows']:
 M=row['M'];_,H,n=ns['models'](M);psi=np.zeros(M+4,complex);psi[0]=1;u=expm_multiply(-16j*H,psi,traceA=-16j*np.trace(H));q=float(np.vdot(u[:4],u[:4]).real);row['cold_retained_error']=q
 row['diagnostic_amendment']='d0-only captured target; four live native amplitudes counted'
 print(M,q)
p.write_text(json.dumps(a,indent=2)+'\n')
