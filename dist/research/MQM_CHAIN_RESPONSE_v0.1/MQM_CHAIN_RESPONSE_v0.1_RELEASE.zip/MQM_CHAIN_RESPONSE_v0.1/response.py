import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json,math,time
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import expm_multiply
P=Path(__file__).resolve().parent;protocol=json.loads((P/'PROTOCOL.json').read_text())
def models(M):
 x,w=leggauss(M);delta=16*x;c=np.sqrt(64*w/math.pi);n=1/np.expm1((5/16)*(64+delta))
 D=3+4*M+M*(M+1)//2;off=3+4*M
 r=[];s=[];v=[]
 def edge(a,b,z):
  a=np.atleast_1d(a);b=np.atleast_1d(b);z=np.broadcast_to(z,a.shape)
  r.extend([a,b]);s.extend([b,a]);v.extend([z,z])
 edge(np.array([0,1]),np.array([1,2]),1.)
 for a,z in [(0,1.),(1,1.),(2,math.sqrt(4*math.sqrt(2)))]:edge(3+a*M+np.arange(M),3+(a+1)*M+np.arange(M),z)
 for a in range(3):edge(np.full(M,a),3+a*M+np.arange(M),c)
 j,k=np.triu_indices(M);ids=off+np.arange(len(j))
 r.extend([3+np.arange(4*M),ids]);s.extend([3+np.arange(4*M),ids]);v.extend([np.tile(delta,4),delta[j]+delta[k]])
 for a in range(M):
  b=np.arange(M);lo=np.minimum(a,b);hi=np.maximum(a,b);pair=off+lo*(2*M-lo+1)//2+hi-lo
  edge(np.full(M,3+3*M+a),pair,c*np.sqrt(1+(a==b)))
 H=coo_matrix((np.concatenate(v),(np.concatenate(r),np.concatenate(s))),shape=(D,D)).tocsr();H.eliminate_zeros()
 H1=np.zeros((M+4,M+4));H1[0,1]=H1[1,0]=1;H1[1,2]=H1[2,1]=1;H1[2,3]=H1[3,2]=math.sqrt(4*math.sqrt(2));H1[3,4:]=c;H1[4:,3]=c;H1[4:,4:]=np.diag(delta)
 return H,H1,n

def retained(W,n,M):
 out=np.zeros((8,8),complex);root=np.sqrt(n)
 V=W[:3]*root;out[5:8,5:8]=V@V.conj().T
 V=(W[3:3+4*M]*root).reshape(4,M,M)
 out[:4,:4]=np.einsum('ajk,bjk->ab',V,V.conj())
 out[4,4]=np.sum(abs(W[3+4*M:])**2*n)
 return out
rows=[]
for M in protocol['quadrature_modes']:
 start=time.monotonic();H,H1,n=models(M);V=np.zeros((H.shape[0],M),complex);V[3+np.arange(M),np.arange(M)]=1
 trace=float(H.diagonal().sum());W=expm_multiply(-16j*H,V,traceA=-16j*trace)
 hot=retained(W,n,M);psi=np.zeros(M+4,complex);psi[0]=1;u=expm_multiply(-16j*H1,psi,traceA=-16j*np.trace(H1))
 cold=np.zeros((8,8),complex);cold[:4,:4]=np.outer(u[:4],u[:4].conj());cold[4,4]=np.vdot(u[4:],u[4:])
 D=hot-n.sum()*cold;ev=np.linalg.eigvalsh(D);half=float(abs(ev).sum()/2)
 assert abs(np.trace(D))<1e-12 and np.linalg.norm(D-D.conj().T)<1e-12
 refinement=None
 if M==32:
  W2=expm_multiply(-8j*H,V,traceA=-8j*trace);W2=expm_multiply(-8j*H,W2,traceA=-8j*trace)
  refinement=float(np.linalg.norm(retained(W2,n,M)-hot));assert refinement<1e-12
 row={'M':M,'Q2_dimension':H.shape[0],'nonzeros':H.nnz,'all_one_photon_columns':M,'half_trace_Delta2':half,'trace_residual':float(abs(np.trace(D))),'Hermiticity_residual':float(np.linalg.norm(D-D.conj().T)),'M32_halfstep_refinement_difference':refinement,'occupation_trace':float(n.sum()),'cold_retained_error':float(np.vdot(u[:4],u[:4]).real),'Delta2_real':D.real.tolist(),'Delta2_imag':D.imag.tolist(),'seconds':time.monotonic()-start,'scope':'SIMULATED finite stationary Legendre-chain reference; covariance and vacuum continuum transfer unclosed for this numerical size'}
 rows.append(row);print(json.dumps({k:v for k,v in row.items() if k not in ['Delta2_real','Delta2_imag']}),flush=True)
 (P/'results/NUMERICAL_RESPONSE.json').write_text(json.dumps({'status':'SIMULATED','rows':rows,'thermal_target':'OPEN','physical_promotion':0},indent=2)+'\n')
