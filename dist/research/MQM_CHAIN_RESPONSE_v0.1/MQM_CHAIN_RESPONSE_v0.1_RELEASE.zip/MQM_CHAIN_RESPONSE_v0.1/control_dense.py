from pathlib import Path
import itertools,json,math
import numpy as np
from scipy.linalg import eigh
P=Path(__file__).resolve().parent
ns={'__file__':str(P/'response.py')};exec((P/'response.py').read_text().split('rows=[]')[0],ns)
M=4;H,H1,n=ns['models'](M);x,w=np.polynomial.legendre.leggauss(M);freq=16*x;c=np.sqrt(64*w/math.pi)
charge=[1,1,1,1,0,2,2,2];bs=[]
for a,q in enumerate(charge):
 for modes in itertools.combinations_with_replacement(range(M),2-q):bs.append((a,tuple(modes.count(j) for j in range(M))))
lut={v:i for i,v in enumerate(bs)};K=np.zeros((len(bs),len(bs)))
for j,(a,f) in enumerate(bs):
 K[j,j]=np.dot(freq,f)
 for u,v,z in [(0,1,1),(1,2,1),(2,3,math.sqrt(4*math.sqrt(2))),(5,6,1),(6,7,1)]:
  if a==u and (v,f) in lut:
   k=lut[(v,f)];K[j,k]=K[k,j]=z
 for hi,lo in [(3,4),(5,0),(6,1),(7,2)]:
  if a==hi:
   for site in range(M):
    ff=list(f);ff[site]+=1
    if (lo,tuple(ff)) in lut:
     k=lut[(lo,tuple(ff))];z=c[site]*math.sqrt(1+f[site]);K[j,k]=K[k,j]=z
states=[(a,(0,)*M) for a in [5,6,7]]
for a in [0,1,2,3]:
 for j in range(M):states.append((a,tuple(int(k==j) for k in range(M))))
for j,k in itertools.combinations_with_replacement(range(M),2):states.append((4,tuple(int(v==j)+int(v==k) for v in range(M))))
perm=[lut[s] for s in states];matrix_error=float(np.max(abs(K[np.ix_(perm,perm)]-H.toarray())))
e,V=eigh(K);U=(V*np.exp(-16j*e))@V.T
out=np.zeros((8,8),complex)
for mode in range(M):
 f=tuple(int(k==mode) for k in range(M));v=U[:,lut[(0,f)]]
 for j,(a,f) in enumerate(bs):
  for k,(b,g) in enumerate(bs):
   if f==g:out[a,b]+=n[mode]*v[j]*v[k].conjugate()
seed=np.zeros((H.shape[0],M),complex);seed[3+np.arange(M),np.arange(M)]=1
from scipy.sparse.linalg import expm_multiply
W=expm_multiply(-16j*H,seed,traceA=-16j*H.diagonal().sum());sp=ns['retained'](W,n,M);err=float(np.linalg.norm(sp-out));assert matrix_error<1e-12 and err<1e-12
(P/'results/DENSE_CONTROL.json').write_text(json.dumps({'M':M,'independent_occupation_matrix_error':matrix_error,'dense_sparse_retained_hot_difference':err,'status':'SIMULATED independent implementation route, not independent reviewer'},indent=2)+'\n')
print(matrix_error,err)
