from pathlib import Path
import json,hashlib,shutil,tempfile,subprocess,sys,zipfile,platform
import numpy,scipy
P=Path(__file__).resolve().parent
A=json.loads((P/'results/TRANSFER_AUDIT.json').read_text())
def put(name,obj):(P/name).write_text(json.dumps(obj,indent=2)+'\n')
put('CLAIM_REGISTER.json',{'finite_response':'SIMULATED full covariance-weighted Q2 columns, M32/64/128/192, not continuum certificate','M192_half_trace_response':2.2505874657197752e-8,'dense_control':'SIMULATED independent implementation route; not independent reviewer','Chebyshev_transfer':'DERIVED conditional at L1536, EXACT rational comparison <2^-229','covariance_transfer':'DERIVED ideal stationary Gauss-node kernel at M192, EXACT rational response allowance <2^-57','primary_beta_5_16_target':'OPEN','vacuum_transfer_at_192':'OPEN','directed_numerical_error':'OPEN','independent_review':'OPEN same-agent audit only','physical_promotion':0})
put('RESOURCE_LEDGER.json',{'M192_Q2_dimension':19299,'M192_nnz':95236,'M192_all_initial_columns':192,'M192_complex_column_array_bytes':19299*192*16,'certified_Chebyshev_chain_L':1536,'certified_reference_Q2_dimension':1186563,'previous_sufficient_reference_L':3072,'previous_reference_Q2_dimension':4732419,'representation_rule':'Legendre sites versus quadrature eigenmodes; ideal unitary equivalence at equal M only. Transfer at L1536 cannot certify numerics at M192.','physical_qubit_advantage':False})
put('NEXT_GATE.json',{'recommended':'Vacuum observable transfer bound at M192 (or execute at certified L1536), then directed numerical error','why':'Covariance difference is bounded but vacuum truncation dominates the unclosed certificate. Finite response estimates alone cannot promote target.','parallel':'Directed Gauss-node/weight and exponential-action assembly/roundoff bounds, preserving frozen source parameters','priority_score':95,'score_type':'prioritization judgment, not measured closure percentage','target':'1/65536','beta':'5/16','T':16})
put('ENVIRONMENT.json',{'python':sys.version,'numpy':numpy.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'BLAS_threads':1})
(P/'requirements.txt').write_text('numpy=='+numpy.__version__+'\nscipy=='+scipy.__version__+'\nPyMuPDF==1.26.6\n# pdflatex and Poppler for PDF rebuild\n')
(P/'inputs').mkdir(exist_ok=True);sources=[]
for parent,name in [('MQM_SECOND_ORDER_SPEC_v0.1','PROTOCOL.json'),('MQM_LOCAL_DRIVE_CHAIN_v0.1','PROTOCOL.json'),('MQM_THERMAL_KERNEL_v0.1','results/THERMAL_AUDIT.json'),('MQM_FREQUENCY_BOUND_v0.1','PROTOCOL.json')]:
 src=P.parent/parent/name;out=P/'inputs'/(parent+'_'+Path(name).name);shutil.copyfile(src,out);sources.append({'parent':parent,'source':name,'snapshot':str(out.relative_to(P)),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
put('SOURCE_ANCHORS.json',{'parents':sources,'primary_external_methods':['https://dlmf.nist.gov/10.9.E4','https://dlmf.nist.gov/3.5','https://arxiv.org/abs/1006.4507'],'external_review':False})
(P/'README.txt').write_text('MQM CHAIN RESPONSE v0.1\n\nReproduce numerical runs: python3 response.py (about150seconds in recorded environment; full columns, not a performance benchmark).\nExact transfer audit: python3 audit_transfer.py.\nIndependent dense implementation control: python3 control_dense.py.\nPDF rebuild: python3 build_pdf.py (pdflatex,Poppler).\n\nStatus: finite M192 response ~2.2505875e-8, SIMULATED. The new Chebyshev vacuum transfer at L1536 is <2^-229. The separate M192 covariance response replacement bound is <2^-57. These sizes cannot be conflated: vacuum transfer at192 and directed numerical error remain OPEN. Physical promotion0.\n\nInitial cold diagnostic incorrectly counted auxiliary d1 as captured; corrected receipt and original JSON are preserved. Delta2 matrices were unaffected. Analytic covariance comparison and dense control were added after evaluation began; this development amendment is disclosed, source target unchanged. Same-agent alternative proof audit is not independent external review.\n')
initial=(P/'response.py').read_text().replace('float(np.vdot(u[:4],u[:4]).real)','float(1-cold[3,3].real-cold[4,4].real)')
(P/'response_initial_diagnostic.py').write_text(initial)
with tempfile.TemporaryDirectory() as t:
 q=Path(t);(q/'results').mkdir()
 for name in ['PROTOCOL.json','response.py','control_dense.py','audit_transfer.py']:shutil.copyfile(P/name,q/name)
 for name in ['audit_transfer.py','control_dense.py']:
  r=subprocess.run([sys.executable,str(q/name)],capture_output=True,text=True);assert r.returncode==0,r.stderr
 assert (q/'results/TRANSFER_AUDIT.json').read_bytes()==(P/'results/TRANSFER_AUDIT.json').read_bytes()
 b=json.loads((q/'results/DENSE_CONTROL.json').read_text());assert b['independent_occupation_matrix_error']==0 and b['dense_sparse_retained_hot_difference']<1e-12
 put('results/REPLAY_QA.json',{'fresh_directory':True,'exact_transfer_receipt_byte_identical':True,'dense_implementation_control_pass':True,'full_M192_rerun':False,'reason':'Only cold readout diagnostic changed; original full-column response matrices retained. Dense route and exact arithmetic replay verified.','protocol_sha256':hashlib.sha256((P/'PROTOCOL.json').read_bytes()).hexdigest(),'PDF_visual_review':'Latest two Poppler-rendered IEEE A4 pages inspected; readable, no clipping or overlaps'})
files=[f for f in P.rglob('*') if f.is_file() and f.suffix not in ['.aux','.log','.out','.pyc'] and '__pycache__' not in f.parts and f.name!='SHA256SUMS']
(P/'SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(P))+'\n' for f in sorted(files)));files.append(P/'SHA256SUMS')
z=P.parent/(P.name+'_RELEASE.zip')
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for f in sorted(files):out.write(f,str(Path(P.name)/f.relative_to(P)))
print(json.dumps({'files':len(files),'ZIP_SHA256':hashlib.sha256(z.read_bytes()).hexdigest(),'exact_fresh_replay':'PASS'},indent=2))
