from pathlib import Path
import json,subprocess,fitz
R=Path(__file__).resolve().parent;M=R/'manuscript';name='MQM_SPARSE_TRANSFER_IEEE_A4_v0.1'
for k in range(2):
 p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,capture_output=True,text=True)
 (R/'results'/('PDF_BUILD_'+str(k)+'.txt')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout[-1500:]
doc=fitz.open(M/(name+'.pdf'));log=(M/(name+'.log')).read_text()
for i,p in enumerate(doc):p.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/('PAGE_'+str(i+1)+'.png'))
qa={'pages':len(doc),'A4':all(abs(p.rect.width-595.276)<1 and abs(p.rect.height-841.89)<1 for p in doc),'IEEEtran':'journal,a4paper,10pt','two_columns':True,'no_overfull':'Overfull' not in log,'no_unresolved_references':'undefined' not in log,'visual_review':'pending'}
(R/'results/PDF_QA.json').write_text(json.dumps(qa,indent=2));print(qa)
