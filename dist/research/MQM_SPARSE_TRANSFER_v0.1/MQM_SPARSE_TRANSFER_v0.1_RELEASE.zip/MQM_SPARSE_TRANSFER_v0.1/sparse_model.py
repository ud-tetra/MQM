import numpy as np,math
from scipy.sparse import coo_matrix

def model(M):
 D=3+4*M+M*(M+1)//2;offset=3+4*M;delta=(2*np.arange(M)+1-M)*(16/M);c=math.sqrt(128/(math.pi*M));r=[];s=[];v=[]
 def edges(a,b,w):
  a=np.atleast_1d(a);b=np.atleast_1d(b);w=np.broadcast_to(w,a.shape)
  r.extend([a,b]);s.extend([b,a]);v.extend([w,w])
 edges(np.array([0,1]),np.array([1,2]),1.)
 for a,w in [(0,1),(1,1),(2,math.sqrt(4*math.sqrt(2)))]:edges(3+a*M+np.arange(M),3+(a+1)*M+np.arange(M),w)
 for a in range(3):edges(np.full(M,a),3+a*M+np.arange(M),c)
 j,k=np.triu_indices(M);ids=offset+np.arange(len(j));diag=delta[j]+delta[k]
 r.extend([3+np.arange(4*M),ids]);s.extend([3+np.arange(4*M),ids]);v.extend([np.tile(delta,4),diag])
 for a in range(M):
  b=np.arange(M);lo=np.minimum(a,b);hi=np.maximum(a,b);pair=offset+lo*(2*M-lo+1)//2+hi-lo
  edges(np.full(M,3+3*M+a),pair,c*np.sqrt(1+(a==b)))
 H=coo_matrix((np.concatenate(v),(np.concatenate(r),np.concatenate(s))),shape=(D,D)).tocsr();H.eliminate_zeros()
 return H

def lanczos(H,v,k):
 basis=[];alpha=[];beta=[];q=v.copy();prev=np.zeros_like(q);bp=0.
 for j in range(k):
  basis.append(q);w=H@q-bp*prev;a=float(q@w);alpha.append(a);w-=a*q
  V=np.column_stack(basis)
  for rep in range(2):w-=V@(V.T@w)
  b=float(np.linalg.norm(w))
  if b<1e-14:
   b=0.;qn=np.zeros_like(q);break
  qn=w/b
  if j<k-1:beta.append(b);prev=q;q=qn;bp=b
 V=np.column_stack(basis);Tk=np.diag(alpha)
 for j,z in enumerate(beta):Tk[j,j+1]=Tk[j+1,j]=z
 return V,Tk,b,qn
