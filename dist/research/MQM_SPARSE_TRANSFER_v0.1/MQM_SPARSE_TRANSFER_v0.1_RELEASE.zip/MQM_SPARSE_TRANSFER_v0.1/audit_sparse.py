import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,math
import numpy as np
from scipy.linalg import eigh
from numpy.polynomial.legendre import leggauss
from sparse_model import model,lanczos
from dense_reference import basis,ham
R=Path(__file__).resolve().parent
rows=[]
for M,orders in [(16,[16,32,64,128]),(768,[16])]:
 H=model(M);D=H.shape[0];pairs=M*(M+1)//2;nnz=2*(2+6*M+M*M)+4*M+pairs-M//2
 assert D==3+4*M+pairs and H.nnz==nnz and (H-H.T).nnz==0
 launch=np.zeros(D);launch[3]=1
 actual=None;assembly=None
 if M==16:
  bs=basis(M,2);Hd=ham(M,bs);order=[]
  for a,f in bs:
   inds=[j for j,n in enumerate(f) for _ in range(n)]
   if a>=5:idx=a-5
   elif a<4:idx=3+a*M+inds[0]
   else:
    j,k=inds;idx=3+4*M+j*(2*M-j+1)//2+k-j
   order.append(idx)
  assembly=float(np.max(abs(H.toarray()[np.ix_(order,order)]-Hd)));assert assembly<1e-12
  e,W=eigh(H.toarray());actual=(W*np.exp(-1j*16*e))@W.T@launch
 for K in orders:
  V,T,b,nextv=lanczos(H,launch,K);k=V.shape[1];e,W=eigh(T);coef=W[-1,:]*W[0,:];ints=[]
  for N in [256,512]:
   x,w=leggauss(N);s=8*(x+1);f=np.exp(-1j*np.outer(s,e))@coef;ints.append(float(8*b*np.dot(w,abs(f))))
  E=H@V-V@T-b*np.outer(nextv,np.eye(k)[-1]);fro=float(np.linalg.norm(E));estimate=max(ints)+16*fro
  projected=V@(W@(np.exp(-1j*16*e)*W[0,:]));err=None if actual is None else float(np.linalg.norm(actual-projected))
  if err is not None:assert err<=estimate+1e-10
  rows.append({'M':M,'requested_k':K,'actual_k':k,'dimension':D,'nnz':H.nnz,'csr_bytes':H.data.nbytes+H.indices.nbytes+H.indptr.nbytes,'basis_bytes':V.nbytes,'assembly_max_difference':assembly,'beta_last':b,'residual_integral_estimates':ints,'non_rankone_residual_frobenius_estimate':fro,'vector_error_estimate':estimate,'dense_actual_error':err,'orthogonality_error':float(np.linalg.norm(V.T@V-np.eye(k))),'scope':'SIMULATED one-hot-mode propagation only; residual numbers are not directed certificates'})
  print(M,K,'error',err,'estimate',estimate,flush=True)
  del V,E
res={'status':'Sparse assembly and finite Krylov implementation controls pass','rows':rows,'M768_full_thermal_response':'NOT COMPUTED; pilot onlyj0,k16','continuum_response':'OPEN','physical_promotion':0}
(R/'results/SPARSE_AUDIT.json').write_text(json.dumps(res,indent=2)+'\n')
