import numpy as np
import itertools,math
Snames=["p0","m0","e0","d1","d0","p1","m1","e1"]
charges=[1,1,1,1,0,2,2,2]

def basis(M,q):
 out=[]
 for a,charge in enumerate(charges):
  n=q-charge
  if n<0:continue
  for inds in itertools.combinations_with_replacement(range(M),n):
   f=[0]*M
   for i in inds:f[i]+=1
   out.append((a,tuple(f)))
 return out

def ham(M,bs):
 lookup={s:i for i,s in enumerate(bs)};delta=-16+(np.arange(M)+.5)*32/M;c=math.sqrt(128/(math.pi*M));H=np.zeros((len(bs),len(bs)))
 edges=[(0,1,1),(1,2,1),(2,3,math.sqrt(4*math.sqrt(2))),(5,6,1),(6,7,1)];low={3:4,5:0,6:1,7:2}
 for i,(a,f) in enumerate(bs):
  H[i,i]=np.dot(delta,f)
  for u,v,w in edges:
   if a==u and (v,f) in lookup:
    j=lookup[(v,f)];H[i,j]+=w;H[j,i]+=w
  if a in low:
   for n in range(M):
    ff=list(f);ff[n]+=1;state=(low[a],tuple(ff))
    if state in lookup:
     j=lookup[state];val=c*math.sqrt(f[n]+1);H[i,j]+=val;H[j,i]+=val
 return H
