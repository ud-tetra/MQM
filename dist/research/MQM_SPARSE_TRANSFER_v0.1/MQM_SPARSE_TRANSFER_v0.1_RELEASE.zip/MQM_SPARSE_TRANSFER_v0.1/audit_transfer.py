from pathlib import Path
from fractions import Fraction as F
import json,math
R=Path(__file__).resolve().parent
assert sum((F(15)**j/F(math.factorial(j)) for j in range(81)),F())>2**21
n=F(1,2**21-1);V=F(128,3)*n;B=F(16);T=F(16);beta=F(5,16)
coef=V*B*(2*beta*(1+n)*T*T+F(50,3)*T**3);debit=coef/768
margin=F(127,2**25)-F(1,2**128)
assert debit>margin
res={'status':'DERIVED conditional paired-response continuum comparison with EXACT rational majorants','formula':'delta_cont2 <=Vstar B/M[2beta(1+nstar)T^2+(50/3)T^3]','Vstar_ceiling_exact':str(V),'coefficient_exact':str(coef),'M768_transfer_debit_exact':str(debit),'M768_transfer_debit_decimal':float(debit),'required_second_order_budget_exact':str(margin),'target_status':'OPEN; coarse bound insufficient, not a channel error floor','clock_arithmetic':{'M_factorization':'3*2^8','delta_j_exact':'(2j-767)/48','spacing_exact':'1/24','coupling_squared_exact':'1/(6pi)','free_bath_relative_phase_alignment':'48pi','free_bath_full_phase_alignment':'96pi','scope':'Free bath arithmetic only, not coupled-latch recurrence.'},'physical_promotion':0}
(R/'results/TRANSFER_AUDIT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
