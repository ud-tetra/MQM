from pathlib import Path
from fractions import Fraction as F
import math,json
R=Path(__file__).resolve().parent
# Post-exposure analytical algorithm design; physical source/target unchanged.
z=F(16);k=64;tail=2*z**k/F(math.factorial(k))/(1-z/F(k+1));global_bound=64*tail
assert global_bound<F(1,2**32)
prop=2*F(768,2**21-1)*(global_bound+global_bound**2/2)
assert prop<F(1,2**43)
res={'ideal_full_covariance_response_propagation_ceiling_exact':str(prop),'ideal_response_propagation_decimal':float(prop),'status':'DERIVED exact-arithmetic ideal short-step Krylov allowance','sector_norm_ceiling':64,'step_exact':'1/4','steps':64,'k':64,'per_step_vector_ceiling_exact':str(tail),'global_vector_ceiling_exact':str(global_bound),'global_vector_ceiling_decimal':float(global_bound),'simple_ceiling':'1/4294967296','proof':'Exact isometric Hermitian Krylov projection matches polynomial powers throughk-1 and projectednorm<=64; both Taylor tails <=sum_n>=k 16^n/n!; ratio<=16/65; unitary exact propagation sums steperrors.','scope':'A priori ideal exact-arithmetic design only. Restarted complex propagation and directed Lanczos/rounding certification not implemented. Full768-mode thermalresponse notcomputed.','amendment':'Analytical algorithm supplement after fullinterval pilot exposure; no change to source,T,beta,target or interpretation rules.','physical_promotion':0}
(R/'results/SHORTSTEP_PLAN.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
