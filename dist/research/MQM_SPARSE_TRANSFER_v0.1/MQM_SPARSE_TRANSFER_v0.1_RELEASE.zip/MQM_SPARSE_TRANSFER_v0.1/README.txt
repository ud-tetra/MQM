MQM SPARSE TRANSFER v0.1

Replay:
python freeze.py
python audit_transfer.py
python audit_shortstep.py
python audit_sparse.py

Sparse builder creates the fullM768Q2 matrix but pilot launches onlyonehot modej0 atKrylovk16. M16 densecontrols independently verifybasispermution/assembly andprojectiondefect estimates. Nofullcovarianceweightedthermalresponse computed.

Numerical residualintegrals andLanczoscoefficients are binary64diagnostics, notdirectedcertificates. The shortstep result is anidealexact-arithmetic derivation, notimplementedrestartedcomplexpropagation or measured accuracy. Its postexposurealgorithm design isdisclosed.

Continuum bound is a separate conditional response comparison usingflatbandstepfrequencies andanalyticnoise kernels. CoarseM768allowance0.029003 isinsufficient andnot a lowererror bound. Originaltarget remainsOPEN.

IEEEtran A4 journal10pttwo-column paper: python build_pdf.py; needs pdflatex. Class/licenseincluded. CSRstates andmemoryaremathematicalresources, notphysicalqubits. Physicalpromotion0; noquantumadvantage, permanentsink, hardwareorindependentreviewclaim.
