from fractions import Fraction as F
from pathlib import Path
import math,json
R=Path(__file__).resolve().parent
parent=json.loads((R/'PARENT_CONTINUUM_CERTIFICATE.json').read_text())
assert F(parent['continuum_ceiling_exact'])==F(3,2**18)+F(1,2**128)
# Post-freeze analytical supplement; parameters and target unchanged.
assert sum((F(14,3)**j/F(math.factorial(j)) for j in range(81)),F())>F(517,5)
assert F(17,12)**2>2
for a,p in [(15,21),(25,36)]:assert sum((F(a)**j/F(math.factorial(j)) for j in range(81)),F())>2**p
A=F(4,3)*(F(1,2**21-1)+F(1,2**36-1))
Fenv=F(16)*F(14,3)-16+F(5,16)
x=4*F(17,12)*A*Fenv
assert 0<x<1
thermal=x/(2*(1-x));E0=F(3,2**18)+F(1,2**128);total=E0+thermal
assert total<F(1,8192)
assert thermal>F(1,65536)-E0
r={'status':'EXACT rational majorants for DERIVED conditional frequency bound','A_ceiling_exact':str(A),'F_ceiling_exact':str(Fenv),'exponent_ceiling_exact':str(x),'thermal_ceiling_exact':str(thermal),'total_ceiling_exact':str(total),'total_ceiling_decimal':float(total),'certified_target_exact':'1/8192','original_target_exact':'1/65536','original_target_status':'OPEN; bound inconclusive, not actual channel failure','exp_proof':'Positive Taylor lower sums through80 prove exp(14/3)>517/5, exp15>2^21, exp25>2^36; pi>3; sqrt2<17/12','remainder_proof':'exp(x)-1<=x/(1-x) for0<x<1 from1/n!<=1','supplement':'Post-freeze analytic majorant; no source parameter, deadline, target or evaluation rule changed.','physical_promotion':0}
(R/'EXACT_RESULT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
