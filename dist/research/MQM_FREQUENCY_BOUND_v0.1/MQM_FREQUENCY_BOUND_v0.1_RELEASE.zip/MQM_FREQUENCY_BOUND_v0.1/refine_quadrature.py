from pathlib import Path
import json,math,warnings
import numpy as np
from scipy.integrate import quad,IntegrationWarning
from scipy.optimize import brentq
R=Path(__file__).resolve().parent
# Diagnostic amendment: resolve absolute-value cusps; all source parameters unchanged.
k=8;B=16;t=16;b=5/16
def C(s):return k/(2*math.pi)*sum((math.exp(-l*b*48)*np.exp(1j*B*s)-math.exp(-l*b*80)*np.exp(-1j*B*s))/(l*b+1j*s) for l in range(1,5))
roots=[];grid=np.linspace(0,16,8193)
for component in [lambda s:C(s).real,lambda s:C(s).imag]:
 for lo,hi in zip(grid[:-1],grid[1:]):
  if component(lo)*component(hi)<0:roots.append(brentq(component,lo,hi,xtol=1e-14))
pts=sorted(set(roots));warnings_seen=[]
with warnings.catch_warnings(record=True) as w:
 warnings.simplefilter('always',IntegrationWarning)
 val,err=quad(lambda s:(t-s)*(abs(C(s).real)+abs(C(s).imag)),0,t,points=pts,epsabs=1e-13,epsrel=1e-11,limit=4000)
 warnings_seen=[str(x.message) for x in w]
assert not warnings_seen
prior=json.loads((R/'RESULT.json').read_text());assert abs(val-prior['independent_scipy_I_abs'])<prior['independent_scipy_error_estimate']
r={'status':'SIMULATED independent cusp-resolved diagnostic','source_unchanged':True,'refinement_reason':'Original adaptive integral emitted roundoff warning; preserved as initial diagnostic, not certified quadrature.','I_abs':val,'error_estimate':err,'root_breakpoints':len(pts),'warnings':warnings_seen,'estimated_thermal_debit':math.expm1(4*val)/2,'second_order_scope':'Scalar integral diagnostic only; exact channel response remains OPEN'}
(R/'REFINED_QUADRATURE.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
