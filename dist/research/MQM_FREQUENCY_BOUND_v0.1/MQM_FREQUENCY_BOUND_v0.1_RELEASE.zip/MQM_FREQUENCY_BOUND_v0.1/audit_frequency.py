from pathlib import Path
from fractions import Fraction
import json,math
import mpmath as mp
from mpmath import iv
import numpy as np
from scipy.integrate import quad
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text());mp.mp.dps=80;iv.dps=80
b=mp.mpf(5)/16;O=64;B=16;k=8;t=16
rlo=mp.exp(-b*(O-B));rhi=mp.exp(-b*(O+B))
V=k/(2*mp.pi*b)*(mp.log(1-rhi)-mp.log(1-rlo));tail=k*B/mp.pi*mp.exp(-5*b*(O-B))/(1-mp.exp(-b*(O-B)))
def C(s):return k/(2*mp.pi)*sum((mp.exp(-l*b*(O-B))*mp.exp(1j*B*s)-mp.exp(-l*b*(O+B))*mp.exp(-1j*B*s))/(l*b+1j*s) for l in range(1,5))
L=(2+2*B*t)*V # f=(t-s)(|Re C|+|Im C|) is Lipschitz with bound2V+2BtV
rows=[]
for N in [65536,131072]:
 h=mp.mpf(t)/N;sm=mp.mpf(0)
 for j in range(N):
  s=(j+mp.mpf('0.5'))*h;z=C(s);sm+=(t-s)*(abs(z.real)+abs(z.imag))
 val=h*sm;radius=L*t*h/4+t*t*tail # two component tail triangle
 rows.append({'N':N,'midpoint_80digit':str(val),'analytic_quadrature_radius':str(radius),'I_abs_lower_estimate':str(val-radius),'I_abs_upper_estimate':str(val+radius),'numeric_arithmetic_status':'80-digit mpmath, not directed; radius analytically controls quadrature and Bose tail only'})
 print('MESH',N,'I_abs',mp.nstr(val,16),flush=True)
# Entire-kernel analytic envelope: no frequency quadrature necessary.
bv=iv.mpf(5)/16;rl=iv.exp(-bv*48);rh=iv.exp(-bv*80)
A=iv.mpf(k)/(2*iv.pi)*(rl/(1-rl)+rh/(1-rh))
F=iv.mpf(t)*iv.ln((t+iv.sqrt(t*t+bv*bv))/bv)-iv.sqrt(t*t+bv*bv)+bv
Imod=A*F
# |Re|+|Im|<=sqrt2|C|, exponent4I_abs, safe bound below.
thermal=(iv.exp(4*iv.sqrt(2)*Imod)-1)/2
E0=iv.mpf(3)/262144+iv.mpf(2)**-128;total=E0+thermal
assert total.b < (iv.mpf(1)/8192).a
assert thermal.a > (iv.mpf(1)/65536-E0).b # this selected upper-bound expression does not suffice, not a channel lower bound
# Exact rational majorants: pi>3,rlo<2^-21,rhi<2^-36 (exp25>2^36 from positive Taylor).
for a,power in [(15,21),(25,36)]:assert sum((Fraction(a)**j/Fraction(math.factorial(j)) for j in range(81)),Fraction())>2**power
# Independent scipy integration using same four-term analytic spectrum formula.
def Cf(s):return k/(2*math.pi)*sum((math.exp(-l*(5/16)*48)*np.exp(1j*B*s)-math.exp(-l*(5/16)*80)*np.exp(-1j*B*s))/(l*(5/16)+1j*s) for l in range(1,5))
quad_I,quad_err=quad(lambda s:(t-s)*(abs(Cf(s).real)+abs(Cf(s).imag)),0,t,epsabs=1e-13,epsrel=1e-11,limit=4000,points=np.linspace(0,t,513))
assert all(abs(mp.mpf(quad_I)-mp.mpf(x['midpoint_80digit']))<mp.mpf(x['analytic_quadrature_radius']) for x in rows)
# Signed scalar filter: cancels oscillations but omits noncommuting response; diagnostic only.
def f2(d):return k/(2*math.pi)*((1-math.cos(d*t))/(d*d) if abs(d)>1e-7 else t*t/2)/math.expm1((5/16)*(O+d))
signed,err=quad(f2,-B,B,epsabs=1e-15,epsrel=1e-11,limit=1000,points=[0])
res={'protocol':P,'V_80digit':str(V),'old_t_squared_V':str(t*t*V),'Bose_tail_uniform':str(tail),'midpoint_rows':rows,'independent_scipy_I_abs':quad_I,'independent_scipy_error_estimate':quad_err,'estimated_Wick_debit':math.expm1(4*quad_I)/2,'signed_scalar_filter':signed,'signed_filter_scope':'Diagnostic only; cannot substitute for full-channel bound with time-dependent noncommuting interaction operators.','analytic_envelope_I_mod_interval':str(Imod),'directed_analytic_Wick_debit_interval':str(thermal),'directed_total_ceiling_interval':str(total),'certified_looser_target_exact':'1/8192','requested_target_status':'OPEN; chosen conservative bound inconclusive','model_status':'DERIVED conditional Gaussian bound; numerical quadrature diagnostics; analytic envelope evaluated with directed mpmath intervals','physical_promotion':0}
(R/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({q:v for q,v in res.items() if q not in ['protocol','midpoint_rows']},indent=2))
