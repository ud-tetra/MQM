MQM FREQUENCY BOUND v0.1

Short replay:
python freeze.py
python audit_exact.py
python audit_remainder.py
python refine_quadrature.py

Full optional diagnostic replay (several minutes):
python audit_frequency.py

This includes 80-digit midpoint meshes65536,131072. Its original adaptive scipy quadrature emits a roundoff warning; initial result and warning are preserved. refine_quadrature.py resolves161 absolute-value cusps and eliminates the warning. Neither diagnostic is a directed quadrature certificate. The exact rational error certificate is independent of them.

IEEEtran A4 two-column PDF: run python build_pdf.py (requires pdflatex and PyMuPDF). Class and LPPL license included.

Claim: conditional Gaussian frequency bound gives retainederror<2^-13 at beta5/16,t16. Original2^-16targetOPEN. Fourth-and-higher-order correction<2^-25; remaining actual second-order response must satisfy127/2^25-2^-128. No simulation of a complete thermal channel, permanenthold, native2localcompiler, hardwareperformance or advantage. Physicalpromotion0.

Source lineage: parentthermal andvacuumcertificate copied with hashanchors. Protocolfrozen; analyticalsupplements and numericaldiagnosticrepair disclosed.
