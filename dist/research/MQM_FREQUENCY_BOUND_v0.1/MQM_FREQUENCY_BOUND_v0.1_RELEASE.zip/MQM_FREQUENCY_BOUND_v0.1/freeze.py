from pathlib import Path
import json
R=Path(__file__).resolve().parent
P={'version':'0.1','status':'FROZEN before frequency evaluation','source':'MQM_THERMAL_KERNEL_v0.1 flat-band Gaussian continuum reference','Omega':64,'B':16,'kappa':8,'beta_exact':'5/16','time_exact':'16','target_exact':'1/65536','vacuum_ceiling':'3/262144+2^-128','claim_scope':'retained thermal-vacuum half diamond bound conditional on declared Gaussian continuum; original bath traced','primary_bound':'min(t^2 V, [exp(4 I_abs)-1]/2), I_abs=integral0^t(t-s)(abs(Re Cn(s))+abs(Im Cn(s)))ds','kernel':'Cn(s)=integral_-B^B kappa/(2pi)n_beta(Omega+delta)exp(-i delta s)d delta','proof':'Gaussian real quadratures, four absolute covariance entries; bounded Pauli commutators each norm<=2; Wick pairings in time-ordered Dyson expansion','enclosure':'4-term Bose kernel, omitted tail<=kappa B/pi exp(-5 beta(Omega-B))/(1-exp(-beta(Omega-B))); midpoint quadrature Lipschitz enclosure with |Cn|<=V, |Cn derivative|<=B V. Mesh N=65536 and131072; 80-digit numerical midpoint evaluation with analytic quadrature envelope; numeric evaluation itself not directed certificate','signed_filter':'F2=integral Jn (1-cos(delta t))/delta^2 d delta, removable value t^2/2 at0; diagnostic only, not full-channel bound','acceptance':'report whether upper error envelope plus inherited vacuum ceiling<target; failure inconclusive, not no-go','physical_promotion':0}
p=R/'PROTOCOL.json';s=json.dumps(P,indent=2)+'\n'
if p.exists():assert p.read_text()==s
else:p.write_text(s)
print('FROZEN')
