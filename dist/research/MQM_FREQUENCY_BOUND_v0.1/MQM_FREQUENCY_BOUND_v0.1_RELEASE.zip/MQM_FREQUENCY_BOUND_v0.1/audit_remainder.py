from pathlib import Path
from fractions import Fraction as F
import json
R=Path(__file__).resolve().parent;P=json.loads((R/'EXACT_RESULT.json').read_text());x=F(P['exponent_ceiling_exact']);tail=x*x/(2*(1-x));assert tail<F(1,2**25)
allowance=F(127,2**25)-F(1,2**128)
assert F(3,2**18)+F(1,2**128)+F(1,2**25)+allowance==F(1,2**16)
q={'status':'DERIVED exact all-orders tail budget; response computation OPEN','higher_even_orders_half_diamond_ceiling_exact':str(tail),'simpler_tail_ceiling_exact':'1/33554432','second_order_fixed_launch_half_trace_sufficient_budget_exact':str(allowance),'budget_fraction_display':'127/33554432-2^-128','expansion':'Delta_2=E integral0^t ds integral0^s du A_zeta(s) A_zeta(u), A_zeta=-i[drive_I(t),.] ; compose with fixed launch and trace original bath','proof':'Wick bound order2n <=(4I_abs)^n/n!; n>=2 half sum <=x^2/[2(1-x)]. No odd Gaussian orders.','scope':'Sufficient criterion only; Delta_2 numerical and directed certificate not computed. No scalar filter replacement. Source launch bank/reference remains identity spectator.','physical_promotion':0}
(R/'REMAINDER_GATE.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q,indent=2))
