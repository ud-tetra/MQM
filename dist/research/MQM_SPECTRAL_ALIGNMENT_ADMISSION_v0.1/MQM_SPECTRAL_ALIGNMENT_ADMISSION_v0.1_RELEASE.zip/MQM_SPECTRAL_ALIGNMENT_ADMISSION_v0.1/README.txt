Spectral Orientation Before Phase Matching for Autonomous Joint Qubit Admission
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM note v0.1, 2026-10-06

RESULT
Four bounded 97-coordinate spectral fits improved S to 3.9991205292960474 / 4.
An exact enclosure nevertheless excludes this frozen best generator at EVERY
deadline: complete half-diamond error > 1/64, versus target 1/65536.
The bounded phase scan also supplies no successful endpoint. Orientation gains
are not operational resource gains. No planar-family no-go is established.
191 exact checks and 194 finite-difference derivative column checks.
Independent review and theorem-level novelty comparison pending. Physical 0.

CERTIFICATE REPLAY (numpy, scipy, networkx)
  python3 verify_frozen.py
  python3 spectral_certificate.py
These consume frozen receipts and do not require re-optimization. Exact
Gaussian-integer residuals, dyadic square-root enclosures and resolved spectral
gaps certify the all-time lower bound. H/L has full norm<=1 by exact Pauli
triangle inequality. Include every physical sector, not a low-energy slice.

OPTIONAL RE-OPTIMIZATION (overwrites numerical search receipts)
  python3 search_alignment.py
  python3 verify_frozen.py
  python3 spectral_certificate.py
Four seeded starts, 250 iterations each, simple-spectrum guard. Library versions
can change finite optimizer results. Coordinates are normalized for numerical
scale only; physical norm is separately audited. Grouped projectors are required
at degeneracy. Smoothing bias is larger than final target tolerance and cannot
certify an endpoint. Finite scan is not exhaustive in time.

PDF REBUILD (PyMuPDF and pdflatex)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png files before freezing:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two-column PDF; class license bundled.
Read NEXT_GATE.json for scoped joint orientation-phase continuation.
Parent release remains immutable. Hash manifest covers every distributed file.
