"""Exact coefficient-assembly and complete-domain admission audit."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json
import numpy as np
import networkx as nx
from complex_objective import load_model
R=Path(__file__).resolve().parent
source,labels,B,P,F,E,W=load_model()
best=json.loads((R/'results'/'ALIGNMENT_SEARCH.json').read_text())['best']
theta=[Q(float(v)) for v in best['theta']]
coeff=[Q(best['Pauli_coefficients_exact'][l]) for l in labels]
checks=[]
def check(name,condition):
    assert condition,name
    checks.append(name)
for l,row,c in zip(labels,B,coeff):
    check('integer-kernel coefficient '+l,c==sum((int(b)*t for b,t in zip(row,theta)),Q(0)))
den=max(c.denominator for c in coeff)
HR=np.zeros((64,64),dtype=object);HI=HR.copy()
for c,p in zip(coeff,P):
    n=c.numerator*(den//c.denominator)
    HR+=np.rint(p.real).astype(int).astype(object)*n
    HI+=np.rint(p.imag).astype(int).astype(object)*n
ss=[8,24,40,56];tt=[8,4,2,1]
check('complete-domain Hermitian real block',np.array_equal(HR,HR.T))
check('complete-domain Hermitian imaginary block',np.array_equal(HI,-HI.T))
check('exact first-moment real block',np.array_equal(HR[np.ix_(ss,ss)],HR[np.ix_(tt,tt)]))
check('exact first-moment imaginary block',np.array_equal(HI[np.ix_(ss,ss)],HI[np.ix_(tt,tt)]))
check('input isometry',np.array_equal(E.conj().T@E,np.eye(4)))
check('target isometry',np.array_equal(W.conj().T@W,np.eye(4)))
pairs=[(0,2),(0,4),(0,5),(1,2),(1,3),(1,4),(1,5),(2,4),(2,3),(4,5)]
g=nx.Graph();g.add_nodes_from(range(6));g.add_edges_from(pairs)
check('permitted graph planar',nx.check_planarity(g)[0])
check('permitted graph maximum degree four',max(dict(g.degree()).values())==4)
check('all frozen nonzero terms have support at most two on permitted pairs',all(len(s:=[k for k,x in enumerate(l) if x!='I'])<=2 and (len(s)<2 or tuple(s) in pairs) for l,c in zip(labels,coeff) if c))
check('nonzero exact full-spectrum Pauli norm budget',sum(abs(c) for c in coeff)>0)
receipt={'status':'EXACT, scoped to frozen best kernel combination','exact_count':len(checks),'checks':checks,'Pauli_norm_upper':str(sum(abs(c) for c in coeff)),'full_dimension':64,'logical_dimension':4,'physical_qubits':6,'allowed_pairs':10,'physical_promotion':0}
(R/'results'/'FROZEN_AUDIT.json').write_text(json.dumps(receipt,indent=2))
scan=json.loads((R/'results'/'DEADLINE_SCAN.json').read_text())
ratio=float(sum(abs(c) for c in coeff))/scan['sampled_centered_full_norm']
scan['exact_full_norm_implementation']='H / L, L=sum |exact Pauli coefficient|; ||H/L||<=1 on all 64 dimensions'
scan['conservative_unit_norm_deadline_diagnostic']=scan['best_sampled_deadline']*ratio
scan['conservative_unit_norm_scan_cap_diagnostic']=scan['unit_sampled_norm_time_cap']*ratio
(R/'results'/'DEADLINE_SCAN.json').write_text(json.dumps(scan,indent=2))
print({'exact_count':len(checks),'Pauli_norm_upper_decimal':float(sum(abs(c) for c in coeff))})
