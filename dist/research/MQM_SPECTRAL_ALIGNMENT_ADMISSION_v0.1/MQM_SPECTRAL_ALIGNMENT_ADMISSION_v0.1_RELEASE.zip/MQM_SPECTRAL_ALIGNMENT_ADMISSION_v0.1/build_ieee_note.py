"""Build actual IEEEtran A4 two-column development note and render for QA."""
from pathlib import Path
import json,subprocess
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript'
def read(n):return json.loads((R/'results'/n).read_text())
s=read('ALIGNMENT_SEARCH.json');g=read('GRADIENT_RECEIPT.json');c=read('SPECTRAL_CERTIFICATE.json');d=read('DEADLINE_SCAN.json');a=read('FROZEN_AUDIT.json')
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\begin{document}
\title{Spectral Orientation Before Phase Matching\\for Autonomous Joint Qubit Admission}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 6, 2026. ORCID: 0009-0002-5813-0724. Conditional derivation and finite computational exploration. Independent review and theorem-level novelty comparison pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We separate spectral-subspace orientation from deadline selection for a static two-local six-qubit joint-admission interface. On the existing planar ten-pair graph, an exact first-moment kernel permits 97 real Hermitian coordinates. A smoothed orientation objective and analytic simple-spectrum gradient are implemented and checked in 194 finite-difference columns. Four bounded fits increase the best spectral overlap sum to @S@ out of four. Nevertheless, exact Gaussian-integer backward-error enclosures prove complete half-diamond error strictly greater than $1/64$ for that frozen generator at every deadline and uniform norm rescaling. A bounded phase scan finds no admission endpoint. Orientation improvement is therefore not an operational resource improvement or a planar-family impossibility result. The note supplies a quantitative target for subsequent joint orientation--phase optimization, with the full physical norm and spectator domain retained.
\end{abstract}
\begin{IEEEkeywords}
Autonomous quantum control, spectral projector, two-local Hamiltonian, joint admission, certified error.
\end{IEEEkeywords}
\section{Contract and fixed resources}
Order the six physical qubits as $(A,O,u,v,w,z)$. The four mode qubits represent labels $(00,01,10,11)$. Define isometries from a four-dimensional logical input by
\begin{align}
E\ket{ab}&=\ket{ab}_{AO}\ket{\mathbf1_{00}}_M,\\
W\ket{ab}&=\ket{00}_{AO}\ket{\mathbf1_{ab}}_M.
\end{align}
The target is $e^{-iTH}E=e^{i\phi}W$ for a single common phase and arbitrary input, including input entangled with spectators. Mode excitation is required at the endpoint; it is not assumed invariant during transit. All candidate dynamics remain unitary.

The permitted pairs are
\begin{equation}
\{Au,Aw,Az,Ou,Ov,Ow,Oz,uw,uv,wz\}.
\end{equation}
This planar graph has six vertices and maximum degree four. Its 108 nonidentity support-at-most-two Hermitian Pauli terms include one-body fields. The exact first-moment constraints have rank eleven. The inherited integer kernel $B$ gives
\begin{equation}
H(\theta)=\sum_{k=1}^{108}(B\theta)_kP_k
=\sum_{a=1}^{97}\theta_aF_a.
\end{equation}
Real coefficients multiply Hermitian Paulis, including odd-$Y$ terms with imaginary matrix entries. The preceding release \cite{parent} established this kernel and an all-time spectral exclusion for its selected fits. We change the optimization objective, not the graph or carrier. No physical gravitational or gauge-theory equivalence is inferred from the finite operator graph.

\section{Orientation and phase are different obligations}
For distinct eigenvalues $\lambda$ with full eigenspace projectors $\Pi_\lambda$, put
\begin{equation}
a_\lambda=\operatorname{Tr}(W^\dagger\Pi_\lambda E),\qquad
S=\sum_\lambda |a_\lambda|\le4.
\end{equation}
An eigensolver's arbitrary basis within a degenerate eigenspace must not be assigned independent physical phases.
\begin{proposition}[All-time complete-channel witness]
For every deadline and common phase, the half-diamond error of the admission channel obeys
\begin{equation}
\epsilon(T)\ge\sqrt{1-(S/4)^2}.
\end{equation}
Exact admission requires $S=4$ and compatible spectral phases at one finite deadline.
\end{proposition}
\begin{proof}
Use a maximally entangled logical/reference input with reference dimension four. The actual and target pure outputs have overlap $\operatorname{Tr}(W^\dagger e^{-iTH}E)/4$, whose modulus is at most $S/4$. Their trace distance supplies a half-diamond lower bound. Also, Cauchy--Schwarz gives $|a_\lambda|\le\|\Pi_\lambda W\|_F\|\Pi_\lambda E\|_F$, and the sums of squared norms are each four. Equality in the summed bound forces $\Pi_\lambda W=e^{i\alpha_\lambda}\Pi_\lambda E$ on every active eigenspace. Exact evolution still requires
\begin{equation}
T\lambda+\phi+\alpha_\lambda\in2\pi\mathbb Z
\end{equation}
simultaneously for every active eigenvalue. These conditions together are sufficient by spectral decomposition.
\end{proof}
In particular, target error $\varepsilon=2^{-16}$ requires
\begin{equation}
S\ge4\sqrt{1-2^{-32}}.
\end{equation}
Thus the allowed orientation deficit is approximately $4.66\cdot10^{-10}$, not a conventional $10^{-5}$ optimization tolerance. This is necessary, not sufficient.

\section{Simple-spectrum objective and implementation}
Write $H=V\Lambda V^\dagger$ and $C=V^\dagger EW^\dagger V$. For a resolved simple spectrum, $a_n=C_{nn}$. We minimize
\begin{equation}
f_\tau=4-\sum_{n=1}^{64}\sqrt{|a_n|^2+\tau^2},
\qquad\tau=10^{-10}.
\end{equation}
The smoothing changes the objective by at most $64\tau=6.4\cdot10^{-9}$. This exceeds the ultimate required deficit and therefore cannot certify the target. Reported $S$ is always unsmoothed. The search is scale invariant; normalizing coordinate vectors prevents meaningless growth but does not constitute a physical norm constraint.

Let $A^{(a)}=V^\dagger F_aV$. Projector differentiation yields
\begin{equation}
\partial_a a_n=\sum_{r\ne n}
\frac{A^{(a)}_{nr}C_{rn}+A^{(a)}_{rn}C_{nr}}
{\lambda_n-\lambda_r}.
\end{equation}
Consequently,
\begin{equation}
\partial_a f_\tau=-\operatorname{Re}\sum_n
\frac{\overline{a_n}\,\partial_a a_n}{\sqrt{|a_n|^2+\tau^2}}.
\end{equation}
The formula follows from $\partial_a\Pi_n=\sum_{r\ne n}(\Pi_rF_a\Pi_n+\Pi_nF_a\Pi_r)/(\lambda_n-\lambda_r)$. It is not used at unresolved degeneracy: the implementation stops when the smallest gap is below $10^{-10}\max(1,\|\Lambda\|)$. A degenerate-family continuation requires grouped-projector calculus instead.

Central differences at two resolved probes check all 97 columns each, with step $2\cdot10^{-7}$. The largest discrepancy is @GRAD@. These are numerical derivative checks, not rigorous enclosures of the optimizer.

\section{Bounded search and candidate certification}
Four seeded BFGS starts, each capped at 250 iterations, use the previous selected fit, a perturbed fit, and two random vectors. All four hit the iteration cap; none is a certified optimum. Their unsmoothed overlap sums are
\begin{equation}
3.999121,\quad3.868023,\quad3.986268,\quad3.831921.
\end{equation}
The best orientation deficit is @DEFICIT@. Its sampled minimum eigenvalue gap is approximately $1.91\cdot10^{-4}$ before physical normalization. Extra independently tunable Pauli components remain charged to hardware realizability.

Freeze the best binary64 coordinates as exact binary fractions, then assemble coefficients through integer $B$. The replay verifies 108 coefficient identities plus ten structural checks, including exact first moments, Hermiticity, and graph locality. Set $L=\sum_k|c_k|$; $H/L$ has full 64-dimensional norm at most one by the exact triangle inequality. Here $L\simeq2.622334$, not a low-energy or marginal norm.

The spectral enclosure treats approximate eigenvectors and eigenvalues solely as dyadic inputs. Exact Gaussian-integer Gram and eigen residuals bound the distance to a unitary eigenbasis and the Hermitian backward error. An enclosed grid gap greater than twice that error identifies the true simple projectors. Integer square-root bounds then enclose all 64 overlap moduli. The resulting rational upper bound is
\begin{equation}
S<S_{\rm up}\simeq@SUP@,
\end{equation}
with 73 exact checks. Its exact rational squared error floor exceeds $(1/64)^2$. Therefore this frozen candidate fails the $2^{-16}$ task at \emph{every} deadline, including uniform full-norm scaling and scalar energy shifts. The decimal radical diagnostic is @FLOOR@; it is a lower bound, not the exact channel distance. There are 191 exact checks in total.

\section{Finite phase scan and next lifecycle gate}
A separate numerical scan uses 65,537 equally spaced deadlines up to 4096 under sampled centered unit norm, then refines 64 selected intervals. It is not exhaustive or enclosed. Its best sampled deadline is @TIME@, with Choi trace error @CHOI@ and common-phase isometry operator residual @RESID@. The same sampled point corresponds to time approximately @LTIME@ for the conservative $H/L$ implementation, up to an irrelevant scalar phase. This scan supplies no successful endpoint and cannot circumvent the all-time orientation exclusion.

The next gate is a \emph{joint} orientation--phase continuation retaining all four coherent columns. Reduce or rigorously debit smoothing, use grouped projectors if gaps close, enforce a declared finite deadline and full-spectrum norm budget, and freeze every promising fit for interval certification. Keep the original endpoint fit as an independent baseline: improved orientation has not improved the operational endpoint here. Only after native joint admission closes should the compiler connect to the 16-mode SWAP core. A matched resource improvement or lower bound across competing architectures remains the publication breakthrough target. No family no-go, hardware advantage, or full autonomous refresh is established. Independent review is pending; physical promotion remains zero.
\begin{thebibliography}{1}
\bibitem{parent} B. W. Mayes, ``Complex Hermitian Optimization and Spectral Alignment for Joint Qubit Admission,'' MQM development note v0.1, Oct. 5, 2026, accompanying immutable replay release. DOI not assigned; independent review pending.
\end{thebibliography}
\end{document}
'''
values={'S':f"{s['best']['S']:.9f}",'DEFICIT':f"{s['best']['orientation_deficit']:.6g}",'GRAD':f"{g['max_absolute_error']:.3g}",'SUP':f"{c['overlap_upper_decimal']:.9f}",'FLOOR':f"{c['floor_decimal_diagnostic']:.6f}",'TIME':f"{d['best_sampled_deadline']:.3f}",'CHOI':f"{d['Choi_trace_error']:.6f}",'RESID':f"{d['isometry_operator_residual']:.6f}",'LTIME':f"{d['conservative_unit_norm_deadline_diagnostic']:.3f}"}
for key,value in values.items():tex=tex.replace('@'+key+'@',value)
name='MQM_SPECTRAL_ALIGNMENT_ADMISSION_IEEE_A4_v0.1'
(M/(name+'.tex')).write_text(tex)
for k in range(2):
    proc=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,capture_output=True,text=True)
    (R/'results'/('PDF_BUILD_'+str(k)+'.txt')).write_text(proc.stdout+proc.stderr)
    assert proc.returncode==0,proc.stdout[-3000:]
doc=fitz.open(M/(name+'.pdf'));log=(M/(name+'.log')).read_text()
for i,p in enumerate(doc):p.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/('PAGE_'+str(i+1)+'.png'))
qa={'pages':len(doc),'A4':all(abs(p.rect.width-595.276)<1 and abs(p.rect.height-841.89)<1 for p in doc),'actual_IEEEtran':True,'class_options':'journal,a4paper,10pt','two_columns':True,'no_overfull':'Overfull' not in log,'no_unresolved_references':'undefined' not in log,'visual_review':'pending'}
(R/'results'/'PDF_QA.json').write_text(json.dumps(qa,indent=2));print(qa)
