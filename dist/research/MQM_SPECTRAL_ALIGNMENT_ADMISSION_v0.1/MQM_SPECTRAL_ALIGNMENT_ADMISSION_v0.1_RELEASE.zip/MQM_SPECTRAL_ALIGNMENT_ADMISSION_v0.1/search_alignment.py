"""Bounded spectral orientation search; no family or endpoint certificate."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction
import json,time
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import minimize, minimize_scalar
from complex_objective import load_model
R=Path(__file__).resolve().parent
source,labels,B,P,F,E,W=load_model()

def alignment(theta, smoothing=1e-10, gradient=True):
    H=np.einsum('a,aij->ij',theta,F)
    lam,V=eigh(H)
    gap=float(np.min(np.diff(lam)))
    if gap < 1e-10*max(1.,np.max(np.abs(lam))):
        raise ValueError('Unresolved spectral degeneracy: simple-projector gradient unavailable')
    C=(V.conj().T@E)@(W.conj().T@V)
    a=np.diag(C)
    r=np.sqrt(abs(a)**2+smoothing**2)
    cost=4-float(np.sum(r))
    if not gradient:return cost,lam,V,a,gap
    A=np.einsum('ia,kij,jb->kab',V.conj(),F,V,optimize=True)
    denom=lam[:,None]-lam[None,:]
    np.fill_diagonal(denom,np.inf)
    da=np.sum((A*C.T[None,:,:]+A.transpose(0,2,1)*C[None,:,:])/denom[None,:,:],axis=2)
    grad=-np.real(np.sum(da*a.conj()[None,:]/r[None,:],axis=1))
    return cost,grad

def freeze(theta):
    tq=[Fraction(float(x)) for x in theta]
    c=[sum((int(b)*q for b,q in zip(row,tq)),Fraction(0)) for row in B]
    return {l:str(q) for l,q in zip(labels,c)}

def main():
    rng=np.random.default_rng(20261006)
    parent=json.loads((R/'PARENT_SEARCH.json').read_text())['best']
    print('parent keys',list(parent),flush=True)
    theta=np.array([float(Fraction(q)) for q in parent['kernel_coordinates_exact']])
    theta/=np.linalg.norm(theta)
    probes=[theta,theta+.03*rng.normal(size=97)]
    errors=[]
    for x in probes:
        _,g=alignment(x)
        h=2e-7
        for k in range(97):
            e=np.zeros(97);e[k]=h
            numerical=(alignment(x+e,gradient=False)[0]-alignment(x-e,gradient=False)[0])/(2*h)
            errors.append(abs(numerical-g[k]))
    assert max(errors)<2e-6,max(errors)
    (R/'results'/'GRADIENT_RECEIPT.json').write_text(json.dumps({'columns_checked':194,'max_absolute_error':max(errors),'step':2e-7,'simple_spectrum_only':True,'smoothing':1e-10,'smoothing_bias_upper':64e-10},indent=2))
    runs=[]
    starts=[theta,theta+.12*rng.normal(size=97),rng.normal(size=97),rng.normal(size=97)]
    for i,x in enumerate(starts):
        x=x/np.linalg.norm(x)
        start=time.monotonic()
        fit=minimize(alignment,x,jac=True,method='BFGS',options={'maxiter':250,'gtol':1e-8})
        t=fit.x/np.linalg.norm(fit.x)
        _,lam,V,a,gap=alignment(t,gradient=False)
        S=float(np.sum(abs(a)))
        run={'run':i,'success':bool(fit.success),'message':str(fit.message),'iterations':int(fit.nit),'evaluations':int(fit.nfev),'seconds':time.monotonic()-start,'S':S,'orientation_deficit':4-S,'simple_minimum_gap':gap,'theta':t.tolist(),'Pauli_coefficients_exact':freeze(t)}
        runs.append(run)
        print({k:run[k] for k in ('run','iterations','S','orientation_deficit','seconds')},flush=True)
        (R/'results'/'ALIGNMENT_SEARCH.json').write_text(json.dumps({'seed':20261006,'starts':4,'iteration_cap':250,'objective':'4-sum sqrt(abs(a_n)^2+1e-20)','bias_upper':64e-10,'scope':'Finite numerical exploration of simple spectra, not a family exclusion. No endpoint certified.','runs':runs,'best':max(runs,key=lambda r:r['S'])},indent=2))
    best=max(runs,key=lambda r:r['S'])
    _,lam,V,a,_=alignment(np.array(best['theta']),gradient=False)
    radius=(lam[-1]-lam[0])/2
    eigenvalues=(lam-(lam[-1]+lam[0])/2)/radius
    def loss(t):return 1-abs(np.sum(a*np.exp(-1j*t*eigenvalues))/4)**2
    grid=np.linspace(0,4096,65537)
    losses=np.array([loss(t) for t in grid])
    candidates=np.argsort(losses)[:64]
    fits=[minimize_scalar(loss,bounds=(max(0,grid[k]-.0625),min(4096,grid[k]+.0625)),method='bounded') for k in candidates]
    fit=min(fits,key=lambda x:x.fun)
    UE=V@(np.exp(-1j*fit.x*eigenvalues)[:,None]*(V.conj().T@E))
    phase=np.angle(np.trace(W.conj().T@UE))
    residual=float(np.linalg.norm(UE-np.exp(1j*phase)*W,2))
    receipt={'status':'NUMERICAL bounded deadline scan, not exhaustive or certified','sampled_centered_full_norm':float(radius),'unit_sampled_norm_time_cap':4096,'grid_count':65537,'refined_intervals':64,'best_sampled_deadline':float(fit.x),'Choi_trace_error':float(np.sqrt(max(0,fit.fun))),'isometry_operator_residual':residual,'phase':float(phase),'comparison':'The spectral orientation ceiling applies at every deadline; scanning cannot defeat it.'}
    (R/'results'/'DEADLINE_SCAN.json').write_text(json.dumps(receipt,indent=2))
    print(receipt,flush=True)
if __name__=='__main__':main()
