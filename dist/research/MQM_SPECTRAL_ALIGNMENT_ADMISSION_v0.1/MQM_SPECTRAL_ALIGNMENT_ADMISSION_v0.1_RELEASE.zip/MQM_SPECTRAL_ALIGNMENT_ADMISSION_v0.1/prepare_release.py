"""Freeze verified note, exact receipts and reproducible search."""
from pathlib import Path
import argparse,json,hashlib,zipfile,platform
import numpy,scipy,networkx,fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args()
assert args.visual_review_confirmed
def read(n):return json.loads((R/n).read_text())
def write(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
qa=read('results/PDF_QA.json');assert qa['A4'] and qa['actual_IEEEtran'] and qa['no_overfull'] and qa['no_unresolved_references']
qa['visual_review']='PASSED: both final page renders inspected; readable equations, IEEE two columns, no clipping or overlap'
write('results/PDF_QA.json',qa)
s=read('results/ALIGNMENT_SEARCH.json');c=read('results/SPECTRAL_CERTIFICATE.json');a=read('results/FROZEN_AUDIT.json');g=read('results/GRADIENT_RECEIPT.json')
assert len(s['runs'])==4 and c['strict_dyadic_channel_floor']=='1/64'
assert c['exact_count']+a['exact_count']==191 and g['columns_checked']==194
parent=R.parent/'MQM_COMPLEX_PLANAR_ADMISSION_v0.1_RELEASE.zip'
write('INPUT_ANCHORS.json',{'parent_library_zip_id':'libfile_9f278b22aa808191bb8fef3066afaea9','parent_library_pdf_id':'libfile_d64d02f991b881918fb663b20b107dcc','parent_zip_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'parent_immutable':True,'author':'Benjamin Walker Mayes','orcid':'0009-0002-5813-0724','source_boundary':'Copied integer kernel and exact parent selected fit; current-source-only mathematical continuation.'})
write('CLAIM_REGISTER.json',{'spectral_orientation_gradient':'DERIVED, simple resolved spectrum; numerical implementation checked in 194 columns','finite_search':{'status':'NUMERICAL, not global optimality','runs':4,'iteration_cap':250,'best_S':s['best']['S'],'target_orientation_necessary':'S>=4 sqrt(1-2^-32)','smoothing_bias':'64*10^-10=6.4e-9, too large to certify target; unsmoothed S reported'},'frozen_generator':{'status':'EXACT ENCLOSED / AUTO_LOCK SCOPED','exact_checks':191,'all_time_half_diamond_error':'strictly greater than 1/64','scope':'One frozen generator, all deadlines, arbitrary spectators, scalar shifts and uniform scaling. Not a family obstruction.'},'resources':{'physical_qubits':6,'allowed_pairs':10,'planar':True,'maximum_degree':4,'full_dimension':64,'logical_dimension':4,'full_norm_certificate':'H/L, L=sum abs(exact Pauli coefficients), full norm<=1'},'joint_admission':'OPEN','phase_scan':'NUMERICAL bounded grid and local refinements, no exhaustiveness or certified endpoint','operational_resource_improvement':False,'physical_promotion':0,'independent_review':'pending','theorem_level_novelty_comparison':'pending'})
write('NEXT_GATE.json',{'status':'OPEN, subsequent bounded joint orientation-phase continuation','contract':'All four coherent admission columns, one common phase, arbitrary spectators; no postselection','objective':'0.5||exp(-i T H(theta))E-exp(i phi)W||_F^2 plus a declared orientation penalty; keep the preceding endpoint fit as an independent baseline','constraints':['Keep six qubits and declared ten-pair graph initially.','Declare finite deadline cap before running.','Enforce full-spectrum norm<=1 on all 64 dimensions, with scalar shift accounted explicitly.','Charge all coupling components and freeze exact binary-rational coefficients.','Reduce smoothing below required orientation deficit or debit bias rigorously.','Use grouped true eigenspace projectors if eigenvalues merge; arbitrary eigenvector phases are not allowed.'],'completion_gate':'Certified complete half-diamond error<=2^-16 over a nonzero readout window and full norm<=1, not optimizer loss alone','failure_policy':'Only frozen-candidate exclusions, unless an independent family-wide proof is supplied; finite search failure does not require changing graph or carrier.','downstream':'Do not connect to 16-mode SWAP core or claim physical advantage before admission closes.'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'networkx':networkx.__version__,'pymupdf':fitz.VersionBind})
(R/'README.txt').write_text('''Spectral Orientation Before Phase Matching for Autonomous Joint Qubit Admission
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM note v0.1, 2026-10-06

RESULT
Four bounded 97-coordinate spectral fits improved S to 3.9991205292960474 / 4.
An exact enclosure nevertheless excludes this frozen best generator at EVERY
deadline: complete half-diamond error > 1/64, versus target 1/65536.
The bounded phase scan also supplies no successful endpoint. Orientation gains
are not operational resource gains. No planar-family no-go is established.
191 exact checks and 194 finite-difference derivative column checks.
Independent review and theorem-level novelty comparison pending. Physical 0.

CERTIFICATE REPLAY (numpy, scipy, networkx)
  python3 verify_frozen.py
  python3 spectral_certificate.py
These consume frozen receipts and do not require re-optimization. Exact
Gaussian-integer residuals, dyadic square-root enclosures and resolved spectral
gaps certify the all-time lower bound. H/L has full norm<=1 by exact Pauli
triangle inequality. Include every physical sector, not a low-energy slice.

OPTIONAL RE-OPTIMIZATION (overwrites numerical search receipts)
  python3 search_alignment.py
  python3 verify_frozen.py
  python3 spectral_certificate.py
Four seeded starts, 250 iterations each, simple-spectrum guard. Library versions
can change finite optimizer results. Coordinates are normalized for numerical
scale only; physical norm is separately audited. Grouped projectors are required
at degeneracy. Smoothing bias is larger than final target tolerance and cannot
certify an endpoint. Finite scan is not exhaustive in time.

PDF REBUILD (PyMuPDF and pdflatex)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png files before freezing:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two-column PDF; class license bundled.
Read NEXT_GATE.json for scoped joint orientation-phase continuation.
Parent release remains immutable. Hash manifest covers every distributed file.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'pages':qa['pages'],'exact_checks':191}))
