from pathlib import Path
import json,math
import numpy as np
from scipy.sparse.linalg import expm_multiply
P=Path(__file__).resolve().parent
model=P/'inputs/response_model.py';ns={'__file__':str(model)};exec(model.read_text(),ns)
rows=[];w=2.**-16;U=16+w
for M in [4,8]:
 H,H1,n=ns['models'](M);seed=np.zeros((H.shape[0],M),complex);seed[3+np.arange(M),np.arange(M)]=1;psi=np.zeros(M+4,complex);psi[0]=1
 def calc(t):
  W=expm_multiply(-1j*t*H,seed,traceA=-1j*t*H.diagonal().sum());u=expm_multiply(-1j*t*H1,psi,traceA=-1j*t*H1.diagonal().sum());cold=np.zeros((8,8),complex);cold[:4,:4]=np.outer(u[:4],u[:4].conj());cold[4,4]=np.vdot(u[4:],u[4:]);D=ns['retained'](W,n,M)-n.sum()*cold
  return float(np.vdot(u[:4],u[:4]).real),D
 q,D=calc(16);G=float(np.linalg.norm(H1[3,4:]));V=float(np.dot(H1[3,4:]**2,n));qb=2*G*math.sqrt(q)*w+G*G*w*w;db=4*V*(64*U*U+U)*w
 for t in [16-w,16+w]:
  qt,Dt=calc(t);change=float(abs(np.linalg.eigvalsh(Dt-D)).sum()/2);assert qt-q<=qb+1e-12 and change<=db+1e-12
  rows.append({'M':M,'t':t,'q_change':qt-q,'q_variation_majorant':qb,'half_trace_response_change':change,'response_variation_majorant':db})
(P/'results/CONTINUITY_CONTROLS.json').write_text(json.dumps({'status':'SIMULATED same-agent finite controls','rows':rows,'external_review':False},indent=2)+'\n');print(json.dumps(rows,indent=2))
