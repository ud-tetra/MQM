from fractions import Fraction as F
from pathlib import Path
import json
P=Path(__file__).resolve().parent
T=F(16);V=F(64,31457265);E0=F(3,2**18)+F(1,2**128);S2=F(3,2**26)
x16=F(12433696189517,58512905602490430)
assert E0<F(49,2**22)
rows=[]
for k in range(15,31):
 w=F(1,2**k);U=T+w
 dq=F(49,1024)*w+49*w*w
 d2=4*V*(64*U*U+U)*w
 xu=x16+6*V*(T*w+w*w/2)
 rem=xu*xu/(2*(1-xu));assert xu<1
 total=E0+dq+S2+d2+rem
 rows.append({'k':k,'halfwidth':str(w),'halfwidth_relative_to_T':str(w/T),'cold_population_variation':str(dq),'response_variation':str(d2),'higher_order_uniform_bound':str(rem),'uniform_total_numerator':str(total.numerator),'uniform_total_denominator':str(total.denominator),'diagnostic_total_decimal':float(total),'target_pass':total<F(1,2**16),'higher_order_below_2^-25':rem<F(1,2**25)})
chosen=next(r for r in rows if r['target_pass']);assert chosen['k']==16
assert F(int(chosen['uniform_total_numerator']),int(chosen['uniform_total_denominator']))<F(15,2**20)<F(1,2**16)
res={'status':'DERIVED conditional uniform retention/timing window','window':'[16-2^-16,16+2^-16] model time units','post_deadline_hold':'2^-16 model time units','total_width':'2^-15 model time units','relative_halfwidth':'2^-20 of deadline','uniform_retained_error_upper':'15/2^20','target':'2^-16','selection':'Largest passing halfwidth in declared dyadic list; not maximal physical window','coarse_bound_k15':'Insufficient certificate, not physical failure','physical_promotion':0,'external_independent_review':'OPEN','rows':rows}
(P/'results/WINDOW_CERTIFICATE.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:v for k,v in res.items() if k!='rows'},indent=2))
