MQM finite timing/retention window v0.1,7 October2026.
Replay: python3 audit_window.py; python3 control_continuity.py. Exact audit uses standard-library Fractions. Finite controls use numpy/scipy. PDF: python3 build_pdf.py (pdflatex/Poppler).
Uniform window conclusion is conditional on inherited point-time certificate, arithmetic model and Gaussian/continuum assumptions. Model time is not device time. The finite post-deadline interval is not permanent latching or bath renewal.
review/EXTERNAL_REVIEW_PACKET.md is ready for an outside reviewer. No review was performed or message sent. Dependency bundles and SHA256 anchors are included. Physical promotion0.
