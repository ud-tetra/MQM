"""Directed interval cold-latch readout bound using scaled Taylor exponential."""
from pathlib import Path
from fractions import Fraction
import json,math
from mpmath import iv
iv.dps=80
R=Path(__file__).resolve().parent;P=json.loads((R/'PROTOCOL.json').read_text())
def rat(x):f=Fraction(x);return iv.mpf(f.numerator)/f.denominator
def mul(A,B):return [[sum(A[i][k]*B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def eye():return [[rat(int(i==j)) for j in range(3)] for i in range(3)]
rows=[]
for kap in P['kappa_scan']:
 G=2*iv.sqrt(rat(2));lam=iv.sqrt(G*kap)/2
 A=[[rat(0),rat(-1),rat(0)],[rat(1),rat(0),-lam],[rat(0),lam,-rat(Fraction(kap,2))]]
 # Interval covers the complete original window; coefficients keep exact declared radicals.
 tw=iv.mpf([rat(Fraction(16)-Fraction(1,1024)).a,rat(Fraction(16)+Fraction(1,1024)).b])
 scale=14;h=tw/2**scale;B=[[x*h for x in row] for row in A]
 b=(1+lam+kap/2)*h
 V=eye();term=eye();order=32
 for j in range(1,order+1):
  term=mul(term,B);term=[[x/j for x in row] for row in term]
  V=[[V[i][k]+term[i][k] for k in range(3)] for i in range(3)]
 remainder=iv.exp(b)*b**(order+1)/math.factorial(order+1)
 rad=iv.mpf([-remainder.b,remainder.b])
 V=[[x+rad for x in row] for row in V]
 for _ in range(scale):V=mul(V,V)
 # q is the norm squared of the real no-jump amplitudes launched at m0.
 # Interval squaring as x*x is conservative even across zero.
 amps=[V[i][0] for i in range(3)]
 q=sum(a*a for a in amps);reduced=sum(a*a for a in amps[:2])
 passed=q.b<rat(Fraction(1,65536)).a
 rows.append({'kappa':kap,'full_error_interval':str(q),'full_error_upper_float_diagnostic':float(q.b),'clock_error_upper_float_diagnostic':float(reduced.b),'passed_strict_full_target':bool(passed),'window_center':16,'half_width_exact':'1/1024','method':'80-digit directed interval arithmetic; Taylor order32, scale 2^14, analytic infinity-norm remainder then interval squaring'})
res={'status':'INTERVAL VERIFIED conditional zero-reverse readout-window calculation','rows':rows,'scope':'Fixed eligible product m0 launch; native qutrit plus auxiliary qubit retained, bath traced, identity data, zero reverse jumps. Not full completion-gated circuit, bath microscopic validity or hardware.','physical_promotion':0}
(R/'results/COLD_INTERVAL_CERTIFICATE.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
