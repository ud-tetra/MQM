MQM MICROSCOPIC LATCH v0.1
Conditional native-qutrit and damped-auxiliary-qubit cell; physical promotion0.

Replay in order:
 python3 audit_latch.py
 python3 certify_cold.py
 python3 certify_reverse.py
PDF: python3 build_pdf.py; inspect PAGE_*.png.
IEEEtran A4 journal two-column. Dependencies in requirements.txt; pdflatex external.

Evidence: 24 exact checks; 262 binary64 checks; directed interval full-window cold bounds.
Cold kappa2 FAILS; kappa8,32,128 PASS original |t-16|<=1/1024 window.
Derived selected kappa8, r<=2^-24 bound:2147614721/281474976710656 <1/65536.
Bath is traced; explicit auxiliary and arbitrary spectator data retained.
Identity-on-data and trusted eligibility are assumptions; no full completion compiler.
Native pair-local interaction is generally weight3 after displayed qubit encoding.
Reverse jumps break exact dark-ground retention while leaving ideal factorized data intact.
No physical bath validation, temperature calibration, hardware result or quantum advantage.
Original numerical scan and failed configuration preserved; further range selection disclosed.
IEEEtran redistributed under LPPL; license retained.
