"""Native qutrit plus damped qubit latch. Conditional cell, not full compiler."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction
import json,hashlib,math
import numpy as np
import sympy as s
from scipy.linalg import expm
R=Path(__file__).resolve().parent
P={'version':'0.1','status':'FROZEN before outcome evaluation','subsystems':{'C':'native qutrit m,e,d','R':'auxiliary physical two-level reservoir interface','B':'stored logical data and arbitrary spectator; identity coupling assumed','external_bath':'Markov bath traced, not modeled as finite closed system'},'eligible_ingress':'product |m,0>; trusted prior completion and occupancy eligibility; coherent cross-sector gating NOT compiled','g':1,'Gamma_effective_target':'2sqrt(2)','kappa_scan':[2,8,32,128],'lambda_rule':'sqrt(Gamma*kappa)/2, disclosed engineering matching','reverse_ratio_scan':['0','1/1048576','1/65536','1/4096'],'times':[4,16,64,1024],'readout_center':16,'readout_half_width':'1/1024','target_full_retained_half_diamond':'1/65536 to |d,0> tensor identity_data for fixed product launch; bath traced','reverse_model':'J_down=sqrt(kappa)I_C sigma_R-;J_up=sqrt(kappa*r)I_C sigma_R+;r phenomenological, not calibrated material temperature','H':'g(|m><e|+h.c.) tensor I_R + lambda(|d><e| tensor sigma_R+ + h.c.)','spectator_assumption':'all Hamiltonian/jump terms identity on data; H_store=0','model_locality':'one qutrit-qubit interaction pair; qubit dilation becomes generally weight3','finite_bandwidth_scope':'explicit damped two-level auxiliary; not an exact harmonic continuum pseudomode; reduced C dynamics has memory','norm_budget':'centered interaction-picture ||H_CR||; reservoir rates charged separately; lab free energies excluded and disclosed','numerical_precision':'binary64','numerical_tolerance':2e-10,'thermal_floor_tolerance':2e-9,'physical_promotion':0,'frozen_claim_rules':'cold interval bounds exact-scoped; reverse stationary identities exact-model; finite-time numerics simulated; hardware and full compiler OPEN'}
(R/'PROTOCOL.json').write_text(json.dumps(P,indent=2))
exact=[];num=[]
def ck(n,v,ledger):assert bool(v),n;ledger.append(n)
g,lam,kap=s.symbols('g lam kap',positive=True);r=s.symbols('r',nonnegative=True)
K=s.Matrix([[0,1,0],[1,0,0],[0,0,0]]);S=s.zeros(3);S[2,1]=1
sm=s.Matrix([[0,1],[0,0]]);sp=sm.T;I3=s.eye(3);I2=s.eye(2)
H=g*s.kronecker_product(K,I2)+lam*(s.kronecker_product(S,sp)+s.kronecker_product(S.T,sm))
D=s.kronecker_product(I3,sm);U=D.T;Pd0=s.zeros(6);Pd0[4,4]=1
ck('Hermitian pair Hamiltonian',H==H.T,exact)
x=s.symbols('x');ck('full six-state spectrum',s.factor(H.charpoly(x).as_expr()-x*x*(x*x-g*g)*(x*x-g*g-lam*lam))==0,exact)
ck('cold absorbing state Hamiltonian',H*Pd0==s.zeros(6),exact)
ck('cold jump annihilates target',D*Pd0==s.zeros(6),exact)
ck('reverse jump leaves dark-ground target',U*Pd0!=s.zeros(6),exact)
weights=[r,r*r,r,r*r,1,r];Z=(1+r)*(1+2*r);rho=s.diag(*weights)/Z
def diss(J,v):C=J.T*J;return J*v*J.T-(C*v+v*C)/2
ck('thermal candidate trace one',s.simplify(s.trace(rho)-1)==0,exact)
ck('thermal candidate Hamiltonian commutation',H*rho-rho*H==s.zeros(6),exact)
ck('thermal candidate jump stationarity',s.simplify(diss(D,rho)+r*diss(U,rho))==s.zeros(6),exact)
ck('stationary reduced clock failure',s.simplify(1-rho[4,4]-rho[5,5]-2*r/(1+2*r))==0,exact)
ck('stationary full ground-target failure',s.simplify(1-rho[4,4]-(3*r+2*r*r)/Z)==0,exact)
# Commuting with R ladder algebra forces X=X_C tensor I. These remaining generators force scalar X_C.
xs=s.symbols('x0:9');X=s.Matrix(3,3,xs)
comm=[]
for O in [S,S.T,K]:comm.extend(list(X*O-O*X))
mat,_=s.linear_eq_to_matrix(comm,xs)
ck('remaining qutrit commutant scalar',len(mat.nullspace())==1 and s.Matrix(3,3,mat.nullspace()[0])==s.eye(3),exact)
N=s.diag(1,1,0);NR=s.diag(0,1);Ntot=s.kronecker_product(N,I2)+s.kronecker_product(I3,NR)
ck('interaction conserves declared energy quantum',H*Ntot-Ntot*H==s.zeros(6),exact)
ck('downward bath energy commutator',Ntot*D-D*Ntot==-D,exact)
ck('upward bath energy commutator',Ntot*U-U*Ntot==U,exact)
# Physical qubit dilation e=01,d=10; this is a three-qubit coupling to auxiliary R.
qp=s.Matrix([[0,0],[1,0]]);qm=qp.T
Senc=s.kronecker_product(qp,qm)
ck('two-qubit encoded e-to-d operator',Senc[2,1]==1 and sum(abs(v) for v in Senc)==1,exact)
px=s.Matrix([[0,1],[1,0]]); py=s.Matrix([[0,-s.I],[s.I,0]])
exchange=s.kronecker_product(Senc,qp)+s.kronecker_product(Senc.T,qm)
ck('dilated exchange nonzero weight3 Pauli coefficient',s.trace(s.kronecker_product(px,px,px)*exchange)/8==s.Rational(1,4),exact)
ck('dilated exchange exact Pauli expansion',exchange==(s.kronecker_product(px,px,px)+s.kronecker_product(py,py,px)-s.kronecker_product(py,px,py)+s.kronecker_product(px,py,py))/4,exact)
for O in [s.Matrix([[0,1],[1,0]]),s.diag(1,-1)]:
 ck('spectator Hamiltonian factor identity '+str(O),s.kronecker_product(H,s.eye(2))*s.kronecker_product(s.eye(6),O)==s.kronecker_product(s.eye(6),O)*s.kronecker_product(H,s.eye(2)),exact)
 ck('spectator jump factor identity '+str(O),s.kronecker_product(D,s.eye(2))*s.kronecker_product(s.eye(6),O)==s.kronecker_product(s.eye(6),O)*s.kronecker_product(D,s.eye(2)),exact)
# Necessary stationary target conditions, exact rational tests.
eps=s.Rational(1,65536)
for rv in [s.Rational(1,2**20),s.Rational(1,2**16),s.Rational(1,2**12)]:
 full=s.simplify((3*rv+2*rv*rv)/((1+rv)*(1+2*rv)))
 ck('thermal floor decision '+str(rv),(full<eps)==(rv==s.Rational(1,2**20)),exact)
G=2*math.sqrt(2);K=np.array(K,float);S=np.array(S,float);down=np.kron(np.eye(3),np.array(sm,float));up=down.T
init=np.diag([1.,0,0,0,0,0]);target=np.array(Pd0,float);c_target=np.diag([0.,0,1.]);cm=np.diag([1.,0,0])
def gen(h,jumps):
 d=len(h);I=np.eye(d);out=-1j*(np.kron(I,h)-np.kron(h.T,I))
 for j in jumps:
  C=j.conj().T@j;out+=np.kron(j.conj(),j)-.5*(np.kron(I,C)+np.kron(C.T,I))
 return out

def evol(L,rho,t):return (expm(L*t)@rho.reshape(-1,order='F')).reshape(rho.shape,order='F')
def td(a,b):v=(a-b+(a-b).conj().T)/2;return float(sum(abs(np.linalg.eigvalsh(v)))/2)
def ptr(v):return np.einsum('arbr->ab',v.reshape(3,2,3,2))
hideal=K;li=np.sqrt(G)*S;idealgen=gen(hideal,[li])
rows=[]
for k in P['kappa_scan']:
 l=math.sqrt(G*k)/2;h=np.kron(K,np.eye(2))+l*(np.kron(S,np.array(sp,float))+np.kron(S.T,np.array(sm,float)))
 norm=math.sqrt(1+l*l)
 ck('full norm numeric '+str(k),abs(np.linalg.norm(h,2)-norm)<1e-12,num)
 for rf in P['reverse_ratio_scan']:
  rv=float(Fraction(rf));Lio=gen(h,[math.sqrt(k)*down,math.sqrt(k*rv)*up])
  steady=np.diag([rv,rv*rv,rv,rv*rv,1,rv])/((1+rv)*(1+2*rv))
  ck('stationarity numerical '+str((k,rf)),np.linalg.norm(Lio@steady.reshape(-1,order='F'))<1e-10,num)
  for t in P['times']:
   state=evol(Lio,init,t);clock=ptr(state);ideal=evol(idealgen,cm,t)
   ck('trace '+str((k,rf,t)),abs(np.trace(state)-1)<2e-10,num)
   ck('positivity '+str((k,rf,t)),min(np.linalg.eigvalsh(state))>-2e-10,num)
   ck('reduced trace '+str((k,rf,t)),abs(np.trace(clock)-1)<2e-10,num)
   if rv==0:
    a=np.array([[0,-1,0],[1,0,-l],[0,l,-k/2.]])
    v=expm(a*t)@np.array([1.,0,0]);q=float(v@v)
    ck('cold no-jump full error '+str((k,t)),abs(td(state,target)-q)<2e-10,num)
    ck('cold reduced error '+str((k,t)),abs(td(clock,c_target)-float(v[0]**2+v[1]**2))<2e-10,num)
   if t==1024:ck('long-time stationary convergence '+str((k,rf)),td(state,steady)<2e-9,num)
   rows.append({'kappa':k,'lambda':l,'reverse_ratio_exact':rf,'time':t,'interaction_norm':norm,'unit_norm_time':t*norm,'full_retained_error_to_d0':td(state,target),'clock_error_to_d':td(clock,c_target),'clock_channel_deviation_from_ideal':td(clock,ideal),'auxiliary_excitation_probability':float(np.trace(state.reshape(3,2,3,2)[:,1,:,1]).real),'stationary_full_error':1-1/((1+rv)*(1+2*rv)),'stationary_clock_error':2*rv/(1+2*rv)})
# Explicit Bell retention at representative finite-temperature point; full dynamics factor identity.
bell=np.array([1,0,0,1])/math.sqrt(2);br=np.outer(bell,bell)
state=evol(gen(h,[math.sqrt(k)*down,math.sqrt(k*float(Fraction('1/4096')))*up]),init,16)
full=np.kron(state,br)
reduced=np.einsum('abac->bc',full.reshape(6,4,6,4))
ck('Bell spectator remains intact',td(reduced,br)<2e-10,num)
# Eligibility-off launch: g=0, lambda unchanged, no e population even with reverse jumps.
hclosed=l*(np.kron(S,np.array(sp,float))+np.kron(S.T,np.array(sm,float)))
closed=evol(gen(hclosed,[math.sqrt(k)*down,math.sqrt(k/4096)*up]),init,64)
ck('blocked ingress has no false clock capture',abs(np.trace(closed[4:6,4:6]))<1e-12,num)
res={'status':'EXACT algebra and stationary identities; SIMULATED finite-time microscopic model','exact_count':len(exact),'exact_checks':exact,'numerical_count':len(num),'numerical_checks':num,'rows':rows,'physical_promotion':0,'half_diamond_scope':'Fixed product CR launch and identity-on-data channel; preparation channel error equals trace distance of CR state, arbitrary data spectators. Original bath traced. No eligible-sector superpositions or source history included.','stationary_full_error_formula':'(3r+2r^2)/[(1+r)(1+2r)]','stationary_clock_error_formula':'2r/(1+2r)','necessary_full_stationary_target':'2*65535*r^2 +3*65535*r <1','necessary_reduced_stationary_target':'r <1/(2*65535)','spectrum':'0,0,+g,-g,+sqrt(g^2+lambda^2),-sqrt(g^2+lambda^2)','resource_obstruction':'Holding Gamma=4lambda^2/kappa fixed requires lambda~sqrt(kappa); full interaction norm increases. Unit-norm Hamiltonian time t scales by sqrt(g^2+lambda^2), and bath rates must be scaled with generator for equivalent dynamics.'}
(R/'results/LATCH_AUDIT.json').write_text(json.dumps(res,indent=2));print(json.dumps({'exact_count':len(exact),'numerical_count':len(num),'t16':[x for x in rows if x['time']==16],'stationary':res['stationary_full_error_formula']},indent=2))
