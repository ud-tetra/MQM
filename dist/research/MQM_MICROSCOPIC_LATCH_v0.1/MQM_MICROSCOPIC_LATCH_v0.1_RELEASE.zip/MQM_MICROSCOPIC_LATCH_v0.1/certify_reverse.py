"""Conservative finite-window reverse-jump robustness from CPTP Duhamel bound."""
from pathlib import Path
from fractions import Fraction
import json
R=Path(__file__).resolve().parent
cold=json.loads((R/'results/COLD_INTERVAL_CERTIFICATE.json').read_text())
selected=next(x for x in cold['rows'] if x['kappa']==8)
# Validate exact rational ceiling with interval certificate's diagnostic upper value.
# The actual interval comparison is repeated directly from certificate string endpoints below.
from mpmath import iv
iv.dps=80
end=selected['full_error_interval'].split(',')[1].strip().rstrip(']')
assert iv.mpf(end).b<(iv.mpf(1)/2**48).a
q_ceiling=Fraction(1,2**48);rmax=Fraction(1,2**24);tmax=Fraction(16)+Fraction(1,1024)
bound=q_ceiling+8*rmax*tmax;eps=Fraction(1,2**16)
assert bound<eps
res={'status':'DERIVED uniform retained-channel bound from interval cold certificate and CPTP perturbation inequality','scope':'kappa8,lambda=sqrt(4sqrt2),g1; fixed eligible product m0 launch; arbitrary spectator data retained, explicit auxiliary retained, original bath traced; reverse jump r<=1/2^24','cold_ceiling_exact':str(q_ceiling),'reverse_ratio_max_exact':str(rmax),'window_half_width_exact':'1/1024','total_upper_exact':str(bound),'target_exact':str(eps),'passed_exact_fraction_comparison':True,'derivation':'For Delta L=kappa*r*D[I tensor sigma+], ||Delta L||_diamond<=2*kappa*r; Duhamel and CPTP contraction give half-diamond distance between thermal and cold channels <= kappa*r*t. Add cold preparation-channel bound; factor identity_data keeps arbitrary data spectators.','interpretation':'Conservative sufficient reverse-rate bound, not an optimized thermal threshold or independent prediction. The model does not calibrate r to material temperature.','physical_promotion':0}
(R/'results/REVERSE_CERTIFICATE.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
