"""Exact basis replay and numerical validation of every complex Jacobian column."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json
import sympy as s
import numpy as np
import networkx as nx
from complex_objective import load_model,Objective
R=Path(__file__).resolve().parent;(R/'results').mkdir(exist_ok=True)
source,labels,B,P,Fbasis,E,W=load_model()
checks=[]
def check(name,v):
    assert bool(v),name
    checks.append(name)
check('108 nonidentity Hermitian Pauli parameters',len(labels)==108)
check('97 exact integer kernel coordinates',B.shape==(108,97) and s.Matrix(B).rank()==97)
def entry(label,row,col):
    mask=sum(1<<(5-k) for k,p in enumerate(label) if p in 'XY')
    if row!=(col^mask):return s.Integer(0)
    out=s.Integer(1)
    for k,p in enumerate(label):
        bit=(col>>(5-k))&1
        if p=='Y':out*=s.I*(-1 if bit else 1)
        elif p=='Z' and bit:out*=-1
    return out
ss=[8,24,40,56];tt=[8,4,2,1]
M=s.zeros(32,108)
for k,label in enumerate(labels):
    for a in range(4):
        for b in range(4):
            d=entry(label,ss[a],ss[b])-entry(label,tt[a],tt[b]);M[4*a+b,k]=s.re(d);M[16+4*a+b,k]=s.im(d)
check('exact first-moment real rank eleven',M.rank()==11)
check('exact first-moment kernel annihilation',M*s.Matrix(B)==s.zeros(32,97))
odd=[i for i,l in enumerate(labels) if sum(c=='Y' for c in l)%2]
even=[i for i in range(108) if i not in odd]
check('real-entry and imaginary-entry Pauli counts 62 and 46',len(even)==62 and len(odd)==46)
check('real-entry first-moment rank seven',M[:,even].rank()==7)
check('imaginary-entry first-moment rank four',M[:,odd].rank()==4)
check('kernel decomposes into 55 real-entry and 42 imaginary-entry directions',len(even)-M[:,even].rank()==55 and len(odd)-M[:,odd].rank()==42)
check('every Hermitian Pauli string has support <=2',all(sum(x!='I' for x in l)<=2 for l in labels))
check('all physical support pairs on allowed planar graph',all(tuple(i for i,c in enumerate(l) if c!='I') in [tuple(p) for p in source['graph']['pairs']] for l in labels if sum(c!='I' for c in l)==2))
g=nx.Graph(source['graph']['pairs'])
check('same six qubits and ten planar allowed pairs',len(g)==6 and g.number_of_edges()==10 and nx.check_planarity(g)[0])
check('maximum physical degree four',max(dict(g.degree()).values())==4)
check('all Pauli entries Gaussian integers',np.array_equal(P.real,np.rint(P.real)) and np.array_equal(P.imag,np.rint(P.imag)))
check('exact Hermitian Pauli matrices',np.array_equal(P,P.conj().transpose(0,2,1)))
check('Pauli square is identity using bounded Gaussian integers',np.array_equal(P@P,np.broadcast_to(np.eye(64),(108,64,64))))
check('integer kernel keeps every basis Hermitian',np.array_equal(Fbasis,Fbasis.conj().transpose(0,2,1)))
check('source and target each orthonormal four-column isometries',np.array_equal(E.conj().T@E,np.eye(4)) and np.array_equal(W.conj().T@W,np.eye(4)))
check('odd-Y terms supply imaginary computational-basis entries',sum(sum(c=='Y' for c in l)%2 for l in labels)>0)
numeric=[]
rng=np.random.default_rng(2026100552)
for weight in [0.,2.]:
    obj=Objective(B,Fbasis,E,W,weight)
    for name,probe in [('zero_degenerate',np.zeros(98)),('complex_random',np.r_[rng.normal(0,.25,97),.3])]:
        J=obj.evaluate(probe)[1];err=0.
        for col in range(98):
            h=np.zeros(98);h[col]=1e-6
            finite=(obj.evaluate(probe+h)[0]-obj.evaluate(probe-h)[0])/(2e-6)
            err=max(err,float(np.max(abs(finite-J[:,col]))))
        assert err<2e-7,(weight,name,err)
        numeric.append({'check':'all 98 real-coordinate Jacobian columns','weight':weight,'probe':name,'max_error':err,'threshold':2e-7})
    # General directional check at a larger spectral scale.
    probe=np.r_[rng.normal(0,1.,97),.2];direction=rng.normal(0,1,98);direction/=np.linalg.norm(direction)
    J=obj.evaluate(probe)[1];h=2e-6
    finite=(obj.evaluate(probe+h*direction)[0]-obj.evaluate(probe-h*direction)[0])/(2*h)
    err=float(np.max(abs(finite-J@direction)));assert err<2e-7,err
    numeric.append({'check':'directional derivative at larger spectrum','weight':weight,'max_error':err,'threshold':2e-7})
receipt={'status':'Exact basis replay and validated numerical analytic gradient, not an encoder',
 'exact_count':len(checks),'exact_checks':checks,'gradient_checks':numeric,
 'gradient_coverage':'392 central-difference columns plus two larger-scale directional checks',
 'formulation':'H(theta)=sum theta_a F_a; exp(-iH)E-exp(i phi)W; stack real and imaginary parts. Optional 2*M2/(1+sum c_P^2) soft penalty.',
 'complex_correction':'Use V dagger, not transpose, and conjugate moment products.',
 'kernel_decomposition':{'real_entry_Paulis':62,'real_entry_first_moment_rank':7,'real_entry_kernel':55,'imaginary_entry_Paulis':46,'imaginary_entry_first_moment_rank':4,'imaginary_entry_kernel':42},
 'physical_promotion':0,'joint_admission':'OPEN'}
(R/'results/OBJECTIVE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'exact_count':len(checks),'gradient_checks':numeric}))
