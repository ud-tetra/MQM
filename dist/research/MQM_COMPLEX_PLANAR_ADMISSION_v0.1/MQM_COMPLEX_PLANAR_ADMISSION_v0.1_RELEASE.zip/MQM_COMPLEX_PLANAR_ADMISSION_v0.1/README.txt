Complex Hermitian Optimization and Spectral Alignment for Joint Qubit Admission
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM development note v0.1

STATUS
The 97-real-coordinate Hermitian planar search has now been executed in eight
bounded starts (four endpoint-only, four with a second-moment soft penalty).
No encoder was found. Best sampled operator residual: 0.32910369230828146.
An optimizer residual is not a certified complete-channel error.

EXACT RESULTS
The full kernel is 55 real-matrix-entry plus 42 imaginary-matrix-entry directions.
The generator H=X_z activates the terminal mode and matches ALL compressed
spectral moments but preserves native occupations, failing admission at all
times. Spectral-subspace orientation and compatible phases remain necessary.
Exact dyadic spectral enclosures prove complete half-diamond error > 1/8 for
each best frozen generator at EVERY deadline and uniform norm rescaling.
These are candidate exclusions, not a planar-family impossibility theorem.
The logical/reference witness retains a reference of dimension four.

EVIDENCE
198 scoped exact checks; 392 central-difference Jacobian column checks and two
directional checks; eight finite optimizer starts. Independent review and
theorem-level novelty comparison pending. Physical evidence promotion 0.
Six-qubit joint single-excitation admission remains OPEN.

REPLAY (requires numpy, scipy, sympy, networkx, PyMuPDF; pdflatex for PDF)
  python3 verify_objective.py
  python3 audit_complex.py
  python3 audit_complex.py --moment
  python3 spectral_certificate.py
  python3 spectral_certificate.py --moment
  python3 verify_counterexample.py
The stored coefficients are exact binary-rational kernel combinations. Spectral
certificates treat the approximate eigensolver's output as dyadic input only;
Gaussian-integer backward errors and integer square roots certify all bounds.

OPTIONAL RE-OPTIMIZATION (overwrites search receipts; versions may change fits)
  python3 search_complex.py --max-nfev 1000
  python3 search_complex.py --max-nfev 1000 --moment-weight 2
The coordinate box is not a physical coupling or full-norm ceiling. Normalize
the full spectrum separately. Additional coupling components are admitted on
the same six-qubit ten-pair planar graph and remain charged to realizability.
Run ALL audits again after changing any candidate or basis.

PDF AND RELEASE
  python3 build_ieee_note.py
Inspect all three current PAGE_*.png files before freezing:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran A4, 10pt, two columns; IEEEtran class and LPPL bundled.
Parent releases remain unchanged. All hashes are in SHA256SUMS.txt.

NEXT TARGET
Spectral-subspace alignment on the same planar graph, then one finite deadline
and common phase, with full-norm and complete-input certificates. Moment-only
or independent-population objectives cannot close the coherent admission task.
