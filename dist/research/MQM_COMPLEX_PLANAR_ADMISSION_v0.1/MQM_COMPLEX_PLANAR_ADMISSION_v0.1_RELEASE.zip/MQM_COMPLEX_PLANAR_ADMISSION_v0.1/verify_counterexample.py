"""Exact counterexample: all compressed moments and activation do not imply admission."""
from pathlib import Path
import json
import sympy as s
R=Path(__file__).resolve().parent
X=s.Matrix([[0,1],[1,0]]);I=s.eye(64);H=s.kronecker_product(s.eye(32),X)
E=s.zeros(64,4);W=s.zeros(64,4)
for a,(e,w) in enumerate(zip([8,24,40,56],[8,4,2,1])):E[e,a]=1;W[w,a]=1
def N(q):return s.diag(*[((i>>(5-q))&1) for i in range(64)])
NA,NO,NU,NV,NW,NZ=[N(q) for q in range(6)]
QA=NA+NW+NZ;QO=NO+NV+NZ
checks=[]
def check(name,p):
    assert p,name
    checks.append(name)
check('X_z Hermitian and one-local',H.H==H)
check('X_z square equals full identity',H*H==I)
check('X_z has both eigenvalues plus and minus one',H.trace()==0 and H*H==I)
check('source isometry orthonormal',E.H*E==s.eye(4))
check('target isometry orthonormal',W.H*W==s.eye(4))
check('source odd compressed moments zero',E.H*H*E==s.zeros(4))
check('target odd compressed moments zero',W.H*H*W==s.zeros(4))
check('native A occupation conserved',H*NA==NA*H)
check('native O occupation conserved',H*NO==NO*H)
check('terminal z occupation changes',H*NZ!=NZ*H)
check('bookkeeping QA broken',H*QA!=QA*H)
check('bookkeeping QO broken',H*QO!=QO*H)
check('input01 has native O one and target has zero',NO*E[:,1]==E[:,1] and NO*W[:,1]==s.zeros(64,1))
Pplus=(I+H)/2;Pminus=(I-H)/2
check('spectral projectors orthogonal and complete',Pplus*Pminus==s.zeros(64) and Pplus+Pminus==I)
check('positive eigenspace orientations for input01 orthogonal but nonzero',
      (Pplus*E[:,1]).H*(Pplus*W[:,1])==s.zeros(1) and (Pplus*E[:,1]).norm()**2==s.Rational(1,2) and (Pplus*W[:,1]).norm()**2==s.Rational(1,2))
check('spectral trace overlap sum exactly one',abs((W.H*Pplus*E).trace())+abs((W.H*Pminus*E).trace())==1)
receipt={'status':'EXACT counterexample and derived all-order consequence',
 'generator':'H=X_z','physical_register_dimension':64,'full_norm':1,'spectral_width':2,
 'source_contract':'Original six-qubit native joint single-excitation endpoint.',
 'all_compressed_moments':'For every k>=0, E^dagger H^k E=W^dagger H^k W: identity at even k, zero at odd k.',
 'terminal_activation':True,'both_bookkeeping_charges_broken':True,
 'admission_failure':'Native O occupation is invariant. Input01 output stays orthogonal to required target for every time; complete channel trace error one.',
 'exact_projector_condition':'Exact admission iff, for every distinct lambda, exp(-i*T*lambda)*Pi_lambda*E = exp(i*phi)*Pi_lambda*W with one common phi.',
 'projector_phase_relaxation':'For all times half-diamond error >=sqrt(1-(sum_lambda |Tr W^dagger Pi_lambda E|/4)^2). Here sum=1 and the relaxed Choi floor is sqrt(15)/4.',
 'lesson':'All compressed moments and terminal activation are necessary filters but insufficient; spectral-subspace orientation and phases remain essential.',
 'exact_count':len(checks),'exact_checks':checks,'scope':'This explicit candidate; not a universal no-go.','physical_promotion':0,'independent_review':'pending'}
(R/'results/COUNTEREXAMPLE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'exact_count':len(checks),'all_moments_match':True,'complete_error':'one for input01 at every time'}))
