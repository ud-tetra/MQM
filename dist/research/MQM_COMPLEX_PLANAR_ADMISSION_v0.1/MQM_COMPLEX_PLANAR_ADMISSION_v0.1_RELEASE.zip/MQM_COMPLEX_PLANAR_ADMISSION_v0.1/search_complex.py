"""Bounded multistart search in the full graph-local Hermitian moment kernel."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json,time,argparse
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import least_squares
from complex_objective import load_model,Objective
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--max-nfev',type=int,default=1000);ap.add_argument('--moment-weight',type=float,default=0.);args=ap.parse_args()
source,labels,B,P,Fbasis,E,W=load_model();obj=Objective(B,Fbasis,E,W,args.moment_weight)
old=json.loads((R/'PARENT_REAL_SEARCH.json').read_text())['best']
initial=np.array([float(Q(old['Pauli_coefficients_exact'].get(l,'0'))) for l in labels])
theta=np.linalg.lstsq(B,initial,rcond=None)[0]
rng=np.random.default_rng(2026100552);seeds=[np.r_[theta,old['phase']]]
if args.moment_weight and (R/'results/COMPLEX_SEARCH_RECEIPT.json').exists():
    prior=json.loads((R/'results/COMPLEX_SEARCH_RECEIPT.json').read_text())['best']
    seeds[0]=np.r_[[float(Q(q)) for q in prior['kernel_coordinates_exact']],prior['phase']]
complex_rows=np.array([sum(c=='Y' for c in l)%2 for l in labels])
newdirs=np.linalg.norm(B[complex_rows.astype(bool)],axis=0)>0
perturbed=theta.copy();perturbed[newdirs]+=rng.normal(0,.35,int(sum(newdirs)))
seeds.append(np.r_[perturbed,old['phase']])
for scale in [.4,1.2]:seeds.append(np.r_[rng.normal(0,scale,97),0.])
runs=[];best=None
for run,x0 in enumerate(seeds):
    x0=np.clip(x0,-4*np.pi+1e-8,4*np.pi-1e-8);started=time.monotonic()
    result=least_squares(lambda x:obj.evaluate(x)[0],x0,jac=lambda x:obj.evaluate(x)[1],bounds=(-4*np.pi,4*np.pi),max_nfev=args.max_nfev,ftol=1e-10,xtol=1e-10,gtol=1e-10)
    H=np.einsum('a,aij->ij',result.x[:-1],Fbasis);val,V=eigh(H)
    center=(val[0]+val[-1])/2;radius=(val[-1]-val[0])/2
    UE=V@(np.exp(-1j*val)[:,None]*(V.conj().T@E));phi=np.angle(np.trace(W.conj().T@UE))
    op=float(np.linalg.norm(UE-np.exp(1j*phi)*W,2));Hc=H-center*np.eye(64)
    moments={str(k):float(np.linalg.norm(E.conj().T@np.linalg.matrix_power(Hc,k)@E-W.conj().T@np.linalg.matrix_power(Hc,k)@W,2)/radius**k) for k in [1,2,3,4]}
    raw=[Q(float(v)) for v in result.x[:-1]]
    coeff=[sum((Q(int(B[k,a]))*raw[a] for a in range(97)),Q(0)) for k in range(108)]
    rec={'run':run,'seed_type':[('prior_complex_best' if args.moment_weight else 'prior_real_best'),'imaginary_coupling_perturbation','random_0.4','random_1.2'][run],
       'nfev':result.nfev,'status':int(result.status),'seconds':time.monotonic()-started,'cost':float(result.cost),
       'isometry_operator_residual':op,'basis_trace_errors':[float(np.sqrt(max(0,1-abs(W[:,a].conj()@UE[:,a])**2))) for a in range(4)],
       'phase':float(phi),'sampled_centered_norm':float(radius),'spectral_center':float(center),'sampled_unit_norm_deadline':float(radius),'normalized_moment_mismatches':moments,
       'imaginary_coupling_l2':float(np.linalg.norm(np.array([float(c) for c in coeff])[complex_rows.astype(bool)]))}
    runs.append(rec)
    if best is None or op<best['isometry_operator_residual']:
        best={**rec,'kernel_coordinates_exact':[str(v) for v in raw],'Pauli_coefficients_exact':{l:str(c) for l,c in zip(labels,coeff)}}
    receipt={'status':'FINITE EXPLORATION ONLY; no family no-go or exact endpoint inferred',
       'real_coordinates':97,'Pauli_terms':108,'graph':{'physical_qubits':6,'pairs':source['graph']['pairs'],'planar':True,'maximum_degree':4},'moment_weight':args.moment_weight,'random_seed':2026100552,
       'starts':4,'max_nfev_per_start':args.max_nfev,'coordinate_box':'[-4*pi,4*pi] in kernel coordinates and common phase; not a physical norm ceiling',
       'objective':'Full four-column endpoint residual with common phase, exact linear moment parametrization and optional scaled second-moment soft penalty.',
       'higher_moments':'Diagnostic, or soft penalty for k=2; not exact nonlinear constraints.',
       'normalization':'H is dimensionless TH. A sampled centered unit-norm implementation has deadline equal to sampled spectral radius.',
       'freeze':'Exact binary fractions of kernel coordinates, followed by integer basis assembly.',
       'runs':runs,'best':best,'joint_admission':'OPEN','physical_promotion':0}
    name='COMPLEX_MOMENT_SEARCH_RECEIPT.json' if args.moment_weight else 'COMPLEX_SEARCH_RECEIPT.json'
    (R/'results'/name).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(rec),flush=True)
