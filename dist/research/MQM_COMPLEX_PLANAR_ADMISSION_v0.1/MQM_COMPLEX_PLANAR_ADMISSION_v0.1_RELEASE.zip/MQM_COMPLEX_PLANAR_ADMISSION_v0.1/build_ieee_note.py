"""IEEEtran A4 formulation, bounded complex search and scoped exact exclusions."""
from pathlib import Path
import json,shutil,subprocess
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript';M.mkdir(exist_ok=True)
parent=R.parent/'MQM_MOMENT_FILTERED_ADMISSION_v0.1'
for name in ['IEEEtran.cls','LPPL-1.3c.txt']:
    src=parent/'manuscript'/name
    if src.exists():shutil.copy2(src,M/name)
    else:assert (M/name).exists()
def read(name):return json.loads((R/'results'/name).read_text())
s0=read('COMPLEX_SEARCH_RECEIPT.json');s1=read('COMPLEX_MOMENT_SEARCH_RECEIPT.json')
a0=read('COMPLEX_AUDIT.json');a1=read('COMPLEX_MOMENT_AUDIT.json');v=read('OBJECTIVE_RECEIPT.json')
cert0=read('SPECTRAL_CERTIFICATE.json');cert1=read('SPECTRAL_MOMENT_CERTIFICATE.json');counter=read('COUNTEREXAMPLE_RECEIPT.json')
assert a0['excluded_at_error_2_minus_16_for_all_times'] and a1['excluded_at_error_2_minus_16_for_all_times']
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\newcommand{\sinc}{\operatorname{sinc}}
\begin{document}
\title{Complex Hermitian Optimization and\\Spectral Alignment for Joint Qubit Admission}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 5, 2026. ORCID: 0009-0002-5813-0724. Scoped derivation and finite constructor search. Independent review and theorem-level novelty comparison pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We formulate and execute a complex Hermitian optimization for a still-open six-qubit joint admission interface. A fixed planar graph permits 108 nonidentity two-local Hermitian Pauli coefficients. Eleven exact first-moment constraints leave 97 real coordinates, decomposing into 55 real-entry and 42 imaginary-entry directions. The objective retains all four input columns and one common phase; its analytic derivative uses conjugate-transpose spectral calculus with a continuous divided difference. All 392 numerical Jacobian-column checks and two directional checks pass. Eight bounded fits supply no encoder. The best sampled endpoint residual is @BEST@, not a channel certificate. An exact counterexample shows that terminal activation and all compressed spectral moments remain insufficient. Spectral-projector orientation supplies a sharper criterion. Exact dyadic backward-error enclosures certify an all-time half-diamond error greater than $1/8$ for each best frozen fit, using a maximally entangled logical/reference witness. These exclusions concern individual generators, not the planar family. The joint endpoint and physical realization remain open.
\end{abstract}
\begin{IEEEkeywords}
Autonomous control, Hermitian Hamiltonian, two-local interaction, complex gradient, quantum admission, spectral moment.
\end{IEEEkeywords}

\section{Operational contract and typed search space}
With register order $(A,O,u,v,w,z)$, define isometries
\begin{equation}
E\ket{ab}=\ket{ab}_{AO}\ket{\mathbf1_{00}}_M,\qquad
W\ket{ab}=\ket{00}_{AO}\ket{\mathbf1_{ab}}_M,
\end{equation}
where modes $(u,v,w,z)$ are labeled $(00,01,10,11)$. We seek a static Hermitian two-local generator whose propagator maps $E$ to $W$ with one common phase, including arbitrary spectator entanglement. The full physical space has dimension 64. All candidate evolutions are unitary; failed endpoint admission is not evidence of nonunitary dynamics.

The permitted pairs remain
\begin{equation}
\{Au,Aw,Az,Ou,Ov,Ow,Oz,uw,uv,wz\},
\end{equation}
a planar graph with maximum degree four. The prior note \cite{parent} supplies the exact linear first-moment kernel. This note executes that previously unrun larger search. Bookkeeping charges $Q_A,Q_O$ remain explicitly defined algebraic operators; no Gauss-law, Wilson-loop, or gravitational correspondence is derived. Static gate synthesis has prior spectral and numerical frameworks \cite{innocenti}; the gradient formulation itself is not asserted as a new general method.

There are $3\cdot6+9\cdot10=108$ nonidentity Hermitian Pauli strings $P_k$. All coefficients $c_k$ are real. Odd numbers of $Y$ factors permit imaginary matrix entries while preserving Hermiticity. In particular $Y$ is a one-body term; a direction of support at most two need not be exclusively two-body. First-moment alignment
\begin{equation}
E^\dagger H E=W^\dagger H W
\end{equation}
has real rank eleven. An exact integer matrix $B\in\mathbb Z^{108\times97}$ parametrizes $c=B\theta$. The 62 real-entry Pauli terms have constraint rank seven and kernel dimension 55. The 46 imaginary-entry terms have rank four and kernel dimension 42. Thus the enlarged kernel is $55+42=97$, not the earlier 55-coordinate kernel. More independently tunable components are admitted, even though no qubits or allowed pairs are added.

\section{Objective with a common phase}
Put $F_a=\sum_k B_{ka}P_k$ and $H(\theta)=\sum_a\theta_aF_a$. We use dimensionless model time one and fit $\theta\in\mathbb R^{97}$ and $\phi\in\mathbb R$:
\begin{equation}
R=e^{-iH(\theta)}E-e^{i\phi}W,\qquad
f_0=\tfrac12\|R\|_F^2.
\end{equation}
The residual stacks real and imaginary entries of all four columns. Each input is retained; independent column phases are not allowed. The phase derivative is
\begin{equation}
\partial_\phi R=-ie^{i\phi}W.
\end{equation}
The endpoint operator residual $\|R\|$ gives an isometry-based upper bound on half-diamond channel distance, but its computed floating value is not an enclosed channel certificate. A large operator residual alone is not a lower bound; basis-state trace diagnostics and exact moment witnesses provide the failures reported below.

For the optional second-moment penalty, set
\begin{equation}
M_2=E^\dagger H^2E-W^\dagger H^2W,\qquad
s=1+\sum_k c_k^2,
\end{equation}
and minimize
\begin{equation}
f_\mu=\tfrac12\|R\|_F^2+
\tfrac{\mu^2}{2}\|M_2/s\|_F^2.
\end{equation}
We use $\mu=0$ or $2$. The penalty is soft; higher moments are necessary diagnostics, not exactly enforced nonlinear constraints. Exact first moment is preserved by freezing binary-rational kernel coordinates before coefficient assembly.

\section{Complex analytic gradient}
For $H=V\Lambda V^\dagger$, let $A_a=V^\dagger F_aV$ and $Q=V^\dagger E$. The exponential Fr\'echet derivative is
\begin{equation}
\partial_a(e^{-iH}E)=V(D\odot A_a)Q,
\end{equation}
where
\begin{equation}
D_{rs}=-ie^{-i(\lambda_r+\lambda_s)/2}
\sinc\!\big((\lambda_r-\lambda_s)/2\big),
\end{equation}
and $\sinc x=\sin x/x$, $\sinc0=1$. At coincidence $D_{rr}=-ie^{-i\lambda_r}$; no division by a small eigenvalue gap is required. Conjugate transposes cannot be replaced by ordinary transposes for this complex ansatz.
\begin{proof}[Derivative identity]
Differentiation of the propagator gives
\begin{equation}
-i\int_0^1 e^{-i(1-q)H}F_ae^{-iqH}\,dq.
\end{equation}
In the eigenbasis, integration of the two scalar phases yields the displayed continuous divided difference, including equal eigenvalues. Multiplication by $E$ gives the stated formula.
\end{proof}
For the penalty,
\begin{align}
\partial_aM_2&=E^\dagger(F_aH+HF_a)E\notag\\
&\quad-W^\dagger(F_aH+HF_a)W,\\
\partial_as&=2\sum_k c_kB_{ka},\\
\partial_a(M_2/s)&=(\partial_aM_2)/s-
M_2(\partial_as)/s^2.
\end{align}
The loss gradient takes real Frobenius inner products with these derivatives. Equivalently, the solver uses the Jacobian of the stacked real residual. Four complete 98-column central-difference comparisons and two larger-spectrum directional comparisons pass, with maximum discrepancy below $@GRAD@$; these are numerical consistency checks, not a rigorous floating exponential enclosure.

\section{Bounded fits and exact frozen-candidate rejection}
Each batch has four deterministic starts: the preceding best embedded fit, a seed perturbed in imaginary-entry directions, and two seeded random vectors. Each start has at most 1000 function evaluations and a coordinate box $[-4\pi,4\pi]$. This box is not a Pauli coefficient ceiling or full operator-norm budget. Five runs stop under loss tolerances and three reach evaluation caps. No global optimality is certified.
\begin{table}[t]
\caption{Sampled diagnostics; neither batch supplies an encoder}
\centering\begin{tabular}{lrr}
\hline Batch & Best operator residual & Spectral radius\\\hline
Endpoint only & @RES0@ & @TIME0@\\
Second-moment penalty & @RES1@ & @TIME1@\\\hline
\end{tabular}
\end{table}
These are four-column common-phase diagnostics on the full register. Both selected fits have basis-state trace errors far above $2^{-16}$ at the sampled endpoint. The radius is a sampled full centered norm of dimensionless $H$; dividing by it gives the same endpoint after that much unit-norm model time, up to centering phase. It is not a certified exact spectrum. Alternatively $B_1=\sum_k|c_k|$ supplies the exact conservative budget $\|H/B_1\|\le1$, with deadline $B_1$. No favorable accuracy--latency or physical-resource comparison is promoted from these unsuccessful fits.

The exact frozen Hamiltonians have Gaussian-rational matrix entries. For any selected logical input and its required output, static dynamics conserve the expectation of $H^2$. Trace duality therefore gives
\begin{equation}
D_{\rm tr}(e^{-itH}\ket{e},\ket{f})
\ge\frac{|\langle e,H^2e\rangle-\langle f,H^2f\rangle|}{2B_1^2}
\end{equation}
for every deadline. The endpoint-only best fit has a floor strictly exceeding $1/2048$ on input $\ket{10}$. The penalty batch best has a floor strictly exceeding $1/8192$ on
\begin{equation}
\ket{\xi}=(\ket{01}+i\ket{11})/\sqrt2.
\end{equation}
Both exceed $1/65536$; exact fractions are in the audits. This coherent witness tests the admitted input space rather than only four population transfers. Uniform norm rescaling and a scalar energy shift cannot evade an all-time state exclusion. Each witness concerns only its specified frozen generator; other coefficients, spectral branches, and graphs remain unexcluded.

\section{Spectral alignment beyond moment matching}
The allowed one-local candidate $H=X_z$ has full norm one, spectrum $\{-1,1\}$, and $H^2=I$. Both compressed odd moments vanish and both even moments equal $I_4$. Thus every nonnegative compressed moment matches exactly. It also breaks $Q_A,Q_O$ and activates $N_z$. Yet it conserves both native occupations, so input $01$ remains orthogonal to its required native-zero output for every deadline. Its complete error is one on that input. Activation and even all-order moment matching are insufficient.

For distinct eigenvalues, let $\Pi_\lambda$ be the true spectral projectors. Exact admission is equivalent to
\begin{equation}
e^{-it\lambda}\Pi_\lambda E
=e^{i\phi}\Pi_\lambda W\quad\text{for every }\lambda.
\end{equation}
Necessity follows by projection; sufficiency follows by summing the complete projectors. This condition retains orientation inside each eigenspace and one common phase across the four columns.

Define the spectral trace overlap
\begin{equation}
S=\sum_\lambda|\operatorname{Tr}(W^\dagger\Pi_\lambda E)|\le4.
\end{equation}
\begin{proposition}[All-time complete-channel spectral witness]
For every deadline, the half-diamond distance between the two isometric admission channels satisfies
\begin{equation}
\tfrac12\|\mathcal U_t-\mathcal W\|_\diamond
\ge\sqrt{1-S^2/16}.
\end{equation}
\end{proposition}
\begin{proof}
Use the maximally entangled logical/reference input of dimension four. Its two output states are pure, with overlap
$\operatorname{Tr}(W^\dagger e^{-itH}E)/4$. Expanding into projectors and applying the triangle inequality bounds its modulus by $S/4$. The pure-state trace distance is the displayed radical and lower-bounds half-diamond distance. Global phase does not change it.
\end{proof}
For $X_z$, $S=1$, giving the relaxed reference witness $\sqrt{15}/4$, while the basis witness already gives one. Moreover $S=4$ forces equality in the matrix and scalar Cauchy--Schwarz inequalities: each $\Pi_\lambda W$ must equal $\Pi_\lambda E$ up to a scalar phase shared by all four columns. Those eigenspace phases must still fit one finite deadline. This separates orientation from phase timing; neither is closed by compressed moments alone.

\subsection{Exact enclosure for the frozen fits}
Treat the floating eigendecomposition $(V,\Lambda)$ only as exact binary-rational data. Compute Gaussian-integer Gram and eigen residuals, with rational upper enclosures
\begin{equation}
\delta\ge\|V^\dagger V-I\|_F,\qquad
\rho\ge\|HV-V\Lambda\|_F.
\end{equation}
The polar unitary $Q$ satisfies $\|Q-V\|\le\delta$ for $\delta<1$. Thus, with $B_1=\sum|c_k|$,
\begin{equation}
\|H-Q\Lambda Q^\dagger\|\le
\eta:=\rho+(B_1+\|\Lambda\|)\delta.
\end{equation}
Let $\gamma$ be the smallest exact binary-rational grid gap. The receipts verify $\gamma>2\eta$. Eigenvalue perturbation then identifies one true rank-one projector per grid point. Projecting the true eigenvector equation onto other grid eigenspaces bounds the projector displacement by $\eta/(\gamma-\eta)$. Replacing $Q_nQ_n^\dagger$ by $V_nV_n^\dagger$ adds at most $3\delta$.

Each four-column trace overlap incurs at most four times this projector debit. Summing the 64 terms yields
\begin{align}
S\le S_{\rm up}:={}&\sum_n
|\operatorname{Tr}(W^\dagger V_nV_n^\dagger E)|_{\rm up}\notag\\
&+256\left(\eta/(\gamma-\eta)+3\delta\right).
\end{align}
Every square root is enclosed by exact integer square-root arithmetic on an $80$-bit dyadic grid. Both certified $S_{\rm up}<4$ and $1-(S_{\rm up}/4)^2>(1/8)^2$. Hence both frozen generators have all-time complete channel error strictly greater than $1/8$, including under uniform norm rescaling. Diagnostic radical values are @SPEC0@ and @SPEC1@. These are lower bounds, not exact channel distances. Neither certificate excludes other coefficients or a different spectral branch.

\newpage
\section{Verification and next gate}
This release records 18 exact basis and decomposition checks, two nine-check Gaussian-rational moment audits, a 16-check counterexample, and two 73-check spectral enclosures: 198 exact checks. Numerical evidence comprises eight fits, 392 gradient-column comparisons and two directional comparisons. Independent review and theorem-level novelty comparison remain pending; physical evidence promotion is zero.

The next mathematical gate is spectral-subspace alignment on the same planar graph, followed by phase compatibility at a finite normalized deadline. Moment constraints remain useful prefilters; a soft penalty cannot certify closure. Near-degenerate gaps and long phase-fitting times must be charged rather than treated as free solutions. An exact or interval-certified candidate remains the target. The present finite search is not a proof that the planar graph must change or that a multi-excitation carrier is necessary. Native extraction, static concatenation, irreversible retention, supervising-clock refresh and thermodynamic supply remain separate open obligations.
\begin{thebibliography}{2}
\bibitem{parent} B. W. Mayes, ``Moment-constrained symmetry breaking for autonomous joint qubit admission,'' MQM development note v0.1, Oct. 5, 2026, unpublished. Frozen parent identified in INPUT\_ANCHORS.json.
\bibitem{innocenti} L. Innocenti, L. Banchi, A. Ferraro, S. Bose, and M. Paternostro, ``Supervised learning of time-independent Hamiltonians for gate design,'' arXiv:1803.07119, 2018, doi: 10.1088/1367-2630/ab8aaf.
\end{thebibliography}
\end{document}
'''
maxgrad=max(c['max_error'] for c in v['gradient_checks'])
repl={'BEST':f"{min(s0['best']['isometry_operator_residual'],s1['best']['isometry_operator_residual']):.6f}",'RES0':f"{s0['best']['isometry_operator_residual']:.6f}",'RES1':f"{s1['best']['isometry_operator_residual']:.6f}",
 'TIME0':f"{s0['best']['sampled_centered_norm']:.6f}",'TIME1':f"{s1['best']['sampled_centered_norm']:.6f}",'GRAD':'10^{-8}',
 'SPEC0':f"{cert0['floor_decimal_diagnostic']:.6f}",'SPEC1':f"{cert1['floor_decimal_diagnostic']:.6f}"}
assert maxgrad<1e-8
assert a0['strict_dyadic_lower_bound']=='1/2048' and a1['strict_dyadic_lower_bound']=='1/8192'
for key,value in repl.items():tex=tex.replace('@'+key+'@',value)
assert '@' not in tex
stem='MQM_COMPLEX_PLANAR_ADMISSION_IEEE_A4_v0.1';(M/(stem+'.tex')).write_text(tex)
for n in range(3):
    proc=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',stem+'.tex'],cwd=M,capture_output=True,text=True)
    (R/'results'/f'PDF_BUILD_{n+1}.txt').write_text(proc.stdout+proc.stderr)
    assert proc.returncode==0,proc.stdout[-2500:]
log=(M/(stem+'.log')).read_text();assert 'Overfull' not in log
pdf=M/(stem+'.pdf');doc=fitz.open(pdf);sizes=[]
for n,page in enumerate(doc):
    sizes.append([page.rect.width,page.rect.height]);assert abs(page.rect.width-595.276)<.1 and abs(page.rect.height-841.89)<.1
    assert '??' not in page.get_text()
    page.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/f'PAGE_{n+1}.png')
(R/'results/PDF_QA.json').write_text(json.dumps({'pages':len(doc),'sizes_points':sizes,'format':'actual IEEEtran v1.8b journal,a4paper,10pt, two columns','no_overfull':True,'no_unresolved_references':True,'visual_review':'pending'},indent=2)+'\n')
print(json.dumps({'pdf':str(pdf.resolve()),'pages':len(doc)}))
