"""Real-coordinate objective for complex Hermitian static joint admission."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json
import numpy as np
from scipy.linalg import eigh
R=Path(__file__).resolve().parent
I=np.eye(2,dtype=complex);X=np.array([[0,1],[1,0]],dtype=complex)
Y=np.array([[0,-1j],[1j,0]]);Z=np.diag([1,-1]).astype(complex)
ops=dict(I=I,X=X,Y=Y,Z=Z)
def pauli(label):
    out=np.array([[1]],dtype=complex)
    for symbol in label:out=np.kron(out,ops[symbol])
    return out
def load_model():
    source=json.loads((R/'PARENT_EXPANDED_FILTER.json').read_text())
    labels=source['labels_without_identity']
    B=np.array([[int(v.get(l,'0')) for v in source['exact_kernel_without_identity']] for l in labels],dtype=int)
    P=np.array([pauli(l) for l in labels])
    Fbasis=np.einsum('ka,kij->aij',B,P)
    E=np.zeros((64,4),dtype=complex);W=np.zeros_like(E)
    for a,(s,t) in enumerate(zip([8,24,40,56],[8,4,2,1])):E[s,a]=1;W[t,a]=1
    return source,labels,B,P,Fbasis,E,W
class Objective:
    def __init__(self,B,Fbasis,E,W,moment_weight=0.):
        self.B=B;self.F=Fbasis;self.E=E;self.W=W;self.weight=moment_weight;self.cache={}
    def evaluate(self,x):
        if 'x' in self.cache and np.array_equal(self.cache['x'],x):return self.cache['r'],self.cache['j']
        theta=x[:-1];H=np.einsum('a,aij->ij',theta,self.F)
        val,V=eigh(H,check_finite=False);VE=V.conj().T@self.E
        phase=np.exp(-1j*val);target=np.exp(1j*x[-1])*self.W
        UE=V@(phase[:,None]*VE);error=UE-target
        divided=-1j*np.exp(-1j*(val[:,None]+val[None,:])/2)*np.sinc((val[:,None]-val[None,:])/(2*np.pi))
        transformed=np.einsum('ia,kij,jb->kab',V.conj(),self.F,V,optimize=True)
        dU=np.einsum('ia,kab,bj->kij',V,transformed*divided[None,:,:],VE,optimize=True)
        derivatives=np.concatenate([dU,(-1j*target)[None,:,:]],axis=0).reshape(len(x),-1).T
        residual=np.r_[error.real.ravel(),error.imag.ravel()]
        jac=np.vstack([derivatives.real,derivatives.imag])
        if self.weight:
            c=self.B@theta;den=1+np.dot(c,c)
            HE=H@self.E;HW=H@self.W;BE=self.F@self.E;BW=self.F@self.W
            M=HE.conj().T@HE-HW.conj().T@HW
            dM=np.einsum('kia,ib->kab',BE.conj(),HE)+np.einsum('ia,kib->kab',HE.conj(),BE)-np.einsum('kia,ib->kab',BW.conj(),HW)-np.einsum('ia,kib->kab',HW.conj(),BW)
            dden=2*self.B.T@c
            dpen=(dM/den-M[None,:,:]*dden[:,None,None]/den**2).reshape(len(theta),-1).T
            dpen=np.column_stack([dpen,np.zeros(16)])
            residual=np.r_[residual,self.weight*M.real.ravel()/den,self.weight*M.imag.ravel()/den]
            jac=np.vstack([jac,self.weight*dpen.real,self.weight*dpen.imag])
        self.cache.update(x=x.copy(),r=residual,j=jac)
        return residual,jac
