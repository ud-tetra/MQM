"""Freeze the complex objective, candidate exclusions, spectral proof and IEEE A4 note."""
from pathlib import Path
import argparse,json,hashlib,zipfile,platform
import numpy,scipy,sympy,networkx,fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args()
assert args.visual_review_confirmed,'Inspect every current PDF page before release.'
def read(name):return json.loads((R/name).read_text())
def write(name,value):(R/name).write_text(json.dumps(value,indent=2)+'\n')
v=read('results/OBJECTIVE_RECEIPT.json');a0=read('results/COMPLEX_AUDIT.json');a1=read('results/COMPLEX_MOMENT_AUDIT.json')
c0=read('results/SPECTRAL_CERTIFICATE.json');c1=read('results/SPECTRAL_MOMENT_CERTIFICATE.json');ce=read('results/COUNTEREXAMPLE_RECEIPT.json')
s0=read('results/COMPLEX_SEARCH_RECEIPT.json');s1=read('results/COMPLEX_MOMENT_SEARCH_RECEIPT.json')
qa=read('results/PDF_QA.json');assert qa['pages']==3 and qa['no_overfull'] and qa['no_unresolved_references']
assert c0['strict_dyadic_channel_floor']==c1['strict_dyadic_channel_floor']=='1/8'
assert a0['excluded_at_error_2_minus_16_for_all_times'] and a1['excluded_at_error_2_minus_16_for_all_times']
assert len(s0['runs'])==len(s1['runs'])==4
qa['visual_review']='passed: all three final page renders inspected; IEEE two-column text, equations and table readable; final sections occupy both columns; no clipping or overlap'
write('results/PDF_QA.json',qa)
total=sum(j['exact_count'] for j in [v,a0,a1,c0,c1,ce]);assert total==198
parent=R.parent/'MQM_MOMENT_FILTERED_ADMISSION_v0.1_RELEASE.zip'
write('INPUT_ANCHORS.json',{
 'author':'Benjamin Walker Mayes','orcid':'0009-0002-5813-0724',
 'parent_pdf_library_id':'libfile_47f1c038f1188191a14faaf89d48171b',
 'parent_zip_library_id':'libfile_ef65c032f3548191ab80d8ad3640823c',
 'parent_zip_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.exists() else '6d92c971c45e82d8905a363bf639b9857193193963581bda41860dafc3ae9b20',
 'user_task':'Formalize and execute the unrun 97-coordinate planar Hermitian first-moment optimization.',
 'source_boundary':'Known exact source kernel and frozen preceding fit copied into separate PARENT records; user review scope corrected. Parent releases not modified.',
 'seeded_search_provenance':{'random_seed':2026100552,'starts_per_batch':4,'max_nfev_per_start':1000,'moment_weights':[0,2]},
 'publication_format':'Actual IEEEtran A4, 10pt, two columns',
 'external_claim_policy':'Bookkeeping charge graphs are not identified with Gauss-law or gravity operators; general matrix derivative and quantum channel methods are not claimed as novel.'})
write('CLAIM_REGISTER.json',{
 'kernel':{'status':'EXACT / AUTO_LOCK SCOPED','Pauli_terms':108,'first_moment_rank':11,'real_coordinates':97,'split':{'real_matrix_entry':55,'imaginary_matrix_entry':42},'physical_qubits':6,'allowed_pairs':10,'planar':True,'maximum_degree':4,
  'resource_charge':'Additional independently tunable Pauli components beyond preceding real ansatz; no additional qubits or allowed pairs in the abstract graph.'},
 'objective_gradient':{'status':'DERIVED analytic formulation; numerical implementation checked','endpoint':'All four columns, one common phase. Real and imaginary residual stacked.','derivative':'Complex spectral Frechet derivative with conjugate transposes and continuous sinc divided difference.','second_moment':'Soft penalty only; exact first-moment parameterization.','central_difference_columns':392,'directional_checks':2,'largest_discrepancy':max(c['max_error'] for c in v['gradient_checks'])},
 'search':{'status':'FINITE NUMERICAL EXPLORATION','starts':8,'endpoint_only_best_residual':s0['best']['isometry_operator_residual'],'penalty_best_residual':s1['best']['isometry_operator_residual'],'global_optimizer_certificate':False,'certified_endpoint_at_target':False},
 'moment_counterexample':{'status':'EXACT / AUTO_LOCK SCOPED','generator':'H=X_z','full_norm':1,'spectrum_width':2,'all_compressed_moments_match':True,'terminal_mode_activated':True,'native_charges_QA_QO_broken':True,'admission_complete_error':1,'scope':'This generator preserves native A and O; input01 never reaches its target.'},
 'spectral_alignment':{'status':'DERIVED exact criterion; proof supplied','criterion':'Every spectral projector must obey exp(-iT lambda) Pi_lambda E = exp(i phi) Pi_lambda W with common phi.','necessary_orientation':'S=sum_lambda |Tr W^dagger Pi_lambda E|=4','all_time_channel_floor':'Half diamond >= sqrt(1-(S/4)^2)','exact_admission_sufficiency':'Projector orientations AND one finite compatible deadline/phase; S=4 alone not sufficient.'},
 'frozen_candidate_spectral_exclusion':{'status':'EXACT ENCLOSED / AUTO_LOCK SCOPED','candidate_runs':[c0['best_run'],c1['best_run']],'strict_all_time_half_diamond_floor':'1/8 for each frozen best fit','witness':'Maximally entangled logical/reference input, reference dimension four','certification':'Exact dyadic Gram, eigen residual, polar-normalization and projector bounds; integer square-root enclosures.','scope':'The two named exact binary-rational models only; every deadline, scalar centering and uniform rescaling. Not the whole planar family.'},
 'verification':{'total_exact_checks':total,'counts_by_receipt':{'basis':v['exact_count'],'moment_audit_A':a0['exact_count'],'moment_audit_B':a1['exact_count'],'counterexample':ce['exact_count'],'spectral_A':c0['exact_count'],'spectral_B':c1['exact_count']},'optimization_runs':8,'gradient_column_checks':392,'gradient_directional_checks':2},
 'six_qubit_joint_admission':'OPEN','full_static_episode':'OPEN','physical_promotion':0,'independent_review':'pending','theorem_level_novelty_comparison':'pending'})
write('NEXT_GATE.json',{
 'target':'Original six-qubit native-to-four-mode single-excitation isometry, common phase, arbitrary spectators.',
 'next_objective':'Reduce spectral-subspace orientation deficit Gamma=4-sum_lambda |Tr W^dagger Pi_lambda E| on the SAME allowed planar graph. This is a necessary filter, not a finished encoder.',
 'follow_on':'Once projector orientations align, fit one finite deadline and common phase to all active eigenspace phases; certify full-register norm and complete channel error <=1/65536.',
 'moment_role':'Exact first and higher moments are necessary prefilters. Even all moments plus terminal activation are insufficient, as H=X_z proves.',
 'charges':'Nonzero [H,N_z] remains necessary; native charge breaking alone does not establish reachability.',
 'near_degeneracy_policy':'Use true spectral projectors or certified clusters; arbitrary phases inside degenerate eigenspaces are not available from exp(-iTH). Charge small gaps, long phase times and coupling components.',
 'resource_ledger':['Six qubits and ten allowed planar pairs initially','Full 64-dimensional centered norm','Per-component coupling ceilings','Seed preparation and native/spectator domain','Finite deadline and readout interval','Additional components introduced by odd-Y terms'],
 'negative_result_policy':'Finite search failure does not force nonplanarity, additional registers or carrier abandonment. Frozen-generator certificates exclude only those generators.',
 'downstream_open':['Native extraction','Sixteen-mode core interface','Static gate concatenation','Irreversible retention','Supervising-clock refresh','Thermodynamic supply','Physical realization']})
write('REVIEW_CORRECTIONS.json',{
 'first_moment_space':'20+35 and 45+10 refer to the prior 55-coordinate real matrix-entry kernel, not the full 97-coordinate Hermitian kernel.',
 'two_local_terms':'Support at most two includes one-body fields such as X_z; sums can contain both one- and two-body terms.',
 'activation':'Changing N_z is necessary but does not guarantee correct data transfer or native reset.',
 'unitarity':'Hermitian candidate evolution remains unitary; endpoint admission failure is an isometry-contract error.',
 'failure_scope':'Eight bounded fits and two all-time spectral exclusions do not establish a family no-go or mandatory graph/carrier change.',
 'physical_correspondence':'No Gauss-law, Wilson-loop or gravitational correspondence is established by this operator graph.'})
write('ARITHMETIC_COUNTS.json',{
 'physical_dimension':'64=2^6','logical_dimension':'4=2^2','Pauli_parameter_count':'108=2^2*3^3','kernel_dimension':'97 is prime','exact_check_count':'198=2*3^2*11','dyadic_target':'1/65536=2^-16','certified_strict_channel_floor':'1/8=2^-3',
 'scope':'Arithmetic factorizations of typed counts; no geometric or physical identity is inferred from equal integers.'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'networkx':networkx.__version__,'pymupdf':fitz.VersionBind})
(R/'README.txt').write_text('''Complex Hermitian Optimization and Spectral Alignment for Joint Qubit Admission
Benjamin Walker Mayes | ORCID 0009-0002-5813-0724 | MQM development note v0.1

STATUS
The 97-real-coordinate Hermitian planar search has now been executed in eight
bounded starts (four endpoint-only, four with a second-moment soft penalty).
No encoder was found. Best sampled operator residual: 0.32910369230828146.
An optimizer residual is not a certified complete-channel error.

EXACT RESULTS
The full kernel is 55 real-matrix-entry plus 42 imaginary-matrix-entry directions.
The generator H=X_z activates the terminal mode and matches ALL compressed
spectral moments but preserves native occupations, failing admission at all
times. Spectral-subspace orientation and compatible phases remain necessary.
Exact dyadic spectral enclosures prove complete half-diamond error > 1/8 for
each best frozen generator at EVERY deadline and uniform norm rescaling.
These are candidate exclusions, not a planar-family impossibility theorem.
The logical/reference witness retains a reference of dimension four.

EVIDENCE
198 scoped exact checks; 392 central-difference Jacobian column checks and two
directional checks; eight finite optimizer starts. Independent review and
theorem-level novelty comparison pending. Physical evidence promotion 0.
Six-qubit joint single-excitation admission remains OPEN.

REPLAY (requires numpy, scipy, sympy, networkx, PyMuPDF; pdflatex for PDF)
  python3 verify_objective.py
  python3 audit_complex.py
  python3 audit_complex.py --moment
  python3 spectral_certificate.py
  python3 spectral_certificate.py --moment
  python3 verify_counterexample.py
The stored coefficients are exact binary-rational kernel combinations. Spectral
certificates treat the approximate eigensolver's output as dyadic input only;
Gaussian-integer backward errors and integer square roots certify all bounds.

OPTIONAL RE-OPTIMIZATION (overwrites search receipts; versions may change fits)
  python3 search_complex.py --max-nfev 1000
  python3 search_complex.py --max-nfev 1000 --moment-weight 2
The coordinate box is not a physical coupling or full-norm ceiling. Normalize
the full spectrum separately. Additional coupling components are admitted on
the same six-qubit ten-pair planar graph and remain charged to realizability.
Run ALL audits again after changing any candidate or basis.

PDF AND RELEASE
  python3 build_ieee_note.py
Inspect all three current PAGE_*.png files before freezing:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran A4, 10pt, two columns; IEEEtran class and LPPL bundled.
Parent releases remain unchanged. All hashes are in SHA256SUMS.txt.

NEXT TARGET
Spectral-subspace alignment on the same planar graph, then one finite deadline
and common phase, with full-norm and complete-input certificates. Moment-only
or independent-population objectives cannot close the coherent admission task.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'pages':qa['pages'],'exact_checks':total}))
