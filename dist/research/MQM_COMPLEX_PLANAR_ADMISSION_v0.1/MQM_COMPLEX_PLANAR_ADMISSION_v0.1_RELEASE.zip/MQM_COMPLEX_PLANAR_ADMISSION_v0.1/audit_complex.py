"""Exact Gaussian-rational moment witness for a frozen complex Hermitian fit."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json,argparse
import numpy as np
from complex_objective import load_model
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--moment',action='store_true');args=ap.parse_args()
name='COMPLEX_MOMENT_SEARCH_RECEIPT.json' if args.moment else 'COMPLEX_SEARCH_RECEIPT.json'
run=json.loads((R/'results'/name).read_text());best=run['best']
source,labels,B,P,Fbasis,E,W=load_model()
theta=[Q(t) for t in best['kernel_coordinates_exact']]
c=[Q(best['Pauli_coefficients_exact'][l]) for l in labels]
checks=[]
def check(n,v):
    assert v,n
    checks.append(n)
check('exact integer-kernel coefficient freeze',all(c[k]==sum((Q(int(B[k,a]))*theta[a] for a in range(97)),Q(0)) for k in range(108)))
HR=[[Q(0) for _ in range(64)] for _ in range(64)]
HI=[[Q(0) for _ in range(64)] for _ in range(64)]
for coeff,p in zip(c,P):
    for r,col in zip(*np.nonzero(p)):
        HR[int(r)][int(col)]+=int(p[r,col].real)*coeff
        HI[int(r)][int(col)]+=int(p[r,col].imag)*coeff
check('full 64-dimensional Gaussian-rational Hamiltonian Hermitian',all(HR[r][k]==HR[k][r] and HI[r][k]==-HI[k][r] for r in range(64) for k in range(64)))
ss=[8,24,40,56];tt=[8,4,2,1]
check('first-moment matrix exactly zero in real and imaginary parts',all(HR[ss[a]][ss[b]]==HR[tt[a]][tt[b]] and HI[ss[a]][ss[b]]==HI[tt[a]][tt[b]] for a in range(4) for b in range(4)))
charges={'QA':[1,0,0,0,1,1],'QO':[0,1,0,1,0,1],'Nz':[0,0,0,0,0,1]}
def charge_value(index,q):return sum(v*((index>>(5-k))&1) for k,v in enumerate(q))
flags={n:any((HR[a][b] or HI[a][b]) and charge_value(a,q)!=charge_value(b,q) for a in range(64) for b in range(64)) for n,q in charges.items()}
check('frozen candidate changes terminal mode occupation',flags['Nz'])
check('frozen candidate breaks a native bookkeeping charge',flags['QA'] or flags['QO'])
MR=[[Q(0) for _ in range(4)] for _ in range(4)];MI=[[Q(0) for _ in range(4)] for _ in range(4)]
def inner_columns(a,b):
    re=sum((HR[k][a]*HR[k][b]+HI[k][a]*HI[k][b] for k in range(64)),Q(0))
    im=sum((HR[k][a]*HI[k][b]-HI[k][a]*HR[k][b] for k in range(64)),Q(0))
    return re,im
for a in range(4):
    for b in range(4):
        er,ei=inner_columns(ss[a],ss[b]);wr,wi=inner_columns(tt[a],tt[b]);MR[a][b]=er-wr;MI[a][b]=ei-wi
check('exact second-moment matrix Hermitian',all(MR[a][b]==MR[b][a] and MI[a][b]==-MI[b][a] for a in range(4) for b in range(4)))
ledger=sum((abs(a) for a in c),Q(0));check('full physical Pauli sum norm bound positive',ledger>0)
witnesses=[]
for a in range(4):witnesses.append({'input':f'|{a:02b}>','delta':MR[a][a]})
for a in range(4):
    for b in range(a+1,4):
        for sign in (-1,1):
            witnesses.append({'input':f'(|{a:02b}> {"+" if sign==1 else "-"} |{b:02b}>)/sqrt(2)','delta':(MR[a][a]+MR[b][b])/2+sign*MR[a][b]})
            witnesses.append({'input':f'(|{a:02b}> {"+" if sign==1 else "-"} i|{b:02b}>)/sqrt(2)','delta':(MR[a][a]+MR[b][b])/2-sign*MI[a][b]})
selected=max(witnesses,key=lambda w:abs(w['delta']))
floor=abs(selected['delta'])/(2*ledger**2);den=1
while floor and Q(1,den)>=floor:den*=2
simple=Q(1,den) if floor else Q(0)
check('selected second-moment lower bound and dyadic bracket',floor==abs(selected['delta'])/(2*ledger**2) and (not floor or floor>simple))
rounding=sum((abs(Q(float(v))-v) for v in c),Q(0))
check('binary64 independent coefficient rounding debit nonnegative',rounding>=0)
receipt={'status':'Scoped exact Gaussian-rational frozen-candidate audit; not a family exclusion',
 'batch':'second_moment_penalty' if args.moment else 'endpoint_only','best_run':best['run'],'exact_count':len(checks),'exact_checks':checks,
 'physical_register_dimension':64,'first_moment':'exact zero complex 4x4 matrix','second_moment_real':[[str(v) for v in row] for row in MR],'second_moment_imag':[[str(v) for v in row] for row in MI],
 'charge_commutators_nonzero':flags,'witness_input':selected['input'],'second_moment_delta':str(selected['delta']),'Pauli_norm_upper_bound':str(ledger),
 'all_time_trace_error_floor':str(floor),'strict_dyadic_lower_bound':str(simple),'error_floor_decimal_diagnostic':float(floor),'excluded_at_error_2_minus_16_for_all_times':floor>Q(1,65536),
 'coefficient_rounding_norm_debit':str(rounding),'coefficient_rounding_norm_debit_decimal':float(rounding),
 'scope':'Exact binary-rational frozen coefficients assembled from the integer kernel. Static H conserves H^2; trace duality gives D>=abs(delta)/(2 sum(abs(c_P))^2). Every deadline and uniform norm rescaling for this generator only.',
 'physical_promotion':0,'independent_review':'pending','joint_admission':'OPEN'}
dest='COMPLEX_MOMENT_AUDIT.json' if args.moment else 'COMPLEX_AUDIT.json'
(R/'results'/dest).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('exact_count','best_run','witness_input','strict_dyadic_lower_bound','error_floor_decimal_diagnostic','excluded_at_error_2_minus_16_for_all_times')}))
