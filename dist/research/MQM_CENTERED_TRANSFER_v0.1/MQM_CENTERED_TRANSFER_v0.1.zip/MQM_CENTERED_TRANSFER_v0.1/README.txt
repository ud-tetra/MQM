MQM centered transfer v0.1, development release, 7 October2026.
Replay: python3 audit.py; python3 control_embedding.py. PDF: python3 build_pdf.py (pdflatex and Poppler required). Python3.12.14; dependencies pinned in requirements.txt.
The proof and exact fraction checks supply a conditional ideal-reference comparison. Numerical controls and inherited finite response remain simulations. Directed finite response error, independent review, complete thermal target and physical realization remain OPEN. Physical promotion0.
Capacity selection is a separate track. See CAPACITY_SELECTION_GATES.md. Equal192 counts are not identified.
The protocol accepted <2^-28; the stronger achieved <2^-30 is a reported result, not a retroactively changed threshold.
