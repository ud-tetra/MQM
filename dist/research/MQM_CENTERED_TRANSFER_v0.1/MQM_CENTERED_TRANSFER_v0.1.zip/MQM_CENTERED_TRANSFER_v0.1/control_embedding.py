import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,math
import numpy as np
from numpy.polynomial.legendre import leggauss,legvander
from scipy.special import spherical_jn
from fractions import Fraction
P=Path(__file__).resolve().parent;pr=json.loads((P/'CONTROL_PROTOCOL.json').read_text());rows=[]
for M in pr['M']:
 x,w=leggauss(M);omega=w/2;E=np.sqrt(omega[:,None])*legvander(x,M-1)*np.sqrt(2*np.arange(M)+1)
 iso=float(np.linalg.norm(E.T@E-np.eye(M)));assert iso<1e-11
 for st in pr['centered_time_offsets']:
  tau=float(Fraction(st));a=16*tau;n=np.arange(M+128)
  coeff=(-1j)**n*np.sqrt(2*n+1)*spherical_jn(n,a)
  finite=E.T@(np.sqrt(omega)*np.exp(-1j*a*x))
  error=float(np.sqrt(np.linalg.norm(coeff[:M]-finite)**2+np.linalg.norm(coeff[M:])**2))
  xx=a/2;bound=4*xx**M/math.factorial(M)/(1-xx/(M+1))
  assert error<=bound+1e-12
  rows.append({'M':M,'tau':st,'evaluation_isometry_error':iso,'normalized_feature_error':error,'Poisson_upper_diagnostic':bound})
(P/'results/EMBEDDING_CONTROL.json').write_text(json.dumps({'status':'SIMULATED implementation control; analytic theorem independent of numerical check','rows':rows},indent=2)+'\n')
print('Embedding controls',len(rows),'PASS; max isometry error',max(r['evaluation_isometry_error'] for r in rows))
