"""IEEEtran/A4 note for certified regular moment geometry and scoped failure."""
from pathlib import Path
from fractions import Fraction as Q
import json,subprocess
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript'
def read(n):return json.loads((R/'results'/n).read_text())
geo=read('MOMENT_GEOMETRY.json');s=read('MANIFOLD_SEARCH.json');g=read('MOMENT_GRADIENT_RECEIPT.json');root=read('ROOT_CERTIFICATE.json');floor=read('ROOT_SPECTRAL_FLOOR.json')
rows='\n'.join(f"{r['run']} & {r['isometry_operator_residual']:.6f} & {r['normalized_moment_max']:.2g} & {r['iterations']} \\\\" for r in s['runs'])
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\begin{document}
\title{A Certified Regular Second-Moment Branch\\for Planar Joint Qubit Admission}
\author{Benjamin Walker Mayes\thanks{MQM development note v0.1, October 6, 2026. ORCID: 0009-0002-5813-0724. Scoped conditional derivation and constructor replay; independent review and theorem-level novelty comparison pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We derive the exact quadratic second-moment constraints for a six-qubit planar joint-admission interface with 97 Hermitian first-moment coordinates. Sixteen real Hermitian components reduce to fifteen independent quadratic forms. Exact integer Jacobian probes have rank fifteen, but the feasible $X_z$ control has rank thirteen. Four bounded equality-constrained searches find no certified encoder. A rational contraction argument instead certifies a nearby exact real algebraic second-moment-zero point with a regular fifteen-coordinate Jacobian. The implicit-function theorem gives a local 82-dimensional feasible branch, not a global manifold claim. Full-spectrum norm remains bounded by one at a conservative finite deadline below 512. Nevertheless, a transferred spectral-projector enclosure excludes this exact moment-feasible point from admission at every deadline: half-diamond error is strictly greater than $1/16$. The release supplies 245 scoped exact checks and 196 numerical nonlinear-gradient checks. Local moment feasibility is certified; the complete operational interface remains open.
\end{abstract}
\begin{IEEEkeywords}
Autonomous quantum control, second moment, exact root, two-local Hamiltonian, interval certification.
\end{IEEEkeywords}
\section{Interface and physical accounting}
Use physical register order $(A,O,u,v,w,z)$ and mode labels $(00,01,10,11)$. The four-column isometries are
\begin{align}
E\ket{ab}&=\ket{ab}_{AO}\ket{\mathbf1_{00}}_M,\\
W\ket{ab}&=\ket{00}_{AO}\ket{\mathbf1_{ab}}_M.
\end{align}
Admission requires $e^{-iTH}E=e^{i\phi}W$ for a physical Hamiltonian $H$, with one common phase on arbitrary coherent inputs and spectators. The mode excitation condition is imposed at the endpoint, not assumed during transfer.

The permitted pairs are $\{Au,Aw,Az,Ou,Ov,Ow,Oz,uw,uv,wz\}$, a planar graph of maximum degree four. Its 108 nonidentity Hermitian Pauli terms have support at most two, including one-body fields. The inherited integer kernel gives
\begin{equation}
G(\theta)=\sum_k(B\theta)_kP_k=\sum_{a=1}^{97}\theta_aF_a,
\end{equation}
with exact $E^\dagger GE=W^\dagger GW$. Real coefficients permit complex matrix entries. The previous joint-phase study \cite{parent} supplied a failed fit with nonzero second-moment mismatch. This note resolves the next local moment-feasibility question without changing qubits or permitted pairs.

For an accumulated generator $G$, define $L=\sum_k|c_k|$. Then $H=G/L$ has full 64-dimensional norm at most one and implements $e^{-iG}$ at deadline $T=L$. The declared conservative cap remains $L\le512$. It is not a low-energy budget, nor an optimal centered norm. No resource advantage or physical gravitational/gauge correspondence is claimed.

\section{Exact quadratic equations and rank}
The necessary second-moment condition is
\begin{equation}
M_2(\theta)=E^\dagger G^2E-W^\dagger G^2W=0.
\end{equation}
List four real diagonal components and real/imaginary parts of six upper off-diagonal components. Each of these sixteen real polynomials has form
\begin{equation}
q_j(\theta)=\tfrac12\theta^\mathsf TD_j\theta,
\qquad D_j\in\mathbb Z^{97\times97},\quad D_j=D_j^\mathsf T.
\end{equation}
For a logical matrix entry, the twice-coefficient tensor comes from the appropriate real or imaginary part of
\begin{equation}
E^\dagger(F_aF_b+F_bF_a)E
-W^\dagger(F_aF_b+F_bF_a)W.
\end{equation}
The input and target columns for $\ket{00}$ coincide. Hence $q_0=\operatorname{Re}(M_2)_{00}=0$ identically. Flattening the integer symmetric forms and exact row reduction proves rank fifteen: a nonzero integer minor witnesses independence of the remaining forms, and exact relations reconstruct all sixteen. Three integer coordinate probes have Jacobian rank fifteen.

Polynomial independence does not imply Jacobian independence everywhere. The exact feasible $G=X_z$ has rank thirteen, while the origin has rank zero. $X_z$ matches all compressed moments but retains native occupations and is not an encoder. A solver launched at that control cannot assume fifteen independent local constraint normals. A regular zero point, if established, has local dimension $97-15=82$; the generic integer probes alone do not establish such a point on the zero fiber.

\section{Finite equality-constrained continuation}
The objective keeps all four columns and a common phase:
\begin{equation}
f=\tfrac12\|e^{-iG(\theta)}E-e^{i\phi}W\|_F^2.
\end{equation}
Impose fifteen equalities $q_j/s=0$, where $s=1+\|B\theta\|_2^2>0$. This preserves the mathematical zero set but does not make floating feasibility exact. The derivative is
\begin{equation}
\partial_a(q_j/s)=\frac{(D_j\theta)_a}{s}
-\frac{2q_j(B^\mathsf TB\theta)_a}{s^2}.
\end{equation}
The phase column is zero. All 196 columns at two probes pass central-difference checks with step $10^{-6}$; maximum discrepancy is @GRAD@. The full-norm deadline inequality uses the inherited conservative smoothing $\sum_k\sqrt{c_k^2+10^{-16}}\le512$, followed by an exact frozen ledger.

Four SLSQP starts are capped at 600 iterations. They use the preceding joint fit, its endpoint lineage, a seeded perturbation, and the $X_z$ control.
\begin{table}[t]
\caption{Numerical diagnostics; moment entry is $\max_j|q_j/s|$.}
\centering\begin{tabular}{c|c|c|c}
Run & $\|R\|$ & Moment max & Iterations\\\hline
@ROWS@
\end{tabular}
\end{table}
One fit reports success; two reach the cap, and the rank-deficient control stops after one iteration. The selected numerical fit has residual @RESID@. It is not better than the preceding unconstrained endpoint fit and is not an exact encoder. Its frozen binary-rational coefficients still have nonzero $M_2$. Exact feasibility requires a separate construction.

\section{Rational certification of an exact regular zero}
Select fifteen coordinate columns by a numerical pivot proposal, then fix the other 82 coordinates as exact binary fractions. A short numerical Newton refinement supplies a center $y_0$ in this slice; its stopping criterion is not the proof. The fifteen rational quadratic equations define $q(y)$, with exact Jacobian $J_0$ and constant Hessians. Freeze an approximate inverse as a dyadic matrix $R_0$ and define
\begin{equation}
\mathcal T(y)=y-R_0q(y).
\end{equation}
Exact rational arithmetic encloses
\begin{align}
\eta&=\|R_0q(y_0)\|_\infty,\\
\beta_0&=\|I-R_0J_0\|_\infty,\\
\beta(r)&=\beta_0+\kappa r,
\end{align}
where $\kappa$ is the maximum row sum over both variable indices of the preconditioned Hessian tensor. For radius
\begin{equation}
r=2^{-49},\qquad \beta(r)<1,\qquad
\eta+\beta(r)r<r,
\end{equation}
all inequalities pass exactly. Diagnostic values are $\eta\simeq@ETA@$ and $\beta(r)\simeq@BETA@$.
\begin{proposition}[Certified regular second-moment point]
The declared fifteen-coordinate rational slice has one unique real root in the closed box $\|y-y_0\|_\infty\le r$. All first and second compressed moments match exactly there. Its full second-moment Jacobian has rank fifteen, giving a local real zero manifold of dimension 82.
\end{proposition}
\begin{proof}
The derivative bound makes $\mathcal T$ a contraction on the box, and the strict residual inequality maps it into itself. Banach's theorem gives a unique fixed point. Since $\beta_0<1$, both $R_0$ and $J_0$ are invertible; the same Neumann argument applies to $R_0J(y)$ throughout the box. The fixed point is therefore a root and its selected minor is nonsingular. Exact global row relations include the sixteenth component. The first moment is enforced identically by $B$. The implicit-function theorem gives the local 82-dimensional zero branch.
\end{proof}
The root is defined implicitly by rational polynomials and its unique box; its coefficients are real algebraic, not claimed binary-rational. Uniqueness concerns this fixed 15-coordinate slice, not the whole zero set. The Pauli triangle inequality gives
\begin{equation}
\|G_*-G_0\|\le d=r\sum_{a\in\mathrm{ports}}\sum_k|B_{ka}|.
\end{equation}
Consequently $L_*^{\rm up}=L_0+d<512$, approximately @DEADLINE@. Using $H_*=G_*/L_*^{\rm up}$ certifies full norm at most one and deadline $L_*^{\rm up}$.

\section{Exact moments still do not close admission}
The dyadic center has an exact spectral-projector enclosure, obtained from Gaussian-integer eigen/Gram residuals and integer square-root bounds. Let its true spectral gap lower bound be $\gamma_0$, with $\gamma_0>2d$. Each root projector differs from the corresponding center projector by at most $d/(\gamma_0-d)$. Thus
\begin{equation}
S_*\le S_0^{\rm up}+256\frac{d}{\gamma_0-d},\qquad
S=\sum_\lambda|\operatorname{Tr}(W^\dagger\Pi_\lambda E)|.
\end{equation}
The factor is $64\cdot4$, charging every full-domain projector and all four logical columns. A maximally entangled logical/reference input then proves, at every deadline,
\begin{equation}
\tfrac12\|\mathcal U_t-\mathcal W\|_\diamond
\ge\sqrt{1-(S_*/4)^2}>1/16.
\end{equation}
The root's radical lower-bound diagnostic is @FLOOR@. Scalar shifts and uniform norm scaling do not remove this spectral obstruction. It excludes one exact regular moment-feasible point, not the planar family.

The next development gate is rank-aware, retracted endpoint optimization along the regular branch. For dependent coordinates $y$, free coordinates $z$, and $q(y,z)=0$,
\begin{equation}
\frac{dy}{dz}=-J_y^{-1}J_z,\qquad
\nabla_z f_{\rm branch}=\nabla_z f-J_z^\mathsf TJ_y^{-\mathsf T}\nabla_y f.
\end{equation}
There are 82 free coordinates plus one common phase, not 83 physical qubits. Each promising iterate needs a fresh exact root, norm and complete-input deadline/window audit. Third and higher moments remain diagnostics, never sufficient substitutes for spectral orientation and common phase matching. Native joint admission remains OPEN at target $2^{-16}$; no encoded-core composition or physical promotion follows. Independent review and novelty comparison are pending. Publication remains conditional on a matched resource improvement or informative competing-architecture lower bound.
\begin{thebibliography}{1}
\bibitem{parent} B. W. Mayes, ``Finite-Budget Joint Phase Optimization for a Planar Qubit-Admission Interface,'' MQM development note v0.1, Oct. 6, 2026, immutable replay release; independent review pending.
\end{thebibliography}
\end{document}
'''
v={'GRAD':f"{g['max_discrepancy']:.3g}",'ROWS':rows,'RESID':f"{s['best']['isometry_operator_residual']:.6f}",'ETA':f"{float(Q(root['eta_preconditioned_residual_inf'])):.3g}",'BETA':f"{float(Q(root['contraction_beta'])):.3g}",'DEADLINE':f"{float(Q(root['root_Pauli_norm_upper'])):.6f}",'FLOOR':f"{floor['floor_diagnostic']:.6f}"}
for k,val in v.items():tex=tex.replace('@'+k+'@',val)
name='MQM_SECOND_MOMENT_MANIFOLD_IEEE_A4_v0.1';(M/(name+'.tex')).write_text(tex)
for k in range(2):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,capture_output=True,text=True)
    (R/'results'/('PDF_BUILD_'+str(k)+'.txt')).write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout[-3000:]
doc=fitz.open(M/(name+'.pdf'));log=(M/(name+'.log')).read_text()
for i,p in enumerate(doc):p.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(R/'results'/('PAGE_'+str(i+1)+'.png'))
qa={'pages':len(doc),'A4':all(abs(p.rect.width-595.276)<1 and abs(p.rect.height-841.89)<1 for p in doc),'actual_IEEEtran':True,'class_options':'journal,a4paper,10pt','two_columns':True,'no_overfull':'Overfull' not in log,'no_unresolved_references':'undefined' not in log,'visual_review':'pending'}
(R/'results'/'PDF_QA.json').write_text(json.dumps(qa,indent=2));print(qa)
