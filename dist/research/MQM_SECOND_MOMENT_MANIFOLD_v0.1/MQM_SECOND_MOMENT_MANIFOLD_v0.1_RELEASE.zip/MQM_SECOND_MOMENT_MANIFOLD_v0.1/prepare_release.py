"""Freeze local moment-feasibility certificate and IEEE/A4 successor."""
from pathlib import Path
import argparse,json,hashlib,zipfile,platform
import numpy,scipy,sympy,networkx,fitz
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--visual-review-confirmed',action='store_true');args=ap.parse_args()
assert args.visual_review_confirmed
def read(n):return json.loads((R/n).read_text())
def write(n,d):(R/n).write_text(json.dumps(d,indent=2)+'\n')
geo=read('results/MOMENT_GEOMETRY.json');a=read('results/FROZEN_AUDIT.json');root=read('results/ROOT_CERTIFICATE.json');center=read('results/ROOT_CENTER_SPECTRAL_CERTIFICATE.json');floor=read('results/ROOT_SPECTRAL_FLOOR.json');s=read('results/MANIFOLD_SEARCH.json');g=read('results/MOMENT_GRADIENT_RECEIPT.json');qa=read('results/PDF_QA.json')
assert geo['polynomial_row_rank_exact']==15 and geo['X_z_Jacobian_rank_exact']==13
assert floor['strict_dyadic_error_floor']=='1/16' and floor['exact_second_moment_zero']
total=sum(r['exact_count'] for r in [geo,a,root,center,floor]);assert total==245
assert qa['pages']==2 and qa['A4'] and qa['actual_IEEEtran'] and qa['no_overfull'] and qa['no_unresolved_references']
qa['visual_review']='PASSED: both final page renders inspected; readable IEEE two columns, equations and table; no overlap or clipping'
write('results/PDF_QA.json',qa)
parent=R.parent/'MQM_JOINT_PHASE_ADMISSION_v0.1_RELEASE.zip'
write('INPUT_ANCHORS.json',{'parent_library_zip_id':'libfile_f80bd5eb2bb48191b083226d9b32d3db','parent_library_pdf_id':'libfile_df96ac79641c819186ac8a94fdd267c5','parent_zip_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'parent_immutable':True,'author':'Benjamin Walker Mayes','orcid':'0009-0002-5813-0724','user_task':'Continue next MQM paper development step; second-moment manifold gate','instruction_source':'Copied MQM v0.2 working conventions. Its dated handoff is a parent snapshot; current handoff is NEXT_GATE.json.'})
write('CLAIM_REGISTER.json',{'quadratic_geometry':{'status':'EXACT / AUTO_LOCK SCOPED','kernel_coordinates':97,'Hermitian_components':16,'polynomial_row_rank':15,'integer_Jacobian_probe_ranks':[p['Jacobian_rank_exact'] for p in geo['integer_Jacobian_probes']],'X_z_zero_point_rank':13,'origin_zero_point_rank':0,'scope':'Fifteen independent quadratic forms, not globally regular constraints.'},'finite_search':{'status':'NUMERICAL bounded exploration','attempts':4,'iteration_cap':600,'best_operator_residual':s['best']['isometry_operator_residual'],'floating_equality_is_not_exact':True,'certified_encoder':False},'exact_regular_root':{'status':'EXACT RATIONAL CONTRACTION / AUTO_LOCK SCOPED','unique_in_fixed_slice_box':True,'varied_coordinates':15,'fixed_coordinates':82,'root_type':'Implicitly defined real algebraic root of rational quadratics, not frozen binary-rational coefficients','box_radius':root['box_radius_inf'],'first_moment_exact_zero':True,'second_moment_exact_zero':True,'Jacobian_rank':15,'local_zero_manifold_dimension':82,'global_manifold_or_uniqueness_claim':False,'full_norm_implementation':'G_root / L_root_upper; norm<=1 on all64 dimensions','finite_deadline_upper':root['root_Pauli_norm_upper'],'feasibility_gate':'Local second-moment feasibility CLOSED, complete admission OPEN'},'root_admission_exclusion':{'status':'EXACT ENCLOSED / AUTO_LOCK SCOPED','all_time_half_diamond_error':'strictly greater than1/16','scope':'This exact algebraic root only; all deadlines, common phases, spectators, scalar shifts and uniform norm rescaling. Not a family no-go.'},'total_scoped_exact_checks':total,'numerical_gradient_columns':g['columns_checked'],'physical_promotion':0,'operational_resource_improvement':False,'independent_review':'pending','theorem_level_novelty_comparison':'pending'})
write('NEXT_GATE.json',{'status':'OPEN','target':'Rank-aware retracted coherent endpoint optimization on the certified regular branch','local_geometry':'15 dependent coordinates solve rational quadratic equations;82 free coordinates plus one common phase','objective':'0.5||exp(-iG(theta(z)))E-exp(i phi)W||_F^2','reduced_gradient':'grad_z f - J_z^T J_y^(-T) grad_y f','workflow':['Start from the certified root slice and its identified ports; the local regular branch does not imply a global chart.','Vary free coordinates with a declared step/trust region; solve dependent coordinates and verify Jacobian nonsingularity.','Use exact rational contraction or interval certification for each selected root; do not infer exact feasibility from small floating residuals.','Maintain full64-dimensional norm<=1 and a declared finite deadline cap.','Monitor higher moments and projector orientation but keep all four coherent endpoint columns and one common phase.','Require complete error<=2^-16 on a nonzero readout window before encoded-core composition.'],'singular_point_policy':'Rank13 X_z control and origin are not regular starting charts; do not pretend the fifteen constraint normals are independent there.','failure_scope':'Frozen point or implicit root exclusion only; no family no-go from finite continuation.','publication_target':'Matched operational resource improvement or informative lower bound across competing architectures.'})
write('ARITHMETIC_COUNTS.json',{'physical_dimension':'64=2^6','logical_dimension':'4=2^2','kernel_coordinates':'97 is prime','second_moment_components':'16=2^4','independent_quadratics':'15=3*5','local_free_coordinates':'82=2*41','free_plus_phase':'83 is prime','contraction_radius':'1/562949953421312=2^-49','deadline_cap':'512=2^9','target_denominator':'65536=2^16','exact_checks':'245=5*7^2','gradient_columns':'196=2^2*7^2','scope':'Different typed counts are not interchangeable physical objects.'})
write('REPLAY_ENVIRONMENT.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'networkx':networkx.__version__,'pymupdf':fitz.VersionBind})
(R/'README.txt').write_text('''A Certified Regular Second-Moment Branch for Planar Joint Qubit Admission
Benjamin Walker Mayes | ORCID0009-0002-5813-0724 | MQM note v0.1

RESULT
Exact quadratic component rank15, not16. Three integer Jacobian probes have
rank15; the feasible X_z control has rank13 and the origin rank0.
Four bounded equality-constrained attempts supply no certified encoder.
A rational Banach contraction proves one exact regular algebraic root in a
fixed15-coordinate slice. The remaining82 coordinates are exact dyadic values.
All first and second moments match at the root; the local zero manifold has
dimension82. This is not a global regularity or uniqueness theorem.
The root is not claimed to have binary-rational coefficients. It is defined by
its exact rational polynomial system, fixed coordinates and unique closed box.

The root has a certified full-norm<=1 implementation with conservative deadline
approximately356.049424, below512. Despite exact moment feasibility, its complete
half-diamond admission error is >1/16 at EVERY deadline, from an exact spectral
projector enclosure transferred across the root box. This excludes one regular
moment-feasible root, not the planar family. Joint admission remains OPEN.
245 scoped exact checks and196 numerical nonlinear-gradient checks.
Independent review and novelty comparison pending. Physical promotion0.

REPLAY (numpy, scipy, sympy, networkx)
  python3 moment_geometry.py
  python3 verify_frozen.py
  python3 certify_root.py
  python3 spectral_certificate.py --root-center
  python3 certify_root_spectral_floor.py
Root Newton iterations only propose a center. Exact residual, preconditioner,
quadratic Hessian bounds and rational comparisons are the existence proof.
The dyadic spectral center is NOT the exact root; the root box perturbation is
charged explicitly to the all-time error floor. Every physical sector is kept.

OPTIONAL RE-OPTIMIZATION (overwrites search receipt)
  python3 search_manifold.py
Repeat all certificate steps above after any change. Four attempts,600 iterations
each, normalized second-moment equalities and declared norm/deadline cap512.
Numerical feasibility is not exact feasibility. The singular X_z control stops
after one iteration; its moments match but it is not an encoder.

PDF (PyMuPDF and pdflatex)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png files, then:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two columns; class license included.

NEXT
Read NEXT_GATE.json: rank-aware retracted endpoint search on the local regular
branch,82 free coordinates plus one phase. Each selected iterate requires a
fresh exact root and full-domain error/deadline/window certificate. Higher
moments are diagnostics, never sufficient substitutes for spectral orientation
and common phase matching. Native admission closes before encoded SWAP routing.
Copied instructions v0.2 contain a parent snapshot; NEXT_GATE is current.
All parent releases remain immutable. SHA256SUMS.txt covers distributed files.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts)
(R/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files))
dest=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files+[R/'SHA256SUMS.txt']:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
print(json.dumps({'zip':str(dest.resolve()),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files)+1,'pages':qa['pages'],'exact_checks':total}))
