A Certified Regular Second-Moment Branch for Planar Joint Qubit Admission
Benjamin Walker Mayes | ORCID0009-0002-5813-0724 | MQM note v0.1

RESULT
Exact quadratic component rank15, not16. Three integer Jacobian probes have
rank15; the feasible X_z control has rank13 and the origin rank0.
Four bounded equality-constrained attempts supply no certified encoder.
A rational Banach contraction proves one exact regular algebraic root in a
fixed15-coordinate slice. The remaining82 coordinates are exact dyadic values.
All first and second moments match at the root; the local zero manifold has
dimension82. This is not a global regularity or uniqueness theorem.
The root is not claimed to have binary-rational coefficients. It is defined by
its exact rational polynomial system, fixed coordinates and unique closed box.

The root has a certified full-norm<=1 implementation with conservative deadline
approximately356.049424, below512. Despite exact moment feasibility, its complete
half-diamond admission error is >1/16 at EVERY deadline, from an exact spectral
projector enclosure transferred across the root box. This excludes one regular
moment-feasible root, not the planar family. Joint admission remains OPEN.
245 scoped exact checks and196 numerical nonlinear-gradient checks.
Independent review and novelty comparison pending. Physical promotion0.

REPLAY (numpy, scipy, sympy, networkx)
  python3 moment_geometry.py
  python3 verify_frozen.py
  python3 certify_root.py
  python3 spectral_certificate.py --root-center
  python3 certify_root_spectral_floor.py
Root Newton iterations only propose a center. Exact residual, preconditioner,
quadratic Hessian bounds and rational comparisons are the existence proof.
The dyadic spectral center is NOT the exact root; the root box perturbation is
charged explicitly to the all-time error floor. Every physical sector is kept.

OPTIONAL RE-OPTIMIZATION (overwrites search receipt)
  python3 search_manifold.py
Repeat all certificate steps above after any change. Four attempts,600 iterations
each, normalized second-moment equalities and declared norm/deadline cap512.
Numerical feasibility is not exact feasibility. The singular X_z control stops
after one iteration; its moments match but it is not an encoder.

PDF (PyMuPDF and pdflatex)
  python3 build_ieee_note.py
Inspect both current PAGE_*.png files, then:
  python3 prepare_release.py --visual-review-confirmed
Actual IEEEtran journal,A4,10pt,two columns; class license included.

NEXT
Read NEXT_GATE.json: rank-aware retracted endpoint search on the local regular
branch,82 free coordinates plus one phase. Each selected iterate requires a
fresh exact root and full-domain error/deadline/window certificate. Higher
moments are diagnostics, never sufficient substitutes for spectral orientation
and common phase matching. Native admission closes before encoded SWAP routing.
Copied instructions v0.2 contain a parent snapshot; NEXT_GATE is current.
All parent releases remain immutable. SHA256SUMS.txt covers distributed files.
