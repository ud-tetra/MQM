"""Bounded numerical equality-constrained continuation, not an exact endpoint proof."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
import json,time
import numpy as np
from scipy.optimize import minimize
from scipy.linalg import eigh
from complex_objective import Objective
from moment_geometry import B,F,E,W,D,R,labels,MomentConstraint
CAP=512.;LT=1e-8
geo=json.loads((R/'results'/'MOMENT_GEOMETRY.json').read_text())
moment=MomentConstraint(geo['independent_components'])
endpoint=Objective(B,F,E,W)
def objective(x):
    r,j=endpoint.evaluate(x);return float(r@r/2),j.T@r
def budget(x):
    c=B@x[:-1];return 1-float(sum(np.sqrt(c*c+LT*LT)))/CAP
def budget_jac(x):
    c=B@x[:-1];return np.r_[-B.T@(c/np.sqrt(c*c+LT*LT))/CAP,0.]
def freeze(x):
    theta=[Q(float(v)) for v in x[:-1]]
    return {l:str(sum((int(b)*t for b,t in zip(row,theta)),Q(0))) for l,row in zip(labels,B)}
def diagnostics(x):
    r,_=endpoint.evaluate(x);error=r[:256].reshape(64,4)+1j*r[256:].reshape(64,4)
    m,j=moment.evaluate(x);sv=np.linalg.svd(j[:,:97],compute_uv=False)
    H=np.einsum('a,aij->ij',x[:-1],F);lam,V=eigh(H);UE=V@(np.exp(-1j*lam)[:,None]*(V.conj().T@E))
    a=np.diag((V.conj().T@E)@(W.conj().T@V));S=float(sum(abs(a)))
    return {'isometry_operator_residual':float(np.linalg.norm(error,2)),'normalized_moment_max':float(max(abs(m))),'normalized_moment_l2':float(np.linalg.norm(m)),'Jacobian_singular_values_diagnostic':sv.tolist(),'numerical_Jacobian_rank_at_relative_1e_minus_10':int(sum(sv>sv[0]*1e-10)),'sampled_spectral_overlap_sum':S,'minimum_gap_diagnostic':float(min(np.diff(lam))),'Choi_trace_error_diagnostic':float(np.sqrt(max(0,1-abs(np.trace(W.conj().T@UE)/4)**2)))}
def main():
    parent=json.loads((R/'PARENT_JOINT_SEARCH.json').read_text())
    p=parent['best'];x=np.r_[[float(Q(v)) for v in p['kernel_coordinates_exact']],p['phase']]
    p0=parent['runs'][0];x0=np.r_[[float(Q(v)) for v in p0['kernel_coordinates_exact']],p0['phase']]
    rng=np.random.default_rng(2026100604)
    # Validate all nonlinear equality columns, including the zero phase column.
    errors=[]
    for probe in [x,x+.01*rng.normal(size=98)]:
        _,jac=moment.evaluate(probe);h=1e-6
        for k in range(98):
            step=np.zeros(98);step[k]=h
            num=(moment.evaluate(probe+step)[0]-moment.evaluate(probe-step)[0])/(2*h)
            errors.append(float(max(abs(num-jac[:,k]))))
    assert max(errors)<2e-7,max(errors)
    (R/'results'/'MOMENT_GRADIENT_RECEIPT.json').write_text(json.dumps({'columns_checked':196,'max_discrepancy':max(errors),'step':1e-6,'independent_constraints':len(moment.rows),'status':'NUMERICAL gradient validation'},indent=2))
    xz=np.r_[np.array(geo['X_z_kernel_coordinates'],float)*np.pi,0.]
    starts=[(x,'parent_joint_best'),(x0,'parent_endpoint_lineage'),(x+.02*rng.normal(size=98),'parent_joint_perturbed'),(xz,'exact_X_z_second_moment_seed')]
    runs=[]
    for i,(seed,kind) in enumerate(starts):
        start=time.monotonic();fit=minimize(objective,seed,jac=True,method='SLSQP',constraints=[{'type':'eq','fun':lambda z:moment.evaluate(z)[0],'jac':lambda z:moment.evaluate(z)[1]},{'type':'ineq','fun':budget,'jac':budget_jac}],options={'maxiter':600,'ftol':1e-12})
        coeff=freeze(fit.x);L=sum((abs(Q(v)) for v in coeff.values()),Q(0))
        run={'run':i,'seed_type':kind,'success':bool(fit.success),'message':str(fit.message),'iterations':int(fit.nit),'evaluations':int(fit.nfev),'seconds':time.monotonic()-start,**diagnostics(fit.x),'kernel_coordinates_exact':[str(Q(float(v))) for v in fit.x[:-1]],'phase':float(fit.x[-1]),'Pauli_coefficients_exact':coeff,'Pauli_norm_upper_exact':str(L),'strict_deadline_cap_exact':L<=512,'second_moment_exact_zero':'Not inferred from floating solver; exact audit required'}
        runs.append(run)
        eligible=[r for r in runs if r['strict_deadline_cap_exact'] and r['normalized_moment_max']<1e-8]
        best=min(eligible,key=lambda r:r['isometry_operator_residual']) if eligible else min(runs,key=lambda r:r['normalized_moment_max'])
        receipt={'status':'NUMERICAL equality-constrained exploration only; no exact manifold or endpoint certification inferred','seed':2026100604,'starts':4,'iteration_cap':600,'deadline_cap':512,'second_moment_constraints':len(moment.rows),'normalization':'M2/(1+||B theta||_2^2), positive denominator preserves mathematical zero set','numerical_selection_filter':'Exact norm cap and floating normalized moment max<1e-8; not an exact manifold assertion','runs':runs,'best':best}
        (R/'results'/'MANIFOLD_SEARCH.json').write_text(json.dumps(receipt,indent=2))
        print({k:run[k] for k in ['run','iterations','isometry_operator_residual','normalized_moment_max','success','seconds']},flush=True)
if __name__=='__main__':main()
