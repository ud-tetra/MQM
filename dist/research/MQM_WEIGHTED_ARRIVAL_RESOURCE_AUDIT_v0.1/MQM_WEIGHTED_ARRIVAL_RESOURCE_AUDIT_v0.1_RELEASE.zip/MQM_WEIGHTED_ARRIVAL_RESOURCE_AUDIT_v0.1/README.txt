MQM WEIGHTED ARRIVAL RESOURCE AUDIT v0.1
Date 2026-10-05. Conditional development result. Review pending; physical promotion 0.

The previous direct two-local SWAP primitive had exact compilation but no
certified arrival deadline. This release closes arrival conditionally by
engineering the 27 backbone weights and adding six paired-rail detuning
barriers. The barriers act on twelve physical clock pairs and become exactly
six blind-leaf detunings in the computational graph.

KEY RESULTS
- Same 52 clock + 2 data qubits, 204 merged Pauli supports and 102 pairs.
- Same nonplanar graph and degree-18 bottleneck. No new physical support.
- Exact weighted and detuned encoded dynamics with arbitrary spectators.
- T = 56*pi, Delta = 2^20: complete arrival plus coefficient rounding
  error <= 8.817368406643415e-6 < 1/65536.
- Half readout window 1/65536: certified error <= 1.2495827220603037e-5.
- Full spectrum width >= 12*Delta; no energy-origin shift removes this cost.
- With full norm <=1, sufficient scaling is 1/(6*Delta+9), giving
  deadline 56*pi*(6*Delta+9) < 1107297840 normalized time units.
- For the ideal design, any uniform full-norm-one scaling of the declared
  deadline requires T >=336*pi*Delta >1056964608.
- A distinct planar four-active-qubit endpoint comparator is much cheaper,
  but has different intermediate dynamics and does not compile the full word.

The energy width is a required Hamiltonian scale, not a heat/battery law.
Time is in normalized hbar=1 units, not seconds. This branch is not a resource
advantage, physical demonstration, fault-tolerant design, permanent latch or
supervising-clock renewal. A timed readout is still part of the contract.

REPLAY FROM RELEASE ROOT
  OPENBLAS_NUM_THREADS=1 python3 certify_arrival.py
  OPENBLAS_NUM_THREADS=1 python3 build_ieee_paper.py
Expected: 141 new exact checks and 9 new numerical checks; prior baseline is
also replayed (24 exact +16 numerical). Counts are constructor checks, not
independent review. Dependencies are in DEPENDENCIES.json. Network is not needed.
The full 2^54 matrix is not constructed; exact excitation conservation and
intertwining justify the reduced sectors. Every Pauli coefficient is enclosed
with integer square roots and exact fractions before diagnostic float evolution.

ARTIFACTS
  WEIGHTED_PHYSICAL_TERMS.json: physical coefficients and individual roundoff.
  WEIGHTED_COMPUTATIONAL_GRAPH.json: stages, weights, leaves and detuning.
  results/ARRIVAL_RECEIPT.json: exact fractions, counts, norms and window.
  results/ENERGY_LATENCY_FRONTIER.csv: certificate family, not global optimum.
  manuscript/MQM_WEIGHTED_ARRIVAL_IEEE_A4_v0.1.pdf and .tex: IEEE A4 note.
  CLAIM_REGISTER_v0.1.json: exact, derived, numerical, open and scope boundaries.
  COMPARISON_CONTRACT_v0.1.json: endpoint/history/latched-task separation.
  WBS_PROGRESS_v0.1.json: next penalty-free planar/geometry target.

The original short-grid 0.474 value was not an all-time arrival bound. A
late-time q approximately 0.746 sample is included only as a numerical
diagnostic. Clock-only sector dimension is 52; clock plus body is 208.
Invariance does not assert absence of clock-body correlations.

NEXT GATE
Penalty-free geometrically admissible serial-history primitive, explicit
resource ledger, and useful certified arrival window. Only then extend the
thirteen-step episode and integrate irreversible retention/refreshment.

All future paper PDFs: actual IEEEtran formatting, A4, two columns.
PDF metadata/rendering bytes may vary across platforms. Arithmetic checks
and fraction certificates are reproducible; no bitwise PDF-build claim.
