"""Freeze the audited arrival branch and verify its archive hashes."""
from pathlib import Path
import hashlib,json,zipfile,platform
import numpy,scipy,networkx,matplotlib,fitz
R=Path(__file__).resolve().parent
def dump(name,value):(R/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((R/'results/ARRIVAL_RECEIPT.json').read_text())
q=json.loads((R/'results/PDF_FORMAT_RECEIPT.json').read_text())
assert r['status']=='PASS' and q['visual_review']=='PASS'
t=json.loads((R/'TEMPLATE_PROVENANCE.json').read_text())
assert sha(R/'manuscript/IEEEtran.cls')==t['class_sha256']
assert sha(R/'manuscript/LPPL-1.3c.txt')==t['license_sha256']
dump('CLAIM_REGISTER_v0.1.json',{
 'date':'2026-10-05','version':'0.1','independent_review':'pending','physical_promotion':0,
 'claims':[
 {'id':'WA1','status':'EXACT CONSTRUCTOR REPLAY','claim':'All 27 independent weighted stage operators preserve the computational isometry, with the tied leaf edges included.','scope':'Physical one-excitation clock-body sector and admitted computational subspace; arbitrary spectators by tensor identity.'},
 {'id':'WA2','status':'EXACT CONSTRUCTION','claim':'Twelve wrong-rail pair penalties, grouped into six barriers, are two-local and become exactly six leaf detunings on the computational graph.','scope':'No added qubits, Pauli supports or interaction pairs; 48 coefficients changed.'},
 {'id':'WA3','status':'DERIVED FINITE CERTIFICATE','claim':'Residual embedding gives complete-domain isometry error <= (2 beta + |t| beta sqrt(beta^2+a^2))/Delta.','scope':'No asymptotic elimination or adiabatic assumption; backbone is not itself invariant.'},
 {'id':'WA4','status':'EXACT RATIONAL ADMISSION','claim':'At Delta=2^20 and T=56*pi, rounding-inclusive complete-domain distance is <1/65536.','bound':r['complete_arrival_plus_rounding_error_upper'],'scope':'Ideal static proposal with only stored coefficient representation error; not hardware noise.'},
 {'id':'WA5','status':'EXACT RATIONAL WINDOW ADMISSION','claim':'The same tolerance is certified on T +/- 1/65536.','bound':r['window_complete_error_upper'],'scope':'Timed readout still supplied; no permanent capture/latch.'},
 {'id':'WA6','status':'EXACT FAMILY RESOURCE LOWER BOUND','claim':'Vacuum and filled-clock states certify full spectral diameter >=12 Delta, and norm >=6 Delta under every scalar energy shift.','scope':'This specific physical detuned family; outside-sector states are deliberately included because the chosen budget is the full operator norm.'},
 {'id':'WA7','status':'DERIVED SCALING OBSTRUCTION','claim':'Any full-norm-C uniform rescaling has declared transfer deadline >=336*pi*Delta/C.','scope':'Not a universal clock speed limit, not a no-go for other times or encodings; robust rounded norm lower bound 6 Delta - d.'},
 {'id':'WA8','status':'EXACT GRAPH AUDIT','claim':'Physical graph remains nonplanar with 54 qubits, 204 supports, 102 pairs and degree 18.','scope':'Weights and penalties do not planarize this graph; no assertion that every 2D chip requires ancillas.'},
 {'id':'WA9','status':'DERIVED ENDPOINT BENCHMARK','claim':'A planar two-port clock plus ordinary SWAP uses four active physical qubits and has norm-one endpoint deadline pi.','scope':'Different intermediate semantics; not a serial history compiler or complete execute-capture-renew episode.'},
 {'id':'WA10','status':'NUMERICAL DIAGNOSTIC','claim':'Uniform baseline late-time sample gives q approximately 0.746169, exceeding its earlier short-grid maximum.','scope':'Not a certified interval, global optimum, or all-time theorem.'},
 {'id':'WA11','status':'OPEN','claim':'Penalty-free planar history encoding, useful matched resource advantage, complete thirteen-step compilation and closed-loop refreshment.'}
 ],
 'replay_counts':{'new_exact':r['new_exact_check_count'],'new_numerical':r['new_numerical_check_count'],'prior_exact':24,'prior_numerical':16,'interpretation':'Constructor replay; counts are not independent experimental evidence or separate novelty claims.'}})
dump('COMPARISON_CONTRACT_v0.1.json',{
 'task_layers':{
  'endpoint':'Arbitrary-input body SWAP plus clock transfer to a declared final port, retaining spectators.',
  'serial_history':'Specified ordered CNOT/capture/renew word encoded in clock transitions; stronger than endpoint agreement.',
  'latched_episode':'Permanent output hold with an explicit open-system reservoir or another proven retention mechanism; not supplied here.'},
 'common_budget':'Full physical operator norm <=1, after optimizing/declaring scalar energy origin. Time uses hbar=1 and normalized units, not seconds.',
 'weighted_candidate':{'qubits':54,'planar':False,'deadline':r['normalized_deadline'],'error':r['complete_arrival_plus_rounding_error_upper'],'window_error':r['window_complete_error_upper'],'normalization':r['norm_normalization'],'latency_lower_ideal':r['any_full_norm_one_scaling_deadline_lower'],'latency_upper':r['normalized_deadline_upper']},
 'endpoint_comparator':r['endpoint_only_benchmark'],
 'comparability_warning':'Endpoint comparison is meaningful only for the endpoint task. It does not establish an advantage or lower bound across equivalent complete thirteen-step histories.',
 'other_budgets':{'per_Pauli_term_baseline_ceiling':'1/16','candidate_sufficient_scaling':r['Pauli_ceiling_scaling'],'candidate_deadline_upper':r['Pauli_ceiling_deadline_upper'],'boundary':'A term ceiling, incident-strength ceiling, full norm, and sector norm are different constraints.'},
 'pending':['Planar direct compiler under the serial-history task','Perturbative lattice compiler with penalties and dynamical error charged','Launch/readout and exported-correlation resource ledger for full episode']})
dump('WBS_PROGRESS_v0.1.json',{
 'completed':['Review claim corrections','Edgewise exact weighted intertwining','Two-local leaf detuning construction','Finite nonasymptotic residual-isometry certificate','Rounding-inclusive deadline and window admission','Energy-origin-independent full-spectrum lower bound','Matched full-norm normalization','Unchanged graph nonplanarity audit','Typed four-active-qubit endpoint benchmark','IEEEtran A4 paper and replay release'],
 'gates':{'single_primitive_compilation':'PASSED in baseline','conditional_arrival':'PASSED in this detuned proposal','planar_geometry':'OPEN','resource_advantage':'OPEN; large-gap shortcut rejected under full-norm budget','physical_validation':'0','thirteen_step_extension':'GATED'},
 'next_target':'Penalty-free geometrically constrained direct SWAP/history routing with certified arrival and explicit operational benefit beyond the endpoint benchmark.',
 'next_steps':[
 {'priority':1,'action':'Test direct exchange/SWAP routing instead of three generic CNOT routes.','deliverable':'Explicit finite physical graph, launch state, two-body terms and admitted sector; label as candidate until algebra passes.'},
 {'priority':2,'action':'Enforce planar or explicitly costed connectivity and reduced data degree from the outset.','deliverable':'Planarity/embedding receipt, total physical inventory and a bounded coupling ledger.'},
 {'priority':3,'action':'Certify a useful arrival window without a large gap.','deliverable':'Complete-domain isometry/channel certificate with spectators, clock leakage and coefficient intervals.'},
 {'priority':4,'action':'Compare direct and perturbative constructions under the same serial-history task.','deliverable':'Common norm/deadline/error contract; charge every penalty, routing element and ancilla.'},
 {'priority':5,'action':'Extend to thirteen steps and then integrate a latch only after geometry/resource gates pass.','deliverable':'Whole-bank episode and reservoir/refresh ledger; no independent-reset shortcut.'}],
 'format_policy':'Future paper PDFs remain IEEEtran A4 two columns, with target-venue requirements to be checked at submission.'})
dump('SOURCE_PROVENANCE.json',{
 'prior_method':[{'author':'Daniel Nagaj','title':'Universal 2-local Hamiltonian quantum computing','doi':'10.1103/PhysRevA.85.032330','url':'https://arxiv.org/abs/1002.0420v2','role':'Prior-art direct encoding underlying the immutable baseline.'},
 {'authors':'M. Christandl, N. Datta, A. Ekert, A. J. Landahl','title':'Perfect state transfer in quantum spin networks','doi':'10.1103/PhysRevLett.92.187902','url':'https://arxiv.org/abs/quant-ph/0309131v2','role':'Prior-art engineered transfer profile; new finite leaf and resource audit is separately derived.'}],
 'current_derivation':'Physical leaf penalties, coefficientwise intertwining, residual-isometry bound, exact rounding/window admission, spectrum-width obstruction and typed comparator.',
 'review_source':'User-pasted control/lifecycle review. Its citation numbering had no supplied bibliography and is not treated as verified attribution.',
 'verification_date':'2026-10-05'})
prior=R.parent/'MQM_TWO_LOCAL_SWAP_BASELINE_v0.1_RELEASE.zip'
dump('INPUT_ANCHORS.json',{'immutable_prior_release':{'file':prior.name,'sha256':sha(prior)},'copied_baseline_code_sha256':sha(R/'prior_baseline/replay_swap.py'),'prior_release_policy':'Source release remains unchanged; this is a separate development branch.'})
dump('DEPENDENCIES.json',{'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'networkx':networkx.__version__,'matplotlib':matplotlib.__version__,'pymupdf':fitz.VersionBind,'latex':'pdfLaTeX with supplied IEEEtran.cls; amsmath, amssymb, amsthm, graphicx, url, hyperref','network_needed_for_replay':False})
(R/'README.txt').write_text('''MQM WEIGHTED ARRIVAL RESOURCE AUDIT v0.1
Date 2026-10-05. Conditional development result. Review pending; physical promotion 0.

The previous direct two-local SWAP primitive had exact compilation but no
certified arrival deadline. This release closes arrival conditionally by
engineering the 27 backbone weights and adding six paired-rail detuning
barriers. The barriers act on twelve physical clock pairs and become exactly
six blind-leaf detunings in the computational graph.

KEY RESULTS
- Same 52 clock + 2 data qubits, 204 merged Pauli supports and 102 pairs.
- Same nonplanar graph and degree-18 bottleneck. No new physical support.
- Exact weighted and detuned encoded dynamics with arbitrary spectators.
- T = 56*pi, Delta = 2^20: complete arrival plus coefficient rounding
  error <= 8.817368406643415e-6 < 1/65536.
- Half readout window 1/65536: certified error <= 1.2495827220603037e-5.
- Full spectrum width >= 12*Delta; no energy-origin shift removes this cost.
- With full norm <=1, sufficient scaling is 1/(6*Delta+9), giving
  deadline 56*pi*(6*Delta+9) < 1107297840 normalized time units.
- For the ideal design, any uniform full-norm-one scaling of the declared
  deadline requires T >=336*pi*Delta >1056964608.
- A distinct planar four-active-qubit endpoint comparator is much cheaper,
  but has different intermediate dynamics and does not compile the full word.

The energy width is a required Hamiltonian scale, not a heat/battery law.
Time is in normalized hbar=1 units, not seconds. This branch is not a resource
advantage, physical demonstration, fault-tolerant design, permanent latch or
supervising-clock renewal. A timed readout is still part of the contract.

REPLAY FROM RELEASE ROOT
  OPENBLAS_NUM_THREADS=1 python3 certify_arrival.py
  OPENBLAS_NUM_THREADS=1 python3 build_ieee_paper.py
Expected: 141 new exact checks and 9 new numerical checks; prior baseline is
also replayed (24 exact +16 numerical). Counts are constructor checks, not
independent review. Dependencies are in DEPENDENCIES.json. Network is not needed.
The full 2^54 matrix is not constructed; exact excitation conservation and
intertwining justify the reduced sectors. Every Pauli coefficient is enclosed
with integer square roots and exact fractions before diagnostic float evolution.

ARTIFACTS
  WEIGHTED_PHYSICAL_TERMS.json: physical coefficients and individual roundoff.
  WEIGHTED_COMPUTATIONAL_GRAPH.json: stages, weights, leaves and detuning.
  results/ARRIVAL_RECEIPT.json: exact fractions, counts, norms and window.
  results/ENERGY_LATENCY_FRONTIER.csv: certificate family, not global optimum.
  manuscript/MQM_WEIGHTED_ARRIVAL_IEEE_A4_v0.1.pdf and .tex: IEEE A4 note.
  CLAIM_REGISTER_v0.1.json: exact, derived, numerical, open and scope boundaries.
  COMPARISON_CONTRACT_v0.1.json: endpoint/history/latched-task separation.
  WBS_PROGRESS_v0.1.json: next penalty-free planar/geometry target.

The original short-grid 0.474 value was not an all-time arrival bound. A
late-time q approximately 0.746 sample is included only as a numerical
diagnostic. Clock-only sector dimension is 52; clock plus body is 208.
Invariance does not assert absence of clock-body correlations.

NEXT GATE
Penalty-free geometrically admissible serial-history primitive, explicit
resource ledger, and useful certified arrival window. Only then extend the
thirteen-step episode and integrate irreversible retention/refreshment.

All future paper PDFs: actual IEEEtran formatting, A4, two columns.
PDF metadata/rendering bytes may vary across platforms. Arithmetic checks
and fraction certificates are reproducible; no bitwise PDF-build claim.
''')
(R/'REVIEW_CORRECTIONS.txt').write_text('''Review correction ledger
1. q <=0.474 and delta_task >=0.725 were not established for all times.
   The source supplied a finite-grid maximum only. Preserve that scope.
2. The 52-dimensional clock sector becomes 208-dimensional with the body.
   Exact sector invariance preserves correlated dynamics; it does not factor
   the state into independent clock and computational data.
3. Zero compiler leakage into an expanded-graph reference is different from
   complete task error to a fixed final-port target.
4. Nonplanarity prohibits a strictly planar interaction embedding of this
   graph. It does not uniquely require routing ancillas on every 2D device.
5. Weight-three terms obstruct exact unencoded three-qubit generator equality.
   They do not uniquely prove the necessity of clock dilation; the endpoint
   benchmark demonstrates another task semantics with two-local terms.
6. The rounding certificate is not a physical noise/calibration certificate.
7. Large-gap arrival is now certified, including a window, but its matched
   full-spectrum energy/time cost is explicit and prohibitive in this branch.
8. Reweighting and these penalties leave the same K3,3 witness and degree 18.
9. Full norm, sector norm, Pauli coefficient and incident coupling budgets
   are distinct. Comparison must state which is being constrained.
10. IEEE A4 formatting is retained; independent review and physical validation
    remain pending. No generic autonomous-computation novelty claim is made.
''')
files=sorted(p for p in R.rglob('*') if p.is_file() and p.suffix not in {'.aux','.log','.out'} and p.name!='SHA256_MANIFEST.json' and '__pycache__' not in p.parts)
manifest={str(p.relative_to(R)):sha(p) for p in files};dump('SHA256_MANIFEST.json',manifest)
zpath=R.parent/(R.name+'_RELEASE.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[R/'SHA256_MANIFEST.json']:z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for p,h in manifest.items():assert hashlib.sha256(z.read(R.name+'/'+p)).hexdigest()==h
print(json.dumps({'status':'PASS','file_count':len(files)+1,'zip':str(zpath),'bytes':zpath.stat().st_size,'sha256':sha(zpath)},indent=2))
