"""Finite two-local detuned-arrival certificate and resource obstruction.
All claimed enclosures and intertwining checks use integer/rational arithmetic.
Floating evolution and late-time sampling are explicitly diagnostic.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt,sqrt,pi
import contextlib,io,json,runpy,csv
import numpy as np
import networkx as nx
from scipy.linalg import eigh,expm
R=Path(__file__).resolve().parent;O=R/'results';O.mkdir(exist_ok=True)
with contextlib.redirect_stdout(io.StringIO()):b=runpy.run_path(str(R/'prior_baseline/replay_swap.py'))
exact=[];nums=[]
def ck(name,condition):
 if not condition:raise AssertionError(name)
 exact.append(name)
def nm(name,residual,tolerance):
 residual=float(residual)
 if not np.isfinite(residual) or residual>tolerance:raise AssertionError((name,residual,tolerance))
 nums.append({'name':name,'residual':residual,'tolerance':tolerance})
I=b['I'];D=b['D'];ei=b['ei'];pii=b['pi'];phys=b['phys'];pairs=b['pairs']
Ta=b['Taa'];Tb=b['Tbb'];W=b['W'];proj=b['proj'];bodyX=b['bodyX']
paths=b['paths'];ports=b['ports'];leaves=b['leaves'];terms=b['terms']
Qi=[np.zeros((208,208),dtype=np.int64) for i in range(27)]
Ka=[np.zeros((34,34),dtype=np.int64) for i in range(27)]
Aa=[np.zeros((208,208),dtype=np.int64) for i in range(27)]
Ab=[np.zeros((208,208),dtype=np.int64) for i in range(27)]
def block(M,j,k,U):M[4*j:4*j+4,4*k:4*k+4]+=U
def link(M,j,k,U):block(M,ei[j],ei[k],U);block(M,ei[k],ei[j],U.T)
for s,(ctrl,targ) in enumerate([(0,1),(1,0),(0,1)]):
 for rail,z in [('u',1),('l',0)]:
  l=lambda j:f's{s}_{rail}{j}'
  links=[(l(1)+'A',f'c{s}',I),(l(1)+'A',l(1)+'B',proj(ctrl,z)),
   (l(1)+'B',l(2),I),(l(3)+'A',l(2),I),
   (l(3)+'A',l(3)+'B',bodyX[targ] if rail=='u' else I),
   (l(3)+'B',l(4),I),(l(5)+'A',l(4),I),
   (l(5)+'A',l(5)+'B',proj(ctrl,z)),(l(5)+'B',f'c{s+1}',I)]
  for j,(a,c,U) in enumerate(links):link(Qi[9*s+j],a,c,U)
 for j,(a,c) in enumerate(zip(paths[s][:-1],paths[s][1:])):Ka[9*s+j][a,c]=Ka[9*s+j][c,a]=1
 for side,j in [('entry',0),('exit',8)]:
  port=ports[s] if side=='entry' else ports[s+1]
  leaf=b['vertices'].index(f's{s}_wrong_{side}')
  Ka[9*s+j][port,leaf]=Ka[9*s+j][leaf,port]=1
def stage(t):
 clock=[x for x in t['support'] if x in pii]
 pair=next(x for x in clock if x.endswith('_p') or x.endswith('_q'))
 st=int(pair[1]);station=int(pair.split('_')[1][1]);base=9*st
 if t['pauli'] not in ['XX','YY']:return base+{1:1,3:4,5:7}[station]
 other=next(x for x in clock if x!=pair)
 if other.startswith('c'):return base+(0 if station==1 else 8)
 otherstation=int(other.split('_')[1][1])
 return base+{(1,2):2,(3,2):3,(3,4):5,(5,4):6}[(station,otherstation)]
def restrict(t):
 M=np.zeros((208,208),dtype=np.int64);supp=t['support'];p=t['pauli']
 if p in ['XX','YY']:
  j,k=[pii[x] for x in supp];block(M,j,k,I);block(M,k,j,I)
 else:
  site=pii[supp[0]]
  B=I if len(supp)==1 else (bodyX[['A','O1'].index(supp[1])] if p=='ZX' else 2*proj(['A','O1'].index(supp[1]),0)-I)
  for j in range(D):block(M,j,j,(-1 if j==site else 1)*B)
 return M
for term in terms:
 j=stage(term);Q=restrict(term)
 for M,key in [(Aa[j],'a'),(Ab[j],'b')]:
  c=4*F(term['coefficient_over_g'][key]);assert c.denominator==1;M+=c.numerator*Q
for j in range(27):
 ck(f'stage {j} physical intertwining rational',np.array_equal(Aa[j]@Ta+2*Ab[j]@Tb,4*Ta@Qi[j]))
 ck(f'stage {j} physical intertwining radical',np.array_equal(Aa[j]@Tb+Ab[j]@Ta,4*Tb@Qi[j]))
 ck(f'stage {j} computational intertwining',np.array_equal(Qi[j]@W,W@np.kron(Ka[j],I)))
ck('stage sum reproduces original generator',np.array_equal(sum(Qi),b['Hq']))
# Positive detuning: sum N_pair P_wrong on twelve entry/exit rail pairs.
Rp=np.zeros((208,208),dtype=np.int64);Rq=np.zeros_like(Rp)
offsets={};nbarriers=0
for s,ctrl in enumerate([0,1,0]):
 for station in [1,5]:
  nbarriers+=1
  for rail,wrong in [('u',0),('l',1)]:
   pair=f's{s}_{rail}{station}';B=proj(ctrl,wrong);sigma=1 if wrong==0 else -1
   for site in pairs[pair]:block(Rp,pii[site],pii[site],B)
   for state in ['A','B']:block(Rq,ei[pair+state],ei[pair+state],B)
   for site in pairs[pair]:
    offsets[((site,), 'Z')]=F(-1,4)
    offsets[((site,['A','O1'][ctrl]),'ZZ')]=F(-sigma,4)
leafdiag=np.zeros((34,34),dtype=np.int64)
for p,j in leaves:leafdiag[j,j]=1
ck('six paired-rail barriers',nbarriers==6)
ck('physical detuning rational intertwining',np.array_equal(Rp@Ta,Ta@Rq))
ck('physical detuning radical intertwining',np.array_equal(Rp@Tb,Tb@Rq))
ck('detuning is exactly leaf population in computational graph',np.array_equal(Rq@W,W@np.kron(leafdiag,I)))
Moff=np.zeros_like(Rp)
for (support,pauli0),c in offsets.items():Moff+=int(4*c)*restrict({'support':list(support),'pauli':pauli0})
ck('detuning Pauli expansion with global scalar removed',np.array_equal(Moff,4*Rp-24*np.eye(208,dtype=int)))
ck('detuning adds no new Pauli supports',set(offsets).issubset({(tuple(t['support']),t['pauli']) for t in terms}))
for j in range(27):
 body=np.zeros((4,4),dtype=np.int64)
 for t in terms:
  if stage(t)!=j or t['pauli'] in ['XX','YY']:continue
  B=I if len(t['support'])==1 else (bodyX[['A','O1'].index(t['support'][1])] if t['pauli']=='ZX' else 2*proj(['A','O1'].index(t['support'][1]),0)-I)
  body+=int(4*F(t['coefficient_over_g']['a']))*B
 ck(f'stage {j} annihilates vacuum and filled clock',not np.any(body))
for z,label in [(1,'vacuum'),(-1,'filled')]:
 body=np.zeros((4,4),dtype=np.int64)
 for (support,p),c in offsets.items():
  B=I if len(support)==1 else 2*proj(['A','O1'].index(support[1]),0)-I
  body+=int(4*c)*z*B
 ck(f'centered detuning energy {label}',np.array_equal(body,(-24 if z==1 else 24)*I))
ck('each paired-rail positive barrier bounded by two',all(0<= (u if z==0 else l)<=2 for u in range(3) for l in range(3) for z in [0,1]))
# Krawtchouk/spin rotation: 27 backbone edges, maximum sqrt(14*14)/112 = 1/8.
nu=F(1,112);rad=[(j+1)*(27-j) for j in range(27)];Delta=F(2**20)
ck('backbone maximum link coefficient 1/8',max(rad)==196 and 14*nu==F(1,8))
ck('backbone reflection symmetry',rad==rad[::-1])
chain=[paths[0][0]]+[v for path in paths for v in path[1:]]
ck('backbone contains 28 distinct vertices',len(chain)==len(set(chain))==28)
leafvertices=[j for p,j in leaves]
leafsq=[sum(rad[j] for j in range(27) if any(Ka[j][p,k] for k in leafvertices)) for p in ports]
ck('port-to-leaf squared norm numerator',leafsq==[27,351,351,27])
ck('beta radical upper',351<19**2)
ck('residual radical upper',351+27**2<33**2)
beta_hi=F(19,112);res_hi=F(19*33,112**2)
T_hi=F(176);C=2*beta_hi+T_hi*res_hi
ideal_error=C/Delta
ck('arrival error below 2^-16',ideal_error<F(1,2**16))
ck('arrival coefficient is exact 7163/784',C==F(7163,784))
def enclose_sqrt(n,bits=90):
 a=isqrt(n*2**(2*bits));lo=F(a,2**bits);hi=F(a+1,2**bits)
 assert lo*lo<=n<hi*hi
 return lo,hi
def encl_coeff(offset,mul,n):
 l,u=enclose_sqrt(n)
 x,y=offset+mul*l,offset+mul*u
 return min(x,y),max(x,y)
weighted=[];debit=F(0);fulltriangle=F(0);basetriangle=F(0);maxcoeff=F(0)
for t in terms:
 j=stage(t);a=F(t['coefficient_over_g']['a']);bb=F(t['coefficient_over_g']['b'])
 assert not (a and bb)
 mult=nu*(a or bb);n=rad[j] if a else 2*rad[j]
 off=Delta*offsets.get((tuple(t['support']),t['pauli']),F(0))
 lo,hi=encl_coeff(off,mult,n)
 blo,bhi=encl_coeff(F(0),mult,n);basetriangle+=max(abs(blo),abs(bhi))
 value=float(off)+float(mult)*sqrt(n)
 rounded=F.from_float(value);error=max(abs(rounded-lo),abs(rounded-hi));debit+=error
 fulltriangle+=max(abs(lo),abs(hi));maxcoeff=max(maxcoeff,max(abs(lo),abs(hi)))
 weighted.append({'support':t['support'],'pauli':t['pauli'],'stage':j,'coefficient':{'offset':str(off),'multiplier':str(mult),'radicand':n},'binary64':value,'absolute_rounding_error_upper':str(error)})
round_error=T_hi*debit;total_error=ideal_error+round_error
window=F(1,65536)
window_error=(2*beta_hi+(T_hi+window)*res_hi)/Delta+(T_hi+window)*debit+F(27,112)*window
ck('weighted coefficients remain two-local',all(len(t['support'])<=2 for t in weighted))
ck('204 merged physical Pauli terms',len(weighted)==204)
ck('48 detuning-modified terms',len(offsets)==48)
ck('complete rounding-plus-arrival error below 2^-16',total_error<F(1,2**16))
ck('certified readout window below 2^-16',window_error<F(1,2**16))
ck('rounded weighted base norm reserve below nine',basetriangle+debit<9)
ck('full Pauli triangle upper fits 12 Delta + 9',fulltriangle<12*Delta+9)
eta=1/(6*Delta+9);eta_term=1/(4*Delta+F(1,2))
ck('normalized full norm certificate via positive barrier bound',eta*(6*Delta+9)==1)
ck('matched baseline Pauli ceiling certificate',eta_term*maxcoeff<F(1,16))
Gp=nx.Graph();Gp.add_nodes_from(phys+['A','O1'])
for t in weighted:
 if len(t['support'])==2:Gp.add_edge(*t['support'])
old=nx.Graph();old.add_nodes_from(b['Gphys'].nodes);old.add_edges_from(b['Gphys'].edges)
ck('physical interaction graph unchanged',set(map(frozenset,Gp.edges))==set(map(frozenset,old.edges)))
ck('nonplanarity persists',not nx.check_planarity(Gp)[0])
intervals=[encl_coeff(F(t['coefficient']['offset']),F(t['coefficient']['multiplier']),t['coefficient']['radicand']) for t in weighted]
ck('no physical support vanishes under this detuning',all(lo>0 or hi<0 for lo,hi in intervals))
# Diagnostic numerical evolutions. Proofs above supply the unconditional certificate.
w=np.sqrt(rad)*float(nu);H=sum(w[j]*Ka[j] for j in range(27))+float(Delta)*leafdiag
A=H[np.ix_(chain,chain)];B=H[np.ix_(chain,leafvertices)]
T=pi/(2*float(nu));endpoint=expm(-1j*T*A)[:,0]
phase=(-1j)**27
target=np.zeros(28,complex);target[-1]=phase
nm('ideal backbone transfer diagnostic',np.linalg.norm(endpoint-target),1e-12)
nm('ideal backbone spectrum diagnostic',np.max(abs(np.linalg.eigvalsh(A)-np.arange(-27,28,2)*float(nu))),1e-12)
nm('leaf-coupling norm diagnostic',abs(np.linalg.norm(B,2)-sqrt(351)/112),1e-12)
evals,V=eigh(H);state=V@(np.exp(-1j*T*evals)*V[ports[0]])
q=float(abs(state[ports[-1]])**2)
# Stable vector distance after optimal global phase avoids 1-q cancellation.
delta_diag=float(np.sqrt(np.sum(abs(np.delete(state,ports[-1]))**2)))
nm('detuned diagnostic distance respects analytic ideal enclosure',max(0,delta_diag-float(ideal_error)),2e-7)
nm('detuned eigensystem residual',np.linalg.norm(H@V-V*evals),2e-8)
Tf=(b['Ta']+sqrt(2)*b['Tb'])/2;Omega=np.kron(Tf,I)@W
Hphys=sum(w[j]*(Aa[j]+sqrt(2)*Ab[j])/4 for j in range(27))+float(Delta)*Rp
nm('weighted full-input intertwining diagnostic',np.linalg.norm(Hphys@Omega-Omega@np.kron(H,I)),1e-8)
# Uniform baseline late-time counterexample to the review's unqualified 0.474 bound.
tv=F.from_float(2837365.112421669)
e,U=eigh(b['Kf']);alpha=np.sum(U[ports[0]]*U[ports[-1]]*np.exp(-1j*float(tv)*e))
q_late=float(abs(alpha)**2)
nm('late-time diagnostic exceeds earlier sampled maximum',max(0,.70-q_late),1e-12)
nm('uniform eigensystem residual',np.linalg.norm(b['Kf']@U-U*e),1e-12)
# A different, endpoint-only operational benchmark: two clock qubits and two data.
Cclock=np.zeros((4,4),dtype=np.int64);Cclock[1,2]=Cclock[2,1]=1
ck('two-port clock generator has eigenvalues within minus/plus one',np.array_equal(Cclock@Cclock@Cclock,Cclock))
ck('endpoint clock/data terms commute',np.array_equal(np.kron(Cclock,I)@np.kron(I,b['SW']),np.kron(I,b['SW'])@np.kron(Cclock,I)))
ck('SWAP involution exact',np.array_equal(b['SW']@b['SW'],I))
Hendpoint=(np.kron(Cclock,I)+np.kron(I,b['SW']))/8
Eclock=np.zeros((16,4));Eclock[8:12]=I
Bclock=np.zeros((16,4));Bclock[4:8]=-b['SW']
nm('four-active-qubit full-input endpoint benchmark',np.linalg.norm(expm(-1j*4*pi*Hendpoint)@Eclock-Bclock),1e-12)
def frac(x):return {'fraction':str(x),'numerator':str(x.numerator),'denominator':str(x.denominator),'decimal':float(x)}
receipt={
 'status':'PASS','version':'0.1','date':'2026-10-05','physical_promotion':0,'independent_review':'pending',
 'new_exact_check_count':len(exact),'new_numerical_check_count':len(nums),'prior_exact_checks':len(b['exact']),'prior_numerical_checks':len(b['nums']),
 'clock_qubits':52,'data_qubits':2,'total_qubits':54,'Pauli_terms':204,'modified_by_detuning':48,'two_body_pairs':Gp.number_of_edges(),'max_degree':max(dict(Gp.degree()).values()),'planar':False,
 'nu':str(nu),'Delta':str(Delta),'ideal_deadline':'56*pi','deadline_upper':str(T_hi),
 'arrival_ideal_error_upper':frac(ideal_error),'coefficient_generator_rounding_upper':frac(debit),'rounding_channel_error_upper':frac(round_error),'complete_arrival_plus_rounding_error_upper':frac(total_error),'target_tolerance':'1/65536',
 'readout_half_window':str(window),'window_complete_error_upper':frac(window_error),'normalized_readout_half_window':str(window/eta),
 'exact_q_lower':frac(1-total_error**2),'norm_normalization':str(eta),'normalized_deadline':'56*pi*(6*Delta+9)',
 'normalized_deadline_upper':str(T_hi/eta),'normalized_deadline_lower_using_pi_gt_3':str(F(168)/eta),
 'full_spectral_diameter_lower':'12*Delta','optimal_scalar_centered_full_norm_lower':'6*Delta',
 'any_full_norm_one_scaling_deadline_lower':'336*pi*Delta','any_full_norm_one_scaling_deadline_lower_pi_gt_3':str(1008*Delta),
 'baseline_Pauli_ceiling':'1/16','Pauli_ceiling_scaling':str(eta_term),'Pauli_ceiling_deadline_upper':str(T_hi/eta_term),
 'detuned_probability_diagnostic':q,'detuned_complete_distance_diagnostic':delta_diag,
 'uniform_late_time_diagnostic':{'time':str(tv),'decimal_time':float(tv),'probability':q_late,'certified_interval':False},
 'endpoint_only_benchmark':{'active_physical_qubits':4,'clock_qubits':2,'data_qubits':2,'pairs':2,'planar':True,'full_norm_at_nominal_g':'1/4','nominal_deadline':'4*pi','full_norm_one_deadline':'pi','task_boundary':'Same arbitrary-input endpoint transfer in a two-port clock encoding, but different intermediate dynamics; not a serial history compiler or complete thirteen-step episode.'},
 'exact_checks':exact,'numerical_checks':nums,
 'claims_boundary':['All error bounds refer to the same complete clock-body-spectator task.','The clock readout deadline is supplied; no permanent latch or repeated autonomous renewal is claimed.','Detuning trades raw arrival accuracy for a large physical energy/latency cost.','Nonplanarity and 54-qubit footprint persist.','No resource advantage, minimality, or hardware feasibility is established.','Numerical late-time sampling is diagnostic, not an all-time theorem.']}
(O/'ARRIVAL_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
(R/'WEIGHTED_PHYSICAL_TERMS.json').write_text(json.dumps({'dropped_global_scalar':'6*Delta','Delta':str(Delta),'nu':str(nu),'clock_and_data_qubits':phys+['A','O1'],'terms':weighted},indent=2)+'\n')
(R/'WEIGHTED_COMPUTATIONAL_GRAPH.json').write_text(json.dumps({'backbone_vertices':chain,'leaf_vertices':leafvertices,'stage_adjacency_matrices':[k.tolist() for k in Ka],'weight_radicands':rad,'nu':str(nu),'leaf_detuning':str(Delta)},indent=2)+'\n')
rows=[]
for exponent in range(8,25):
 dd=F(2**exponent);err=C/dd;normscale=6*dd+9
 rows.append({'Delta':str(dd),'ideal_error_upper_fraction':str(err),'ideal_error_upper_decimal':float(err),'full_norm_one_deadline_upper_fraction':str(T_hi*normscale),'full_norm_one_deadline_lower_pi_gt_3':str(F(168)*normscale),'passes_2^-16_ideal_bound':err<F(1,65536)})
with (O/'ENERGY_LATENCY_FRONTIER.csv').open('w',newline='') as f:
 out=csv.DictWriter(f,fieldnames=list(rows[0]));out.writeheader();out.writerows(rows)
print(json.dumps({k:receipt[k] for k in ['status','new_exact_check_count','new_numerical_check_count','Delta','arrival_ideal_error_upper','rounding_channel_error_upper','complete_arrival_plus_rounding_error_upper','normalized_deadline_upper','detuned_probability_diagnostic','detuned_complete_distance_diagnostic','uniform_late_time_diagnostic']},indent=2))
