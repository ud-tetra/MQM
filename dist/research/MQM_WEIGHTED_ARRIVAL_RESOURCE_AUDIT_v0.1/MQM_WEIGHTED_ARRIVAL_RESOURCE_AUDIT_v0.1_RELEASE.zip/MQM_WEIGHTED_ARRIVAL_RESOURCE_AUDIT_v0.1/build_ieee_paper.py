"""Render the IEEEtran A4 development paper from the checked arrival receipt."""
from pathlib import Path
import json,subprocess
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fitz
R=Path(__file__).resolve().parent;M=R/'manuscript';F=R/'figures'
r=json.loads((R/'results/ARRIVAL_RECEIPT.json').read_text())
plt.rcParams.update({'font.size':8,'axes.labelsize':8,'font.family':'DejaVu Sans'})
dd=2.**np.arange(8,25);error=(7163/784)/dd;deadline=176*(6*dd+9)
fig,axs=plt.subplots(2,1,figsize=(3.45,2.85),sharex=True,layout='constrained')
axs[0].loglog(dd,error,'o-',lw=1,markersize=3,color='#174f80')
axs[0].axhline(2**-16,color='#ac432c',ls='--',lw=.8)
axs[0].set_ylabel('Error upper bound');axs[0].text(1.2e3,2**-16*1.3,r'$2^{-16}$ target',color='#ac432c',fontsize=7)
axs[1].loglog(dd,deadline,'o-',lw=1,markersize=3,color='#174f80')
axs[1].set(xlabel=r'Blind-leaf detuning $\Delta$',ylabel='Deadline upper bound')
for ax in axs:ax.grid(alpha=.2,which='both');ax.axvline(2**20,color='#69757d',lw=.7,ls=':')
fig.savefig(F/'ENERGY_LATENCY.pdf');fig.savefig(F/'ENERGY_LATENCY.png',dpi=200);plt.close(fig)
tex=r'''\documentclass[journal,a4paper,10pt]{IEEEtran}
\usepackage{amsmath,amssymb,amsthm,graphicx,url}
\usepackage[hidelinks]{hyperref}
\newtheorem{theorem}{Theorem}
\newtheorem{proposition}{Proposition}
\newcommand{\ket}[1]{|#1\rangle}
\newcommand{\bra}[1]{\langle#1|}
\newcommand{\SW}{\operatorname{SWAP}}
\begin{document}
\title{Certified Arrival and Energy Costs in a\\Two-Local Quantum History Clock}
\author{Benjamin Walker Mayes\thanks{Development note v0.1, October 5, 2026. ORCID: 0009-0002-5813-0724. Independent review pending. Physical evidence promotion: 0.}}
\maketitle
\begin{abstract}
We extend an exact two-local SWAP compilation by certifying a finite arrival deadline on its full clock--body domain. Engineered weights on a 27-edge backbone give a perfect-transfer reference, while twelve physical wrong-rail occupancy penalties detune six reachable blind leaves. These penalties remain two-local and add no interaction pairs or clock qubits. An explicit intertwining identity preserves the encoded computational sector for every edge weight. A residual-isometry argument proves a finite, nonasymptotic error bound of $7163/(784\Delta)$ at $T=56\pi$. At $\Delta=2^{20}$, an exact coefficient-rounding ledger keeps complete-domain channel error below $2^{-16}$, including a small readout window and arbitrary spectators. The resource audit proves that the full physical spectral width is at least $12\Delta$, even after optimizing the energy origin. Under a unit operator-norm budget, this design's declared deadline therefore exceeds one billion normalized time units. Its 54-qubit, 102-pair graph also remains nonplanar. Arrival certification is thus closed conditionally, while the sought geometric and resource advantage remains open. A planar four-active-qubit endpoint benchmark clarifies why the novelty target must retain the serial history task.
\end{abstract}
\begin{IEEEkeywords}
Hamiltonian quantum computation, perfect state transfer, two-local interactions, error bounds, spectral resources, finite quantum clocks.
\end{IEEEkeywords}

\section{Development task and source boundary}
The preceding MQM baseline \cite{baseline} compiles $\SW_{A,O_1}$ as three CNOT transitions using a direct entangled-clock encoding adapted from Nagaj \cite{nagaj}. It uses 52 physical clock qubits and two data qubits. The single-clock-excitation sector has clock dimension 52 and joint clock--data dimension 208. Within it, an isometry $\Omega$ embeds a 136-dimensional computational sector represented by a 34-vertex clock graph and a four-dimensional body. Both sectors are invariant; neither assertion says that clock and body remain uncorrelated.

The graph consists of a 27-edge backbone and six blind leaves attached at its ports. Each CNOT segment has nine backbone edges, an entry leaf, and an exit leaf. The launch is one clock excitation at the first port, with all remaining clock qubits zero. At the last port, the body map is SWAP, for arbitrary inputs including entangled spectators. This note asks whether physically two-local modifications can certify useful final-port arrival without concealing their costs.

Engineered spin-chain transfer is prior art \cite{christandl}; it is the reference mechanism here, not a novelty claim. The new instance supplies a physically admitted leaf penalty, edgewise algebraic certificate, finite error enclosure, and a full-spectrum resource obstruction. No minimum compiler, planar realization, fault-tolerance threshold, permanent latch, or repeated clock renewal is established.

\section{Admitted weighted two-local Hamiltonian}
Label the backbone edges $k=0,\ldots,26$ in execution order. Let $K_k$ be the 34-vertex adjacency matrix for backbone edge $k$, together with its tied leaf edge when $k$ is an entry or exit transition. A physical stage operator $H_k$ satisfies
\begin{equation}
 H_k\Omega=\Omega(K_k\otimes I_4).
\end{equation}
These identities are verified independently for all 27 stages over $\mathbb Q(\sqrt2)$. Therefore arbitrary real weights $w_k$ preserve exact encoded dynamics. This is stronger than spectral matching at one low-energy eigenvalue.

We fix the source-defined perfect-transfer profile
\begin{equation}
 w_k=\nu\sqrt{(k+1)(27-k)},\qquad \nu=\frac1{112}.
\label{weights}
\end{equation}
Its maximum backbone amplitude is $14\nu=1/8$, matching the baseline's encoded-edge ceiling. This equality does not equate the full physical operator norms.

At entry and exit on each rail, a clock station is encoded in two qubits $p,q$ with
\begin{equation}
 \ket A=(\ket{10}+\ket{01})/\sqrt2,\quad
 \ket B=(\ket{01}-\ket{10})/\sqrt2.
\end{equation}
Write $N_{pq}=(2I-Z_p-Z_q)/2$. It measures physical clock occupancy, with eigenvalues $0,1,2$. If control $a$ selects the upper rail for value 1 and lower rail for value 0, define one barrier
\begin{equation}
 R_b=N_uP_{a,0}+N_lP_{a,1},\qquad
 P_{a,z}=(I+(-1)^zZ_a)/2.
\label{barrier}
\end{equation}
There are six barriers, at entry and exit of the three gates, each involving two rail pairs. They penalize exactly the wrong-rail occupancy in the admitted computational sector. The expansion is
\begin{equation}
\begin{aligned}
 R_b={}&I-\tfrac14(Z_{u:p}+Z_{u:q}+Z_{l:p}+Z_{l:q})\\
 &-\tfrac14(Z_{u:p}+Z_{u:q})Z_a
 +\tfrac14(Z_{l:p}+Z_{l:q})Z_a.
\end{aligned}
\label{penalty}
\end{equation}
Every nonconstant term is one- or two-local. Each support is already present in the original entry/exit control terms. Let $R=\sum_bR_b$ and let $Q_L$ project onto the six graph leaves. Exact replay verifies
\begin{equation}
 R\Omega=\Omega(Q_L\otimes I_4).
\end{equation}
Consequently the uncentered physical generator
\begin{equation}
 H_{\rm full}=\sum_{k=0}^{26}w_kH_k+\Delta R
\end{equation}
simulates $\sum_kw_kK_k+\Delta Q_L$ exactly on the same computational sector. It also conserves physical clock excitation number. Its 204 merged Pauli supports and 102 interaction pairs are unchanged; 48 coefficients receive detuning offsets. No perturbative mediator ancillas are added.

\section{Finite arrival certificate}
Order the computational clock basis as backbone first, leaves second:
\begin{equation}
 H=\begin{pmatrix}A&B\\B^\dagger&\Delta I_6\end{pmatrix}.
\label{blocks}
\end{equation}
The backbone operator is $A=2\nu J_x$ in the spin-$27/2$ representation. Thus $a=\|A\|=27/112$, and
\begin{equation}
 e^{-iTA}\ket{v_0}=\phi\ket{v_f},\quad
 T=\frac\pi{2\nu}=56\pi,\quad \phi=(-i)^{27}.
\label{transfer}
\end{equation}
The squared leaf couplings at the four ports are
\begin{equation}
 \nu^2(27,351,351,27).
\end{equation}
Their supports are disjoint, so $\beta=\|B\|=\sqrt{351}/112$.

\begin{theorem}[Nonasymptotic backbone simulation]
Let $E=(I_{28},0)^\mathsf T$ embed the backbone. For every real $t$ and $\Delta>0$,
\begin{equation}
 \|e^{-itH}E-Ee^{-itA}\|
 \le\frac{2\beta+|t|\beta\sqrt{\beta^2+a^2}}{\Delta}.
\label{residualbound}
\end{equation}
\end{theorem}
\begin{proof}
Define $F=(I_{28},-B^\dagger/\Delta)^\mathsf T$, which need not be an isometry. Then $\|E-F\|=\beta/\Delta$ and
\begin{equation}
 HF-FA=\frac1\Delta\begin{pmatrix}-BB^\dagger\\B^\dagger A\end{pmatrix}.
\end{equation}
Its norm is at most $\beta\sqrt{\beta^2+a^2}/\Delta$. The integrated intertwining identity bounds $\|e^{-itH}F-Fe^{-itA}\|$ by $|t|$ times that residual. Adding the two $E-F$ terms proves~\eqref{residualbound} using only unitarity. No adiabatic-elimination limit is invoked.
\end{proof}

Since $\sqrt{351}<19$, $\sqrt{1080}<33$, and $T<176$, the exact rational arrival enclosure is
\begin{equation}
 \begin{aligned}
 \|e^{-iTH}E-Ee^{-iTA}\|
 &\le \frac{19/56+176(627/12544)}{\Delta}\\
 &=\frac{7163}{784\Delta}.
 \end{aligned}
\label{arrival}
\end{equation}
Composition with $\Omega$, the launch state, and spectator identity gives the same operator bound for the complete physical input-to-output isometry. Normalized diamond distance to the final-port SWAP channel is no greater than this bound. The comparison retains every clock qubit, both body qubits, and all spectator correlations; it is not a marginal output certificate.

At $\Delta=2^{20}$, the ideal arrival bound is
\begin{equation}
 \epsilon_{\rm arr}\le\frac{7163}{822083584}
 \approx8.71323\times10^{-6}<\frac1{65536}.
\end{equation}
The fixed Hamiltonian thus achieves a certified finite arrival without pulses during evolution. Launch preparation and a timed readout still belong to the operational contract. This is not permanent output absorption or a latch.

\section{Rounding and readout-window ledger}
After dropping the global scalar $6\Delta I$, each physical coefficient has form $a+b\sqrt n$ with rational $a,b$ and integer $n$. The replay encloses every radical using
\begin{equation}
 \ell_n=\frac{\lfloor\sqrt{n2^{180}}\rfloor}{2^{90}},\qquad
 u_n=\ell_n+2^{-90},\quad \ell_n^2\le n<u_n^2.
\end{equation}
For each stored binary64 coefficient $r_j$, its exact rational value is compared against the corresponding coefficient interval. Summing the absolute deviations gives a full-physical-operator error upper bound $d$, since Pauli strings have unit norm. Duhamel's identity contributes at most $|t|d$ on every joint domain. At the deadline,
\begin{equation}
 Td\le\frac{56403437446884833239}{541598767187353870268366848}
 \approx1.04143\times10^{-7}.
\end{equation}
The complete arrival-plus-rounding bound is
\begin{equation}
\begin{aligned}
 \delta(T)&\le
 \frac{33428331012123573389025}{3791191370311477091878567936}\\
 &\approx8.81737\times10^{-6}<2^{-16}.
\end{aligned}
\label{joint}
\end{equation}
This bounds coefficient representation, not physical calibration or decoherence. The physical coefficient ledger supplies the exact fraction for every individual debit.

For $|t-T|\le\tau=1/65536$, comparison with the ideal backbone at $T$ adds at most $a\tau$. Uniformly on that readout window,
\begin{equation}
 \delta(t)\le
 \frac{2\beta_u+(176+\tau)r_u}{\Delta}
 +(176+\tau)d+a\tau<2^{-16},
\label{window}
\end{equation}
where $\beta_u=19/112$ and $r_u=627/12544$. The exact window fraction is in the receipt. This is also an operator-distance bound with a fixed target phase, so every input's final-port probability is at least $1-\delta(t)^2$. Outside this window no such arrival claim is made.

For a launch debit $\epsilon_B$ and an independently bounded physical generator mismatch $d_{\rm phys}$, the same domain permits $\min\{1,\epsilon_B+\delta(t)+|t|d_{\rm phys}\}$. Nonunitary channels, reservoir dynamics, and spectator interactions require separately derived terms. Independent reset or noise assumptions are not inferred from sector invariance.

\section{Full-spectrum resource obstruction}
Large detuning cannot be hidden by citing only the backbone norm or maximum hopping weight. The physical clock vacuum and completely filled clock are both annihilated by every weighted stage: $XX+YY$ exchange vanishes, and each pair difference $Z_p-Z_q$ vanishes. On these states, $R$ has eigenvalues 0 and 12, respectively, for arbitrary body input.

\begin{theorem}[Energy-origin-independent cost]
The ideal full physical spectrum has diameter at least $12\Delta$. For every scalar energy shift $x$,
\begin{equation}
 \|H_{\rm full}-xI\|\ge6\Delta.
\label{normlower}
\end{equation}
Any uniform scaling $\eta(H_{\rm full}-xI)$ with full operator norm at most $C$ therefore has its declared reference-transfer deadline bounded below by
\begin{equation}
 T_\eta=\frac{56\pi}{\eta}\ge\frac{336\pi\Delta}{C}.
\label{timelower}
\end{equation}
\end{theorem}
\begin{proof}
The vacuum and filled-clock eigenspaces provide spectral points 0 and $12\Delta$. Their maximum distance from any origin is at least $6\Delta$. Uniform scaling multiplies all eigenvalues and divides every evolution time by $\eta$.
\end{proof}
This is a family-specific bound for this construction and declared deadline, not a speed limit for every clock design or every possible transfer time. The spectral width specifies a Hamiltonian energy scale; it is not a derived heat expenditure or battery consumption per operation. Under coefficient rounding the spectral endpoints shift by at most $d$, giving the robust norm lower bound $6\Delta-d$.

Each barrier~\eqref{barrier} is positive and no greater than $2I$, so $0\le R\le12I$. After the central shift, $\|\Delta(R-6I)\|=6\Delta$. The exact weighted-stage Pauli enclosure, including rounding, is less than 9. Hence the sufficient normalization
\begin{equation}
 \eta=\frac1{6\Delta+9}
\end{equation}
certifies $\|\eta(H_{\rm full}-6\Delta I)\|\le1$, including coefficient representation. The arrival and window errors remain unchanged under scaling, while the deadline and half-window become
\begin{equation}
 T_\eta=56\pi(6\Delta+9),\qquad
 \tau_\eta=(6\Delta+9)/65536.
\end{equation}
At $\Delta=2^{20}$, the declared deadline lies between 1056966120 and 1107297840 using $3<\pi<22/7$. For the ideal design, even an optimal energy shift and scaling cannot put it below $1008\Delta=1056964608$. These are normalized time units with $\hbar=1$, not seconds. The cost is structural, not an unmodeled decimal normalization.

\begin{figure}[t]
\centering\includegraphics[width=\columnwidth]{../figures/ENERGY_LATENCY.pdf}
\caption{Sufficient ideal arrival bound and norm-one deadline upper bound for the dyadic detuning family. The marked gap is $2^{20}$. The frontier is a certificate family, not an optimality result over all clocks.}\label{frontier}
\end{figure}

\section{Geometry and a typed competing benchmark}
Every physical support of the original direct graph remains nonzero under this construction. Detuning changes coefficients on existing $Z$ and $ZZ$ supports only. The same $K_{3,3}$ subdivision therefore remains. The physical inventory is unchanged: 54 qubits, 204 Pauli supports, 102 two-body pairs, and maximum degree 18. Reweighting and detuning alone do not produce a planar compiler. Nonplanarity does not prove that any two-dimensional device must use routing ancillas: extra connectivity layers, different interactions, or a changed encoding are distinct options with their own resource ledgers.

An endpoint-only comparator uses two physical clock qubits $c_0,c_3$ and the same two data qubits:
\begin{equation}
 H_{\rm end}=g\frac{X_{c_0}X_{c_3}+Y_{c_0}Y_{c_3}}2+g\SW_{A,O_1}.
\end{equation}
Its two commuting interactions have full norm $2g$. At $T_e=\pi/(2g)$, clock input $\ket{10}$ becomes $-i\ket{01}$ and the body becomes $-i\SW\ket\psi$, giving the required endpoint up to global phase. Thus four active physical qubits, two disjoint planar interaction pairs, and a norm-one deadline $\pi$ suffice for this \emph{endpoint task}. Unused clock qubits can be retained in a vacuum embedding when comparing full-domain output spaces; they are not active resources in the smaller architecture.

This comparator is not the original serial history dynamics: clock and SWAP evolve independently. It does not supply an embedded thirteen-step execute--capture--renew word. Its economy exposes the need to define the stronger operational benefit before claiming resource superiority for history control.

\section{Review corrections, replay and next gate}
The earlier $q=0.4739700233$ was a largest sampled value on $[0,1024]$, not an all-time cap or a proof that $\delta_{\rm task}\ge0.725$. A new late-time numerical diagnostic finds $q\approx0.746169$ at $t\approx2837365.1124$ for the unchanged uniform baseline. That diagnostic is not a certified interval, but the original finite-grid statement never supported the proposed universal bound. Likewise, the three-qubit weight-three obstruction prohibits exact unencoded generator equality; it does not uniquely require clock dilation. Different encodings or endpoint tasks remain possible.

The new replay passes EXACTCOUNT exact checks and NUMCOUNT numerical checks, in addition to replaying the preceding 24 exact and 16 numerical checks. All 27 stage identities, leaf penalties, physical supports, radical intervals, readout window, graph persistence and resource budgets are tested. Numerical values are diagnostics; exact arithmetic and the stated proofs supply the certificates. No experimental run is reported.

The next development gate is a \emph{penalty-free, geometrically specified} construction with an explicit useful arrival window and full-domain error ledger. It must beat or meaningfully differ from the endpoint comparator while retaining the desired serial episode semantics. A planar alternative and a perturbative compiler should be compared under the same stated norm or coupling budget; these budgets are not interchangeable. The present design closes a conditional arrival gap and supplies a resource obstruction, while leaving the breakthrough target open. Scaling the thirteen-step word and integrating an irreversible latch remain gated behind that comparison.

\begin{thebibliography}{3}
\bibitem{baseline} B. W. Mayes, ``An exact two-body SWAP compilation: Invariant dynamics and a nonplanar resource baseline,'' MQM development note v0.1, Oct. 5, 2026, unpublished. Replay source included with this release.
\bibitem{nagaj} D. Nagaj, ``Universal 2-local Hamiltonian quantum computing,'' \emph{Phys. Rev. A}, vol. 85, p. 032330, 2012, doi: 10.1103/PhysRevA.85.032330. arXiv:1002.0420v2.
\bibitem{christandl} M. Christandl, N. Datta, A. Ekert, and A. J. Landahl, ``Perfect state transfer in quantum spin networks,'' \emph{Phys. Rev. Lett.}, vol. 92, p. 187902, 2004, doi: 10.1103/PhysRevLett.92.187902. arXiv:quant-ph/0309131v2.
\end{thebibliography}
\end{document}
'''
tex=tex.replace('EXACTCOUNT',str(r['new_exact_check_count'])).replace('NUMCOUNT',str(r['new_numerical_check_count']))
name='MQM_WEIGHTED_ARRIVAL_IEEE_A4_v0.1'
(M/(name+'.tex')).write_text(tex)
for i in range(3):
 p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=M,capture_output=True,text=True)
 (R/'results'/f'LATEX_PASS_{i+1}.txt').write_text(p.stdout)
 if p.returncode:raise RuntimeError(p.stdout[-5000:])
log=(M/(name+'.log')).read_text();assert 'Overfull' not in log,'Fix overfull boxes'
doc=fitz.open(M/(name+'.pdf'));qa=[];Q=R/'results/visual_qa';Q.mkdir(exist_ok=True)
for i,page in enumerate(doc):
 assert abs(page.rect.width-595.276)<.6 and abs(page.rect.height-841.89)<.6
 page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(Q/f'page_{i+1}.png')
 qa.append({'page':i+1,'width_pt':page.rect.width,'height_pt':page.rect.height,'text_characters':len(page.get_text())})
assert '??' not in ''.join(p.get_text() for p in doc)
(R/'results/PDF_FORMAT_RECEIPT.json').write_text(json.dumps({'format':'IEEEtran journal, A4, 10pt, two columns','pages':qa,'overfull_boxes':False,'unresolved_references':False,'visual_review':'PENDING'},indent=2)+'\n')
print(json.dumps({'pdf':str(M/(name+'.pdf')),'page_count':len(doc),'exact_checks':r['new_exact_check_count'],'numerical_checks':r['new_numerical_check_count']},indent=2))
